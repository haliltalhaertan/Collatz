# CP18 TASK 1 — INDEPENDENT AUDIT

Date: 2026-08-23   Object: `CP18_TASK1_FINDINGS.md` (736 lines)
Auditor stance: zero-trust. Every numeric claim was recomputed from scratch with newly written code;
no verdict below rests on the report's own statements.

---

## 0. Verdict

**The report holds up. Every mathematical claim I could check is correct, and every number in it
reproduces — including the large enumerations.** The strategic verdict **C — MECHANISM FAILS** is
correct and properly supported.

| Node | Verdict | Basis |
|---|---|---|
| Frozen basis (CP17 archive SHA-256) | `[VALID]` | hash matches the actual file exactly |
| §1 sign algebra, block affine identity, q>0 ⇒ expansion | `[VALID]` | 3920 block checks, 0 failures |
| §2 weighted observable + Abel summation | `[VALID]` | identity re-derived by hand; the `[FAIL]` is correctly scoped |
| §3 word cylinder mod 2^{A+1} | `[VALID]` | 6434 words forward-validated, 0 failures |
| §4 counting identity `C(F_r−L_r−q, r)` | `[VALID]` | hockey-stick re-derived; exact, no floating point |
| §5 enumeration totals (97 families, 11,904,053 words) | `[VALID]` | both reproduced exactly |
| §5 selected table rows | `[VALID]` | all 9 rows reproduce: counts, R_min, words, A, modulus, endpoints, bins, max ρ, ties |
| §6 H1–H4 counterexamples | `[VALID]` | each specific counterexample reproduced |
| §6 H5–H6 nesting / non-independence | `[VALID]` | argument correct |
| §6 H7 + §11 stabilization theorem | `[VALID]` | 48,135 checks, 0 violations — but the "theorem" is two lines (see A3) |
| §7 direct scan | `[VALID]` | full 2^21 scan reproduced; one off-by-one, explained below |
| §10 long `a=1` block congruence | `[VALID]` | verified as an ⟺, 0 violations |
| §13 strategic verdict C | `[VALID]` | follows from the above |

**Nothing is wrong. Two housekeeping items and three framing observations follow.**

---

## 1. Frozen basis

The report's claimed archive hash

```
a6ecb47897cf316f955bb6c3056e17e7c2b11daaefe67a8fde753a309114c42a
```

**matches `CP17_FINAL_PACKAGE_V3.zip` byte for byte.** That is the same archive I audited on
2026-08-23 with verdict `PROOF VALID` and standalone completeness `[VALID]`, so §0's frozen-basis
statement is accurate and the "CP17 was not re-audited here" discipline is the right call.

## 2. What I reproduced

### Exact identities

* **Block affine identity** `2^{A_{u,v}} n_v = 3^r n_u + B_{u,v}` — 3920 (start, u, r) combinations
  over seven real orbits (7, 27, 31, 97, 703, 159487, 670617279): **0 failures**.
* **`q>0 ⇒ n_v > n_u`** — 0 violations. §1's verdict that large positive `s_k` is a *low-valuation /
  expansion* event, not a contraction event, is correct: `n_k = n_0 2^{−D_k} U_k` and `D_k = −s_k − {kα}`,
  so large `s_k` makes `n_k` large. The `[FALSE]` verdict on "CP17 records force contraction" is right.
* **§2 Abel summation** — I re-derived it independently. Both displayed forms are correct, including
  the `U_1`-centred version, and the consequence
  `X^{(σ)}_N/(3n_0) ≤ f_{N−1}(U_N − U_1)` giving only `U_N − U_1 ≳ (log N)/N^σ` is right.
  The pointwise step `k^σ 2^{D_k} ≥ 2^{−C−1}/k` under `s_k ≤ (1+σ)log_2 k + C` also checks out.
* **§3 cylinder** `n_0 ≡ 3^{−r}(2^A − B_w) (mod 2^{A+1})` — computed for all 6434 words with `r ≤ 8`,
  `A ≤ r+6`, then **forward-validated by real Syracuse simulation**: 0 failures, and every least
  representative is odd (as it must be, since `B_w` is odd).
* **§4** `F_r = bitlength(3^r) − 1` is exactly `⌊r log_2 3⌋` — good practice, no floating point
  anywhere. The count identity `|W(r,q)| = C(F_r − L_r − q, r)` is the hockey-stick sum
  `Σ_{A=r}^{M} C(A−1, r−1) = C(M, r)`; re-derived by direct summation, 0 failures.

### Enumeration totals

| Quantity | Report | Mine |
|---|---|---|
| feasible `(r,q)` families, `r ≤ 22` | 97 | **97** |
| distinct words with `e_r ≥ 0`, `r = 1..22` | 11,904,053 | **11,904,053** |

### The §5 table — every column, exhaustively

I re-enumerated the seven largest cited families from scratch (up to 5,852,925 words each) and the
small ones:

| (r,q) | count | R_min | minimizing word | ties | max ρ | endpoint |
|---|---|---|---|---|---|---|
| (11,0) | 364 ✓ | 111 ✓ | ✓ | 1 ✓ | 32463 ✓ | 2429 ✓ |
| (11,1) | 78 ✓ | 111 ✓ | ✓ | 1 ✓ | 16381 ✓ | 2429 ✓ |
| (20,0) | 888,030 ✓ | 91 ✓ | ✓ | 1 ✓ | 268,435,417 ✓ | 2429 ✓ |
| (20,1) | 230,230 ✓ | 1819 ✓ | ✓ | 1 ✓ | 134,217,699 ✓ | 189,175 ✓ |
| (20,7) | 1 ✓ | 2,097,151 ✓ | all-ones ✓ | 1 ✓ | ✓ | 6,973,568,801 ✓ |
| (21,0) | 4,292,145 ✓ | 103 ✓ | ✓ | 1 ✓ | 1,073,741,771 ✓ | 2051 ✓ |
| (21,8) | 1 ✓ | 4,194,303 ✓ | all-ones ✓ | 1 ✓ | ✓ | 20,920,706,405 ✓ |
| (22,0) | 5,852,925 ✓ | 103 ✓ | ✓ | 1 ✓ | 2,147,483,595 ✓ | 3077 ✓ |
| (22,8) | 1 ✓ | 8,388,607 ✓ | all-ones ✓ | 1 ✓ | ✓ | 62,762,119,217 ✓ |

Every minimizing word forward-validates to the stated endpoint through the stated valuation
sequence. The dyadic percentile bins also reproduce: `(11,0) → 11/13/14`, `(11,1) → 10/12/13`.
**"No minimizing tie occurred: tie count was 1 throughout" is confirmed for every family I ran.**

A pleasing internal cross-check that also holds: the `q = 7, 8` singleton families are the all-ones
words, and their `R_min` values 2^21−1, 2^22−1, 2^23−1 are exactly what §10's congruence
`n ≡ −1 (mod 2^{m+1})` predicts.

### H1–H4, H7, §10

* **H1** — `R_min(11,0) = R_min(11,1) = 111`, word `(1,1,1,2,1,2,1,1,1,1,1)`, `A=13`, modulus 16384.
  **Plateau reproduced.** The nondecreasing direction is correct and genuinely set-theoretic.
* **H2** — `R_min(5,0) = 63`, `R_min(6,0) = 27`. **Decrease across `r` reproduced.**
* **H3** — at `r=11`: `A=13` gives ρ=111 with word `(1,1,1,2,1,2,1,1,1,1,1)`; `A=14` gives ρ=223 with
  word `(1,1,1,1,3,2,1,1,1,1,1)`. **The lower-valuation word has the smaller realizer — reproduced.**
* **H4** — at `r=7, A=9` (28 words, modulus 1024): global minimum is `(1,2,1,1,1,1,2)` with ρ=27;
  `(1,2,1,1,2,1,1)` has ρ=91. **Both reproduced.** See A2 for a caveat.
* **H7 / stabilization** — `M_r > n_0 ⇒ ρ_r = n_0` checked over all odd `n_0 < 4000` and every prefix
  length to 40 or absorption: **48,135 checks, 0 violations**.
* **§10** — I verified the stronger **⟺** form: `a_k = … = a_{k+m−1} = 1` **iff** `n_k ≡ −1 (mod 2^{m+1})`,
  for `1 ≤ m ≤ 14` over four full periods each: **0 violations**. So the least possible block-start
  state really is `2^{m+1} − 1`.

### §7 — the full scan, rerun end to end

| Quantity | Report | Mine |
|---|---|---|
| starts scanned | 2,097,152 | **2,097,152** |
| odd-only transitions | 106,809,691 | **106,809,692** |
| starts reaching 1 within cap | 2,097,152 / 2,097,152 | **2,097,152 / 2,097,152** |
| largest record level | q = 11 | **q = 11** |

**All twelve rows of the smallest-start table reproduce exactly** — start, first `r`, `A_r`, `s_r`,
`e_r`, modulus and `n_r`, for `q = 0 … 11` (3, 27, 27, 871, 4255, 4591, 26623, 65307, 77671, 159487,
159487, 159487).

The transition count differs by **exactly 1**, and the cause is identifiable: the trivial start
`n_0 = 1`. My loop executes one step (1 → 4 → 1) before detecting absorption; theirs evidently tests
`n = 1` before stepping. Both conventions are defensible and nothing else in the scan depends on it.
I flag it only because a 1-in-10⁸ discrepancy with a traceable cause is positive evidence that the
number is a genuine computation rather than a plausible-looking figure.

---

## 3. Findings

### H1 — housekeeping: the enumeration artifact is not shipped

§5 says "The complete 97-row table is in `CP18_TASK1_EXACT_ENUM.csv`" and §9 says that CSV carries
the per-family count/min/p10/p50/p90/max statistics. **That file is not in `Downloads/`.** Only the
nine sampled rows are in the report, so the other 88 families and all the distributional data are
currently unreproducible from what was delivered. Everything I *could* check reproduced perfectly,
which makes it likely the CSV is fine — ship it.

### A1 — §13's verdict correctly mixes two different strengths of negative result, and says so

Worth affirming rather than criticising: the report keeps `[FALSE]`/`[PROVED]` (H5–H7, the
residue-cost branch — genuinely dead) distinct from `[FAIL]` (§2's weighted observable — *not found
to work in this task*, which is weaker). The mandatory question table preserves that distinction,
and §2 explicitly says "No normalization was found **in this task**". That is the honest framing and
should survive into CP18's next document.

### A2 — H4's "best balanced competitor" is unsupported as written

Two small issues, neither changing the verdict:

1. H4 silently changes the family definition. H1/H2 range over `W(r,q)` (total valuation `≤` a
   bound); H4 uses the fixed-`A` family `r=7, A=9`. Each test is internally well-posed, but the
   report should say which family it is enumerating.
2. The report calls `(1,2,1,1,2,1,1)`, ρ=91, "the best standard cyclic-balanced competitor" without
   listing the balanced words considered. In my full enumeration of that family the sorted head is

   ```
   ρ=27   (1,2,1,1,1,1,2)      <- the claimed global minimum
   ρ=31   (1,1,1,1,2,2,1)
   ρ=91   (1,2,1,1,2,1,1)      <- the claimed balanced competitor
   ρ=103  (1,1,2,1,1,1,2)
   ```

   The second-smallest word sits between them. It is not balanced either, so the claim may well be
   right — but as written it is an assertion, and H4 is already flagged `[INCONCLUSIVE]` for the
   unformalised "Christoffel-type" reading, so nothing rests on it.

### A3 — the "Actual-prefix stabilization theorem" is trivial, and that makes it *stronger*

§11 presents it as "New theorem proved in this task" and a "theorem-level obstruction". The
mathematical content is two lines: if `n_0 ≡ ρ_r (mod M_r)` with `1 ≤ ρ_r < M_r` and `M_r > n_0`,
then `n_0` is already the unique representative in `[1, M_r)`, so `ρ_r = n_0`. That is immediate.

The *strategic* content is what matters, and the report says so plainly ("it is a **negative theorem**
for the proposed CP18 mechanism"). But one quantitative point is missing and would sharpen §8:
since `A_r ≥ r`, stabilization occurs once `r ≳ log_2 n_0` — i.e. **almost immediately**, not merely
"eventually". For the report's own example `n_0 = 159487` (`log_2 ≈ 17.3`) the realizer has been
pinned at `n_0` since about `r = 17`, while the cited records occur at `r = 28, 30, 31`. The
mechanism was not dying slowly; it was dead long before any record appeared. State that and the
negative conclusion gets stronger, not weaker.

### A4 — a warning for the recommended next task

The surviving lead is the right object, but §11 states it in two inequivalent ways and only one of
them survives its own theorem:

* "study the **residue restriction on the current state `n_u`**" — this phrasing dies to exactly the
  same argument. For a fixed orbit, `n_u` is a specific integer; once the block's modulus exceeds
  `n_u`, the least representative of its cylinder is `n_u` itself. Stabilization applies verbatim
  with `n_0` replaced by `n_u`.
* "test whether the **minimum feasible `n_u`** … admits a uniform lower bound in the record
  increment/length" — this survives, because it is a *lower bound on the state* quantified over all
  admissible blocks, not a least-representative statistic of one fixed orbit. That is precisely the
  shape of §10's `n_k ≥ 2^{m+1} − 1`, which is the one thing in Task 1 that did survive.

Freeze the second formulation explicitly, or Task 2 will rediscover the stabilization theorem.

---

## 4. Scope discipline

Clean. §0 disclaims Collatz, divergent orbits and nontrivial cycles. §7 labels its scan
`[CERTIFIED NUM]` "finite evidence, not a theorem about all starts". §9 explicitly refuses to read
the finite ensemble statistics as orbit probabilities. §6 H4 marks the unformalised claim
`[INCONCLUSIVE]` rather than falsifying a strawman. §11 marks the surviving direction `[LEAD]`, not
a theorem. This is the same discipline as the CP17 publication branch and it should be kept.

## 5. Final answer

**Is any claim in `CP18_TASK1_FINDINGS.md` wrong?** No. Every exact identity, every counting
identity, every enumeration total, every table row and every counterexample reproduces
independently. The single numerical discrepancy is one transition in 10⁸, caused by a boundary
convention at the trivial start `n_0 = 1`.

**Is the strategic verdict justified?** Yes. `C — MECHANISM FAILS` is correct: exact prefix cylinders
are nested rather than independent, their least representatives plateau and decrease across finite
families, and along any fixed orbit the least representative collapses to `n_0` almost immediately.
The global-start least-realizer branch is genuinely dead and should not be revisited.

**Actions:** ship `CP18_TASK1_EXACT_ENUM.csv`; add the `r ≳ log_2 n_0` sharpening to §8/§11; name the
family in H4 and either support or drop the "best balanced competitor" claim; and freeze the next
task as *minimum feasible `n_u`*, never as *least representative of `n_u`'s cylinder*.