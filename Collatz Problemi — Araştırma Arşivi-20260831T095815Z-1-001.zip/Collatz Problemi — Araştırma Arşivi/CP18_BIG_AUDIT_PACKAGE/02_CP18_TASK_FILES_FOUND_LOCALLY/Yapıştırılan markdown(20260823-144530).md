# CP18 TASK 3 — INDEPENDENT AUDIT

Date: 2026-08-23   Object: `CP18_TASK3_FINDINGS.md` (413 lines)
Stance: zero-trust. Everything recomputed from scratch.
Prior: `CP18_TASK1_AUDIT_2026-08-23.md`, `CP18_TASK2_AUDIT_2026-08-23.md`

---

## 0. Verdict

**The report is correct, and its central claim is a genuine theorem that I re-derived and verified
independently.** The strategic verdict **`A — [FAIL: NO EXPONENTIAL SAVING]`** is justified. Close
the first-passage counting branch.

This is the strongest of the three CP18 documents: like Task 1 it closes on a theorem (an infinite
exact family), not on finite sampling as Task 2 did.

| Node | Verdict | Basis |
|---|---|---|
| §1 exact first-passage formulation | `[VALID]` | identity re-derived; endpoint count `C(A−1,r−1)` confirmed |
| §2 `O(r²)` DP | `[VALID]` | DP vs independent brute force, 101 cases, **0 mismatches** |
| §3 finite diagnostic table | `[VALID]` | **all 13 `R_max` cells match to 9 significant digits**; maximizing `u` confirmed |
| §4.1 Christoffel phase realization | `[VALID]` | all three witnesses verified by exact integer `bitlength` arithmetic |
| §4.2 cycle-minimum lemma | `[VALID]` | proof re-derived line by line; verified for **every** coprime `(p,r)`, `r ≤ 12` |
| §4.3 exact witnesses | `[VALID]` | `r=12 → 1/12` and `r=53 → 1/53` exactly by DP |
| §5 admissible-length density `β = log₂(3/2)` | `[VALID]` | iff-characterisation cross-checked vs DP; all five counts exact |
| §7 redundancy vs CP9–CP17 | `[VALID]` | consistent with CP17's `O(log t)` bookkeeping |
| §8 real-orbit scan | `[VALID]` | **all four numbers reproduce exactly** — but see F3 |
| §9/§10 verdict tables | `[VALID]` | follow from the above |

---

## 1. The core theorem — re-derived, not just re-run

The load-bearing claim is §4: an infinite exact family with `N_FP/N_END = 1/r`. I reconstructed the
whole argument.

**Cycle lemma (§4.2).** For an endpoint composition of `p` into `r` positive parts put
`X_j = rS_j − pj`. Then `X_j ≡ −pj (mod r)`, and since `gcd(p,r)=1` the map `j ↦ −pj` is a bijection
on `ℤ/r`, so `X_0,…,X_{r−1}` are pairwise distinct mod `r`, hence distinct integers with a unique
minimum. Rotating to start just after that minimum gives `X'_j = X_{(m+j) mod r} − X_m > 0` for
`1 ≤ j < r` — I checked both index ranges (`m+j ≤ r` and the wrap-around) explicitly. Since
`gcd(p,r)=1` forces `pj/r ∉ ℤ`, `X'_j > 0 ⟺ S'_j ≥ ⌈pj/r⌉`. Aperiodicity: a period `d | r` would make
`r/d` divide both `p` and `r`. So each cyclic orbit has exactly `r` members and exactly one
first-passage representative, giving `N_FP = N_END/r`. **Correct.**

Verified computationally for **every** coprime `(p,r)` with `r ≤ 12`, `r < p < 3r`: **0 violations**
of `N_FP = N_END/r`.

**Phase realization (§4.1).** The report asserts a nonempty phase interval without displaying it.
Working it out: with `ε = α − p/r` and `θ = {uα}`, the requirement `⌊jα+θ⌋ = ⌈pj/r⌉` for `1 ≤ j < r`
together with `⌊rα+θ⌋ = p+1` holds exactly for

```
θ ∈ [1 − rε, 1) ,     window length = rε > 0.
```

(The upper constraints are automatic because `δ_j ≥ 1/r > jε`.) The window is nonempty, equidistribution
of `{uα}` hits it infinitely often, and the density-zero set of `u` near a power of two can be avoided,
so `L_{u+j} = L_u` throughout. **Correct.**

**The three witnesses are real.** Using exact `bitlength(3^k)` arithmetic — no floating logarithm:

| r | p | u | `C_u(j) = ⌈pj/r⌉` for all `j<r` **and** `C_u(r) = p+1` | `L` constant | `A = p` | ratio |
|---|---|---|---|---|---|---|
| 12 | 19 | 1,065 | ✔ | ✔ | ✔ | `N_END=31824`, `N_FP=2652` → **exactly 1/12** |
| 53 | 84 | 1,277 | ✔ | ✔ | ✔ | `N_END=59488706401523551644624`, `N_FP=1122428422670255691408` → **exactly 1/53** |
| 665 | 1,054 | 1,063,222 | ✔ (all 664 interior equalities) | ✔ | ✔ | 1/665 by the lemma |

And `19/12`, `84/53`, `1054/665` are all genuine **lower** convergents of `log₂3` — verified exactly
by `2^p < 3^r`, with `|α − p/r| < 1/r²` — while `65/41` and `485/306` are upper convergents and are
correctly not used. The alternation the report relies on is confirmed: lower convergent denominators
are `2, 12, 53, 665, 31867, 111202, …`

**Conclusion.** `R = 1/r` for infinitely many `r`, so no fixed `η > 0` can satisfy
`N_FP ≤ 2^{−ηr} N_END` uniformly. Correct.

## 2. Everything else reproduced

* **§2 DP.** My independent DP agrees with brute-force composition enumeration on 101 `(u,r)` cases,
  **0 mismatches**. (The report claims 79 cases; mine is a different set and also clean.)
* **§3 table.** All thirteen `R_max` cells reproduce to nine significant digits, and for every
  `r ≤ 100` the cited maximizing `u` really is the maximum over `u = 1…100`:

  | r | reported `R_max` | mine | max at u |
  |---|---|---|---|
  | 10 | 0.42377622 | 0.423776224 | 14 ✔ |
  | 20 | 0.24643509 | 0.246435087 | 1 ✔ |
  | 30 | 0.24322309 | 0.243223086 | 1 ✔ |
  | 40 | 0.10592422 | 0.105924221 | 3 ✔ |
  | 50 | 0.10062009 | 0.100620088 | 3 ✔ |
  | 75 | 0.085925436 | 0.085925436 | 2 ✔ |
  | 100 | 0.092174332 | 0.092174332 | 1 ✔ |
  | 150 – 1000 | all | all match | — |

  The `I_min` column is internally consistent with `−(1/r)log₂R_max` in every row.
* **§5.** The identity `B_u(j) = ⌊(u+j)β⌋ − ⌊uβ⌋ − (L_{u+j}−L_u)` follows from
  `⌊kα⌋ = k + ⌊kβ⌋`; I re-derived the feasibility characterisation (`Y_j` nondecreasing,
  `Y_r = B_u(r)−1`, so feasibility ⟺ `B_u(r) > max_{j<r} B_u(j)`, with `Y_j = max_{i≤j}B_u(i)` as the
  witness) and **cross-checked it against the DP for `u < 30`, `r < 40`: 0 mismatches**. All five
  density counts are exact: 2329, 2333, 2334, 2335, 2334 → densities 0.5823–0.5838, converging to
  `β = 0.5849625`. The record-counting argument (increments `≤ 1` ⟹ #records = running max;
  `B_u(R) = βR − O(log R)`) is correct.
* **§8.** All four numbers reproduce **exactly**: 524,288 starts; 24,195,557 odd-only transitions;
  79,742 consecutive record blocks; 0 first-passage violations.

---

## 3. Findings

### F1 — the counterexample window is thin, and the report never says how thin

§4.1 establishes only that the phase interval is *nonempty*. Its exact length is `rε`, and that
number matters for reading the result. At the usable lower convergents:

| r | p | `ε = α − p/r` | window `rε` | 1 good `u` in … |
|---|---|---|---|---|
| 2 | 3 | 8.50e−02 | 1.70e−01 | 6 |
| 12 | 19 | 1.63e−03 | 1.96e−02 | 51 |
| 53 | 84 | 5.68e−05 | 3.01e−03 | 332 |
| 665 | 1054 | 9.47e−08 | 6.30e−05 | **15,878** |
| 31867 | 50508 | 3.29e−10 | 1.05e−05 | 95,410 |
| 111202 | 176251 | 4.67e−11 | 5.19e−06 | 192,529 |

So at `r = 665` roughly **one record time in 15,878** lands in the window. **What §4 refutes is
uniformity in `u`, not typical behaviour** — and the report's own §3 table shows the sampled
`R_max` is 5–10× larger than `1/r` at every `r`, i.e. ordinary phases are *worse* for the mechanism
than the Christoffel phases, not better. Nothing is wrong; the scope of the refutation should just
be stated.

### F2 — the refutation extends to the *averaged* version too (worth adding)

The obvious next objection is "fine, but maybe the saving is exponential for typical `u`, and that is
what CP17 would use." It is not, and the same construction settles it. From the table above,
`1/(rε) ≈ C·r` with `C` between ≈1.7 and ≈24 across the computed range. Hence the good-phase set has
density `≳ 1/(Cr)`, and the **average** ratio over `u` at `r = q_k` is

```
avg_u R(u,r)  ≳  (1/(Cr)) · (1/r)  =  1/(C r²)  =  exp(−O(log r)),
```

still subexponential. So no averaged variant of the mechanism produces a positive rate either.

**Caveat, stated honestly:** this step needs `q_{k+1} = poly(q_k)`, i.e. a finite irrationality
measure for `log₂3`. Finite effective measures are known in the literature; I did not verify a
specific constant here, and the empirical `C ≤ 24` above is evidence, not proof. Flag it as
conditional if it goes into the frozen record.

### F3 — §8 is an implementation check, not a mathematical one

The first-passage inequalities `S_j ≥ C_u(j)` **are** the definition of "`v` is the next record time
after `u`" (via the §1 identity). So "0 blocks violating the first-passage family" over 79,742 real
blocks is necessarily zero for any correct implementation. It is a useful regression test of the
code — and it passed on my independent implementation too — but it is not evidence about the theory.
The report's following paragraph hedges correctly about realization; the `[VALID]` label on §8 should
say "implementation check".

### F4 — §3's `I_max = ∞` column is a category error

`R_min(r) = 0` in the sampled set does not mean "infinite entropy saving". It means that for that `u`,
`r` simply is not an admissible record gap — and §5 proves those zeros are a *density* phenomenon
(admissible lengths have density `β ≈ 0.585 < 1`, so ~41% of lengths are infeasible for any given `u`).
Reporting `I_max = ∞` conflates infeasibility with saving. Drop the column, or relabel it
"infeasible `u` present". The `I_min` column, which the report already marks diagnostic-only, is fine.

### F5 — no other issues

Arithmetic is integer-exact throughout (`F_k = bitlength(3^k)−1`); no external artifact is referenced;
`H5` is honestly marked `[OPEN]`; §7's redundancy argument ("multiplying a CP17 count by `1/r` moves
its logarithm by `−log r = o(r)`") is correct and matches CP17's Lemma 9.1, which absorbs exactly
this class of `O(log t)` factors. Like Task 2, there is no scope disclaimer paragraph; the risk is
nil for a negative result but the chain has otherwise been consistent about it.

---

## 4. Final answer

**Is anything in `CP18_TASK3_FINDINGS.md` wrong?** No. The DP, all thirteen diagnostic cells, all
three Christoffel witnesses, the cycle lemma, the density theorem and all four scan statistics
reproduce exactly, and the two structural proofs (cycle lemma, feasibility characterisation) are
correct as written.

**Is the strategic verdict justified?** Yes. There is an infinite exact subsequence with
`N_FP/N_END = 1/r`, so the normalized saving `log₂(r)/r → 0`; admissible record-gap lengths have
positive density `log₂(3/2)`; and even the averaged variant stays subexponential (F2). First-passage
counting supplies **no new exponential obstruction** and cannot improve the CP17 rate machinery.
**Close the branch.**

**Actions:** add the window length `rε` and the thinness table to §4.1 so the scope of the refutation
is explicit; add F2 so the averaged variant is closed too; relabel §8 as an implementation check;
drop or relabel the `I_max` column.

**Status of the CP18 exploration after three tasks:** the residue-cost / least-realizer branch is
closed (Tasks 1–2) and the first-passage counting branch is closed (Task 3). Task 1's `§10`
observation — `a_k = … = a_{k+m−1} = 1` **iff** `n_k ≡ −1 (mod 2^{m+1})`, hence
`n_k ≥ 2^{m+1} − 1` — remains the only lead from this phase that was never refuted.