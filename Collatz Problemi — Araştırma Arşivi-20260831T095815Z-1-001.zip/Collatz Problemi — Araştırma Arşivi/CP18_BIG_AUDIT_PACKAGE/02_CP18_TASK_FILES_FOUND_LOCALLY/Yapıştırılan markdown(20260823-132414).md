# CP18 TASK 2 — INDEPENDENT AUDIT

Date: 2026-08-23   Object: `CP18_TASK2_FINDINGS.md` (401 lines)
Stance: zero-trust. Everything recomputed from scratch; no verdict rests on the report's own numbers.
Prior: `CP18_TASK1_AUDIT_2026-08-23.md`

---

## 0. Verdict

**The report holds up. Every claim verifies, and an extension I ran makes the negative conclusion
stronger than the report itself establishes.** The strategic verdict
**`[FAIL][FROZEN]` — close the residue-cost / least-realizer branch** is correct and I endorse it.

| Node | Verdict | Basis |
|---|---|---|
| §1 exact record coordinate, `E_{u+j}−E_u = C_u(j)−S_j` | `[VALID]` | 2888 checks on real orbits, 0 failures |
| §1 "record height `h` cancels" | `[VALID]` | only differences appear; algebra re-derived |
| §2 `Δ = 1` forced, `a_{v−1}=1`, `C_u(r)−C_u(r−1)=2` | `[VALID]` | step-range facts verified to k<10⁵; empirical max increment over 200k orbits = 1 |
| §3 cylinder + `ρ₆` unit-mod-3 correction | `[VALID]` | `Q=2^{A+1}` is a unit mod 3 for every A |
| §4 enumeration table (all 8 rows, 7 columns) | `[VALID]` | **every entry reproduced exactly** |
| §4 feasible-`r` list `{5,6,10,11,13,17,18,20}` | `[VALID]` | reproduced; `r=8` correctly excluded (reason below) |
| §5 counterexample `M(1,5)=127 > M(1,6)=103` | `[VALID]` | reproduced, both minimizing words match |
| §5/§7 four orbit realizations | `[VALID]` | all four reproduce exactly |
| §6 counting saving without state saving | `[VALID]` | `1820→680` with `31→31`; `657800→162105` with `91→91` |
| §8 wraparound | `[VALID]` as an argument, **not a theorem** — see F2 |
| Strategic verdict `[FAIL][FROZEN]` | `[VALID]`, and **strengthened** by F1 | |

---

## 1. What reproduced

### Exact algebra

* **§1 identity.** `E_{u+j} − E_u = C_u(j) − S_j` with `C_u(j) = (F_{u+j}−F_u) − (L_{u+j}−L_u)`:
  2888 `(orbit, u, j)` checks over eight real orbits, **0 failures**. The cancellation of the record
  height `h` is immediate from the fact that only differences enter — correct, and it is the right
  observation to make.
* **§2 `Δ = 1`.** `F_{k+1}−F_k ∈ {1,2}` and `L_{k+1}−L_k ∈ {0,1}` verified for all `k < 10⁵`
  (0 violations), so `E_{k+1}−E_k ≤ 2−1−0 = 1`. The chain `E_v = E_u+1`, `E_{v−1} = E_u`,
  `S_{r−1} = C_u(r−1)`, `a_{v−1} = 1`, `C_u(r)−C_u(r−1) = 2` all follow, and I re-derived each by hand.
  Empirically: over every odd `n₀ < 4·10⁵`, the **maximum observed record increment is exactly 1**.
* **§3 `ρ₆`.** `Q = 2^{A+1}` is a unit mod 3 for every `A` (0 violations), so exactly one of
  `ρ, ρ+Q` is a unit mod 3 and the stated two-case formula gives the least state-feasible
  representative. The `u ≥ 1` justification is right: `2^{a}n_u = 3n_{u−1}+1 ≡ 1 (mod 3)`, so
  `gcd(n_u, 3) = 1`.

### The §4 table — every cell

I re-enumerated from scratch (largest family 657,800 words):

| r | A | modulus | endpoint words | fp words | endpoint M | fp M |
|---|---|---|---|---|---|---|
| 5 | 5 | 64 ✓ | 1 ✓ | 1 ✓ | 127 ✓ | 127 ✓ |
| 6 | 7 | 256 ✓ | 6 ✓ | 5 ✓ | 103 ✓ | 103 ✓ |
| 10 | 12 | 8,192 ✓ | 55 ✓ | 20 ✓ | 167 ✓ | 167 ✓ |
| 11 | 14 | 32,768 ✓ | 286 ✓ | 135 ✓ | 223 ✓ | 223 ✓ |
| 13 | 17 | 262,144 ✓ | 1,820 ✓ | 680 ✓ | 31 ✓ | 31 ✓ |
| 17 | 22 | 8,388,608 ✓ | 20,349 ✓ | 3,741 ✓ | 703 ✓ | 17,897 ✓ |
| 18 | 24 | 33,554,432 ✓ | 100,947 ✓ | 28,662 ✓ | 103 ✓ | 4,985 ✓ |
| 20 | 27 | 268,435,456 ✓ | 657,800 ✓ | 162,105 ✓ | 91 ✓ | 91 ✓ |

Endpoint counts also match the closed form `C(A−1, r−1)` in every row. The minimizing words match
§5 and §7 exactly, including the `r=13` word `(1,1,1,1,2,2,1,2,1,1,2,1,1)` — which I confirmed
independently by forward-simulating `n = 31` for 13 steps and recovering precisely that word.

**Two pleasing cross-checks with Task 1**, which used a different enumerator on a different family
definition: the `r=20` minimizer here is byte-for-byte Task 1's `R_min(20,0)` minimizer
`(1,2,1,1,2,1,1,1,2,3,1,1,2,1,2,1,1,1,1,1)`, and the `r=11` minimizer `(1,1,1,1,3,2,1,1,1,1,1)` is
Task 1's H3 `A=14` word. The two tasks are computing the same underlying objects.

**`r=8` is correctly absent.** It passes the necessary condition `C₁(8)−C₁(7)=2` and has 8 endpoint
words, so its omission looks like a gap — it is not. `C₁(6)=C₁(7)=8`, so the interior constraint
forces `S₆ ≥ 8` while `S₇ = C₁(7) = 8` with `a₈ ≥ 1` forces `S₆ ≤ 7`. No word survives. Worth one
sentence in the report, since a reader checking the necessary condition alone will expect `r=8`.

### The four orbit realizations

All four reproduce exactly, including `E₁ = −1`, every interior `E_k ≤ E₁`, and `E_v = 0`:

| n₀ | n₁ | next record v | r |
|---|---|---|---|
| 169 | 127 ✓ | 6 ✓ | 5 |
| 137 | 103 ✓ | 7 ✓ | 6 |
| 41 | 31 ✓ | 14 ✓ | 13 |
| 121 | 91 ✓ | 21 ✓ | 20 |

---

## 2. Findings

### F1 — the enumeration is `u = 1` only; I extended it, and the conclusion gets *stronger*

Every table in §4–§8 is computed at the single record time `u = 1`. The report never says why one
`u` suffices, and there is a structural reason to worry: `C_u(j)` carries an `L`-correction
`−(L_{u+j} − L_u)`, which at `u = 1` equals `−⌊log₂(j+1)⌋` and grows to `−4` by `j = 20`, whereas
for typical `u` it is `0` or `1`. Concretely:

```
C_1(1..13)    = [1, 2, 3, 4, 6, 8,  8, 10, 11, 13, 15, 16, 18]
C_17(1..13)   = [2, 4, 5, 7, 8, 10, 12, 13, 15, 16, 18, 19, 21]
C_1000(1..13) = [2, 4, 5, 7, 8, 10, 12, 13, 15, 16, 18, 19, 21]
```

So the interior constraints `S_j ≥ C_u(j)` are markedly **weaker** at `u = 1` than at typical `u`.
A counterexample found only at the most permissive `u` would be weak evidence.

I therefore recomputed `M_fp(u, r)` for `u = 1 … 40` at each feasible `r`:

| r | M(1,r) (report) | **min over u** | max over u | feasible u |
|---|---|---|---|---|
| 5 | 127 | **41** | 127 | 21 |
| 6 | 103 | **55** | 509 | 20 |
| 10 | 167 | **71** | 593 | 22 |
| 11 | 223 | **41** | 1,211 | 21 |
| 13 | 31 | **31** | 4,997 | 22 |
| 17 | 17,897 | **73** | 17,897 | 23 |
| 18 | 4,985 | **97** | 4,985 | 22 |
| 20 | 91 | **91** | 8,861 | 23 |

**`min_u M(u,r)` = 41, 55, 71, 41, 31, 73, 97, 91 — flat, bounded, with no growth in `r` at all.**
The falsification is therefore not a `u = 1` artifact; it holds at every `u` I tested, and the true
minimum is usually *smaller* than the report's `u = 1` value. **The branch closure is better
supported than the report claims.**

One correction of emphasis follows from the same table. §5 presents

> `M(1,17) = 17897, M(1,18) = 4985, M(1,20) = 91` — "a much stronger finite collapse"

as the dramatic evidence. It is not a collapse. At `r = 17` and `r = 18`, `u = 1` happens to be the
**maximum** over `u` (17,897 and 4,985); other record times give 73 and 97. The min-over-`u`
sequence through those same `r` is `73, 97, 91` — essentially flat. The conclusion ("no growth") is
right; the specific rhetorical example oversells itself and should be replaced by the min-over-`u`
row, which is both more honest and more damning.

### F2 — Task 2 closes on finite evidence; Task 1 closed on a theorem. Record the difference.

Task 1's closure rested on an actual (if two-line) theorem: `M_r = 2^{A_r+1} > n₀ ⟹ ρ_r = n₀`, valid
for every start and every orbit. Task 2 has **no analogous theorem**. §8 asserts

> "This is exactly the same type of ordinary-integer wraparound obstruction that killed the global-start
> branch, now appearing in the state-local first-passage formulation."

That is an argument by analogy plus finite counterexamples at `r ≤ 20` (mine: `u ≤ 40` too). It is
persuasive — a modulus of `2^28` coexisting with a minimum feasible state of 91 is exactly the
phenomenon — but nothing here proves `min_u M(u,r) ↛ ∞`. The branch is being closed on a judgment
call backed by strong finite evidence, not on a proof, and the frozen record should say so. Do not
let a later reader remember this as "we proved wraparound kills it".

### F3 — no scope disclaimer

Task 1 opened with an explicit paragraph disclaiming Collatz, divergent orbits and nontrivial
cycles. Task 2 has none. The risk is nil here — the verdict is negative and nothing is claimed — but
the CP17/CP18 chain has been disciplined about this and the habit is worth keeping in the frozen
document.

### F4 — nothing else

No missing artifact this time: unlike Task 1, every number cited is either in the document or
directly recomputable from it. No external CSV is referenced. Arithmetic is integer-exact
throughout (`F_k` via `bitlength(3^k)−1`, no floating logarithms) — the same good practice as Task 1.

---

## 3. What is worth keeping from Task 2

Two structural facts that are new, exact, and cheap to re-derive but easy to forget:

1. **`Δ ≡ 1`.** Consecutive records of `E_k = F_k − A_k − L_k` always increase by exactly one, and the
   record step is fully rigid: `a_{v−1} = 1`, `F_v − F_{v−1} = 2`, `L_v − L_{v−1} = 0`,
   `E_{v−1} = E_u`. There is no "large record increment" regime to exploit — anywhere.
2. **The record height cancels.** `E_{u+j} − E_u = C_u(j) − S_j` depends on `u` only through the
   deterministic boundary `C_u(·)`, never through `h`. A block to the next record is no harder at
   record height 50 than at record height 5. Any future mechanism that expects "higher records cost
   more locally" is dead on arrival.

## 4. Final answer

**Is anything in `CP18_TASK2_FINDINGS.md` wrong?** No. Every exact identity, every table cell, every
minimizing word, every orbit realization and every verdict reproduces independently.

**Is the strategic verdict justified?** Yes, and more so than the document argues. `min_u M(u,r)`
stays in the range 31–97 across all feasible `r ≤ 20` and all `u ≤ 40` — the minimum feasible current
state simply does not grow, at any record time. Combined with Task 1's stabilization theorem, the
residue-cost / least-realizer branch is dead in both its global and its state-local form.
**Close it.**

**Actions:** replace §5's "17897 → 4985 → 91" with the min-over-`u` row; add the one-sentence reason
`r = 8` is infeasible; state in §4 that the enumeration is `u = 1` and either cite a `u`-extension or
flag it as a limitation; and mark §8 explicitly as finite evidence rather than a theorem, so the
asymmetry with Task 1 survives into the frozen record.