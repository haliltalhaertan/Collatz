# COLLATZ CP18 — TASK 10 FINDINGS
## Nested compatibility / compactness barrier

**Final strategic verdict**
\[
\boxed{\textbf{A — [FAIL: ABSTRACT NESTED BRANCHES SURVIVE]}}
\]

Task 10 does not produce Side B. It does formalize the LEVEL-2/LEVEL-3 gap exactly.

The decisive result is that Task-5 occupation has explicit infinite nested valuation branches. Every finite prefix of those branches has positive ordinary realizers. 2-adic compactness therefore succeeds—but it produces a point of \(\mathbb Z_2\), not necessarily a positive ordinary integer.

---

## 1. Exact three-level separation

### LEVEL 1
An abstract infinite positive valuation sequence exists.

### LEVEL 2
Every finite prefix is realized by some positive odd integer.

### LEVEL 3
One fixed positive odd integer realizes the entire infinite sequence.

For every finite word,
\[
\boxed{
n\equiv\rho(w)\pmod{2^{A_R+1}}
}
\]
is the exact valuation cylinder, and it contains infinitely many positive integers.

Nested infinite words determine one unique inverse-limit point
\[
x\in\mathbb Z_2.
\]

But:
\[
\boxed{
x\in\mathbb N_{>0}
\iff
\rho_R\text{ is eventually constant}.
}
\]

This is the exact quantifier/topology barrier.

---

## 2. Explicit full Task-5 nested branch: all ones

Take
\[
a_k=1\quad\forall k.
\]

Then
\[
E_R=F_R-R-L_R
=
(\log_2 3-1)R-O(\log R)\to+\infty.
\]

Hence for every fixed \(B\),
\[
\boxed{
W_B(R)/Z_R\to0.
}
\]

Every finite prefix is positive-realizable:
\[
\boxed{
\rho_R=2^{R+1}-1.
}
\]

But
\[
\boxed{
\rho_R\to-1\text{ in }\mathbb Z_2.
}
\]

Therefore Task-5 occupation itself has a fully nested abstract branch whose every finite prefix has positive witnesses while positive LEVEL 3 fails.

This already kills any valuation-word compactness obstruction.

---

## 3. Second exact model: alternating branch

For
\[
(1,2)^\infty,
\]
\[
E_R=(\log_2 3-3/2)R+O(\log R)\to+\infty.
\]

At even depths,
\[
\boxed{
\rho_{2m}=2^{3m+1}-5
}
\]
and
\[
\boxed{
\rho_{2m}\to-5\quad\text{in }\mathbb Z_2.
}
\]

Again:

- infinite abstract Task-5 branch: yes;
- every finite prefix positive-realizable: yes;
- one positive integer realizing the whole branch: no.

This is the canonical compactness counterexample requested by Task 10.

---

## 4. Near-critical control branch also survives abstractly

Task 9 gives a sparse-defect infinite branch with
\[
s_k=\log_2 k+\log_2\log k+O(1),
\]
so
\[
E_k=\log_2\log k+O(1).
\]

Thus it satisfies:

- every fixed-\(B\) occupation law;
- Task-5 moving threshold for every coefficient \(b<1\), hence for every \(b<1-K_{17}/3\).

Every finite prefix is exactly positive-realizable.

Selected canonical witnesses:

| R | \(A_R\) | \(E_R\) | canonical positive start |
|---:|---:|---:|---:|
| 32 | 32 | 13 | \(2^{33}-1\) |
| 64 | 80 | 15 | 1638038818605883270889471 |
| 128 | 180 | 15 | 1294509726594194940461929473356458443502319292741844991 |
| 256 | 382 | 15 | 1793691733637540156850745748128437338648024253505058266735175566986193403225688714612350677270444827570601967222783 |

Unlike the periodic controls, its full 2-adic realizer is not classified. Deciding whether it could be a positive ordinary integer is already the LEVEL-3 problem.

---

## 5. Stronger checkpoint theorem: all-ones is a universal compatible node

For every valuation word,
\[
A_k\ge k,
\]
hence
\[
E_k(w)\le F_k-k-L_k=E_k^{(1)}.
\]

Therefore all-ones:

- maximizes \(E_k\) at every prefix time;
- minimizes the low-\(E\) occupation mass \(W_B\).

So for any fixed \(B,\varepsilon,R\):

\[
\boxed{
G(B,\varepsilon;R)\ne\varnothing
\Longrightarrow
1^R\in G(B,\varepsilon;R).
}
\]

The statement remains true if terminal \(E_R>B\) is imposed.

Consequently, if a sequence of checkpoint families is individually nonempty, the all-ones prefixes form a common compatible chain through **every** checkpoint.

Thus the proposed finite failure mode

> “all checkpoint levels are nonempty but no compatibility chain exists”

cannot occur for these occupation families.

The failure occurs one level later: the common inverse-limit point may lie outside positive integers.

---

## 6. Exact finite compatibility diagnostics

Three terminal-high-\(E\) checkpoint schedules were exhaustively enumerated. These are diagnostics only; a hypothetical orbit is not required to hit these arbitrary terminal-high-\(E\) times.

For the dyadic-small schedule
\[
(R,\varepsilon)=(4,1/2),(8,1/4),(12,1/8),(16,1/16)
\]
with \(B=-1\):

- \(|G_R|=1,6,287,3268\);
- **2856** exact chains survive all four checkpoints;
- **182** level-12 nodes remain extendible through the final checkpoint.

For the shifted schedule
\[
(5,1/2),(9,1/4),(13,1/8),(17,1/16):
\]

- \(|G_R|=1,25,480,4995\);
- **4176** exact chains survive all four checkpoints.

So finite compatibility is abundant, not scarce.

---

## 7. Checkpoint injury does not yet give a new obstruction

Define injury when the canonical representative changes between checkpoints.

For the dyadic-small schedule the minimum injuries through all four checkpoints is
\[
2.
\]

But for the shifted schedule the minimum is only
\[
1,
\]
attained by the chain whose checkpoint residues are
\[
\boxed{
63,\ 703,\ 703,\ 703.
}
\]

Thus one ordinary integer, \(703\), already realizes the later three checkpoint prefixes of this finite schedule.

This is an exact finite warning against extrapolating injury growth.

More importantly, checkpoint injury is simply nonzero accumulated Task-7 binary lift activity. Therefore a theorem forcing infinitely many injuries would be the same unresolved nonzero-lift/eventual-stabilization obstruction in coarser notation.

\[
\boxed{
\text{injury mechanism }=[\text{REDUNDANT WITH TASK 7}].
}
\]

---

## 8. Topological reason compactness is insufficient

\(\mathbb Z_2\) is compact.

Positive ordinary integers are dense in \(\mathbb Z_2\), but they are not closed.

The simplest example is
\[
2^m-1\to-1.
\]

Thus a sequence of positive finite witnesses can have a perfectly coherent 2-adic limit outside the positive integers.

Even stronger, every finite valuation cylinder has:

- a Task-5-good extension, obtained by appending all \(a_k=1\);
- a Task-5-bad extension, obtained by appending all \(a_k=2\).

So the fixed-\(B\) good realizer set and its complement both meet every finite valuation cylinder.

2-adic largeness, smallness, density, category, or compactness therefore does not decide intersection with \(\mathbb N_{>0}\).

---

## 9. Finite-satisfiability barrier

Task 10 formalizes the methodological barrier:

\[
\boxed{
\text{consistent finite valuation coordinates + finitely many congruences}
}
\]

always define either an empty finite system or an arithmetic progression containing infinitely many positive integers.

Therefore an argument built only from finitely many valuation coordinates and finitely many congruence conditions cannot distinguish:

\[
\forall R\ \exists n_R
\]

from the required infinite coherence problem.

A Side-B proof must genuinely control the inverse limit and show:

\[
\boxed{
\text{every Task-5-compatible nested branch fails eventual residue stabilization.}
}
\]

No such theorem is proved.

---

## 10. What is the minimal remaining global property?

After Tasks 6–10, the cleanest equivalent target is:

> **Occupation–ordinary-integer exclusion:** every infinite nested valuation branch satisfying Task-5 occupation has a 2-adic realizer outside \(\mathbb N_{>0}\).

Equivalently:

- canonical truncations change infinitely often on every full good branch;
- no full good branch has eventually constant canonical residues.

This is not a new theorem. It is the unresolved LEVEL-3 problem in its cleanest form.

Task 7 already attacked one quantitative version via popcount/nonzero lifts and failed to prove it.

---

## 11. Hypothesis ledger

| Hypothesis | Verdict | Evidence |
|---|---|---|
| H1. Nonempty good checkpoint levels need not have a common branch | `[FAIL FOR THIS FAMILY]` | all-ones belongs to every nonempty occupation checkpoint |
| H2. Infinite good branch implies positive integer | `[COUNTEREXAMPLE][FAIL]` | all-ones \(\to-1\), alternating \(\to-5\) |
| H3. Task-5 good tree has no infinite abstract branch | `[COUNTEREXAMPLE][FAIL]` | explicit all-ones, alternating, Task-9 branches |
| H4. Task 5 forces infinitely many injuries | `[OPEN]` | equivalent to ordinary-integer exclusion |
| H5. Minimum checkpoint injury tends to infinity | `[NO FINITE SUPPORT / OPEN]` | schedule-dependent; shifted four-level minimum is 1 |
| H6. Every full good branch has non-eventually-constant residues | `[OPEN]` | this is Side B itself |
| H7. General eventual-constancy exclusion theorem exists | `[OPEN]` | not proved |
| H8. Injury is genuinely new vs Task 7 | `[REDUNDANT]` | same nonzero lift activity |
| H9. 2-adic compactness yields a positive ordinary integer | `[COUNTEREXAMPLE][FAIL]` | positive witnesses converge to \(-1,-5\) |
| H10. Finite congruence arguments can distinguish LEVEL 2/3 | `[FAIL]` when the finite system is consistent | exact cylinder + CRT/arithmetic progression |

---

## 12. Required final table

| Question | Verdict | Evidence |
|---|---|---|
| Are finite valuation cylinders exactly nested? | `[EXACT] YES` | extension cylinders are subsets |
| Does an infinite nested word define a unique 2-adic realizer? | `[EXACT] YES` | inverse limit, modulus depth \(\to\infty\) |
| When is that realizer a positive ordinary integer? | `[EXACT]` | canonical residues eventually constant |
| Does finite satisfiability imply positive LEVEL 3? | `[FAIL]` | \(2^{R+1}-1\to-1\), \(2^{3m+1}-5\to-5\) |
| Does the Task-5 good-prefix system have infinite abstract branches? | `[PROVED] YES` | all-ones; alternating; Task-9 critical branch |
| Can every finite prefix of such a branch be positive-realized? | `[EXACT] YES` | valuation cylinder |
| Do compatibility graphs survive arbitrarily deep? | `[PROVED ABSTRACTLY] YES` | explicit infinite branches; finite graph diagnostics also abundant |
| Does Task-5 force infinitely many canonical-residue injuries? | `[OPEN]` | no universal theorem |
| Can a good branch eventually stabilize to one positive integer? | `[OPEN]` | exactly the hypothetical LEVEL-3 case |
| Is injury growth genuinely new vs Task 7? | `[REDUNDANT]` | checkpoint-coarsened nonzero lift count |
| Is compactness in \(\mathbb Z_2\) useful or misleading for \(\mathbb N\)? | useful for existence of \(x\), misleading for positivity | \(\mathbb N\) dense, not closed |
| Do we now have Side B? | **NO** | no universal ordinary-integer exclusion |

# FINAL STRATEGIC VERDICT

\[
\boxed{\textbf{A — [FAIL: ABSTRACT NESTED BRANCHES SURVIVE]}}
\]

Task 10 kills the idea that the missing obstruction could be mere nested compatibility of valuation prefixes.

Nested compatibility survives exactly—even with full fixed-\(B\) occupation and even in a near-critical Task-9 control branch.

The true unresolved statement is not existence of an infinite branch in valuation space. It is whether **any** Task-5-compatible infinite branch can have an eventually constant 2-adic truncation, equivalently a positive ordinary-integer realizer.

No big-threshold audit is triggered.
