# CP20 TASK 2 — ADVERSARIAL SURVIVOR

A direct symbolic controller attacks the proposed shell mechanism.

Let

\[
d_k=s_{k+1}-s_k=g_k-a_k,
\qquad g_k\in\{1,2\}.
\]

For a target

\[
s_k\approx\kappa\log_2k,
\qquad \kappa>1,
\]

use only

\[
d_k\in\{-1,+1\},
\]

with \(+1\) allowed only when \(g_k=2\). The implementation chooses an upward move when possible and the current discrepancy is at/below the slowly varying target; otherwise it chooses \(-1\).

Then

\[
a_k=g_k-d_k\in\{1,2,3\},
\]

and

\[
a_k\ne g_k
\]

at every site: there are zero exact critical sites.

For \(\kappa=1.053,1.06,1.10\), exact symbolic generation through 250,000 steps gives bounded tracking error at the tested endpoint, mean valuation tending toward \(\alpha\), and no critical site. Numerical partial carry sums are finite-looking, consistent with the theorem-level fact that if

\[
s_k=\kappa\log_2k+O(1),\qquad\kappa>1,
\]

then

\[
\sum 2^{-s_k-\{\alpha k\}}
\]

converges by comparison with \(\sum k^{-\kappa}\).

On logarithmic windows, the target changes by only \(o(1)\), so local discrepancy variation remains bounded and

\[
A(v,j)-\alpha j=O(1)
\]

for the balanced local morphology. Start, endpoint and intermediate state exponents therefore remain in the same polynomial shell up to constant/subpolynomial factors.

This is a direct adversarial explanation for why the two-sided/intermediate shell constraints do not automatically create a new exponent saving.

## Logical status

[EXACT] symbolic valuation schedule construction.

[NUM] finite carry diagnostics.

The construction is only LEVEL 2 / symbolic necessary-condition evidence. It is **not** a proof that one fixed positive ordinary integer realizes the infinite word.
