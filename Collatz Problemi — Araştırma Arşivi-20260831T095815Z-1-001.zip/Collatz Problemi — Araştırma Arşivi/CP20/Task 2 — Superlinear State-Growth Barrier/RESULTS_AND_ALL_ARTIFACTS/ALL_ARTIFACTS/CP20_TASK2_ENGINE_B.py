#!/usr/bin/env python3
import math

def comps(T,l):
    if l==1:yield (T,);return
    for a in range(1,T-l+2):
      for z in comps(T-a,l-1):yield (a,)+z

def good(c):
    l=len(c);p=sum(c);S=0
    for j,a in enumerate(c,1):
      S+=a
      if j<l and l*S<p*j:return False
    return True

def main():
    alpha=math.log2(3)
    for l in [5,7,11,13]:
      p=math.ceil(alpha*l);assert math.gcd(p,l)==1
      C=list(comps(p,l));G=sum(good(c) for c in C)
      assert G*l==len(C),(l,p,G,len(C))
      print(l,p,len(C),G)
    # concatenated cylinder depth: +1 occurs once, not once per subblock
    for A1,A2 in [(2,3),(5,7),(10,11)]:
      actual=A1+A2+1;naive=A1+1+A2+1
      assert naive==actual+1
    print('CP20 TASK2 ENGINE B: OK')
if __name__=='__main__':main()
