# CP20 TASK 2 — SHELL-TO-SHELL TRANSFER MATRIX

Partition ordinary states into exponent shells. For a length

\[
\ell=c\log_2N
\]

word with total density \(x=A/\ell\), the homogeneous transition shifts state exponent by

\[
\boxed{c(\alpha-x)}
\]

up to lower-order affine effects when the state itself is polynomially large.

Hence:

- \(x>\alpha\) drives a state downward in exponent;
- \(x<\alpha\) drives it upward;
- \(x=\alpha+o(1)\) stays on the same shell exponent.

The exact two-sided upper-bound contribution from start exponent \(\kappa_i\) to endpoint exponent \(\kappa_j\) has word-density exponent

\[
ch(x)+\min\{\kappa_i-cx,\ \kappa_j-c\alpha\}
\]

before the unavoidable `+1 per word` term.

For the sustained same-shell channel \(\kappa_i=\kappa_j=\kappa\) and any valuation cap \(\mu\ge\alpha\), maximizing over \(x\le\mu\) reproduces

\[
\max\{ch(\mu),\kappa-c\eta(\mu)\},
\]

exactly the CP20 Task-1 exponent.

Numerical shell scans around \(\kappa_0\), 1.053, 1.06 and 1.10 give zero exponent improvement to numerical precision; see `CP20_TASK2_SHELL_MATRIX_TABLE.csv`.

A matrix formulation can redistribute mass among shells, but the near-critical diagonal channel survives and pins the threshold at

\[
\boxed{\kappa_0=1.0526808586079717\ldots}
\]

for this mechanism.

[FAIL: NO POSITIVE THRESHOLD GAIN]
