# CP20 TASK 2 — EXACT ORDINARY TRANSITION COUNTS

For odd \(n\),

\[
a(n)=v_2(3n+1)=a
\]

is one odd residue class modulo \(2^{a+1}\). Therefore any integer interval \([L,H]\) contains exactly

\[
\max\left(0,
\left\lfloor\frac{H-r_a}{2^{a+1}}\right\rfloor
-
\left\lceil\frac{L-r_a}{2^{a+1}}\right\rceil+1
\right)
\]

such states.

More generally a prescribed positive valuation word \(W\) of total \(A\) is one odd residue class modulo \(2^{A+1}\). Adding an endpoint shell gives exactly the interval-intersection formula in `CP20_TASK2_TWO_SIDED_CYLINDER_THEOREM.md`.

Thus short-transition arithmetic confirms rather than improves the cylinder count: start and endpoint conditions act on one arithmetic progression, not two independent progressions.

For contraction/expansion type, the homogeneous scale is

\[
\frac{3^\ell}{2^A}=2^{(\alpha-A/\ell)\ell}.
\]

- \(A>\alpha\ell\): polynomial contraction on logarithmic windows;
- \(A<\alpha\ell\): polynomial expansion;
- \(A=\alpha\ell+O(1)\): constant-factor transition.

The surviving high-state symbolic morphology uses the third channel on most logarithmic windows, so shell arithmetic does not force it out.

[EXACT]
