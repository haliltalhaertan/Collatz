# CP20 TASK 2 — INTERMEDIATE-STATE PATH GEOMETRY

## Exact interval

For a fixed valuation word let

\[
2^{A_j}n_j=3^j n_0+B_j,\qquad 0\le j\le\ell.
\]

Imposing shells \(L_j\le n_j\le H_j\) on any set of intermediate times gives one interval for the same start variable:

\[
I_W^{\rm path}
=\bigcap_j
\left[
\frac{2^{A_j}L_j-B_j}{3^j},
\frac{2^{A_j}H_j-B_j}{3^j}
\right].
\]

The exact valuation word still supplies only one start progression modulo \(2^{A+1}\). Therefore

\[
\boxed{
N_W^{\rm path}\le \frac{|I_W^{\rm path}|}{2^{A+1}}+1.
}
\]

For equal upper ceilings \(H_j=H\), ignoring the affine subtraction can only enlarge the interval and gives

\[
|I_W^{\rm path}|
\le H\min_j 2^{A_j-\alpha j}.
\]

Thus a word with a prefix deficit \(A_j-\alpha j\le-\gamma\ell\) receives an extra factor \(2^{-\gamma\ell}\).

## Why this is not uniform

The extra factor is not available uniformly over low-window words.

Let a composition \((a_0,\dots,a_{\ell-1})\) have total \(p\), with \(\gcd(p,\ell)=1\). The cycle-minimum lemma gives exactly one cyclic rotation per orbit satisfying

\[
A_j\ge\left\lceil\frac{pj}{\ell}\right\rceil\qquad(1\le j<\ell).
\]

Hence exactly a \(1/\ell\) fraction of the fixed-total compositions have all prefixes above their endpoint mean line. If \(p/\ell\ge\alpha\), these words satisfy

\[
A_j-\alpha j\ge0
\]

at every interior prefix.

For prime \(\ell\) and \(p=\lceil\alpha\ell\rceil\), \(\gcd(p,\ell)=1\), and the exact checks give:

- \(\ell=5,p=8\): 35 compositions, 7 good;
- \(\ell=7,p=12\): 462 compositions, 66 good;
- \(\ell=11,p=18\): 19,448 compositions, 1,768 good;
- \(\ell=13,p=21\): 125,970 compositions, 9,690 good.

The loss \(1/\ell\) is polynomial, not exponential.

There is also an explicit zero-critical symbolic controller using only \(d_k=\pm1\) whose cumulative defect remains bounded. Its local valuation prefixes satisfy

\[
A_j-\alpha j=O(1)
\]

while no site has \(a_k=g_k\). Thus the failure is not rescued by the frozen long-critical exclusion.

## Verdict

Some exceptional words do receive exponential interval shrinkage, but no uniform exponential shrinkage holds over the critical low-window language.

[FAIL: INTERMEDIATE CEILINGS DO NOT SUPPLY A UNIFORM SECOND SAVING]
