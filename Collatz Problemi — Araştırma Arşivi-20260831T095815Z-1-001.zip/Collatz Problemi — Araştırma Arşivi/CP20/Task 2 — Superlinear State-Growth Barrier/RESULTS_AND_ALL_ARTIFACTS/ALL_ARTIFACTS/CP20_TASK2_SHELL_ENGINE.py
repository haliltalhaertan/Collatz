#!/usr/bin/env python3
import math,csv
from pathlib import Path
OUT=Path('/mnt/data')
alpha=math.log2(3)
def H2(p):
    if p<=0 or p>=1:return 0.0
    return -p*math.log2(p)-(1-p)*math.log2(1-p)
def h(x):return x*H2(1/x)
def eta(x):return x-h(x)
def scan(k0,k1,mu,c):
    best=(-1e99,None)
    for i in range(30001):
      x=1+(mu-1)*i/30000
      e=c*h(x)+min(k0-c*x,k1-c*alpha)
      if e>best[0]:best=(e,x)
    return best

def main():
    kappa0=alpha/h(alpha);rows=[]
    for mu in [alpha,1.60,1.65,1.70,1.80,1.90]:
      for k in [kappa0,1.053,1.06,1.10]:
        c=k/mu;task=max(c*h(mu),k-c*eta(mu));tw,x=scan(k,k,mu,c);total=max(c*h(mu),tw)
        assert abs(total-task)<2e-4
        rows.append([mu,k,c,task,tw,total,task-total,x])
    with (OUT/'CP20_TASK2_SHELL_MATRIX_TABLE.csv').open('w',newline='') as f:
      w=csv.writer(f);w.writerow(['mu','kappa','c','task1_rho','two_sided_weight','two_sided_total','gain','argmax_x']);w.writerows(rows)
    print('kappa0',kappa0,'rows',len(rows))
    print('CP20 TASK2 SHELL ENGINE: OK')
if __name__=='__main__':main()
