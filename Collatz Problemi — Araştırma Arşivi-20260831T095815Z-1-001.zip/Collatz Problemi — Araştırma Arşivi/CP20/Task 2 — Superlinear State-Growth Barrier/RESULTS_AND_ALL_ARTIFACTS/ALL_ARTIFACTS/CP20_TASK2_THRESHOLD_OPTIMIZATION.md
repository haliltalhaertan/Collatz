# CP20 TASK 2 — THRESHOLD OPTIMIZATION

Frozen threshold:

\[
\alpha=\log_2 3,
\qquad
h(\mu)=\mu H_2(1/\mu),
\qquad
\eta(\mu)=\mu-h(\mu).
\]

CP20 Task 1 uses

\[
\rho_1(\kappa,\mu,c)=\max\{ch(\mu),\kappa-c\eta(\mu)\}.
\]

The optimized critical exponent is

\[
\kappa_0=\frac{\alpha}{h(\alpha)}
=1.0526808586079717\ldots
\]

at the critical mean.

For equal start/endpoint shell exponents, Task 2 gives the exact weighted term

\[
R_{\rm 2side}
=\sup_{1\le x\le\mu}
\left[ch(x)+\min\{\kappa-cx,\kappa-c\alpha\}\right].
\]

For \(\mu\ge\alpha\),

\[
\boxed{R_{\rm 2side}=\kappa-c\eta(\mu)}.
\]

The `+1 per word` term remains \(ch(\mu)\). Therefore

\[
\boxed{\rho_2=\rho_1.}
\]

No positive analytic saving \(\sigma\) was obtained.

Consequently

\[
\boxed{\kappa_{\rm new}=\kappa_0}
\]

for the tested two-sided/intermediate/transition-shell mechanism, and

\[
\boxed{\kappa_{\rm new}-\kappa_0=0.}
\]

This is a structural zero gain, not merely a failed numerical optimizer.

[FAIL: THRESHOLD NOT RAISED]
