# COLLATZ CP20 — TASK 2 FINDINGS
## Superlinear State-Growth Barrier
## Two-Sided Shell Packing • Transition Geometry • Second-Saving Search

## Final verdict

\[
\boxed{\textbf{A — [FAIL: TWO-SIDED/TRANSITION SAVING COLLAPSES]}}
\]

No theorem raises the audited threshold

\[
\kappa_0=1.0526808586079717\ldots
\]

in CP20 Task 2.

## Main result

The exact two-sided start/endpoint count is valid, but in the sustained equal-exponent state regime its asymptotic exponent is exactly the frozen CP20 Task-1 exponent.

For a word of density \(x=A/\ell\), equal state-shell widths \(N^{\kappa+o(1)}\) give the interval contribution

\[
N^{ch(x)+\min(\kappa-cx,\kappa-c\alpha)+o(1)}.
\]

For every cap \(\mu\ge\alpha\), maximizing over \(x\le\mu\) yields

\[
\kappa-c\eta(\mu).
\]

The `+1 per word` term remains

\[
ch(\mu).
\]

Therefore

\[
\boxed{
\rho_{\rm Task2}=\max\{ch(\mu),\kappa-c\eta(\mu)\}
=\rho_{\rm Task1}.
}
\]

Endpoint information improves constants and suppresses the subcritical \(x<\alpha\) side, but does not provide a new exponent on the critical/supercritical channel relevant to the remaining survivor.

## Intermediate states

Intermediate ceilings can give exponential shrinkage to words whose prefix cumulative valuation falls linearly below \(\alpha j\). But this is not uniform.

The cycle-minimum lemma gives a polynomial fraction \(1/\ell\) of fixed-total compositions with every prefix above the endpoint mean line. At totals \(p/\ell\ge\alpha\), those words have no homogeneous intermediate-ceiling shrink at all.

An explicit zero-critical symbolic controller also produces bounded local discrepancy without using exact critical sites.

Thus the frozen CP19 Task-3 long-critical exclusion does not repair this failure.

## Transition graph

For one injective orbit, the \(\ell\)-shift graph on selected starts is a matching. Counting endpoints does not produce an independent collision factor. No CP17-style energy saving independent of the Task-1 cylinder sparsity was found.

## Multiscale dependency

Adjacent word cylinders are conditional, not independent. Concatenating totals \(A_1,A_2\) gives modulus depth

\[
A_1+A_2+1,
\]

not \(A_1+A_2+2\). Naive product counting creates a false extra factor \(1/2\) per concatenation.

Nested and overlapping variants similarly failed the dependency audit.

## Shell transfer

A length-\(c\log N\) block of mean \(x\) moves state exponent by

\[
c(\alpha-x).
\]

The near-critical channel \(x=\alpha+o(1)\) stays on the same exponent shell and remains available. It pins the transfer-matrix mechanism at the original threshold.

Certified exponent scans show zero improvement for \(\kappa_0\), 1.053, 1.06 and 1.10.

## Adversarial survivor

A zero-critical symbolic controller was generated at \(\kappa=1.053,1.06,1.10\). It uses only valuations 1,2,3, has mean valuation tending toward \(\alpha\), tracks \(s_k\approx\kappa\log_2k\), and is compatible with carry convergence when the asymptotic tracking relation holds.

This remains LEVEL 2 / symbolic only. A fixed positive ordinary LEVEL-3 realizer is not proved.

## Threshold

\[
\boxed{
\kappa_{\rm new}=\kappa_0
=1.0526808586079717\ldots
}
\]

\[
\boxed{
\kappa_{\rm new}-\kappa_0=0.
}
\]

No positive \(\varepsilon\) was proved.

## What remains open

The failure is specific to the tested two-sided shell, intermediate-ceiling, edge-energy and multiscale-cylinder mechanisms. It is **not** a theorem that no future Archimedean ordinary-state invariant can raise the threshold.

The high-state LEVEL-3 regime

\[
\kappa\ge\kappa_0
\]

remains open.

## Final theorem table

| Question | Verdict | Evidence |
|---|---|---|
| Exact two-sided interval/count formula? | [EXACT] | affine pullback + one cylinder progression |
| Endpoint shell gives independent exponential saving? | [FAIL] | exponent re-derives Task-1 \(\rho\) |
| Many intermediate ceilings uniformly shrink words exponentially? | [FAIL] | cycle-minimum polynomial family + balanced zero-critical morphology |
| Edge/endpoint energy gives second saving? | [FAIL] | orbit shift graph is a matching; no independent multiplicity |
| Exact short transition counts known? | [EXACT] | one residue class mod \(2^{A+1}\) |
| Shell transfer raises threshold? | [FAIL] | near-critical diagonal channel survives |
| Adjacent/multiscale cylinders independent? | [FAIL] | exact concatenation removes naive product gain |
| New threshold? | [EXACT] same as Task 1 | \(1.0526808586079717\ldots\) |
| Positive gain above \(\kappa_0\)? | [FAIL] | proved gain 0 for tested mechanism |
| Symbolic survivor above threshold still exists? | [EXACT]/[NUM] | zero-critical controller + finite diagnostics |
| Positive ordinary LEVEL 3 excluded? | [OPEN] | no new ordinary-state obstruction |
| Side B? | [OPEN] | not closed |

## Ne denedik?

Başlangıç sayısının büyük olmasının yanında, pencerenin sonundaki ve ortasındaki sayıların da aynı polynomial büyüklük bandında kalmasını şart koştuk. Bunun Task-1 packing'ine ikinci bir ceza ekleyip eklemediğini test ettik.

## Hangi saving öldü?

Endpoint, ara-state, edge-energy ve yanlış bağımsız multi-scale saving'leri yeni bir exponential faktör vermedi. Özellikle iki ardışık cylinder'ı bağımsız çarpmak sahte bir kazanç üretiyor.

## Threshold yükseldi mi?

Hayır.

\[
1.0526808586079717\ldots
\]

değerinden rigorously yukarı çıkamadık.

## Survivor nerede yaşıyor?

Hâlâ \(\kappa\ge\kappa_0\) high-state rejiminde. Symbolic olarak \(\kappa=1.053\) kadar eşik yakınına inebiliyor.

## LEVEL 2 / LEVEL 3

Symbolic valuation schedule ve her finite cylinder LEVEL 2'dir. Tek bir pozitif ordinary integer'ın bütün sonsuz schedule'ı gerçekleştirmesi LEVEL 3'tür ve hâlâ açık.

## Collatz çözüldü mü?

Hayır.

## Sıradaki yön

Aynı shell/cylinder mekanizmasını büyütmek yerine yeni bir Archimedean invariant gerekir. En yüksek bilgi değerli aday: **actual state occupation across multiplicative height bands + recurrence flux**, yani sadece bir pencere başlangıcı/sonu değil, uzun index bloklarında yüksek-state shell'lere giren ve çıkan gerçek integer akışının dengesi. Bu yeni branch cylinder bağımsızlığı varsaymamalı ve parked 2-adic high-half'e dönmemeli.
