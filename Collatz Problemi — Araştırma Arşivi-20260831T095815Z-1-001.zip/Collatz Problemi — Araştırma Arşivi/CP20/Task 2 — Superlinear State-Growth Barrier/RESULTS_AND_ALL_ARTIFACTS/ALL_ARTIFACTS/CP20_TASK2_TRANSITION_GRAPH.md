# CP20 TASK 2 — TRANSITION GRAPH / EDGE PACKING

For a fixed shift \(\ell\), selected starts on one positive injective orbit define edges

\[
n_v\longmapsto n_{v+\ell}.
\]

Because the orbit states are injective, both the selected start vertices and selected endpoint vertices are distinct. The selected edge set is therefore a matching.

This has two consequences.

1. Counting endpoint vertices does not multiply the start count by an independent density factor. It is the same edge set viewed from the other side.
2. A Cauchy–Schwarz/energy argument on this matching has no automatic collision multiplicity to exploit.

For a fixed valuation word the edge map is the affine injection

\[
n_{v+\ell}=\frac{3^\ell n_v+B_W}{2^{A(W)}}
\]

on its unique start cylinder. The exact two-sided shell count is therefore already the complete one-word edge count.

Across different words, any additional collision-energy saving would need a genuinely new theorem about cross-word endpoint multiplicity that is independent of the cylinder sparsity already used in CP20 Task 1. No such theorem was found.

Finite exact enumeration found saturation examples in which the two-sided count equals the direct count and no extra graph factor appears.

[FAIL: NO INDEPENDENT EDGE/COLLISION SAVING FOUND]
