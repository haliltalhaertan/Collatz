# CP20 TASK 2 — TWO-SIDED CYLINDER THEOREM

## Status

[EXACT]

Fix a positive valuation word

\[
W=(a_0,\dots,a_{\ell-1}),\qquad A=\sum a_i,
\]

with affine map

\[
2^A n_\ell=3^\ell n_0+B_W.
\]

The exact word condition pins the odd start to one residue class

\[
n_0\equiv \rho_W\pmod{2^{A+1}}.
\]

Suppose

\[
L_0\le n_0\le H_0,\qquad L_1\le n_\ell\le H_1.
\]

Then the possible starts are exactly the points of the cylinder progression inside

\[
I_W=[L_0,H_0]\cap
\left[
\frac{2^A L_1-B_W}{3^\ell},
\frac{2^A H_1-B_W}{3^\ell}
\right].
\]

Writing the integer endpoints as

\[
L_W=\max\left\{L_0,\left\lceil\frac{2^A L_1-B_W}{3^\ell}\right\rceil\right\},
\]

\[
H_W=\min\left\{H_0,\left\lfloor\frac{2^A H_1-B_W}{3^\ell}\right\rfloor\right\},
\]

the exact count is

\[
\boxed{
N_W=
\max\left(
0,
\left\lfloor\frac{H_W-\rho_W}{2^{A+1}}\right\rfloor
-
\left\lceil\frac{L_W-\rho_W}{2^{A+1}}\right\rceil
+1
\right).
}
\]

Hence

\[
\boxed{
N_W\le \frac{|I_W|}{2^{A+1}}+1
}
\]

and, with shell widths \(\Delta_i=H_i-L_i\),

\[
\boxed{
N_W\le
\frac12\min\{\Delta_0 2^{-A},\Delta_1 3^{-\ell}\}+1.
}
\]

The second term is important: after pulling the endpoint shell back, the factor \(2^A\) cancels the cylinder spacing \(2^{A+1}\). Thus the endpoint contribution is independent of \(A\).

## Equal polynomial ceilings

Let

\[
\Delta_0=\Delta_1=N^{\kappa+o(1)},\qquad
\ell=c\log_2N+o(\log N),
\]

and write \(A=x\ell+o(\ell)\). The interval term at total-valuation density \(x\) has exponent

\[
\boxed{
ch(x)+\min\{\kappa-cx,\kappa-c\alpha\}.
}
\]

For a cap \(A\le \mu\ell\), \(\mu\ge\alpha\), the maximum over \(1\le x\le\mu\) is

\[
\boxed{\kappa-c\eta(\mu)}.
\]

The unavoidable `+1 per word` contribution is

\[
N^{ch(\mu)+o(1)}.
\]

Therefore the complete two-sided upper exponent is exactly

\[
\boxed{
\max\{ch(\mu),\kappa-c\eta(\mu)\},
}
\]

the frozen CP20 Task-1 exponent.

## Verdict

For the equal-exponent sustained-state regime and \(\mu\ge\alpha\), endpoint upper-shell information gives **no new exponential saving**.

[FAIL: SECOND ENDPOINT SAVING COLLAPSES]
