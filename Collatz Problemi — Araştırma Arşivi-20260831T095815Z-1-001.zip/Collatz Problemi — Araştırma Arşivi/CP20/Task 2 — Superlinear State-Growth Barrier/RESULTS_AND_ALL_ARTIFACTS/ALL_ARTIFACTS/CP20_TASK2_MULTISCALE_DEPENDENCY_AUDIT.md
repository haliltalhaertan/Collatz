# CP20 TASK 2 — MULTISCALE DEPENDENCY AUDIT

## Nested windows

A longer valuation prefix contains the shorter cylinder information. Nested cylinder constraints must not be multiplied.

## Adjacent disjoint windows

Let adjacent words have totals \(A_1,A_2\). Their concatenation has one exact start cylinder modulo

\[
\boxed{2^{A_1+A_2+1}}.
\]

Naively multiplying the two integer cylinder densities would use

\[
2^{-(A_1+1)}2^{-(A_2+1)}=2^{-(A_1+A_2+2)},
\]

which introduces a false extra factor \(1/2\).

The correct second-block condition is conditional on an odd endpoint. Relative to odd states its density is \(2^{-A_2}\), so

\[
2^{-(A_1+1)}2^{-A_2}=2^{-(A_1+A_2+1)},
\]

exactly the concatenated cylinder density.

With many blocks, multiplying unconditional integer densities would create a completely artificial exponential factor \(2^{-(m-1)}\).

## Composition language

Separate caps on adjacent blocks may alter a language by large-deviation restrictions, but when the same critical mean channel is allowed their entropy exponents add to the same long-block rate. This is not an independent arithmetic saving.

## Verdict

No proposed nested/adjacent product bound survived the dependency audit as a genuinely independent second cylinder saving.

[FAIL: FALSE INDEPENDENCE]
