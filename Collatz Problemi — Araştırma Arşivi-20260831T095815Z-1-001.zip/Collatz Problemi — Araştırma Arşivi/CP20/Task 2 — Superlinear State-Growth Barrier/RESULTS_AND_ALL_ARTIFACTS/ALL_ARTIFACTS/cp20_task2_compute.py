from pathlib import Path
from fractions import Fraction
from math import comb
import math, csv, json, hashlib, zipfile, random
OUT=Path('/mnt/data')

LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q; hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def g(k): return F(k+1)-F(k)
def syr_step(n):
    x=3*n+1; a=(x & -x).bit_length()-1; return x>>a,a
def word_of(n,ell):
    w=[]
    for _ in range(ell): n,a=syr_step(n);w.append(a)
    return tuple(w)
def affine(word):
    A=B=0
    for a in word: B=3*B+(1<<A);A+=a
    return A,B
def cylinder(word):
    A,B=affine(word);q=1<<(A+1);rho=((1<<A)-B)*pow(pow(3,len(word)),-1,q)%q
    return rho,q,A,B
def compositions(total,length):
    if length==1:
        yield (total,);return
    for a in range(1,total-length+2):
        for tail in compositions(total-a,length-1): yield (a,)+tail
def ceil_div(a,b): return -((-a)//b)
def exact_two_sided_count(word,L0,H0,L1,H1):
    ell=len(word);A,B=affine(word);rho,q,_,_=cylinder(word)
    lo=max(L0,ceil_div((1<<A)*L1-B,3**ell))
    hi=min(H0,((1<<A)*H1-B)//(3**ell))
    if hi<lo:return 0,lo,hi,rho,q
    return max(0,(hi-rho)//q-ceil_div(lo-rho,q)+1),lo,hi,rho,q

def verify_two_sided_small():
    rows=[]
    for ell in range(1,5):
      for A in range(ell,ell+5):
       for w in compositions(A,ell):
        for H0,H1 in [(50,50),(100,70),(70,100),(20,200)]:
         cnt,lo,hi,rho,q=exact_two_sided_count(w,1,H0,1,H1)
         brute=0
         for n in range(1,H0+1,2):
          if word_of(n,ell)==w:
           x=n
           for _ in range(ell): x,_=syr_step(x)
           if 1<=x<=H1: brute+=1
         assert cnt==brute,(w,H0,H1,cnt,brute)
         rows.append(['two_sided',ell,A,H0,H1,cnt,brute,'PASS'])
    return rows

def cycle_min_rotation(comp):
    r=len(comp);p=sum(comp);S=0;vals=[]
    for j in range(r): vals.append(r*S-p*j); S+=comp[j]
    m=min(range(r),key=lambda j:vals[j]); return comp[m:]+comp[:m]
def verify_cycle():
    rows=[];alpha=math.log2(3)
    for ell in [5,7,11,13]:
      p=math.ceil(alpha*ell); assert math.gcd(p,ell)==1 and p<2*ell
      comps=list(compositions(p,ell));good=0
      for c in comps:
       S=0;ok=True
       for j,a in enumerate(c,1):
        S+=a
        if j<ell and ell*S<p*j:ok=False;break
       if ok:good+=1
      assert good*ell==len(comps),(ell,p,good,len(comps))
      rows.append(['cycle_balanced',ell,p,len(comps),good,1/ell,'1/ell exact','PASS'])
    return rows

def balanced_word(K):
    s=0;d=[];a=[];S=[0]
    for k in range(K):
      gg=g(k);dk=1 if gg==2 and s<0 else -1;ak=gg-dk
      assert dk<=gg-1 and ak>=1 and dk!=0
      s+=dk; assert -2<=s<=0
      d.append(dk);a.append(ak);S.append(s)
    return d,a,S
def verify_balanced():
    d,a,S=balanced_word(5000);rows=[];alpha=math.log2(3)
    for ell in [16,32,64,128,256,512]:
      A=0;minD=0;maxD=0
      for j in range(ell+1):
       if j: A+=a[j-1]
       D=A-alpha*j;minD=min(minD,D);maxD=max(maxD,D)
      assert minD>-1.0000001 and maxD<2.0000001,(ell,minD,maxD)
      rows.append(['zero_critical_balanced',ell,sum(a[:ell]),minD,maxD,max(abs(x) for x in S[:ell+1]),0,'PASS'])
    return rows

alpha=math.log2(3)
def H2(p):
    if p<=0 or p>=1: return 0.0
    return -p*math.log2(p)-(1-p)*math.log2(1-p)
def h(mu): return mu*H2(1/mu)
def eta(mu): return mu-h(mu)
kappa0=alpha/h(alpha)
def twoexp(k0,k1,mu,c):
    best=-1e99;bx=None
    for i in range(20001):
      x=1+(mu-1)*i/20000
      val=c*h(x)+min(k0-c*x,k1-c*alpha)
      if val>best:best=val;bx=x
    return best,bx

def high_symbolic(K,kappa):
    s=A=0;X=0.0;crit=0;samples=[]
    for k in range(K):
      target=kappa*math.log2(max(2,k+1));gg=g(k)
      dk=1 if gg==2 and s<=target else -1
      ak=gg-dk
      assert ak in (1,2,3) and dk!=0 and dk<=gg-1
      crit += (ak==gg);A+=ak;s+=dk
      if k+1>=2:
       frac=alpha*(k+1)-math.floor(alpha*(k+1));X+=2**(-s-frac)
      if k+1 in [100,1000,10000,100000,200000]:samples.append((k+1,s,target,s-target,A/(k+1),X))
    return samples,dict(kappa=kappa,K=K,critical_sites=crit,final_s=s,target=kappa*math.log2(K),tracking_error=s-kappa*math.log2(K),mean_valuation=A/K,alpha=alpha,X_partial_numeric=X,classification='LEVEL-2 / symbolic only')

def main():
    small=verify_two_sided_small()+verify_cycle()+verify_balanced()
    with (OUT/'CP20_TASK2_SMALL_CASES.csv').open('w',newline='',encoding='utf-8') as f:
      w=csv.writer(f);w.writerow(['test','p1','p2','p3','p4','p5','p6','status']);w.writerows(small)
    trs=[]
    for mu in [alpha,1.60,1.65,1.70,1.80,1.90]:
      for kap in [1.04,kappa0,1.053,1.06,1.10]:
       c=kap/mu;task1=max(c*h(mu),kap-c*eta(mu));tw,bx=twoexp(kap,kap,mu,c);total=max(c*h(mu),tw)
       if mu>=alpha-1e-12: assert abs(total-task1)<2e-4,(mu,kap,total,task1,bx)
       trs.append(dict(mu=mu,kappa=kap,c=c,task1_rho=task1,two_sided_weight_rho=tw,two_sided_total_rho=total,gain=task1-total,argmax_x=bx,kappa0=kappa0))
    with (OUT/'CP20_TASK2_THRESHOLD_TABLE.csv').open('w',newline='',encoding='utf-8') as f:
      w=csv.DictWriter(f,fieldnames=list(trs[0].keys()));w.writeheader();w.writerows(trs)
    sums=[];samps=[]
    for kap in [1.053,1.06,1.10]:
      rows,sm=high_symbolic(250000,kap);assert sm['critical_sites']==0;sums.append(sm)
      for r in rows:samps.append((kap,)+r)
    (OUT/'CP20_TASK2_ADVERSARIAL_SUMMARY.json').write_text(json.dumps(sums,indent=2),encoding='utf-8')
    with (OUT/'CP20_TASK2_ADVERSARIAL_SAMPLES.csv').open('w',newline='',encoding='utf-8') as f:
      w=csv.writer(f);w.writerow(['kappa','k','s','target','error','mean_A','X_partial']);w.writerows(samps)
    print('SMALL',len(small));print('KAPPA0',repr(kappa0));print('THRESH',len(trs));print(json.dumps(sums,indent=2))
if __name__=='__main__':main()
