#!/usr/bin/env python3
from itertools import product

def step(n):
    x=3*n+1;a=(x & -x).bit_length()-1;return x>>a,a

def word(n,l):
    w=[]
    for _ in range(l):n,a=step(n);w.append(a)
    return tuple(w)

def affine(w):
    A=B=0
    for a in w:B=3*B+(1<<A);A+=a
    return A,B

def cyl(w):
    A,B=affine(w);q=1<<(A+1);r=((1<<A)-B)*pow(pow(3,len(w)),-1,q)%q
    return r,q,A,B

def ceildiv(a,b):return -((-a)//b)
def count(w,L0,H0,L1,H1):
    r,q,A,B=cyl(w);p=3**len(w)
    lo=max(L0,ceildiv((1<<A)*L1-B,p));hi=min(H0,((1<<A)*H1-B)//p)
    if hi<lo:return 0
    return max(0,(hi-r)//q-ceildiv(lo-r,q)+1)

def comps(T,l):
    if l==1:yield (T,);return
    for a in range(1,T-l+2):
        for z in comps(T-a,l-1):yield (a,)+z

def main():
    cases=0
    for l in range(1,5):
      for A in range(l,l+5):
       for w in comps(A,l):
        for H0,H1 in [(40,40),(70,50),(50,70),(100,100)]:
          c=count(w,1,H0,1,H1);b=0
          for n in range(1,H0+1,2):
            if word(n,l)==w:
              x=n
              for _ in range(l):x,_=step(x)
              if x<=H1:b+=1
          assert c==b,(w,H0,H1,c,b);cases+=1
    print('exact two-sided cases',cases)
    print('CP20 TASK2 ENGINE A: OK')
if __name__=='__main__':main()
