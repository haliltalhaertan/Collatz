# CP20 TASK 3 — RESIDUE-CONDITIONED FLUX GRAPH

## [EXACT] Odd-modulus graph has no valuation-language entropy deficit

Fix an odd modulus \(M\). For valuation label \(a\ge1\), define

\[
T_a(r)=(3r+1)2^{-a}\pmod M.
\]

Because \(2\) is invertible modulo \(M\), this is defined for every residue \(r\).

For any \(r\pmod M\) and any \(a\), CRT combines

- \(n\equiv r\pmod M\), and
- the unique exact-valuation class modulo \(2^{a+1}\),

so the labelled edge is represented by infinitely many actual integers.

Let a finite valuation alphabet \(\mathcal A\) carry weight \(z^a\). The weighted adjacency matrix has row sum

\[
S(z)=\sum_{a\in\mathcal A}z^a
\]

for every row. Therefore the all-ones vector is an eigenvector with eigenvalue \(S(z)\), while the nonnegative row-sum bound gives

\[
\boxed{
\rho(M,z)=S(z).
}
\]

So the odd-modulus residue graph has **exactly the unrestricted labelled-path growth**.

This was checked for multiple moduli/alphabet choices in `CP20_TASK3_RESIDUE_DATA.csv`, together with 288 exact CRT edge realizations.

## [FAIL] Powers of two

A \(2^q\) refinement re-encodes the valuation cylinder itself. Every finite positive valuation word already has one exact start cylinder modulo \(2^{A+1}\). Partitioning that cylinder by a fixed finite \(2^q\) state is not an independent entropy penalty.

No residue-conditioned exponential saving independent of the frozen Task-1 cylinder entropy was found.
