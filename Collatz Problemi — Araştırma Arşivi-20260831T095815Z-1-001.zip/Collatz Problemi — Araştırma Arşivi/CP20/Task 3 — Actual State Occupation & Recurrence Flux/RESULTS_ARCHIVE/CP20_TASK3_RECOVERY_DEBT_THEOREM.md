# CP20 TASK 3 — RECOVERY DEBT

## [EXACT] Fastest possible recovery

Suppose state \(x\) takes an exact valuation-\(a\) step,

\[
y=\frac{3x+1}{2^a},\qquad a\ge2.
\]

Every future Syracuse step satisfies

\[
T_b(z)=\frac{3z+1}{2^b}\le T_1(z)=\frac{3z+1}{2}.
\]

Hence the fastest conceivable return to height \(x\) is obtained by pretending that **every subsequent valuation is \(1\)**.

Since

\[
T_1^m(y)+1=\left(\frac32\right)^m(y+1),
\]

any actual return to a state at least \(x\) within \(m\) further steps requires

\[
\boxed{
3^m(3x+1+2^a)\ge 2^{m+a}(x+1).
}
\]

Therefore the exact relaxed recovery debt is

\[
\boxed{
m_*(x,a)=
\min\{m\ge0:
3^m(3x+1+2^a)\ge2^{m+a}(x+1)\}.
}
\]

Actual phase restrictions can only increase this duration.

As \(x\to\infty\), the threshold is governed by

\[
\left(\frac32\right)^m\ge\frac{2^a}{3},
\]

so the familiar asymptotic scale is

\[
m\approx \frac{a-\alpha}{\alpha-1}.
\]

## [FAIL] Why the debt does not become a new occupation theorem

Summing the debts of individual drops independently is invalid: recovery intervals can overlap. A single later ascent can repay several nested deficits.

The explicit 20-block symbolic controller in `CP20_TASK3_ADVERSARIAL_SURVIVOR.md` uses only

\[
a\in\{1,2,3\},
\]

has no exact critical sites, tracks

\[
s_k=\kappa\log_2k+O(1)
\]

for every fixed \(1<\kappa<2\), and has convergent carry.

Thus all large-drop tails can be eliminated while the high-state morphology remains. Any theorem based only on repeated large \(a\) events misses this survivor.

The recovery theorem is exact, but it is **not** a new load-bearing occupation bound.
