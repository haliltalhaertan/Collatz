# CP20 TASK 3 — ADVERSARIAL FLUX SURVIVOR

## [EXACT] Infinite zero-critical bounded-valuation construction

Let

\[
g_k=F_{k+1}-F_k\in\{1,2\}.
\]

In any 20 consecutive positions,

\[
F_{u+20}-F_u\in\{31,32\},
\]

because

\[
2^{31}<3^{20}<2^{32}.
\]

Therefore every length-20 block contains exactly 11 or 12 sites with \(g_k=2\).

Choose defects only from

\[
\boxed{d_k\in\{-1,+1\}},
\]

with \(+1\) used only where \(g_k=2\). Then

\[
a_k=g_k-d_k\in\{1,2,3\}
\]

and **no site is exact critical** \((d_k=0)\).

In each 20-block:

- choose exactly 10 of the available \(g=2\) sites with \(d=+1\) to make block net defect 0;
- or choose exactly 11 such sites to make block net defect +2.

Fix any

\[
1<\kappa<2.
\]

At successive block boundaries choose the +2 option only when needed to track the increasing target

\[
T_m=\kappa\log_2(20m).
\]

Since

\[
T_{m+1}-T_m<2
\]

and block increments are 0 or 2, a greedy choice keeps boundary error bounded by an absolute constant. Inside a block only 20 unit defect moves occur. Consequently

\[
\boxed{s_k=\kappa\log_2k+O(1).}
\]

## [EXACT] Carry and occupation compatibility

Because

\[
D_k=-s_k-\{\alpha k\},
\]

\[
2^{D_k}\le Ck^{-\kappa}.
\]

Thus for every \(\kappa>1\),

\[
\boxed{X_\infty<\infty.}
\]

Also

\[
E_k=s_k-\lfloor\log_2k\rfloor
=(\kappa-1)\log_2k+O(1),
\]

so the frozen CP17/CP18 low-\(E\) occupation exclusions are satisfied strongly: their low-threshold sets are eventually empty.

## [EXACT] Asymptotic valuation frequencies

The number of +1 defects is \(10\) per block plus only \(O(\log K)\) extra gain choices, hence

\[
\Pr(a=1)\to\frac12.
\]

The asymptotic fraction of \(g=1\) sites is \(2-\alpha\), and all of them have \(d=-1\), hence

\[
\Pr(a=2)\to2-\alpha.
\]

The remaining fraction is

\[
\boxed{
\Pr(a=3)\to\alpha-\frac32.
}
\]

There are no \(a\ge4\) events at all.

## LEVEL distinction

Every finite prefix is exactly positive-realizable by cylinder arithmetic, and infinitely many sufficiently high finite lifts are injective.

But one fixed positive ordinary integer realizing the entire infinite word is not proved.

\[
\boxed{\text{LEVEL 3 status: [OPEN].}}
\]
