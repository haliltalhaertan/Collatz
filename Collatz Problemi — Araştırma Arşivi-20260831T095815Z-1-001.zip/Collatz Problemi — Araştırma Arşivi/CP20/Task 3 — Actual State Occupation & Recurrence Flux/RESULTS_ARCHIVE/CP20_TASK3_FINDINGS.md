# COLLATZ CP20 — TASK 3 FINDINGS
## Actual State Occupation • Multiplicative Height Bands • Recurrence Flux

## Final verdict

\[
\boxed{{\textbf{{A — [FAIL: FLUX/OCCUPATION DOES NOT RAISE THRESHOLD]}}}}
\]

No new arithmetic flux entropy deficit, threshold improvement, or high-state LEVEL-3 exclusion was obtained.

The audited threshold remains

\[
\boxed{\kappa_0=1.0526808586079717.}
\]

## [EXACT] What survived

Task 3 did produce several exact structural lemmas:

1. exact one-step up/down geometry;
2. exact threshold crossing intervals and residues;
3. exact fastest-possible recovery debt after a valuation drop;
4. exact signed height-flux identity;
5. exact odd-modulus residue-graph row-sum theorem;
6. exact finite-lift high-shell saturation for any finite valuation word;
7. an explicit infinite bounded-valuation, zero-critical symbolic high-state construction.

These are useful, but none supplies an independent polynomial saving beyond frozen Task 1.

## [FAIL] Why recovery debt is insufficient

Large \(a\) events do create a real recovery debt. But the survivor can avoid them entirely.

The exact 20-block controller uses only

\[
a\in\{1,2,3\},
\]

no critical sites, and tracks

\[
s_k=\kappa\log_2k+O(1)
\]

for every fixed \(1<\kappa<2\), including \(\kappa=\kappa_0\) and \(1.053\).

Hence a large-drop occupation theorem cannot cover the frontier.

## [FAIL] Why flux does not control high occupation

For a threshold \(H\),

\[
U_H-D_H=I_{\rm final}(H)-I_{\rm initial}(H).
\]

This controls only signed crossings. A path may enter once and remain high.

The exact number of possible a=1 entrance integers is \(H/12+O(1)\). At the superlinear scale \(H=N^\kappa\), \(\kappa>1\), this is larger than the \(N\)-long index block and therefore gives no sublinear occupation bound.

## [FAIL] Residue arithmetic does not add a second entropy saving

For every odd modulus \(M\), every residue and every valuation label \(a\) has an exact CRT realization. The weighted residue transition matrix has constant row sum

\[
\sum_a z^a,
\]

so its spectral radius is exactly that row sum. Odd residues delete no valuation words.

Power-of-two refinement simply re-encodes the valuation cylinder already used in Task 1.

## [EXACT] Finite integer realizability is not the obstruction

For a finite valuation word \(W\), all cylinder lifts

\[
n_0=\rho_W+m2^{{A(W)+1}}
\]

realize the same word. Internal states are affine in \(m\), so bounded-discrepancy words remain in a bounded multiplicative shell as \(m\to\infty\).

Only finitely many lift values can create an internal repeated state. Thus there are infinitely many arbitrarily high **injective finite integer realizers**.

This kills any proposed finite-horizon theorem saying ordinary residue arithmetic itself prevents the high-shell morphology.

It does not solve LEVEL 3.

## [CERTIFIED NUM] Diagnostics

- 56 exact crossing-family checks passed.
- 12,500 exact recovery-state checks passed.
- 160 weighted odd-modulus graph checks passed.
- 288 CRT edge realizations passed.
- 12 high-shell finite injective lifts were explicitly generated.
- genuine Syracuse trajectories for six starting integers were scanned only as diagnostics; they show repeated up/down flux and recovery overlap, but carry no infinite proof.

The zero-critical controller at \(\kappa=1.053\) over 250,300 steps had frequencies close to the exact limits

\[
(1/2,\ 2-\alpha,\ \alpha-3/2)
\]

for \(a=1,2,3\).

## Threshold

No rigorous flux saving \(\sigma>0\) exists from the tested mechanisms, so

\[
\boxed{\kappa_{\rm new}=\kappa_0=1.0526808586079717}
\]

and the improvement is exactly zero.

## Exact surviving LEVEL-3 requirement

The remaining issue is no longer finite shell geometry, finite cylinder realizability, recovery speed, or finite residue flux.

The surviving requirement is:

\[
\boxed{{
\text{Can one fixed positive ordinary integer realize an infinite bounded-valuation}\
\text{high-state word }s_k=\kappa\log_2k+O(1),\ \kappa\ge\kappa_0?
}}
\]

Every finite prefix can be realized high and injectively; global one-start coherence remains open.

This is an ordinary LEVEL-3 integrality/coherence problem, but the previously parked critical-density high-bit mechanism should not simply be reopened under a new name.

## Required question table

| Question | Verdict |
|---|---|
| Exact up/down geometry? | `[EXACT]` |
| Recovery cost after a large drop? | `[EXACT]` |
| Does recovery debt force occupation loss at the frontier? | `[FAIL]` |
| Can bounded valuations evade large-drop arguments? | `[EXACT] YES` |
| Does signed shell flux bound occupation? | `[FAIL]` |
| Do exact upcross residues give polynomial saving? | `[FAIL]` |
| Does odd-modulus residue flux reduce entropy? | `[FAIL]` — exact row-sum saturation |
| Do finite integer realizers resist high shells? | `[FAIL]` — infinitely many high injective finite lifts |
| Does CP17 lower-tail occupation contradict the symbolic survivor? | `[FAIL]` |
| Is \(\kappa_{new}>\kappa_0\)? | **NO** |
| High-state LEVEL-3 class excluded? | **NO — `[OPEN]`** |
| Side B? | **NO** |

## Strategic conclusion

The Task-3 failure conditions are all met. Increasing residue moduli, trajectory lengths, or shell resolution would merely deepen diagnostics without isolating a new arithmetic ingredient.

The next branch should therefore not be “more flux”. It must attack **global one-start coherence of bounded-valuation high-state words** using a mechanism distinct from the parked pure-neutral high-half classifier.
