# CP20 TASK 3 — UPCROSSING ARITHMETIC

## [EXACT] One threshold

An upcrossing of \(H\) must satisfy

\[
a=1,
\quad n\equiv3\pmod4,
\quad
\left\lceil\frac{2H-1}{3}\right\rceil\le n\le H-1.
\]

This produces \(H/12+O(1)\) candidate integers.

Refining to higher powers of two does not create a new independent density factor. The exact valuation condition is already the first cylinder condition.

## [FAIL] Repeated thresholds

Crossings of nearby multiplicative thresholds are not independent events: one upward step may cross several thresholds, and a path may enter a high region once and then remain there.

Treating residue densities at multiple thresholds as multiplicative would repeat the same independence error killed in CP20 Task 2.

## [EXACT] Odd-modulus CRT compatibility

For any odd modulus \(M\), residue \(r\pmod M\), and prescribed valuation \(a\), the exact valuation residue modulo \(2^{a+1}\) combines with \(r\) by CRT. Hence every odd-modulus state has a realizable outgoing edge labelled by every positive valuation \(a\).

This observation is used in the residue-graph theorem.
