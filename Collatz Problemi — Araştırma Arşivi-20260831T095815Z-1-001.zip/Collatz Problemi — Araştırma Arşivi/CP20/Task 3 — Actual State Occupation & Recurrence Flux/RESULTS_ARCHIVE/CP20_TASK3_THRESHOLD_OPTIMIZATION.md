# CP20 TASK 3 — THRESHOLD OPTIMIZATION

The frozen quantile exponent is

\[
\rho_1=\max\{{c h(\mu),\ \kappa-c\eta(\mu)\}}.
\]

Task 3 searched for an independent flux/occupation saving

\[
\sigma_{\rm flux}(\kappa,\ldots)>0.
\]

No such rigorous saving was obtained.

The exact outcome of the Task-3 mechanisms is therefore

\[
\boxed{{\sigma_{\rm flux}=0}}
\]

at theorem level, so the optimization remains unchanged:

\[
\boxed{{
\kappa_{\rm new}=\kappa_0=1.0526808586079717.
}}
\]

Hence

\[
\boxed{{\kappa_{\rm new}-\kappa_0=0.}}
\]

There is no analytic \(\varepsilon>0\), no uniform neighborhood gain around \(\mu=\alpha\), and no improvement surviving the near-critical channel.

The exact 20-block symbolic construction exists at \(\kappa=\kappa_0\) itself and for every fixed \(1<\kappa<2\), so the abstract adversary reaches the audited boundary.
