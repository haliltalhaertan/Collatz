# CP20 TASK 3 — ONE-STEP FLUX GEOMETRY

## [EXACT] Up/down classification

For the odd-only Syracuse step

\[
n' = \frac{3n+1}{2^a},\qquad a=v_2(3n+1)\ge1,
\]

\[
\frac{n'}n=\frac{3+1/n}{2^a}.
\]

For positive odd \(n\):

- \(a=1\) is strictly upward;
- \(a\ge2\) is non-upward, with equality only at \((n,a)=(1,2)\).

A positive injective infinite orbit cannot contain the fixed point \(1\), so on the research domain every \(a\ge2\) step is strictly downward.

For \(a=1\), exact valuation requires

\[
\boxed{n\equiv3\pmod4}
\]

and

\[
\frac{n'}n=\frac32+\frac1{2n}\le\frac53,
\]

with equality at \(n=3\). If \(n\ge H\),

\[
\log_2\frac{n'}n\le \log_2\!\left(\frac{3+1/H}{2}\right).
\]

For \(a\ge2\) and \(n\ge H\),

\[
\boxed{
\log_2\frac n{n'}
\ge a-\log_2(3+1/H).
}
\]

## [EXACT] Upcrossing of a fixed threshold

If

\[
n<H\le n',
\]

then necessarily \(a=1\) and

\[
\boxed{
\left\lceil\frac{2H-1}{3}\right\rceil
\le n\le H-1,
\qquad n\equiv3\pmod4.
}
\]

Thus all possible integer entrance states lie in one arithmetic progression inside an interval of length asymptotic to \(H/3\). Their number is \(H/12+O(1)\).

## [EXACT] Downcrossing

For a prescribed \(a\ge2\), exact valuation is the unique residue

\[
\boxed{
3n\equiv2^a-1\pmod{2^{a+1}}.
}
\]

If

\[
n\ge H>n',
\]

then

\[
\boxed{
H\le n\le\left\lfloor\frac{2^aH-2}{3}\right\rfloor
}
\]

inside that residue class modulo \(2^{a+1}\).

These formulas were exhaustively checked on the finite ranges in `CP20_TASK3_GEOMETRY_CHECKS.csv`.
