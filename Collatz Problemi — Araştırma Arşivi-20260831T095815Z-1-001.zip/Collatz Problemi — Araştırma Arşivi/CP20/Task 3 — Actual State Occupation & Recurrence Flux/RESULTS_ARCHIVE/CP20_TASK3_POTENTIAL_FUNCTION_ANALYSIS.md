# CP20 TASK 3 — POTENTIAL FUNCTION ANALYSIS

## Exact log balance

For every actual positive orbit,

\[
\boxed{
\log_2 n_{k+1}-\log_2n_k
=
\alpha-a_k+
\log_2\left(1+\frac1{3n_k}\right).
}
\]

Summing gives the exact telescoping balance requested in the Task-3 prompt.

## [FAIL] Linear log potentials

For

\[
\Psi_k(\lambda)=\log_2n_k-\lambda\log_2k,
\]

the total drift is exactly the log-balance identity minus the telescoping deterministic \(\lambda\log k\) term. It introduces no new sign constraint.

## [FAIL] Reciprocal powers

For

\[
\Phi_k(\lambda)=n_k^{-\lambda},
\]

\[
\frac{\Phi_{k+1}}{\Phi_k}
=
\left(\frac{2^{a_k}}{3+1/n_k}\right)^\lambda.
\]

Upward and downward contributions have opposite signs, but no deterministic frequency inequality beyond the valuation balance was found. The symbolic high-state controller explicitly balances them while keeping \(s_k\sim\kappa\log k\).

## [FAIL] Threshold and piecewise-linear potentials

Threshold indicators telescope to the signed-flux identity. Piecewise-linear functions of \(\log n\) decompose into linear drift plus threshold crossing terms. Without an independent bound on total crossing structure, they produce no upper-tail occupation theorem.

The 20-block symbolic model satisfies all these deterministic identities and therefore falsifies any universal contradiction based only on these potential layers.
