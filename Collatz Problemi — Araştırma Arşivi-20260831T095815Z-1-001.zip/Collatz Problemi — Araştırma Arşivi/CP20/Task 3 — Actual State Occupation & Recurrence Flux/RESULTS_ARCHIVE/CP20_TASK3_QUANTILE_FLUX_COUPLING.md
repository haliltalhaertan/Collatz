# CP20 TASK 3 — QUANTILE / FLUX COUPLING

Frozen CP20 Task 1 shows that below the audited threshold, starts cannot be simultaneously low-state and low-window on polynomially most indices.

Task 3 asked whether the complementary high-state starts can themselves be polynomially rare because high shells have limited entrance/recovery flux.

## [FAIL] No sublinear high-state count follows

Three independent obstructions prevent the desired estimate

\[
\#\{k\in[N,2N):n_k\ge N^\kappa\}
\le N^{1-\delta+o(1)}.
\]

1. A high region may be entered once and occupied for \(\Theta(N)\) steps.
2. Exact upcrossing capacity at height \(H=N^\kappa\) is \(\asymp H\), which exceeds \(N\) for \(\kappa>1\).
3. The bounded-valuation symbolic controller has no large recovery debts and is compatible with convergent carry and CP17 lower-tail occupation.

## Conditional LEVEL-3 morphology

For the symbolic controller,

\[
s_k=\kappa\log_2k+O(1),\qquad \kappa>1,
\]

and

\[
X_\infty<\infty.
\]

If its inverse-limit realizer were one fixed positive ordinary integer, then \(U_k\to U_\infty\in(1,\infty)\) and

\[
\boxed{
n_k=k^{\kappa+o(1)}.
}
\]

It would therefore occupy the high-state polynomial regime on essentially all sufficiently large times while satisfying the flux identities.

That LEVEL-3 ordinary-integrality premise remains `[OPEN]`.
