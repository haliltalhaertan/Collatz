# CP20 TASK 8A — FULL-SCALE ACCUMULATION LEMMA

**Date:** 2026-08-26  
**Status:** `[PROVED — AUDIT EXTENSION CANDIDATE]`

This strengthening was suggested by the independent auditor after accepting
the original Task-8A accumulation theorem. It is mathematically proved here,
but it is kept outside the independently-audited freeze core until separately
audited.

## 1. Reachability of an arbitrary large scale

Put
\[
c=\alpha/\kappa>0.
\]

Given a sufficiently large integer \(N\), write
\[
L=\log_2N.
\]

Choose \(r\) to be the smallest positive integer satisfying
\[
cr-\sqrt r\ge L.
\]

Then
\[
s:=cr-L\ge\sqrt r.
\]

By minimality,
\[
c(r-1)-\sqrt{r-1}<L,
\]
so
\[
s=cr-L
<
c+\sqrt{r-1}.
\]

For all sufficiently large \(r\), \(\sqrt r\ge c\), hence
\[
c+\sqrt{r-1}
\le
c+\sqrt r
\le
2\sqrt r.
\]

Therefore
\[
\boxed{
\sqrt r\le s<2\sqrt r.
}
\]

Define
\[
\varepsilon=\frac{s}{r}.
\]
Then
\[
\frac1{\sqrt r}\le\varepsilon<\frac2{\sqrt r},
\]
so
\[
\varepsilon\to0,
\qquad
r\varepsilon=s\to\infty.
\]

Moreover,
\[
(c-\varepsilon)r=L,
\]
and therefore exactly
\[
\boxed{
N=\left\lfloor2^{(c-\varepsilon)r}\right\rfloor.
}
\]

Thus every sufficiently large integer scale is representable by a valid
Task-6 counting pair \((r,\varepsilon)\) with the required vanishing-epsilon
and diverging-gap properties.

## 2. Arbitrary scale sequences

Let \(N_j\to\infty\) be arbitrary.

Apply the construction above to obtain \(r_j\to\infty\) and
\(\varepsilon_j\) satisfying
\[
N_j=
\left\lfloor
2^{(\alpha/\kappa-\varepsilon_j)r_j}
\right\rfloor,
\qquad
\varepsilon_j\to0,
\qquad
r_j\varepsilon_j\to\infty.
\]

If some integer \(r\) is produced more than once, discard repetitions when
passing to an accumulation subsequence. Since \(r_j\to\infty\), every
accumulation point of the density vectors has a subsequence with strictly
increasing \(r_j\).

The repaired Task-8A counting argument therefore applies to that subsequence.

## 3. Full-scale accumulation statement

Define
\[
D_i(N)
=
\frac1N
\#\{k\in[N,2N):k\text{ is type-i critical}\}.
\]

Then for every sequence \(N_j\to\infty\), every accumulation point
\[
\rho
\in
\operatorname{Acc}
\{(D_1(N_j),D_2(N_j))\}
\]
satisfies
\[
\boxed{
\rho\in\mathcal F
}
\]
and
\[
\boxed{
h(\rho)\ge\frac{\alpha}{\kappa}.
}
\]

The theorem is intentionally stated on accumulation points.
At finite \(N\), the exact density vector may sit \(O(1/N)\) outside the
zero-defect feasible region, so no literal finite-\(N\) extended-value
expression \(h(D(N))\) is asserted.

## 4. Audit status

The independent auditor supplied the reachability observation, but the
domain-reconciled full proof above was assembled after that audit.

Therefore this lemma is:
\[
\boxed{\texttt{[PROVED — AUDIT EXTENSION CANDIDATE]}}
\]

It is not labelled independently audited or frozen in the V3 freeze core.
