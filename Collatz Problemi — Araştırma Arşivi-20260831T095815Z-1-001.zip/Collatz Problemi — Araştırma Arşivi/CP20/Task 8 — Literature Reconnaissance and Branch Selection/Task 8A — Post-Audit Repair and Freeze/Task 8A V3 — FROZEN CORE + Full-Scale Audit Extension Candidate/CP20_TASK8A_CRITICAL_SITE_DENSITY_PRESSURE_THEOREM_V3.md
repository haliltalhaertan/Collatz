# CP20 TASK 8A — CRITICAL-SITE DENSITY PRESSURE THEOREM V3

**Date:** 2026-08-26  
**Core status:** `[PROVED][INDEPENDENTLY AUDITED][POST-AUDIT REPAIRED][READY TO FREEZE]`  
**Full-scale strengthening:** `[PROVED — AUDIT EXTENSION CANDIDATE]`

This V3 supersedes V2 for downstream wording after freeze, while preserving
all historical V2 artifacts.

The independent zero-trust audit verdict was
`[PROOF VALID WITH WORDING REPAIR]`.
The two load-bearing wording repairs requested by the auditor are integrated:

1. the pressure is restricted to the correct zero-defect feasible region;
2. the false global finite-optimizer cover is replaced by a two-regime
   uniformity lemma.

The V3 numerical certificate also removes the unproved \(R(t)\)-monotonicity
dependency.

## 1. Setting

Let
\[
\alpha=\log_2 3,
\quad
F_k=\lfloor\alpha k\rfloor,
\quad
g_k=F_{k+1}-F_k\in\{1,2\},
\]
and
\[
A_k=\sum_{i<k}a_i,
\qquad
s_k=F_k-A_k.
\]

Assume a positive ordinary odd-only Syracuse orbit satisfies
\[
\boxed{
s_k=\kappa\log_2k+O(1),
\qquad
\kappa>1.
}
\]

Put
\[
M_1=2-\alpha,
\qquad
M_2=\alpha-1.
\]

A critical site is a site with \(a_k=g_k\).

Type 1:
\[
g_k=1,\quad a_k=1.
\]

Type 2:
\[
g_k=2,\quad a_k=2.
\]

For a length-\(r\) block, let \(\rho_i\) denote the normalized count of
type-\(i\) critical sites.

## 2. Feasible pressure domain

Set
\[
P=M_1-\rho_1,
\qquad
Q=M_2-\rho_2.
\]

Exact zero total defect requires
\[
Q\ge P.
\]

Hence the canonical feasible set is
\[
\boxed{
\mathcal F=
\left\{
(\rho_1,\rho_2):
0\le\rho_1\le M_1,\;
0\le\rho_2\le M_2,\;
\rho_1-\rho_2\ge M_1-M_2
\right\}.
}
\]

\(\mathcal F\) is closed and convex.

For \(t>1\),
\[
A(t)=\frac1{t-1},
\qquad
B(t)=t+\frac1{t-1}.
\]

Define
\[
E_i(\rho_i)
=
M_i\log_2M_i
-(M_i-\rho_i)\log_2(M_i-\rho_i)
-\rho_i\log_2\rho_i.
\]

On \(\mathcal F\),
\[
\boxed{
h(\rho_1,\rho_2)
=
E_1+E_2
+
\inf_{t>1}
\left[
P\log_2A(t)+Q\log_2B(t)
\right].
}
\]

On \(\mathcal F\),
\[
h\ge0.
\]

Outside \(\mathcal F\), the exact zero-defect type language is empty, and
one may use the extended convention \(h=-\infty\), but no finite-type
Jensen argument treats those points as ordinary finite pressure points.

The example
\[
h(0,M_2)=-\infty
\]
records explicitly why the old V2 full-box domain was incorrect.

## 3. Exact saddle formula

Put
\[
y=t-1.
\]

At an interior optimum \(Q>P\), the exact saddle equation is
\[
\boxed{
(Q-P)y^2-Py-(P+Q)=0.
}
\]

It has a unique positive root.

At the boundary \(Q=P\), the finite optimizer escapes to \(t=\infty\), and
\[
\boxed{
h(\rho)=E_1(\rho_1)+E_2(\rho_2).
}
\]

The exact boundary fixed-\(T\) overshoot is
\[
\boxed{
\Phi_T(\rho)-h(\rho)
=
P\log_2
\left(
\frac{T^2-T+1}{(T-1)^2}
\right)
=
O(1/T).
}
\]

## 4. Fixed-type counting

For a fixed Sturmian phase factor with exact phase counts \(n_1,n_2\), and
fixed critical counts \(m_1,m_2\), the critical positions contribute
\[
\binom{n_1}{m_1}\binom{n_2}{m_2}.
\]

The noncritical defect partition functions are exactly \(A(t)\) and \(B(t)\).

If \(N(S)\) counts words with total defect \(S\), then
\[
N(S)t^S
\le
\binom{n_1}{m_1}\binom{n_2}{m_2}
A(t)^{n_1-m_1}
B(t)^{n_2-m_2},
\]
so
\[
\boxed{
N(S)
\le
\binom{n_1}{m_1}\binom{n_2}{m_2}
A(t)^{n_1-m_1}
B(t)^{n_2-m_2}
t^{-S}.
}
\]

The Sturmian balance gives
\[
n_i=M_i r+O(1).
\]

On the Task-6 counting windows,
\[
S=s_{u+r}-s_u=O(1).
\]

A realised finite type can lie \(O(1/r)\) outside \(\mathcal F\).
Project it to a nearest feasible type
\[
\widehat\sigma\in\mathcal F.
\]
Then
\[
\|\sigma-\widehat\sigma\|=O(1/r).
\]

All asymptotic pressure and Jensen steps are applied to the feasible projected
types. The projection and finite \(S\) change the exponent only by \(o(r)\).

## 5. Concavity

The Legendre representation is
\[
h(\rho_1,\rho_2)
=
\inf_{t>1,\mu_1,\mu_2}
\Big[
M_1\log_2(A(t)+2^{\mu_1})
+
M_2\log_2(B(t)+2^{\mu_2})
-\mu_1\rho_1-\mu_2\rho_2
\Big].
\]

Thus \(h\) is an infimum of affine functions of \(\rho\), so
\[
\boxed{
h\text{ is concave on }\mathcal F.
}
\]

The stationary multipliers satisfy
\[
2^{\mu_1}
=
\frac{\rho_1A}{M_1-\rho_1},
\qquad
2^{\mu_2}
=
\frac{\rho_2B}{M_2-\rho_2}.
\]

## 6. Uniformity repair

The optimizer \(t_*(\rho)\) is not uniformly bounded as \(Q-P\downarrow0\).
Therefore V2's one-piece finite-cover statement is removed.

The V3 two-regime lemma proves:

For every \(\delta>0\), on the low-pressure feasible sublevel set
\[
K_\delta
=
\{\rho\in\mathcal F:
h(\rho)\le\alpha/\kappa-\delta\},
\]
there is a finite set of fixed Chernoff parameters
\[
\mathcal T_\delta
\]
such that
\[
\min_{T\in\mathcal T_\delta}\Phi_T(\rho)
\le
h(\rho)+\delta/4
\]
uniformly.

The proof splits into:

1. \(Q-P\ge\eta\): the quadratic saddle gives a uniform optimizer bound and
   compactness yields a finite cover;
2. \(0\le Q-P<\eta\): one sufficiently large fixed \(T\) handles the entire
   strip using the exact \(O(1/T)\) boundary overshoot and the bound
   \[
   P\log_2(AB)+ (Q-P)\log_2B.
   \]

This yields a genuine uniform exponential count for all low-pressure types.

## 7. Repaired Task-6 density bridge — canonical audited core

Let
\[
0<\varepsilon_r<\alpha/\kappa,
\qquad
\varepsilon_r\to0,
\qquad
r\varepsilon_r\to\infty,
\]
and
\[
N_r
=
\left\lfloor
2^{(\alpha/\kappa-\varepsilon_r)r}
\right\rfloor.
\]

The frozen Task-6 spacing argument still makes every length-\(r\) factor
beginning in
\[
[N_r,2N_r-r]
\]
distinct for all sufficiently large \(r\).

The number of starts is
\[
2^{(\alpha/\kappa-o(1))r}.
\]

There are only \(O(r^2)\) critical type pairs.
The V3 uniformity lemma implies that projected feasible types with
\[
h\le\alpha/\kappa-\delta
\]
can account for only an exponentially negligible fraction of the starts.

Let \(\widehat\sigma(u,r)\in\mathcal F\) be the projected feasible type.
Because \(\mathcal F\) is convex, the mean projected type is in
\(\mathcal F\). Concavity and \(h\ge0\) on \(\mathcal F\) give
\[
\liminf
h\left(
\frac1{L_r}
\sum_u\widehat\sigma(u,r)
\right)
\ge
\alpha/\kappa.
\]

The projection changes the mean by \(O(1/r)\).

Double counting critical incidences gives
\[
\frac1{L_r}\sum_u\sigma_i(u,r)
=
D_i(N_r)+O(r/N_r),
\]
where
\[
D_i(N)
=
\frac1N
\#\{k\in[N,2N):
k\text{ is type-i critical}\}.
\]

Therefore:

### CANONICAL AUDITED TASK-8A THEOREM

For every admissible \(\varepsilon_r\) sequence above, every accumulation
point
\[
\rho
\in
\operatorname{Acc}
\{(D_1(N_r),D_2(N_r))\}
\]
satisfies
\[
\boxed{\rho\in\mathcal F}
\]
and
\[
\boxed{
h(\rho_1,\rho_2)
\ge
\frac{\alpha}{\kappa}.
}
\]

This is the repaired theorem covered by the independent audit after the
mandated wording repairs.

## 8. Corollaries inside the freeze core

### Natural-density corollary

If the natural type densities exist,
\[
\frac1N
\#\{k<N:k\text{ is type-i critical}\}
\to\rho_i,
\]
then
\[
\boxed{
\rho\in\mathcal F,
\qquad
h(\rho)\ge\alpha/\kappa.
}
\]

### Zero critical density corollary

Suppose only
\[
\#\{k<N:a_k=g_k\}=o(N).
\]

Then
\[
D_1(N)+D_2(N)\to0.
\]
Hence the audited accumulation theorem has the unique density limit
\[
(0,0).
\]

Therefore
\[
h(0,0)\ge\alpha/\kappa,
\]
so
\[
\boxed{
\kappa\ge\frac{\alpha}{h(0,0)}
=
\frac{\alpha}{h_\infty}
>
2.784.
}
\]

Thus **zero critical density is sufficient**.
Pointwise zero-criticality is not required.

This strictly strengthens the hypothesis form of frozen Task 7 while using
the same pressure endpoint.

## 9. CP19 Task-4 exact identity

When critical counts are unconstrained, every \(a\ge1\) is allowed and
\[
\sum_{a\ge1}t^{g-a}
=
\frac{t^g}{t-1}.
\]

Since the Sturmian phase has mean \(g=\alpha\) and only polynomial factor
complexity,
\[
H_{\rm all}(t)
=
\alpha\log_2t-\log_2(t-1).
\]

The unique minimizer is
\[
t_*=\frac{\alpha}{\alpha-1},
\]
and
\[
\boxed{
\max_{\rho\in\mathcal F}h(\rho)
=
h_{\rm CP19}(\alpha)
=
\alpha\log_2\alpha
-(\alpha-1)\log_2(\alpha-1).
}
\]

The maximizing densities are
\[
\boxed{
\rho_1^*=\frac{2-\alpha}{\alpha},
\qquad
\rho_2^*=\frac{(\alpha-1)^2}{\alpha^2}.
}
\]

They lie strictly inside \(\mathcal F\).

The old claim of a strict Sturmian phase cost at the optimized maximum remains
retracted.

## 10. One-fugacity anchors and zero-critical endpoint

For total critical density optimization, the one-fugacity saddle can be
parametrized by \(x=2^\mu\).

At the unrestricted CP19 optimum,
\[
\boxed{x(t_*)=1}
\]
exactly.

At the zero-critical endpoint,
\[
x(t_0)=0.
\]
Writing \(y_0=t_0-1\), the exact equation is
\[
\boxed{
(2\alpha-3)y_0^2-(2-\alpha)y_0-1=0.
}
\]

The positive root is
\[
\boxed{
y_0
=
\frac{
(2-\alpha)
+
\sqrt{(2-\alpha)^2+4(2\alpha-3)}
}{
2(2\alpha-3)
}.
}
\]

Thus
\[
t_0=1+y_0
\]
is exact.

The V3 interval certificate encloses
\[
t_0
\in
[4.9371845970284873,\,
 4.9371845970284874]
\]
and
\[
\frac{\alpha}{h(0,0)}
\in
[2.7840109030009018067\ldots,\,
 2.7840109030009019658\ldots].
\]

Decimals are informational; the defining root equation is exact.

## 11. Critical-density geometry

Define only on the feasible region:
\[
\boxed{
\rho_{\min}(\kappa)
=
\inf
\{
\rho_1+\rho_2:
\rho\in\mathcal F,\;
h(\rho)\ge\alpha/\kappa
\}.
}
\]

Let
\[
\kappa_*
=
\frac{\alpha}{h_{\rm CP19}(\alpha)},
\qquad
\kappa_0
=
\frac{\alpha}{h(0,0)}.
\]

Then:

1. if
   \[
   \kappa<\kappa_*,
   \]
   no feasible density pair satisfies the pressure demand;

2. if
   \[
   \kappa_*\le\kappa<\kappa_0,
   \]
   a positive critical density is forced:
   \[
   \rho_1+\rho_2\ge\rho_{\min}(\kappa)>0;
   \]

3. if
   \[
   \kappa\ge\kappa_0,
   \]
   Task 8A alone forces no positive total critical-density lower bound.

No monotonicity beyond the proved branch geometry is claimed.

The V3 certificate, using whole-box interval evaluation rather than
unproved \(R(t)\) monotonicity, certifies:

\[
\boxed{
0.3462262370615603636914
<
\rho_{\min}(1.06)
<
0.3462262370615928578729
}
\]

\[
\boxed{
0.0916083301662531377156
<
\rho_{\min}(1.5)
<
0.0916083301662716819078
}
\]

\[
\boxed{
0.0314445508714800107814
<
\rho_{\min}(2.0)
<
0.0314445508714920087543
}
\]

## 12. Structural asymmetry

At every interior minimal-total-density saddle,
\[
\frac{\rho_1}{M_1}
=
\frac{x}{A+x},
\qquad
\frac{\rho_2}{M_2}
=
\frac{x}{B+x}.
\]

Since
\[
B-A=t>0,
\]
\[
\boxed{
\frac{\rho_1}{M_1}
>
\frac{\rho_2}{M_2}.
}
\]

Type-1 criticality is therefore the cheaper escape direction relative to
available phase mass on that interior branch.

## 13. Full-scale strengthening

The separate file
`CP20_TASK8A_FULL_SCALE_ACCUMULATION_LEMMA.md`
proves that every sufficiently large integer \(N\) can be represented as a
valid Task-6 scale with
\[
\varepsilon\to0,
\qquad
r\varepsilon\to\infty.
\]

It yields the stronger statement:

For every sequence \(N_j\to\infty\), every accumulation point of
\[
(D_1(N_j),D_2(N_j))
\]
lies in \(\mathcal F\) and satisfies
\[
h(\rho)\ge\alpha/\kappa.
\]

Because the domain-reconciled full proof was assembled after the independent
audit, this strengthening is labelled
\[
\boxed{\texttt{[PROVED — AUDIT EXTENSION CANDIDATE]}}
\]
and is not part of the independently-audited frozen core until separately
audited.

## 14. Scope

This theorem does not:

- prove Collatz;
- remove the global critical-log hypothesis;
- treat \(\kappa\le1\);
- exclude the CP19 Task-5 excursion survivor;
- prove Task 8B;
- use continued fractions as theorem evidence;
- reopen the parked CP19 high-half/cross-adic branch.

## 15. Freeze recommendation

The repaired **core theorem** satisfies every mandatory audit repair and the
V3 certificate passes.

Recommended core status:
\[
\boxed{
\texttt{[PROVED][INDEPENDENTLY AUDITED][READY TO FREEZE]}.
}
\]

The full-scale strengthening remains separately
\[
\boxed{
\texttt{[PROVED — AUDIT EXTENSION CANDIDATE]}.
}
\]
