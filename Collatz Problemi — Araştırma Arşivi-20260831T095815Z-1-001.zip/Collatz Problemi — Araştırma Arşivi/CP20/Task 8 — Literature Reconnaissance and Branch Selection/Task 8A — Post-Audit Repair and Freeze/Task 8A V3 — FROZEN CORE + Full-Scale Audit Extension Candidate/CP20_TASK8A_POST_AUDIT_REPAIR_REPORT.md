# CP20 TASK 8A — POST-AUDIT REPAIR REPORT

**Date:** 2026-08-26  
**Independent audit verdict:** `[PROOF VALID WITH WORDING REPAIR]`

## Mandatory Repair A — Pressure domain

**Result: `[PASS]`**

Integrated:

- canonical feasible region
  \[
  \mathcal F=
  \{0\le\rho_i\le M_i,\;Q\ge P\};
  \]
- proof that \(\mathcal F\) is closed and convex;
- proof that \(h\ge0\) only on \(\mathcal F\);
- exact boundary \(Q=P\) limit;
- explicit empty-language example \(h(0,M_2)=-\infty\);
- finite realised types are only \(O(1/r)\) from \(\mathcal F\);
- projection-to-\(\mathcal F\) repair before Jensen.

No V3 proof evaluates an \(O(1/r)\)-infeasible finite type as an ordinary
finite zero-defect pressure point.

## Mandatory Repair B — Uniformity

**Result: `[PASS]`**

The false one-piece compactness argument is removed.

V3 uses:

- interior \(Q-P\ge\eta\): exact saddle quadratic gives uniformly bounded
  \(t_*\), then compactness gives a finite fixed-\(t\) cover;
- boundary strip \(0\le Q-P<\eta\): one large fixed \(T\) and the exact
  overshoot
  \[
  P\log_2\frac{T^2-T+1}{(T-1)^2}
  \]
  plus \((Q-P)\log_2B(T)\).

This gives a finite fixed-parameter family uniformly on every low-pressure
sublevel set.

## Mandatory Repair C — Certificate monotonicity hygiene

**Result: `[PASS]`**

The V2 script's endpoint interpretation of \(R(t)\) is removed.

V3 evaluates the entire certified \(t\)-box through directed interval
arithmetic.

The script does not assume or use monotonicity of \(R(t)\).

Output ends with:

`ALL V3 PROOF-CRITICAL INTERVAL ASSERTIONS: PASS`

## Exact saddle anchors

Added to V3:

\[
(Q-P)y^2-Py-(P+Q)=0.
\]

At the unrestricted CP19 optimum:
\[
x(t_*)=1.
\]

At the zero-critical endpoint:
\[
x(t_0)=0
\]
and
\[
(2\alpha-3)y_0^2-(2-\alpha)y_0-1=0.
\]

## Underclaim check

### Every-scale accumulation

A complete reachability proof is now written.
It proves the stronger full-scale accumulation theorem.

Because the domain-reconciled strengthening was assembled after the
independent audit, it is conservatively labelled:

`[PROVED — AUDIT EXTENSION CANDIDATE]`.

It is not included in the independently-audited freeze core.

### Zero critical density

This corollary does not need the full-scale extension.

If
\[
\#\{k<N:a_k=g_k\}=o(N),
\]
then along the already-audited Task-8A scales the multiplicative critical
densities tend to \((0,0)\), so
\[
\kappa\ge\alpha/h_\infty>2.784.
\]

Thus pointwise zero-criticality is not required.

## CP19 Task-5

Canonical source inspected.

Verdict:
`[CP19 TASK5 SURVIVOR NOT EXCLUDED — HYPOTHESIS MISMATCH]`.

## CP20 Task-3 retrospective

Canonical Task-3 findings explicitly used a bounded-\(\{1,2,3\}\),
zero-critical, critical-log controller for \(1<\kappa<2\) as a failure
countermodel.

Frozen Task 6/7 now prevents that object from serving as a positive ordinary
downstream countermodel.

Historical Task-3 `[FAIL]` is not changed.

Current retrospective label:
`[REOPEN CANDIDATE — PRIOR ESCAPE COUNTERMODEL SUPERSEDED]`.

## Final mechanical recommendation

Core:
`[PROVED][INDEPENDENTLY AUDITED][READY TO FREEZE]`.

Full-scale strengthening:
`[PROVED — AUDIT EXTENSION CANDIDATE]`.

No Task 8B work was started.
