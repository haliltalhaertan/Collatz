# CP20 TASK 8A — FREEZE CANDIDATE README

**Date:** 2026-08-26

## Status

Freeze core:
`[PROVED][INDEPENDENTLY AUDITED][POST-AUDIT REPAIRED][READY TO FREEZE]`

Full-scale strengthening:
`[PROVED — AUDIT EXTENSION CANDIDATE]`

No Task 8B content is included.

## Canonical repaired theorem

Under
\[
s_k=\kappa\log_2k+O(1),
\qquad
\kappa>1,
\]
define the multiplicative-window type-critical densities \(D_i(N)\).

For every audited Task-6 scale family
\[
N_r=
\lfloor
2^{(\alpha/\kappa-\varepsilon_r)r}
\rfloor,
\qquad
\varepsilon_r\to0,
\qquad
r\varepsilon_r\to\infty,
\]
every accumulation point \(\rho\) of
\((D_1(N_r),D_2(N_r))\) satisfies
\[
\rho\in\mathcal F
\]
and
\[
h(\rho)\ge\alpha/\kappa.
\]

The feasible region is
\[
\mathcal F=
\{
0\le\rho_1\le2-\alpha,\;
0\le\rho_2\le\alpha-1,\;
\rho_1-\rho_2\ge3-2\alpha
\}.
\]

## New freeze-core corollary

If the critical-site prefix count is \(o(N)\), then
\[
\kappa\ge\alpha/h_\infty>2.784.
\]

Pointwise zero-criticality is not required.

## Certified rho_min intervals

\[
0.3462262370615603636914
<
\rho_{\min}(1.06)
<
0.3462262370615928578729.
\]

\[
0.0916083301662531377156
<
\rho_{\min}(1.5)
<
0.0916083301662716819078.
\]

\[
0.0314445508714800107814
<
\rho_{\min}(2.0)
<
0.0314445508714920087543.
\]

The V3 certificate evaluates the whole \(t\)-box and uses no unproved
\(R(t)\) monotonicity.

## CP19 Task-5

`[NOT EXCLUDED — HYPOTHESIS MISMATCH]`.

## Package contents

1. `CP20_TASK8A_CRITICAL_SITE_DENSITY_PRESSURE_THEOREM_V3.md`
2. `CP20_TASK8A_UNIFORMITY_TWO_REGIME_LEMMA.md`
3. `CP20_TASK8A_FEASIBLE_DOMAIN_LEMMA.md`
4. `CP20_TASK8A_FULL_SCALE_ACCUMULATION_LEMMA.md`
5. `CP20_TASK8A_RIGOROUS_CERTIFICATE_V3.py`
6. `CP20_TASK8A_RIGOROUS_CERTIFICATE_V3_OUTPUT.txt`
7. `CP20_TASK8A_POST_AUDIT_REPAIR_REPORT.md`
8. `CP20_TASK8A_CP19T5_SCOPE_RESOLUTION.md`
9. `CP20_TASK8A_FREEZE_CANDIDATE_README.md`
10. `SHA256SUMS_V3.txt`

## Freeze recommendation

The independently-audited repaired core is ready to freeze.

The every-scale accumulation strengthening is deliberately kept outside the
independently-audited frozen dependency spine until a short extension audit
is performed.
