#!/usr/bin/env python3
"""
CP20 Task 8A — Rigorous Certificate V3
Date: 2026-08-26
Status: [POST-AUDIT REPAIRED — FREEZE CANDIDATE]

Proof-critical numerical work uses directed Decimal interval arithmetic.
Binary floating point is not used in any theorem-critical assertion.

V3 repair relative to the audited V2 certificate:
- rho_min is enclosed by evaluating the WHOLE certified t-box through
  interval arithmetic; no unproved monotonicity of R(t) is used.
- exact saddle/root anchors are checked against the repaired feasible domain.
"""

from decimal import Decimal, localcontext, ROUND_FLOOR, ROUND_CEILING, getcontext

PREC = 80
NLOG = 110
getcontext().prec = PREC + 15

def D(x):
    return x if isinstance(x, Decimal) else Decimal(str(x))

class Iv:
    __slots__ = ("lo","hi")
    def __init__(self, lo, hi=None):
        self.lo = D(lo)
        self.hi = self.lo if hi is None else D(hi)
        assert self.lo <= self.hi
    def __repr__(self):
        return f"[{self.lo}, {self.hi}]"

def add(a,b):
    with localcontext() as c:
        c.prec=PREC; c.rounding=ROUND_FLOOR
        lo=a.lo+b.lo
    with localcontext() as c:
        c.prec=PREC; c.rounding=ROUND_CEILING
        hi=a.hi+b.hi
    return Iv(lo,hi)

def neg(a):
    return Iv(-a.hi,-a.lo)

def sub(a,b):
    return add(a,neg(b))

def mul(a,b):
    lows=[]; highs=[]
    for x in (a.lo,a.hi):
        for y in (b.lo,b.hi):
            with localcontext() as c:
                c.prec=PREC; c.rounding=ROUND_FLOOR
                lows.append(x*y)
            with localcontext() as c:
                c.prec=PREC; c.rounding=ROUND_CEILING
                highs.append(x*y)
    return Iv(min(lows),max(highs))

def divpos(a,b):
    assert b.lo > 0
    with localcontext() as c:
        c.prec=PREC; c.rounding=ROUND_FLOOR
        rlo=Decimal(1)/b.hi
    with localcontext() as c:
        c.prec=PREC; c.rounding=ROUND_CEILING
        rhi=Decimal(1)/b.lo
    return mul(a,Iv(rlo,rhi))

ONE=Iv(1)
TWO=Iv(2)

def ln2_bounds():
    # ln 2 = 2 sum_{n>=0} (1/3)^(2n+1)/(2n+1)
    y=Iv(Decimal(1)/Decimal(3))
    y2=mul(y,y)
    term=y
    s=Iv(0)
    for n in range(NLOG):
        s=add(s,divpos(term,Iv(2*n+1)))
        term=mul(term,y2)
    s=mul(TWO,s)
    m=max(abs(y.lo),abs(y.hi))
    with localcontext() as c:
        c.prec=PREC; c.rounding=ROUND_CEILING
        rem=Decimal(2)*(m**(2*NLOG+1))/Decimal(2*NLOG+1)/(Decimal(1)-m*m)
    return Iv(s.lo-rem,s.hi+rem)

LN2=ln2_bounds()

def ln_point(x):
    assert x>0
    k=0
    m=x
    while m>=2:
        m=m/2; k+=1
    while m<1:
        m=m*2; k-=1
    y=divpos(sub(Iv(m),ONE),add(Iv(m),ONE))
    y2=mul(y,y)
    term=y
    s=Iv(0)
    for n in range(NLOG):
        s=add(s,divpos(term,Iv(2*n+1)))
        term=mul(term,y2)
    s=mul(TWO,s)
    ma=max(abs(y.lo),abs(y.hi))
    with localcontext() as c:
        c.prec=PREC; c.rounding=ROUND_CEILING
        rem=Decimal(2)*(ma**(2*NLOG+1))/Decimal(2*NLOG+1)/(Decimal(1)-ma*ma)
    ans=Iv(s.lo-rem,s.hi+rem)
    if k>0:
        ans=add(ans,mul(Iv(k),LN2))
    elif k<0:
        ans=sub(ans,mul(Iv(-k),LN2))
    return ans

def ln_iv(a):
    return Iv(ln_point(a.lo).lo,ln_point(a.hi).hi)

def log2_iv(a):
    return divpos(ln_iv(a),LN2)

LN3=ln_iv(Iv(3))
ALPHA=divpos(LN3,LN2)
M1=Iv(2-ALPHA.hi,2-ALPHA.lo)
M2=Iv(ALPHA.lo-1,ALPHA.hi-1)
DELTA=Iv(2*ALPHA.lo-3,2*ALPHA.hi-3)

def h0_at_t(T):
    Y=sub(T,ONE)
    A=divpos(ONE,Y)
    B=add(T,A)
    return add(mul(M1,log2_iv(A)),mul(M2,log2_iv(B)))

def dh0_at_point(t):
    T=Iv(t)
    Y=sub(T,ONE)
    A=divpos(ONE,Y)
    B=add(T,A)
    m1=neg(divpos(T,Y))
    invy2=divpos(ONE,mul(Y,Y))
    m2=divpos(mul(T,sub(ONE,invy2)),B)
    return add(mul(M1,m1),mul(M2,m2))

# Exact zero-critical saddle equation:
# (2 alpha - 3)y^2 - (2-alpha)y - 1 = 0, y=t-1.
def zero_root_poly(T):
    Y=sub(T,ONE)
    return sub(sub(mul(DELTA,mul(Y,Y)),mul(M1,Y)),ONE)

T0=Iv("4.9371845970284873","4.9371845970284874")
assert zero_root_poly(Iv(T0.lo)).hi < 0
assert zero_root_poly(Iv(T0.hi)).lo > 0
assert dh0_at_point(T0.lo).hi < 0
assert dh0_at_point(T0.hi).lo > 0
H0=h0_at_t(T0)
K0=divpos(ALPHA,H0)

# Exact CP19 Task-4 identity.
HMAX=sub(mul(ALPHA,log2_iv(ALPHA)),mul(M2,log2_iv(M2)))
KSTAR=divpos(ALPHA,HMAX)

def x_R_G(T):
    """
    Whole-box interval evaluation of the one-fugacity minimal-density saddle.
    No endpoint monotonicity assumption is used.

    y=t-1 and
      x(t)=
      [M1(y^2+y+1)-M2(y^2-1)]
      /
      [y(M2(y^2-1)-M1)].
    """
    Y=sub(T,ONE)
    Y2=mul(Y,Y)
    num=sub(
        mul(M1,add(add(Y2,Y),ONE)),
        mul(M2,sub(Y2,ONE))
    )
    den=mul(
        Y,
        sub(mul(M2,sub(Y2,ONE)),M1)
    )
    assert num.lo>0 and den.lo>0
    X=divpos(num,den)

    A=divpos(ONE,Y)
    B=add(T,A)
    Z1=add(A,X)
    Z2=add(B,X)

    rho1=mul(M1,divpos(X,Z1))
    rho2=mul(M2,divpos(X,Z2))
    R=add(rho1,rho2)

    Phi=add(mul(M1,log2_iv(Z1)),mul(M2,log2_iv(Z2)))
    mu=log2_iv(X)
    G=sub(Phi,mul(mu,R))

    P=sub(M1,rho1)
    Q=sub(M2,rho2)
    GAP=sub(Q,P)
    return X,rho1,rho2,R,G,GAP

def target(kappa):
    return divpos(ALPHA,Iv(kappa))

ROOTS=[
    ("1.06",
     "2.79477476165049","2.79477476165050",
     "0.3462262370615603636914",
     "0.3462262370615928578729"),
    ("1.5",
     "3.78215191151571","3.78215191151573",
     "0.0916083301662531377156",
     "0.0916083301662716819078"),
    ("2.0",
     "4.41721651712703","4.41721651712705",
     "0.0314445508714800107814",
     "0.0314445508714920087543"),
]

CERTS=[]
for k,tlo,thi,safe_lo,safe_hi in ROOTS:
    C=target(k)

    # Root existence is bracketed by endpoint signs.
    Glo=x_R_G(Iv(tlo))[4]
    Ghi=x_R_G(Iv(thi))[4]
    assert Glo.lo > C.hi
    assert Ghi.hi < C.lo

    # V3 hygiene repair: pass the WHOLE t-box through interval arithmetic.
    X,r1,r2,R,G,GAP=x_R_G(Iv(tlo,thi))
    assert X.lo>0 and X.hi<1
    assert GAP.lo>0  # all three saddles lie strictly inside feasible region.
    assert R.lo > D(safe_lo)
    assert R.hi < D(safe_hi)
    CERTS.append((k,tlo,thi,R,r1,r2,GAP))

# Unrestricted maximizing densities are inside F.
RHO1STAR=divpos(M1,ALPHA)
RHO2STAR=divpos(mul(M2,M2),mul(ALPHA,ALPHA))
PSTAR=sub(M1,RHO1STAR)
QSTAR=sub(M2,RHO2STAR)
assert sub(QSTAR,PSTAR).lo>0

print("CP20 TASK 8A — RIGOROUS CERTIFICATE V3")
print("Status: [POST-AUDIT REPAIRED — FREEZE CANDIDATE]")
print()
print("alpha =",ALPHA)
print("M1 =",M1)
print("M2 =",M2)
print("2 alpha - 3 =",DELTA)
print()
print("ZERO-CRITICAL CLOSED-FORM SADDLE")
print("Equation: (2 alpha - 3)y^2 - (2-alpha)y - 1 = 0, t0=1+y")
print("t0 in",T0)
print("root polynomial sign bracket: PASS")
print("derivative sign bracket: PASS")
print("h(0,0) =",H0)
print("kappa0=alpha/h(0,0) =",K0)
print()
print("CP19 TASK-4 EXACT MAXIMUM")
print("h_CP19(alpha) =",HMAX)
print("kappa*=alpha/h_CP19(alpha) =",KSTAR)
print("maximizing density pair lies strictly inside F: PASS")
print()
print("RHO_MIN WHOLE-BOX CERTIFICATES")
for k,tlo,thi,R,r1,r2,gap in CERTS:
    print("kappa =",k)
    print("  t box = [",tlo,",",thi,"]")
    print("  rho_min whole-box image =",R)
    print("  rho1 =",r1)
    print("  rho2 =",r2)
    print("  Q-P =",gap)
    print("  endpoint G-target sign change: PASS")
    print("  no R(t) monotonicity assumption: PASS")
print()
print("ALL V3 PROOF-CRITICAL INTERVAL ASSERTIONS: PASS")
