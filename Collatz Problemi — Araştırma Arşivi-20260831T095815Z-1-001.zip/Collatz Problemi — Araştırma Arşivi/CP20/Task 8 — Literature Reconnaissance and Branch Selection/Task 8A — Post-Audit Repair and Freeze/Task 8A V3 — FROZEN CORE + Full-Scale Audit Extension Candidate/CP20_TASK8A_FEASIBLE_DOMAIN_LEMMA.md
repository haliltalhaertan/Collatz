# CP20 TASK 8A — FEASIBLE DOMAIN LEMMA

**Date:** 2026-08-26  
**Status:** `[POST-AUDIT REPAIRED — FREEZE CORE]`

Let
\[
M_1=2-\alpha,\qquad M_2=\alpha-1,
\]
and for a critical-type density vector \(\rho=(\rho_1,\rho_2)\) define
\[
P=M_1-\rho_1,\qquad Q=M_2-\rho_2.
\]

Here \(P\) and \(Q\) are the asymptotic densities of noncritical sites of
phase type \(g=1\) and \(g=2\), respectively.

## 1. Exact feasibility region

At a noncritical \(g=1\) site,
\[
d=g-a\in\{-1,-2,\ldots\}.
\]
At a noncritical \(g=2\) site,
\[
d\in\{+1,-1,-2,\ldots\}.
\]

For exact total defect zero, the \(Q\)-mass of \(g=2\) noncritical sites is
the only source of positive defect, and each such site contributes at most
\(+1\). Each \(g=1\) noncritical site contributes at most \(-1\).
Therefore zero total defect requires
\[
Q\ge P.
\]

Equivalently,
\[
\rho_1-\rho_2\ge M_1-M_2.
\]

Define the canonical feasible region
\[
\boxed{
\mathcal F=
\left\{
(\rho_1,\rho_2):
0\le\rho_1\le M_1,\;
0\le\rho_2\le M_2,\;
\rho_1-\rho_2\ge M_1-M_2
\right\}.
}
\]

\(\mathcal F\) is the intersection of a closed rectangle and a closed
half-plane. Hence it is closed and convex.

Outside \(\mathcal F\), the exact zero-defect type language is empty at the
exponential model level. We may use the extended convention
\[
h(\rho)=-\infty\qquad(\rho\notin\mathcal F),
\]
but no Jensen or nonnegativity argument treats such points as ordinary finite
points.

For example,
\[
\rho=(0,M_2)
\]
has \(P=M_1>0,\;Q=0\); every noncritical defect is negative, so exact
zero total defect is impossible. Thus
\[
h(0,M_2)=-\infty.
\]

## 2. Pressure on the feasible region

For \(t>1\),
\[
A(t)=\frac1{t-1},
\qquad
B(t)=t+\frac1{t-1}.
\]

Let
\[
E_i(\rho_i)
=
M_i\log_2M_i
-(M_i-\rho_i)\log_2(M_i-\rho_i)
-\rho_i\log_2\rho_i
\]
with \(0\log0=0\).

On \(\mathcal F\), define
\[
\boxed{
h(\rho_1,\rho_2)
=
E_1(\rho_1)+E_2(\rho_2)
+
\inf_{t>1}
\left[
P\log_2A(t)+Q\log_2B(t)
\right].
}
\]

Because \(Q\ge P\),
\[
A(t)^P B(t)^Q
=
(A(t)B(t))^P B(t)^{Q-P}.
\]
For \(t>1\),
\[
B(t)>1,\qquad
A(t)B(t)
=
\frac{t^2-t+1}{(t-1)^2}>1.
\]
Hence the pressure core is nonnegative. Since each binomial entropy
\(E_i\ge0\),
\[
\boxed{h(\rho)\ge0\quad\text{for all }\rho\in\mathcal F.}
\]

## 3. Exact saddle equation

Put
\[
y=t-1>0.
\]
Then
\[
A=\frac1y,
\qquad
B=\frac{y^2+y+1}{y}.
\]

The pressure core is
\[
Q\log_2(y^2+y+1)-(P+Q)\log_2y.
\]

At an interior minimizer its derivative vanishes, giving exactly
\[
\boxed{
(Q-P)y^2-Py-(P+Q)=0.
}
\]

If \(Q>P\), this equation has a unique positive root and therefore a unique
finite Chernoff minimizer.

If \(Q=P>0\), no finite minimizer exists; the infimum is reached only as
\(t\to\infty\), and
\[
\inf_{t>1}
P\log_2(A(t)B(t))=0.
\]
Therefore on the feasibility boundary
\[
\boxed{
h(\rho)=E_1(\rho_1)+E_2(\rho_2).
}
\]

At \(P=Q=0\), the word is fully critical and the same formula gives
\(h=0\).

## 4. Finite realised blocks can sit O(1/r) outside F

For a realised length-\(r\) block, let \(n_i\) be the exact phase counts,
\(m_i\) the exact critical counts, and
\[
p=n_1-m_1,\qquad q=n_2-m_2.
\]

Let
\[
S=s_{u+r}-s_u
\]
be its total defect. Since every \(g=1\) noncritical defect is at most \(-1\)
and every \(g=2\) noncritical defect is at most \(+1\),
\[
S\le q-p.
\]

The Sturmian phase counts satisfy
\[
n_i=M_i r+O(1).
\]
On the Task-6 windows,
\[
S=O(1)
\]
uniformly because \(u\gg r\) and the critical-log law gives
\[
s_{u+r}-s_u
=
\kappa\log_2(1+r/u)+O(1).
\]

Therefore every realised finite type vector \(\sigma\) satisfies
\[
\operatorname{dist}(\sigma,\mathcal F)=O(1/r).
\]

This is why V3 never evaluates the zero-defect extended pressure blindly at
a finite realised type lying slightly outside \(\mathcal F\).

Instead, choose a nearest projection
\[
\widehat\sigma\in\mathcal F.
\]
Then
\[
\|\sigma-\widehat\sigma\|=O(1/r),
\]
and all pressure/Jensen statements are applied to the projected feasible
types. The finite total defect contributes only a fixed-\(t\) multiplicative
factor \(t^{-S}=2^{O(1)}\), while the \(O(1/r)\) type displacement changes
the exponent by only \(o(r)\).

## 5. Canonical status

The old V2 full-box assertion was false as a domain statement.
The corrected domain is \(\mathcal F\).

This repair changes no audited threshold, no \(\rho_{\min}\) saddle, and no
CP19 Task-4 maximum.
