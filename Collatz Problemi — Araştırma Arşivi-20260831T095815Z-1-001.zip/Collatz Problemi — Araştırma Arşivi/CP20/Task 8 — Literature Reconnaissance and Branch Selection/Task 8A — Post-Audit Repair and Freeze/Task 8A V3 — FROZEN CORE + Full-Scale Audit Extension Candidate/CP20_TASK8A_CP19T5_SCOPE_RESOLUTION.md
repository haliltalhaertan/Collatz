# CP20 TASK 8A — CP19 TASK-5 SCOPE RESOLUTION

**Date:** 2026-08-26  
**Status:** `[CANONICAL SOURCE INSPECTED]`

The independent Task-8A audit marked the CP19 Task-5 source check
`[MISSING INPUT]` because the audit zip did not contain CP19 material.

The canonical Drive source `CP19_TASK5_FINDINGS.md` is now inspected.

## Source facts

The canonical Task-5 survivor uses
\[
\kappa=53/50=1.06.
\]

Outside excursion cores it has
\[
s_k=\kappa\log_2k+O(1).
\]

But in every large dyadic block it inserts an exact mean-2 logarithmic window.
For window length
\[
\ell_m\sim\frac12\log_2k,
\]
the excursion depth is
\[
R_m
=
(2-\alpha)\ell_m+O(1)
=
\frac{2-\alpha}{2}\log_2k+O(1).
\]

Therefore along the excursion cores,
\[
|s_k-\kappa\log_2k|
\]
is unbounded and of order \(\log k\).

Hence the complete survivor does not satisfy the Task-8A global hypothesis
\[
s_k=\kappa\log_2k+O(1)
\]
with one bounded additive constant valid at every \(k\).

## Critical-site density

The source-accurate survivor convention uses ordinary neutral defect pairs
\[
(+1,-1)\quad\text{or}\quad(-1,+1).
\]

Defect \(0\) is introduced only for the sparse baseline-height increments.
The target height grows by only \(O(\log N)\) up to \(N\), so the number of
such zero-defect baseline corrections is \(O(\log N)\).

The special excursion defect is negative, and recovery uses positive defect,
so those events do not create a positive-density zero-defect population.

Thus the abstract construction has zero critical density, but this fact does
not allow Task 8A to exclude it because the global critical-log hypothesis is
already violated.

## Canonical verdict

\[
\boxed{
\texttt{[CP19 TASK5 SURVIVOR NOT EXCLUDED — HYPOTHESIS MISMATCH]}.
}
\]

The prior audit `[MISSING INPUT]` note is resolved by canonical source
inspection.

No turnover-density identity is used to infer critical density.
