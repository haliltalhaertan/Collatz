# CP20 TASK 8A — TWO-REGIME UNIFORMITY LEMMA

**Date:** 2026-08-26  
**Status:** `[POST-AUDIT REPAIRED — FREEZE CORE]`

This lemma replaces the incorrect V2 phrase
“compactness + finite cover by fixed Chernoff parameters” on the whole
pressure sublevel set.

The optimizer diverges as the feasibility boundary \(Q=P\) is approached,
so one global bounded optimizer set does not exist.

## 1. Notation

For \(\rho\in\mathcal F\), let
\[
P=M_1-\rho_1,\qquad Q=M_2-\rho_2,
\qquad q=Q-P\ge0.
\]

For \(t>1\), define the fixed-parameter pressure
\[
\Phi_t(\rho)
=
E_1(\rho_1)+E_2(\rho_2)
+
P\log_2A(t)+Q\log_2B(t),
\]
and
\[
h(\rho)=\inf_{t>1}\Phi_t(\rho).
\]

## 2. Interior regime

Fix \(\eta>0\) and restrict to
\[
q=Q-P\ge\eta.
\]

The exact saddle equation is
\[
q y^2-Py-(P+Q)=0,\qquad y=t-1.
\]
Its positive root is
\[
y_*
=
\frac{P+\sqrt{P^2+4q(P+Q)}}{2q}.
\]

Since
\[
0\le P\le1,\qquad
0\le P+Q\le1,\qquad
q\ge\eta,
\]
we have the uniform bound
\[
y_*
\le
\frac{1+\sqrt5}{2\eta}.
\]
Hence \(t_*\) is uniformly bounded on the interior regime.

On the compact set
\[
K_{\eta,\delta}
=
\{\rho\in\mathcal F:
h(\rho)\le c-\delta,\;
Q-P\ge\eta\},
\qquad c=\alpha/\kappa,
\]
the maps \(\Phi_t(\rho)\) are continuous for each fixed \(t\), and each point
has some finite optimizer \(t_*(\rho)\).

Therefore the open sets on which
\[
\Phi_{t_*(\rho_0)}(\rho)
<
h(\rho)+\varepsilon
\]
form an open cover of \(K_{\eta,\delta}\).
Compactness produces a finite subcover and hence a finite fixed set of
Chernoff parameters for the interior regime.

## 3. Boundary strip

Now take
\[
0\le q=Q-P<\eta.
\]

At \(q=0\),
\[
h(\rho)=E_1+E_2
\]
and for any fixed \(T>1\)
\[
\Phi_T(\rho)-h(\rho)
=
P\log_2(A(T)B(T)).
\]

Since
\[
A(T)B(T)
=
\frac{T^2-T+1}{(T-1)^2},
\]
the exact boundary overshoot identity is
\[
\boxed{
\Phi_T(\rho)-h(\rho)
=
P\log_2
\left(
\frac{T^2-T+1}{(T-1)^2}
\right).
}
\]
This is \(O(1/T)\) uniformly in \(0\le P\le M_1\).

For \(0\le q<\eta\),
\[
P\log_2A+Q\log_2B
=
P\log_2(AB)+q\log_2B.
\]

The true pressure core is nonnegative on \(\mathcal F\), so
\[
0\le
\Phi_T(\rho)-h(\rho)
\le
M_1\log_2(A(T)B(T))
+
\eta\log_2B(T).
\]

Given any \(\varepsilon>0\):

1. choose \(T\) large enough that
   \[
   M_1\log_2(A(T)B(T))<\varepsilon/2;
   \]
2. with this fixed \(T\), choose
   \[
   \eta<
   \frac{\varepsilon}{2\log_2B(T)}.
   \]

Then uniformly throughout the boundary strip,
\[
\boxed{
\Phi_T(\rho)\le h(\rho)+\varepsilon.
}
\]

Thus the entire boundary strip is handled by one sufficiently large fixed
parameter \(T\).

## 4. Uniform finite family

Combining the interior finite cover with the single boundary parameter:

For every \(\delta>0\), on
\[
K_\delta=
\{\rho\in\mathcal F:h(\rho)\le c-\delta\},
\]
there exists a finite set
\[
\mathcal T_\delta\subset(1,\infty)
\]
such that for every \(\rho\in K_\delta\),
\[
\boxed{
\min_{T\in\mathcal T_\delta}\Phi_T(\rho)
\le
h(\rho)+\delta/4.
}
\]

No optimizer-boundedness claim is made near \(Q=P\).

## 5. Application to finite realised types

A realised finite type \(\sigma\) may lie \(O(1/r)\) outside
\(\mathcal F\). Let \(\widehat\sigma\in\mathcal F\) be a nearest projection.

For a fixed \(T\in\mathcal T_\delta\):

- phase-count errors are \(O(1)\);
- the finite total defect \(S=O(1)\) contributes \(T^{-S}=2^{O(1)}\);
- moving the type by \(O(1/r)\) changes binomial exponents by \(O(\log r)\);
- all other fixed-\(T\) terms change by \(O(1)\).

Therefore, uniformly over projected low-pressure types,
\[
\#\{\text{factors of that type}\}
\le
2^{r(c-\delta/2)+O(\log r)}.
\]

There are only \(O(r^2)\) integer type pairs.
Hence all projected low-pressure types together contribute
\[
2^{r(c-\delta/2)+O(\log r)},
\]
which is exponentially smaller than the Task-6 distinct-factor window
\[
2^{(c-o(1))r}.
\]

This is the uniformity statement required by the audited Task-8A proof.
