#!/usr/bin/env python3
"""
CP20 Task 8A — rigorous interval certificate
Status: [AUDIT CANDIDATE]

Proof-critical arithmetic:
- decimal endpoints are exact rationals;
- every elementary arithmetic operation is rounded outward;
- logarithms use range-reduced atanh series with an explicit remainder bound;
- binary floating point is not used for theorem-critical decisions.

The analytic proof supplies:
(1) strict concavity / saddle uniqueness on the minimal-density branch;
(2) G(R) is strictly increasing for 0<R<R*;
(3) the exact CP19-T4 maximum identity.

This script certifies all numerical brackets used by the theorem.
"""

from decimal import Decimal, localcontext, ROUND_FLOOR, ROUND_CEILING, getcontext

PREC = 80
NLOG = 110
getcontext().prec = PREC + 10

def D(x):
    return x if isinstance(x, Decimal) else Decimal(str(x))

class Iv:
    __slots__ = ("lo","hi")
    def __init__(self, lo, hi=None):
        self.lo = D(lo)
        self.hi = self.lo if hi is None else D(hi)
        assert self.lo <= self.hi
    def __repr__(self):
        return f"[{self.lo}, {self.hi}]"

def add(a,b):
    with localcontext() as c:
        c.prec=PREC; c.rounding=ROUND_FLOOR
        lo=a.lo+b.lo
    with localcontext() as c:
        c.prec=PREC; c.rounding=ROUND_CEILING
        hi=a.hi+b.hi
    return Iv(lo,hi)

def neg(a):
    return Iv(-a.hi,-a.lo)

def sub(a,b):
    return add(a,neg(b))

def mul(a,b):
    lows=[]; highs=[]
    for x in (a.lo,a.hi):
        for y in (b.lo,b.hi):
            with localcontext() as c:
                c.prec=PREC; c.rounding=ROUND_FLOOR
                lows.append(x*y)
            with localcontext() as c:
                c.prec=PREC; c.rounding=ROUND_CEILING
                highs.append(x*y)
    return Iv(min(lows),max(highs))

def divpos(a,b):
    assert b.lo > 0
    with localcontext() as c:
        c.prec=PREC; c.rounding=ROUND_FLOOR
        rlo=Decimal(1)/b.hi
    with localcontext() as c:
        c.prec=PREC; c.rounding=ROUND_CEILING
        rhi=Decimal(1)/b.lo
    return mul(a,Iv(rlo,rhi))

ONE=Iv(1)
TWO=Iv(2)

def ln2_bounds():
    # ln 2 = 2 sum_{n>=0} (1/3)^(2n+1)/(2n+1)
    y=Iv(Decimal(1)/Decimal(3))
    y2=mul(y,y)
    term=y
    s=Iv(0)
    for n in range(NLOG):
        s=add(s,divpos(term,Iv(2*n+1)))
        term=mul(term,y2)
    s=mul(TWO,s)
    m=max(abs(y.lo),abs(y.hi))
    with localcontext() as c:
        c.prec=PREC; c.rounding=ROUND_CEILING
        rem=Decimal(2)*(m**(2*NLOG+1))/Decimal(2*NLOG+1)/(Decimal(1)-m*m)
    return Iv(s.lo-rem,s.hi+rem)

LN2=ln2_bounds()

def ln_point(x):
    """Rigorous enclosure of ln(exact Decimal x>0)."""
    assert x>0
    k=0
    m=x
    while m>=2:
        m=m/2; k+=1
    while m<1:
        m=m*2; k-=1
    y=divpos(sub(Iv(m),ONE),add(Iv(m),ONE))
    y2=mul(y,y)
    term=y
    s=Iv(0)
    for n in range(NLOG):
        s=add(s,divpos(term,Iv(2*n+1)))
        term=mul(term,y2)
    s=mul(TWO,s)
    ma=max(abs(y.lo),abs(y.hi))
    with localcontext() as c:
        c.prec=PREC; c.rounding=ROUND_CEILING
        rem=Decimal(2)*(ma**(2*NLOG+1))/Decimal(2*NLOG+1)/(Decimal(1)-ma*ma)
    ans=Iv(s.lo-rem,s.hi+rem)
    if k>0:
        ans=add(ans,mul(Iv(k),LN2))
    elif k<0:
        ans=sub(ans,mul(Iv(-k),LN2))
    return ans

def ln_iv(a):
    # ln is increasing.
    return Iv(ln_point(a.lo).lo,ln_point(a.hi).hi)

def log2_iv(a):
    return divpos(ln_iv(a),LN2)

LN3=ln_iv(Iv(3))
ALPHA=divpos(LN3,LN2)
M1=Iv(2-ALPHA.hi,2-ALPHA.lo)
M2=Iv(ALPHA.lo-1,ALPHA.hi-1)

def h0_at_t(lo,hi=None):
    T=Iv(lo,lo if hi is None else hi)
    Y=sub(T,ONE)
    A=divpos(ONE,Y)
    B=add(T,A)
    return add(mul(M1,log2_iv(A)),mul(M2,log2_iv(B)))

def dh0_at_point(t):
    T=Iv(t)
    Y=sub(T,ONE)
    A=divpos(ONE,Y)
    B=add(T,A)
    m1=neg(divpos(T,Y))
    invy2=divpos(ONE,mul(Y,Y))
    m2=divpos(mul(T,sub(ONE,invy2)),B)
    return add(mul(M1,m1),mul(M2,m2))

# Zero-critical Task-7 endpoint.
T0_LO=D("4.9371845970284873")
T0_HI=D("4.9371845970284874")
assert dh0_at_point(T0_LO).hi < 0
assert dh0_at_point(T0_HI).lo > 0
H0=h0_at_t(T0_LO,T0_HI)
K0=divpos(ALPHA,H0)

# Exact CP19-T4 maximum formula:
# hmax = alpha log2(alpha) - (alpha-1) log2(alpha-1).
HMAX=sub(mul(ALPHA,log2_iv(ALPHA)),mul(M2,log2_iv(M2)))
KSTAR=divpos(ALPHA,HMAX)

def x_R_G_at_t(t):
    """
    Minimal-total-density saddle branch.
    t=e^lambda, y=t-1, x=2^mu.
    The zero-defect saddle equation solves exactly for

      x(t) =
      [M1(y^2+y+1)-M2(y^2-1)]
      /
      [y( M2(y^2-1)-M1 )].

    On the rising branch t_full < t < t0, x in (0,1).
    """
    T=Iv(t)
    Y=sub(T,ONE)
    Y2=mul(Y,Y)

    num=sub(
        mul(M1,add(add(Y2,Y),ONE)),
        mul(M2,sub(Y2,ONE))
    )
    den=mul(
        Y,
        sub(mul(M2,sub(Y2,ONE)),M1)
    )
    assert num.lo>0 and den.lo>0
    X=divpos(num,den)

    A=divpos(ONE,Y)
    B=add(T,A)
    Z1=add(A,X)
    Z2=add(B,X)

    rho1=mul(M1,divpos(X,Z1))
    rho2=mul(M2,divpos(X,Z2))
    R=add(rho1,rho2)

    Phi=add(mul(M1,log2_iv(Z1)),mul(M2,log2_iv(Z2)))
    mu=log2_iv(X)
    G=sub(Phi,mul(mu,R))
    return X,rho1,rho2,R,G

def target(kappa):
    return divpos(ALPHA,Iv(kappa))

ROOTS=[
    # kappa, t lower, t upper, advertised R lower, advertised R upper
    ("1.06",
     "2.79477476165049","2.79477476165050",
     "0.34622623","0.34622625"),
    ("1.5",
     "3.78215191151571","3.78215191151573",
     "0.09160832","0.09160834"),
    ("2.0",
     "4.41721651712703","4.41721651712705",
     "0.03144454","0.03144456"),
]

CERTS=[]
for k,tlo,thi,rlo_safe,rhi_safe in ROOTS:
    C=target(k)
    Xlo,r1lo,r2lo,Rlo,Glo=x_R_G_at_t(tlo)
    Xhi,r1hi,r2hi,Rhi,Ghi=x_R_G_at_t(thi)

    # Analytic theorem: G decreases with t on this branch.
    # Endpoint signs rigorously isolate the unique G=alpha/kappa root.
    assert Glo.lo > C.hi
    assert Ghi.hi < C.lo

    # R also decreases with t on this saddle branch.
    R_lower=Rhi.lo
    R_upper=Rlo.hi

    assert R_lower > D(rlo_safe)
    assert R_upper < D(rhi_safe)

    CERTS.append((k,tlo,thi,R_lower,R_upper,
                  r1hi.lo,r1lo.hi,r2hi.lo,r2lo.hi))

# Structural asymmetry is exact:
# B(t)-A(t)=t>0. At an interior fixed-total saddle,
# rho_i/M_i = x/(partition_i+x), so
# rho1/M1 > rho2/M2.
# No decimal comparison is needed.

print("CP20 TASK 8A — RIGOROUS INTERVAL CERTIFICATE")
print("Status: [AUDIT CANDIDATE]")
print()
print("alpha =",ALPHA)
print("M1=2-alpha =",M1)
print("M2=alpha-1 =",M2)
print()
print("ZERO-CRITICAL ENDPOINT")
print("t0 in [",T0_LO,",",T0_HI,"]")
print("h(0,0) =",H0)
print("alpha/h(0,0) =",K0)
print("dH(t0_lower)<0 and dH(t0_upper)>0: PASS")
print()
print("CP19 TASK-4 MAXIMUM")
print("h_max =",HMAX)
print("kappa_* = alpha/h_max =",KSTAR)
print("Exact identity is proved symbolically in theorem file.")
print()
print("CONTINUOUS rho_min CERTIFICATES")
for row in CERTS:
    k,tlo,thi,Rlo,Rhi,r1lo,r1hi,r2lo,r2hi=row
    print("kappa =",k)
    print("  t* in [",tlo,",",thi,"]")
    print("  rho_min in [",Rlo,",",Rhi,"]")
    print("  rho1 in [",r1lo,",",r1hi,"]")
    print("  rho2 in [",r2lo,",",r2hi,"]")
print()
print("STRUCTURAL ASYMMETRY")
print("B(t)-A(t)=t>0 exactly.")
print("At every interior minimal-density saddle:")
print("  rho1/M1 > rho2/M2.")
print()
print("ALL PROOF-CRITICAL INTERVAL ASSERTIONS: PASS")
