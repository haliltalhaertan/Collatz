# CP20 TASK 8A — COUNTEREXAMPLE-FIRST REPORT

**Status:** `[AUDIT CANDIDATE]`

| Attack | Verdict | Result |
|---|---|---|
| Global density implies every local factor has that density | `[COUNTEREXAMPLE TO NAIVE FORM]` | False in general; oscillatory schedules can have atypical windows. Repaired using Task-6 multiplicative windows and double counting. |
| Local-to-global bridge impossible without density limits | `[VALID AFTER REPAIR]` | Multiplicative-window densities along \(N_r\) are enough. Natural density is only a corollary. |
| Chernoff sign reversal | `[VALID]` | Correct inherited form is \(N(S)t^S\le P(t)\), hence \(N(S)\le P(t)t^{-S}\). |
| O(log r) defect band changes entropy | `[VALID]` | Fixed lambda gives only polynomial overhead. Task-6 windows actually have O(1) defect band. |
| Sturmian phase creates strict entropy loss at optimized maximum | `[FALSE CLAIM]` | Exact optimization gives \(\max h=h_{\rm CP19}(\alpha)\). Prior ~0.1% “phase cost” is retracted. |
| Density-sliced pressure is non-concave, breaking Jensen | `[VALID]` | Legendre representation expresses h as an infimum of affine functions in rho, proving concavity. |
| Vanishing epsilon breaks Task-6 distinctness | `[VALID]` | If \(\varepsilon_r\to0\) but \(r\varepsilon_r\to\infty\), the exponential spacing gap still diverges. |
| Fully critical corner has hidden entropy | `[VALID]` | \((M_1,M_2)\) gives only \(a=g\), hence entropy 0. |
| Zero-critical corner fails to reproduce Task 7 | `[VALID]` | It reproduces \(h_\infty\) exactly. |
| kappa <= 1 | `[OUT OF SCOPE]` | Frozen Task-6 lower theorem requires kappa>1. |
| Eventually periodic valuation escape | `[COUNTEREXAMPLE FAILS]` | Periodic integer valuations have rational mean, incompatible with mean \(\alpha=\log_2 3\). |
| CP19 T5 survivor killed by rho=0 threshold | `[FALSE / SCOPE BUG]` | Its critical density is 0, but its excursion cores violate global \(s_k=\kappa\log_2k+O(1)\). It is not excluded. |
| Turnover density = 1 - critical density | `[UNSUPPORTED AS A DEFINITION]` | No such identity is used. Critical sites were counted directly from the source-accurate defect generator. |
| Type-1 is always cheaper in absolute count | `[TOO STRONG]` | What is proved is the normalized interior-saddle inequality \(\rho_1/M_1>\rho_2/M_2\). |
| Continued-fraction repeat gives n0 lower bound | `[UNSUPPORTED]` | It directly lower-bounds the state-bound constant C, not n0 without an explicit C-to-n0 upper relation. |

## Strongest adversarial schedule considered

An oscillatory schedule may alternate very low and very high critical density
on exponentially separated intervals, destroying any global natural density.
This does not violate the repaired theorem: every accumulation point of the
specific Task-6 multiplicative-window density sequence must still lie in the
pressure superlevel region.

## Final falsification status

No load-bearing counterexample to the repaired multiplicative-window theorem
was found.

Two claims from the earlier formulation are rejected:
1. naive use of a global density on every factor;
2. strict entropy improvement over CP19 Task 4 at the optimized maximum.
