# CP20 TASK 8A — FINDINGS V2

**Date:** 2026-08-26  
**Status:** `[THEOREM CANDIDATE — AUDIT REQUIRED]`  
**Verdict:** `[PROVED WITH WORDING REPAIR]`

## Executive result

The critical-site density pressure branch survives, but not in the naive form
“a global critical density controls every factor”.

The correct theorem uses the actual frozen Task-6 counting windows.

For
\[
N_r=\left\lfloor
2^{(\alpha/\kappa-\varepsilon_r)r}
\right\rfloor,
\qquad
\varepsilon_r\to0,\quad r\varepsilon_r\to\infty,
\]
define
\[
D_i(N_r)
=
N_r^{-1}
\#\{k\in[N_r,2N_r):k\text{ is type-i critical}\}.
\]

Then
\[
\boxed{
\liminf_{r\to\infty}
h(D_1(N_r),D_2(N_r))
\ge\alpha/\kappa.
}
\]

Hence every accumulation point of these multiplicative-window density
vectors lies in
\[
\boxed{h(\rho_1,\rho_2)\ge\alpha/\kappa.}
\]

If natural type densities exist, they satisfy the same inequality.

## Why the local-to-global repair works

The frozen Task-6 repeated-factor argument remains valid with a vanishing
epsilon sequence satisfying \(r\varepsilon_r\to\infty\), giving
\[
2^{(\alpha/\kappa-o(1))r}
\]
distinct factors in the counting window.

Only polynomially many type pairs exist. Types lying a fixed amount below
the pressure threshold can generate exponentially fewer factors, so their
fraction of starts vanishes.

The type pressure h is concave via its Legendre representation. Jensen then
transfers the pressure lower requirement to the start-average type.

A direct incidence double count identifies that start-average type with the
critical type densities in \([N_r,2N_r)\) up to \(O(r/N_r)\).

No “typical factor” assumption is used.

## Corrected CP19 Task-4 relation

The earlier numerical interpretation of a ~0.1% Sturmian phase penalty at
the maximum is false.

Exactly,
\[
\boxed{
\max_{\rho_1,\rho_2}h(\rho_1,\rho_2)
=
h_{\rm CP19}(\alpha).
}
\]

The maximizing critical densities are
\[
\rho_1^*=\frac{2-\alpha}{\alpha},
\qquad
\rho_2^*=\frac{(\alpha-1)^2}{\alpha^2}.
\]

Task 8A therefore **recovers** CP19 Task 4 when critical density is optimized
away. Its new information is the density-sliced refinement.

## Certified rho_min

\[
\rho_{\min}(\kappa)
=
\inf\{\rho_1+\rho_2:
h(\rho_1,\rho_2)\ge\alpha/\kappa\}.
\]

Certified intervals:

- \(\kappa=1.06\):
  \[
  0.3462262370615738765
  <
  \rho_{\min}
  <
  0.3462262370615793450.
  \]

- \(\kappa=1.5\):
  \[
  0.0916083301662611616
  <
  \rho_{\min}
  <
  0.0916083301662636580.
  \]

- \(\kappa=2.0\):
  \[
  0.0314445508714852886
  <
  \rho_{\min}
  <
  0.0314445508714867310.
  \]

Zero-critical endpoint:
\[
\alpha/h(0,0)
\in
(2.7840109030009018067,\,
2.7840109030009019658).
\]

## Structural asymmetry

On every interior minimal-total-density saddle,
\[
\frac{\rho_1}{M_1}>\frac{\rho_2}{M_2}
\]
because
\[
B(t)-A(t)=t>0.
\]

Thus type-1 critical sites are the cheaper density escape relative to phase
availability.

## CP19 Task-5 survivor

Directly from the source-accurate generator,
\[
\#\{k<N:d_k=0\}=O(\log N),
\]
so its critical density is zero.

But its special dyadic excursion cores have
\[
|s_k-\kappa\log_2k|=\Theta(\log k)
\]
along a subsequence. Therefore it does not satisfy the global critical-log
\(O(1)\) hypothesis.

Result:
`[NOT EXCLUDED BY TASK 8A — HYPOTHESIS MISMATCH]`.

## CP20 Task 3

The historical FAIL is not changed.

Its explicit zero-critical B=3 controller can no longer serve as a positive
ordinary downstream countermodel under frozen Task 6/7.

Result:
`[FAIL VERDICT RETAINED; SPECIFIC COUNTERMODEL RATIONALE SUPERSEDED]`.

The exact recovery-debt lemmas remain potentially useful.

## Continued-fraction branch

Repeat experiments directly constrain the state-bound constant C, not \(n_0\).
Without a certified upper relation between C and \(n_0\), this branch remains:

`[LEAD]`.

It is not used in Task 8A.

## Audit status

This is now a load-bearing theorem candidate.

Independent zero-trust audit is mandatory before:
- freeze;
- Task 8B;
- any publication-level theorem dependency.
