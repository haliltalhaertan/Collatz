# CP20 TASK 8A — INDEPENDENT ZERO-TRUST AUDIT PROMPT

**Status:** `[AWAITING INDEPENDENT ZERO-TRUST AUDIT]`

You are the independent adversarial mathematical auditor.

Do not accept the candidate theorem, the reported interval output, or the
research-manager interpretation. Try to break every load-bearing transition.

## Claimed theorem

For a positive ordinary odd-only Syracuse orbit satisfying
\[
s_k=\kappa\log_2k+O(1),\qquad\kappa>1,
\]
define type-1 critical sites by \(g=1,a=1\), type-2 critical sites by
\(g=2,a=2\), and multiplicative-window densities
\[
D_i(N)=N^{-1}\#\{k\in[N,2N):k\text{ is type-i critical}\}.
\]

For any
\[
\varepsilon_r\to0,\qquad r\varepsilon_r\to\infty,
\]
let
\[
N_r=\lfloor2^{(\alpha/\kappa-\varepsilon_r)r}\rfloor.
\]

The candidate claims
\[
\liminf_{r\to\infty}
h(D_1(N_r),D_2(N_r))
\ge\alpha/\kappa.
\]

Therefore every accumulation point of \(D(N_r)\) lies in
\[
h(\rho_1,\rho_2)\ge\alpha/\kappa.
\]

If natural type densities exist, the same inequality holds for them.

## Mandatory checks

1. Re-derive fixed-phase fixed-type combinatorics from scratch.
2. Verify critical binomial entropies.
3. Verify noncritical partition functions
   \(A=1/(t-1)\) and \(B=t+1/(t-1)\).
4. Verify the Chernoff sign.
5. Derive the two Legendre multipliers independently.
6. Verify that the Legendre representation really proves concavity of h.
7. Re-run the frozen Task-6 distinct-factor proof with variable
   \(\varepsilon_r\to0\), checking that \(r\varepsilon_r\to\infty\) is
   sufficient.
8. Prove the type-count upper bound uniformly over a pressure sublevel set;
   do not accept a pointwise o(r) estimate as automatically uniform.
9. Verify that polynomially many types plus distinct Task-6 factors imply
   exponentially negligible low-pressure starts.
10. Verify the Jensen/concavity passage from individual start types to the
    average type.
11. Re-derive the double-counting identity
    \(\bar\sigma_r=D(N_r)+O(r/N_r)\) with exact endpoint bookkeeping.
12. Attempt an oscillatory-density counterexample.
13. Verify the natural-density corollary separately.
14. Prove or refute exactly
    \[
    \max h=h_{\rm CP19}(\alpha).
    \]
15. Independently derive the claimed maximizing densities
    \[
    \rho_1^*=(2-\alpha)/\alpha,\quad
    \rho_2^*=(\alpha-1)^2/\alpha^2.
    \]
16. Confirm that the earlier “strict Sturmian phase saving at the maximum”
    must be retracted.
17. Independently derive the one-fugacity formulation of
    \(G(R)=\max_{\rho_1+\rho_2=R}h(\rho)\).
18. Verify the exact x(t) saddle formula and the monotonic/uniqueness argument
    for rho_min.
19. Re-run the interval certificate from source; do not trust its saved
    output.
20. Reproduce certified intervals for kappa=1.06, 1.5, 2.0 and the
    zero-critical endpoint.
21. Verify the structural asymmetry
    \(\rho_1/M_1>\rho_2/M_2\) and its exact scope.
22. Audit all corners: rho=0, fully critical, one-sided, kappa<=1,
    eventual periodicity.
23. Retrieve the source-accurate CP19 Task-5 survivor definition and verify
    directly its d=0 count. Check independently that its excursion cores
    violate the global O(1) critical-log hypothesis.
24. Verify that CP19 Task-5 is **not** claimed excluded.
25. Verify the CP20 Task-3 reassessment does not silently change the
    historical FAIL verdict to VALID.
26. Verify the continued-fraction branch is not used as theorem evidence.
27. Check no CP19 parked high-half/cross-adic mechanism is reopened.
28. Check no claim that Collatz is solved appears.

## Audit verdict

Return exactly one principal verdict:

- `[PROOF VALID]`
- `[PROOF VALID WITH WORDING REPAIR]`
- `[FIXABLE GAP]`
- `[MAJOR GAP]`
- `[FALSE — COUNTEREXAMPLE]`

If valid, explicitly state whether Task 8A may be frozen and whether Task 8B
may begin.

Do not begin Task 8B yourself.
