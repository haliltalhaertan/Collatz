# CP20 TASK 8A THEOREM V2 — AUDIT PACKAGE

**Status:** `[AWAITING INDEPENDENT ZERO-TRUST AUDIT]`  
**Do not freeze. Do not start Task 8B from this package before audit.**

## Main candidate

The Task-6 multiplicative counting windows force their average
phase-separated critical density into the pressure superlevel region:
\[
\liminf h(D_1(N_r),D_2(N_r))\ge\alpha/\kappa.
\]

Natural density, if it exists, is a corollary rather than an assumption in
the proof.

## Key correction

\[
\max_{\rho_1,\rho_2}h(\rho_1,\rho_2)
=
h_{\rm CP19}(\alpha)
\]
exactly.

The earlier numerical “strict Sturmian phase cost at the maximum” is
retracted. Task 8A refines CP19 Task 4 by critical-density slices.

## Certified thresholds

- rho_min(1.06) ≈ 0.3462262370615766
- rho_min(1.5) ≈ 0.0916083301662624
- rho_min(2.0) ≈ 0.0314445508714860
- zero-critical endpoint
  \(\kappa_0≈2.7840109030009019\)

Use the rigorous interval output for theorem-critical digits.

## CP19 Task-5

Direct critical density: 0.

Not excluded by Task 8A because its excursion cores do not satisfy global
\(s_k=\kappa\log_2k+O(1)\).

## Contents

- `CP20_TASK8A_CRITICAL_SITE_DENSITY_PRESSURE_THEOREM_V2.md`
- `CP20_TASK8A_FINDINGS_V2.md`
- `CP20_TASK8A_COUNTEREXAMPLE_REPORT.md`
- `CP20_TASK8A_RIGOROUS_CERTIFICATE.py`
- `CP20_TASK8A_RIGOROUS_CERTIFICATE_OUTPUT.txt`
- `CP20_TASK8A_LITERATURE_COMPARISON.md`
- `CP20_TASK8A_ZERO_TRUST_AUDIT_PROMPT.md`
- `SHA256SUMS.txt`

## Verdict before audit

`[PROVED WITH WORDING REPAIR]`

This is a theorem-candidate verdict only.
