# CP20 TASK 8A — LITERATURE / METHOD COMPARISON

**Status:** `[COMPARISON ONLY — NOT NOVELTY CERTIFICATION]`  
**Date:** 2026-08-26

## Sven Witteveen, July 2026

The public July 2026 preprint/repository
**“Entropy barriers for bounded-amplitude Collatz cycles”** studies primitive
positive cycles of the accelerated odd Collatz map through their amplitude
\(R(C)=x_{\max}/x_{\min}\).

The reported method includes:

- mechanical/Sturmian-like factor languages;
- repeated-factor divisibility;
- entropy / overlap-automaton bounds;
- exact-arithmetic certificate programs;
- explicit linear forms in logarithms;
- computational period floors.

Its two stated targets are:
1. exclusion of nontrivial primitive positive cycles with \(R(C)\le2\);
2. an asymptotic positive-entropy exclusion at \(R=12/5\).

## Genuine methodological overlap

Task 8A and the Witteveen preprint both use:

1. accelerated odd-only valuation/exponent symbolic structure;
2. mechanical/Sturmian language control;
3. repeated-factor arithmetic as a bridge from symbolic recurrence to
   arithmetic restrictions;
4. entropy/pressure as a quantitative language-size obstruction;
5. exact/certified computation rather than floating-point-only threshold
   claims.

This overlap is material and must be acknowledged in any novelty analysis.

## Scope difference

The theorem scopes are different.

### Witteveen

- primitive positive **cycles**;
- bounded amplitude \(R(C)\);
- cycle closure is essential;
- linear forms / period ceiling and computational period floor are used.

### CP20 Task 8A

- one positive ordinary odd-only orbit under the conditional law
  \[
  s_k=\kappa\log_2k+O(1),\quad\kappa>1;
  \]
- no periodic closure is assumed;
- theorem concerns phase-separated critical-site density in
  multiplicative windows;
- pressure is combined with frozen Task-6 factor-complexity lower entropy;
- no period floor, cycle closure, or Rhin/Baker estimate is used in the
  Task-8A theorem.

Thus the preprint does not directly imply the Task-8A theorem, and Task 8A
does not imply the bounded-amplitude cycle results.

## Important novelty caution

No claim of novelty should be made from keyword/bibliography absence.

Before publication, a dedicated novelty audit should compare theorem
statements and proof dependencies line by line, especially around:

- mechanical factor complexity;
- repeated-factor divisibility;
- entropy upper bounds;
- exact certificate methodology.

## Continued-fraction/Baker separation

The Witteveen cycle setting can exploit exact periodic closure to make linear
forms in \(\log2,\log3\) powerful.

Task 8A has no such exact closure. The CP20 continued-fraction repeat branch
therefore remains a separate `[LEAD]`; it is not imported as evidence for the
critical-density theorem.
