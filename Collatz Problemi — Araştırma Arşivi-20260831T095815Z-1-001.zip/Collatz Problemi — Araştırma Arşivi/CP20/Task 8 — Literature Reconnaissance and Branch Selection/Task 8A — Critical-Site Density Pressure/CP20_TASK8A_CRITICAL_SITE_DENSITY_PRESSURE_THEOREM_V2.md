# CP20 TASK 8A — CRITICAL-SITE DENSITY PRESSURE THEOREM V2

**Date:** 2026-08-26  
**Status:** `[LOAD-BEARING THEOREM CANDIDATE — INDEPENDENT AUDIT REQUIRED]`  
**Verdict:** `[PROVED WITH WORDING REPAIR]`

This theorem is downstream of the frozen CP20 Task 6 V3 lower factor-complexity
theorem and frozen CP20 Task 7 V3 pressure theorem. It does not alter either
frozen source.

The two repairs relative to the first Task-8A formulation are load-bearing
wording/bridge repairs:

1. global natural critical density is not assumed to control every factor;
   the theorem is formulated first on the actual Task-6 multiplicative
   counting windows;
2. the optimized Task-8A pressure does **not** lie strictly below CP19 Task 4
   at its maximum; the exact maximum equals the CP19 Task-4 entropy.

No Task 8B argument is used.

---

## 1. Setting

Let
\[
\alpha=\log_2 3,\qquad
F_k=\lfloor\alpha k\rfloor,\qquad
g_k=F_{k+1}-F_k\in\{1,2\},
\]
and for a positive ordinary odd-only Syracuse orbit
\[
A_k=\sum_{i<k}a_i,\qquad s_k=F_k-A_k.
\]

Assume
\[
\boxed{s_k=\kappa\log_2 k+O(1)},\qquad \kappa>1.
\]

Write
\[
M_1=2-\alpha,\qquad M_2=\alpha-1,
\]
so \(M_1+M_2=1\).

A site is **critical** when \(a_k=g_k\). Split critical sites into:

- type 1: \(g_k=1,\ a_k=1\);
- type 2: \(g_k=2,\ a_k=2\).

For a length-r factor beginning at u, let \(m_i(u,r)\) be its type-i critical
count and let
\[
\sigma_i(u,r)=m_i(u,r)/r.
\]

---

## 2. Fixed-phase, fixed-type combinatorics

Fix one length-r factor of the Sturmian phase word \(g\). Let it contain
\(n_1\) sites with \(g=1\) and \(n_2\) sites with \(g=2\).

Fix critical counts \(m_1,m_2\).

At type-1 phase sites:
- \(m_1\) critical positions have \(a=1\), defect \(d=g-a=0\);
- every noncritical position has \(a\ge2\), hence
  \(d\in\{-1,-2,\ldots\}\).

At type-2 phase sites:
- \(m_2\) critical positions have \(a=2\), defect \(d=0\);
- every noncritical position has
  \(a\in\{1,3,4,\ldots\}\), hence
  \(d\in\{+1,-1,-2,\ldots\}\).

For \(t=e^\lambda>1\), define the noncritical partition functions
\[
A(t)=\sum_{a\ge2}t^{1-a}=\frac1{t-1},
\]
\[
B(t)=\sum_{\substack{a\ge1\\a\ne2}}t^{2-a}
=t+\frac1{t-1}.
\]

The critical-position choices contribute
\[
\binom{n_1}{m_1}\binom{n_2}{m_2}.
\]

If \(N(S)\) denotes the number of resulting words with total defect S, the
positive-coefficient generating function satisfies
\[
N(S)t^S\le
\binom{n_1}{m_1}\binom{n_2}{m_2}
A(t)^{n_1-m_1}B(t)^{n_2-m_2}.
\]
Hence
\[
\boxed{
N(S)\le
\binom{n_1}{m_1}\binom{n_2}{m_2}
A(t)^{n_1-m_1}B(t)^{n_2-m_2}t^{-S}.
}
\]

This is the corrected Chernoff direction inherited from frozen Task 7.

The critical-log law gives
\[
\sum_{j=0}^{r-1}(g_{u+j}-a_{u+j})
=s_{u+r}-s_u.
\]
Globally this is \(O(\log r)\); on the Task-6 windows \(u\gg r\) it is
actually \(O(1)\). Either bound contributes only subexponential overhead.

The Sturmian phase counts satisfy
\[
n_1=M_1r+O(1),\qquad n_2=M_2r+O(1).
\]

Therefore a type vector
\[
\rho=(\rho_1,\rho_2),\qquad
0\le\rho_i\le M_i,
\]
has exponential factor-count upper rate
\[
h(\rho_1,\rho_2)
=
\inf_{\lambda>0}
\Big[
(M_1-\rho_1)\log_2A(e^\lambda)
+
(M_2-\rho_2)\log_2B(e^\lambda)
+
E_1(\rho_1)+E_2(\rho_2)
\Big],
\]
where
\[
E_i(\rho)
=
M_i\log_2M_i
-
(M_i-\rho)\log_2(M_i-\rho)
-
\rho\log_2\rho,
\]
with \(0\log 0=0\).

---

## 3. Legendre form and concavity

For fixed positive \(Q\),
\[
E_i(\rho)+(M_i-\rho)\log_2Q
=
\inf_{\mu\in\mathbb R}
\left[
M_i\log_2(Q+2^\mu)-\mu\rho
\right].
\]

The stationary equation is
\[
\boxed{
2^{\mu_i}
=
\frac{\rho_i Q_i}{M_i-\rho_i}
}
\]
with \(Q_1=A\), \(Q_2=B\). Thus
\[
2^{\mu_1}=\frac{\rho_1A}{M_1-\rho_1},
\qquad
2^{\mu_2}=\frac{\rho_2B}{M_2-\rho_2}.
\]

Consequently,
\[
h(\rho_1,\rho_2)
=
\inf_{\lambda>0,\mu_1,\mu_2}
\left[
M_1\log_2(A+2^{\mu_1})
+
M_2\log_2(B+2^{\mu_2})
-
\mu_1\rho_1-\mu_2\rho_2
\right].
\]

This is an infimum of affine functions of \((\rho_1,\rho_2)\). Therefore
\[
\boxed{h\text{ is concave on }[0,M_1]\times[0,M_2].}
\]

This concavity is the load-bearing ingredient in the local-to-global bridge.

---

## 4. Strengthened Task-6 counting window

The frozen Task-6 theorem is stated for each fixed
\(0<\varepsilon<\alpha/\kappa\). Its proof also supports the following
vanishing-epsilon form.

Choose any sequence
\[
\varepsilon_r>0,\qquad
\varepsilon_r\to0,\qquad
r\varepsilon_r\to\infty,
\]
for example \(\varepsilon_r=r^{-1/2}\), and define
\[
N_r=
\left\lfloor
2^{(\alpha/\kappa-\varepsilon_r)r}
\right\rfloor.
\]

Then \(N_r\) is exponential and \(r/N_r\to0\).

Consider starts
\[
\mathcal U_r=[N_r,\,2N_r-r]\cap\mathbb Z.
\]

The frozen repeated-factor spacing gives, for equal factors,
\[
|n_v-n_u|\ge2^{\alpha r-O(1)}.
\]
The polynomial state bound gives throughout this window
\[
|n_v-n_u|
\le
2^{\alpha r-\kappa\varepsilon_rr+O(1)}.
\]
Because
\[
\kappa\varepsilon_rr\to\infty,
\]
these inequalities are incompatible for all large r.

Hence every length-r factor beginning in \(\mathcal U_r\) is distinct and
\[
|\mathcal U_r|
=
2^{(\alpha/\kappa-o(1))r}.
\]

No new arithmetic hypothesis is introduced.

---

## 5. Local-to-global type bridge

Let \(L_r=|\mathcal U_r|\).

There are only \(O(r^2)\) possible integer type pairs \((m_1,m_2)\).

For any fixed type vector \(\sigma\), the fixed-type counting argument gives
\[
\#\{\text{possible factors of type }\sigma\}
\le
2^{r h(\sigma)+o(r)}.
\]

The estimate can be made uniform on every closed pressure sublevel set:
if
\[
h(\sigma)\le\alpha/\kappa-\delta,
\]
compactness plus a finite cover by fixed Chernoff parameters gives
\[
\#\{\text{all factors in all such types}\}
\le
2^{(\alpha/\kappa-\delta/2)r}
\]
for all sufficiently large r, up to polynomial factors.

Since the Task-6 window contains
\[
L_r=2^{(\alpha/\kappa-o(1))r}
\]
**distinct** factors, the fraction of starts with
\[
h(\sigma(u,r))
\le\alpha/\kappa-\delta
\]
tends exponentially to zero.

Let the start-average type be
\[
\bar\sigma_r
=
\frac1{L_r}\sum_{u\in\mathcal U_r}\sigma(u,r).
\]

Because \(h\) is concave,
\[
h(\bar\sigma_r)
\ge
\frac1{L_r}\sum_{u\in\mathcal U_r}h(\sigma(u,r)).
\]
The low-pressure starts have vanishing proportion and \(h\ge0\), so for each
fixed \(\delta>0\)
\[
\liminf_{r\to\infty}h(\bar\sigma_r)
\ge\alpha/\kappa-\delta.
\]
Letting \(\delta\downarrow0\),
\[
\boxed{
\liminf_{r\to\infty}h(\bar\sigma_r)
\ge\frac{\alpha}{\kappa}.
}
\]

This is the step that was missing from the first Task-8A formulation.

---

## 6. Multiplicative-window density theorem

Define the multiplicative-window critical-type densities
\[
D_i(N)
=
\frac1N
\#\{k\in[N,2N): k\text{ is type-i critical}\}.
\]

Double-count the critical incidences in all length-r windows with starts
\(u\in\mathcal U_r\).

Interior sites are counted exactly r times. Only O(r) sites near each end
have smaller multiplicity, hence the total edge error is \(O(r^2)\).

After division by \(L_rr\asymp N_rr\),
\[
\boxed{
\bar\sigma_{i,r}
=
D_i(N_r)+O(r/N_r).
}
\]
Since \(r/N_r\to0\), continuity of h gives:

\[
\boxed{
\liminf_{r\to\infty}
h(D_1(N_r),D_2(N_r))
\ge
\frac{\alpha}{\kappa}.
}
\]

### Theorem 8A — no density-existence assumption

For every sequence
\[
\varepsilon_r\downarrow0,\qquad
r\varepsilon_r\to\infty,
\]
with
\[
N_r=
\left\lfloor2^{(\alpha/\kappa-\varepsilon_r)r}\right\rfloor,
\]
every accumulation point
\[
(\rho_1,\rho_2)
\in
\operatorname{Acc}\{(D_1(N_r),D_2(N_r))\}
\]
satisfies
\[
\boxed{
h(\rho_1,\rho_2)\ge\frac{\alpha}{\kappa}.
}
\]

This is the canonical theorem form.

### Natural-density corollary

If the global natural type densities exist,
\[
\frac1N\#\{k<N:k\text{ is type-i critical}\}\to\rho_i,
\]
then
\[
D_i(N)\to\rho_i
\]
and therefore
\[
\boxed{
h(\rho_1,\rho_2)\ge\frac{\alpha}{\kappa}.
}
\]

No “typical factor” assumption is used.

---

## 7. Exact CP19 Task-4 bridge

If critical counts are unconstrained, every valuation \(a\ge1\) is allowed.

The full one-site partition functions are
\[
Z_1(t)=1+A(t)=\frac{t}{t-1},
\]
\[
Z_2(t)=1+B(t)=\frac{t^2}{t-1}.
\]

Hence the unrestricted pressure is
\[
H_{\rm all}(t)
=
M_1\log_2Z_1(t)+M_2\log_2Z_2(t)
=
\alpha\log_2t-\log_2(t-1).
\]

Its unique minimizer is
\[
t_*=\frac{\alpha}{\alpha-1}.
\]

Therefore
\[
\min_{t>1}H_{\rm all}(t)
=
\alpha\log_2\alpha
-
(\alpha-1)\log_2(\alpha-1).
\]

Equivalently,
\[
\boxed{
h_{\rm CP19}(\alpha)
=
\log_2\alpha
+
(\alpha-1)
\big[
\log_2\alpha-\log_2(\alpha-1)
\big].
}
\]

For every \(\rho\), the type slice is a subset of the unrestricted language,
so
\[
h(\rho)\le h_{\rm CP19}(\alpha).
\]

At the geometric maximum-entropy saddle,
\[
\boxed{
\rho_1^*=\frac{M_1}{\alpha},
\qquad
\rho_2^*=\frac{(\alpha-1)^2}{\alpha^2},
}
\]
and direct substitution gives equality. Hence

\[
\boxed{
\max_{0\le\rho_1\le M_1,\ 0\le\rho_2\le M_2}
h(\rho_1,\rho_2)
=
h_{\rm CP19}(\alpha).
}
\]

Therefore the previous numerical claim of a strict “Sturmian phase cost” at
the optimized maximum is retracted.

**Correct interpretation:** Task 8A exactly recovers CP19 Task 4 when critical
density is optimized away, and refines it into density slices.

The exact-rational interval certificate gives
\[
h_{\rm CP19}(\alpha)
=
1.5056438879463007943\ldots
\]
and
\[
\kappa_*=
\frac{\alpha}{h_{\rm CP19}(\alpha)}
=
1.0526808586079713873\ldots.
\]

---

## 8. Continuous minimal critical density

Define
\[
\rho_{\min}(\kappa)
=
\inf
\left\{
\rho_1+\rho_2:
h(\rho_1,\rho_2)\ge\alpha/\kappa
\right\}.
\]

Let
\[
G(R)=
\max_{\rho_1+\rho_2=R}h(\rho_1,\rho_2).
\]

Using one fugacity \(x=2^\mu\) for total critical count,
\[
G(R)=
\inf_{\lambda>0,\mu\in\mathbb R}
\left[
M_1\log_2(A+2^\mu)
+
M_2\log_2(B+2^\mu)
-
\mu R
\right].
\]

At an interior saddle,
\[
\rho_1=M_1\frac{x}{A+x},
\qquad
\rho_2=M_2\frac{x}{B+x}.
\]

With \(t=e^\lambda\) and \(y=t-1\), the zero-total-defect saddle equation
solves exactly for
\[
\boxed{
x(t)=
\frac{
M_1(y^2+y+1)-M_2(y^2-1)
}{
y\,[M_2(y^2-1)-M_1]
}.
}
\]

On the minimal-density branch between the unrestricted saddle and the
zero-critical saddle,
\[
0<x<1.
\]
The Legendre envelope theorem gives
\[
G'(R)=-\mu=-\log_2x>0.
\]
Thus G is strictly increasing there and the minimal-density solution is
unique.

Let
\[
\kappa_0=\alpha/h(0,0)
\approx2.7840109030009019.
\]

The geometry is:

1. \(\kappa<\kappa_*\): no type vector can satisfy the entropy demand;
2. \(\kappa_*\le\kappa<\kappa_0\): a unique positive
   \(\rho_{\min}(\kappa)\) exists;
3. \(\kappa\ge\kappa_0\): \(\rho_{\min}(\kappa)=0\).

Certified continuous values:

\[
\boxed{
0.3462262370615738765
<
\rho_{\min}(1.06)
<
0.3462262370615793450
}
\]

\[
\boxed{
0.0916083301662611616
<
\rho_{\min}(1.5)
<
0.0916083301662636580
}
\]

\[
\boxed{
0.0314445508714852886
<
\rho_{\min}(2.0)
<
0.0314445508714867310
}
\]

and the zero-critical endpoint is
\[
\boxed{
\kappa_0
=
\alpha/h(0,0)
\in
(2.7840109030009018067,\,
 2.7840109030009019658).
}
\]

These are interval-certified, not grid values.

---

## 9. Structural type asymmetry

At every interior minimal-total-density saddle,
\[
\frac{\rho_1}{M_1}
=
\frac{x}{A+x},
\qquad
\frac{\rho_2}{M_2}
=
\frac{x}{B+x}.
\]

But exactly
\[
B(t)-A(t)=t>0.
\]
Therefore
\[
\boxed{
\frac{\rho_1}{M_1}
>
\frac{\rho_2}{M_2}.
}
\]

Thus, relative to available phase mass, inserting critical sites at \(g=1\)
is always the cheaper escape direction on the entire interior
minimal-density branch.

This is the precise theorem-level asymmetry. It does **not** say that every
minimizer is purely type 1.

---

## 10. Degenerate and adversarial cases

### Zero criticality

\[
h(0,0)=h_\infty
\]
exactly recovers frozen Task 7.

### Fully critical mechanical word

At
\[
(\rho_1,\rho_2)=(M_1,M_2)
\]
there is only the mechanical word \(a_k=g_k\), so
\[
h(M_1,M_2)=0.
\]

### One-sided boundaries

The formulas extend by \(x\log x=0\) and one-sided limits. No boundary
singularity creates an uncounted exponential family.

### kappa <= 1

Outside the frozen Task-6 lower theorem. No Task-8A conclusion is claimed.

### Eventually periodic valuations

Incompatible with the critical-log hypothesis because
\[
A_k/k\to\alpha=\log_2 3
\]
is irrational, whereas an eventually periodic integer valuation word has a
rational limiting mean.

### Oscillatory critical densities

They can destroy global natural density. This does not break the theorem,
because the primary statement is in terms of multiplicative-window
accumulation points along \(N_r\).

---

## 11. CP19 Task-5 survivor

The source-accurate CP19 Task-5 generator uses ordinary neutral pairs with
defects \((+1,-1)\) or \((-1,+1)\). Defect zero is introduced only when a
baseline target-height increment replaces a negative pair member by 0.

The target grows only \(O(\log N)\) times up to N. Special excursion defects
are negative and recovery uses positive defects. Hence
\[
\#\{k<N:d_k=0\}=O(\log N)
\]
and the canonical survivor has
\[
\boxed{\text{critical density }0.}
\]

However, Task 8A does **not** exclude this abstract survivor.

Its inserted mean-2 windows have excursion depth
\[
R_m=(2-\alpha)\ell_m+O(1)=\Theta(m)
\]
near \(k\asymp2^m\). Thus its deviation from
\(\kappa\log_2k\) is unbounded through the excursion cores.

Therefore the global Task-8A hypothesis
\[
s_k=\kappa\log_2k+O(1)
\]
fails.

Correct status:
\[
\boxed{\text{CP19 Task-5 survivor not excluded by Task 8A.}}
\]

Any claim that it is killed solely because its critical density is zero is
unsupported.

---

## 12. CP20 Task-3 reassessment

The historical Task-3 verdict remains a historical FAIL and is not promoted
to VALID.

However, one specific failure rationale is now superseded: the
zero-critical bounded-\(\{1,2,3\}\) critical-log controller used as a
downstream escape object cannot be a positive ordinary realization under the
frozen Task-6/Task-7 pressure theorem.

What remains valid from Task 3:
- exact recovery-debt geometry;
- exact signed flux identities;
- finite-lift realizability lemmas.

Therefore:

\[
\boxed{
\text{Task-3 historical verdict unchanged, but its zero-critical controller
countermodel rationale is superseded.}
}
\]

The recovery-debt mechanism merits a fresh test only inside the remaining
critical-site regime; no new theorem is claimed here.

---

## 13. Continued-fraction / repeat side branch

Repeated-factor spacing can lower-bound the state-bound constant appearing in
\[
n_k\le C\,k^\kappa.
\]

It does **not** directly lower-bound \(n_0\).

To convert a repeat lower bound on C into an \(n_0\) lower bound one needs an
explicit certified relation such as
\[
C\le C_0(M,\kappa)(n_0+1)
\]
with the relevant discrepancy constant M controlled.

The current continued-fraction experiments do not supply that certified
bridge.

Status:
\[
\boxed{\text{[LEAD] only.}}
\]

They are not evidence for Task 8A.

---

## 14. Scope

This theorem does **not**:

- prove the Collatz conjecture;
- exclude all critical-log orbits;
- exclude the CP19 excursion survivor;
- treat discrepancy laws outside
  \(s_k=\kappa\log_2k+O(1)\);
- prove any Task-8B arithmetic occupation obstruction;
- establish a new cycle theorem;
- reopen the parked CP19 high-half/cross-adic mechanism.

---

## 15. Final verdict

\[
\boxed{\textbf{[PROVED WITH WORDING REPAIR]}}
\]

The theorem candidate is load-bearing and must undergo independent
zero-trust audit before it is frozen or used in Task 8B.
