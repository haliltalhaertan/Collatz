#!/usr/bin/env python3
"""
CP20 Task 8B0 Module A — V2 Mechanical Verifier
Date: 2026-08-26

Purpose:
  - exact rational verification of the repaired branch-closure identities;
  - no theorem is inferred from numerical tails;
  - no Task-8A or CP19 high-half input is used.

All equality checks involving the affine/carry/conjugacy formulas use Python
fractions.Fraction exactly.
"""

from fractions import Fraction
from pathlib import Path
import hashlib, json, math

def v2(n):
    c=0
    while n % 2 == 0:
        n//=2
        c+=1
    return c

def odd_orbit(n0, K):
    assert n0>0 and n0%2==1
    n=n0
    vals=[]
    A=[0]
    states=[n]
    for _ in range(K):
        z=3*n+1
        a=v2(z)
        n=z//(2**a)
        vals.append(a)
        A.append(A[-1]+a)
        states.append(n)
    return vals,A,states

def parity_word_from_vals(vals):
    bits=[]
    for a in vals:
        bits.append(1)
        bits.extend([0]*(a-1))
    return bits

def phi_from_one_positions(pos):
    # finite parity series
    ans=Fraction(0)
    for i,d in enumerate(pos):
        ans -= Fraction(2**d,3**(i+1))
    return ans

def shifted_positions(pos, r):
    return [d-r for d in pos if d>=r]

def carry_B(A,k):
    return sum((3**(k-1-j))*(2**A[j]) for j in range(k))

def carry_partial(A,k):
    return sum(Fraction(2**A[j],3**(j+1)) for j in range(k))

def finite_phi(A,N):
    return -carry_partial(A,N)

def finite_Z(A,k,N):
    return -sum(
        Fraction(2**(A[j]-A[k]),3**(j-k+1))
        for j in range(k,N)
    )

def pow2_fraction(e):
    if e>=0:
        return Fraction(2**e,1)
    return Fraction(1,2**(-e))

def exact_suite():
    starts=0
    block_checks=0
    dk_checks=0
    carry_checks=0
    term_checks=0
    ratio_checks=0
    sep_checks=0
    branch_checks=0

    # Diverse actual positive ordinary prefixes.
    for n0 in range(1,1000,2):
        vals,A,states=odd_orbit(n0,28)
        bits=parity_word_from_vals(vals)

        # odd-only -> standard parity blocks and d_k=A_k
        one_positions=[i for i,b in enumerate(bits) if b==1]
        for k in range(len(vals)):
            assert one_positions[k]==A[k]
            dk_checks+=1
            assert bits[A[k]]==1
            assert all(bits[j]==0 for j in range(A[k]+1,A[k+1]))
            block_checks+=1

        # carry identity and partial López series
        for k in range(1,len(A)):
            B=carry_B(A,k)
            p=carry_partial(A,k)
            assert Fraction(B,3**k)==p
            carry_checks+=1

            # Exact rational precursor of
            # 2^A_k/3^(k+1)=(1/3)2^(-s_k-theta_k).
            # With F_k=floor(alpha k), theta identity is equivalent to:
            # left=(1/3)*2^(-s_k)*(2^F_k/3^k).
            alpha=math.log2(3.0)
            F=math.floor(alpha*k)
            s=F-A[k]
            left=Fraction(2**A[k],3**(k+1))
            right=Fraction(1,3)*pow2_fraction(-s)*Fraction(2**F,3**k)
            assert left==right
            term_checks+=1

        N=len(vals)
        phiN=finite_phi(A,N)
        for k in range(0,N):
            zkN=finite_Z(A,k,N)
            factor=Fraction(3**k,2**A[k])
            assert Fraction(states[k],1)-zkN == factor*(Fraction(n0,1)-phiN)
            sep_checks+=1

        # Exact shifted-parity conjugacy branches on finite parity series.
        pos=A[:len(vals)]
        for r in range(0, min(len(bits), A[-1])):
            p=shifted_positions(pos,r)
            x=phi_from_one_positions(p)
            b=bits[r]
            pnext=shifted_positions(pos,r+1)
            y=phi_from_one_positions(pnext)
            if b==0:
                assert y==x/2
            else:
                assert y==(3*x+1)/2
            branch_checks+=1

        # Exact rational precursor of shifted theta/ratio identity:
        # 2^(A_{k+j}-A_k)/3^j
        # = [2^(F_{k+j}-F_k)/3^j] * 2^(s_k-s_{k+j})
        alpha=math.log2(3.0)
        for k in range(1,10):
            Fk=math.floor(alpha*k)
            sk=Fk-A[k]
            for j in range(0,10):
                m=k+j
                Fm=math.floor(alpha*m)
                sm=Fm-A[m]
                lhs=Fraction(2**(A[m]-A[k]),3**j)
                rhs=Fraction(2**(Fm-Fk),3**j)*pow2_fraction(sk-sm)
                assert lhs==rhs
                ratio_checks+=1

        starts+=1

    return {
        "positive_odd_starts":starts,
        "block_encoding_checks":block_checks,
        "d_k_equals_A_k_checks":dk_checks,
        "carry_partial_exact_checks":carry_checks,
        "real_series_term_exact_rational_precursor_checks":term_checks,
        "finite_separation_identity_exact_checks":sep_checks,
        "conjugacy_branch_exact_checks":branch_checks,
        "shifted_ratio_exact_rational_precursor_checks":ratio_checks,
    }

def synthetic_schedule(kappa,N=50000):
    """
    Diagnostic only. Builds a phase-valid positive valuation word staying
    in a fixed-width corridor around kappa log2(k+2).
    """
    alpha=math.log2(3.0)
    s=0
    A=[0]
    ss=[0]
    vals=[]
    for k in range(N):
        g=math.floor(alpha*(k+1))-math.floor(alpha*k)
        target=math.floor(kappa*math.log2(k+2))
        # fixed bounded perturbation at sparse dyadic sites; not used for Result 5.
        shock=(k>=1024 and (k & (k-1) == 0))
        if shock:
            d=-6
        elif s<target and g==2:
            d=1
        elif s>target:
            d=target-s
        else:
            d=0
        a=g-d
        assert a>=1
        vals.append(a)
        s+=d
        ss.append(s)
        A.append(A[-1]+a)
    return A,ss,vals

def repaired_shape_diagnostics():
    rows=[]
    alpha=math.log2(3.0)
    for kappa in (1.06,1.5,2.0):
        A,ss,vals=synthetic_schedule(kappa)
        for k,J in ((256,4000),(1024,8000),(4096,12000)):
            if k+J>=len(vals):
                continue
            sa=0.0
            si=0.0
            for j in range(J+1):
                exponent=(A[k+j]-A[k])-alpha*j
                sa += 2.0**exponent
                si += (k/(k+j))**kappa
            rows.append({
                "kappa":kappa,
                "k":k,
                "J_same_horizon":J,
                "S_actual_over_S_ideal":sa/si,
            })
    return rows

def main():
    exact=exact_suite()
    diag=repaired_shape_diagnostics()

    result={
        "status":"PASS",
        "exact_checks":exact,
        "repaired_same_horizon_shape_diagnostics":diag,
        "diagnostic_warning":
            "Shape ratios are NUM checks only. The old falling truncated -Phi/k "
            "column is not used as evidence because its missing tail grows as k "
            "approaches the fixed truncation endpoint.",
        "result5_status":"[NOT ESTABLISHED — NOT NEEDED]",
        "dependency_checks":{
            "Task8A_used_in_analytic_verifier":False,
            "CP19_high_half_used":False,
        },
        "novelty_attribution":
            "Lopez-Stoll real-series convergence is the frozen Task-6 carry "
            "convergence rewritten in parity notation; Module A novelty is "
            "translation plus negative real-accumulation branch closure."
    }

    out=Path(__file__).with_name("CP20_TASK8B0_MODULE_A_VERIFY_V2_RESULTS.json")
    out.write_text(json.dumps(result,indent=2,sort_keys=True),encoding="utf-8")

    print("CP20 TASK 8B0 MODULE A — V2 MECHANICAL VERIFIER")
    print("STATUS: PASS")
    for k,v in exact.items():
        print(f"{k}: {v}")
    print("finite exact separation identity: PASS")
    print("Task-6 carry == partial Lopez-Stoll series: PASS")
    print("exact conjugacy branches: PASS")
    print("theta/ratio rational precursor identities: PASS")
    print("Result-5 status: [NOT ESTABLISHED — NOT NEEDED]")
    print("Task 8A analytic dependency: NONE")
    print("CP19 parked high-half dependency: NONE")
    print("repaired diagnostics: same-horizon S_actual/S_ideal only")
    for row in diag:
        print(
            "shape_ratio",
            f"kappa={row['kappa']}",
            f"k={row['k']}",
            f"J={row['J_same_horizon']}",
            f"ratio={row['S_actual_over_S_ideal']:.12f}"
        )
    print("ALL V2 MECHANICAL ASSERTIONS: PASS")

if __name__=="__main__":
    main()
