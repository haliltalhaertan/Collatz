# CP20 TASK 8B0 — MODULE A INDEPENDENT ZERO-TRUST AUDIT PROMPT

**Status:** `[AUDIT CANDIDATE]`

Act as an adversarial mathematical auditor. Do not assume any bridge formula
or reported diagnostic is correct.

## Claimed theorem

Under
\[
A_k=\sum_{i<k}a_i,\quad
s_k=\lfloor(\log_2 3)k\rfloor-A_k
=
\kappa\log_2k+O(1),
\]
the standard parity word
\[
v=1\,0^{a_0-1}1\,0^{a_1-1}\cdots
\]
satisfies:

1. one-positions \(d_k=A_k\);
2. parity density tends to \(\ln2/\ln3\);
3. López relative height
   \(n_\ell=(\kappa/\log_2 3)\log_2\ell+O(1)\);
4. level times
   \(\log_2\ell_j=(\log_2 3/\kappa)j+O(1)\);
5. the López real series term is exactly
   \[
   2^{A_k}/3^{k+1}
   =
   (1/3)2^{-s_k-\{(\log_2 3)k\}};
   \]
6. the real series converges absolutely iff \(\kappa>1\);
7. for \(\kappa>1\),
   \[
   \Phi_{\mathbb R}(S^{A_k}v)=-\Theta(k);
   \]
8. bounded valuation gaps imply the full real pseudo-orbit tends to
   \(-\infty\).

## Mandatory checks

1. Read López–Stoll arXiv:2101.12747 from the primary source.
2. Verify their \(T\) convention, parity-vector convention, \(d_i\), and
   conjugacy formula.
3. Verify the exact odd-only → standard parity block
   \(1\,0^{a_k-1}\).
4. Check all off-by-one height conventions:
   \(h(A_k)=k\) versus \(h(A_k+1)=k+1\).
5. Re-derive the parity-density limit.
6. Re-derive bounded valuations from the global critical-log law.
7. Re-derive exactly
   \[
   n_{A_k}
   =
   \lfloor(s_k+\{\alpha k\})/\alpha\rfloor.
   \]
8. Prove the all-\(\ell\) relative-height asymptotic.
9. Prove the level-time exponential rate and check existence of last-level
   times.
10. Verify that this rate alone does not imply López Result-5's consecutive
    gap-ratio hypothesis.
11. Re-derive the real-series term identity from scratch.
12. Check both directions of “converges iff \(\kappa>1\)”.
13. Re-derive the shifted-tail formula
    \[
    \Phi_{\mathbb R}(S^{A_k}v)
    =
    -(1/3)\sum_{j\ge0}2^{A_{k+j}-A_k}/3^j.
    \]
14. Re-derive the ratio identity
    \[
    2^{A_{k+j}-A_k}/3^j
    =
    2^{\theta_k-\theta_{k+j}}
    2^{s_k-s_{k+j}}.
    \]
15. Check the explicit two-sided constants.
16. Check the integral bounds for
    \(\sum_{j\ge0}(k/(k+j))^\kappa\).
17. Verify the passage from odd shifts to all standard parity times.
18. Try to construct a bounded-error critical-log schedule whose real
    pseudo-orbit does not tend to \(-\infty\).
19. Run the supplied exact/diagnostic script independently.
20. Check that Task 8A is not silently used to prove the analytic theorem.
21. Check that no ordinary-integer contradiction is claimed.
22. Check that no CP19 parked high-half/cross-adic mechanism is reopened.

## Required principal verdict

Return exactly one:

- `[PROOF VALID]`
- `[PROOF VALID WITH WORDING REPAIR]`
- `[FIXABLE GAP]`
- `[MAJOR GAP]`
- `[FALSE — COUNTEREXAMPLE]`

If valid, explicitly state whether this theorem is safe to freeze as the
Task-8B0 Module-A branch result and whether Modules B–E may resume afterward.
