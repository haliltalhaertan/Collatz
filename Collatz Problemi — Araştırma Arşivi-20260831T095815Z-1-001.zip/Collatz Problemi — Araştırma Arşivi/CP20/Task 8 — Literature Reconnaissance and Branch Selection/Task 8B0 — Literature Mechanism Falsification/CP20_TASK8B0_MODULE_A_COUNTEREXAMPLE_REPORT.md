# CP20 TASK 8B0 — MODULE A COUNTEREXAMPLE / FALSIFICATION REPORT

**Status:** `[AUDIT CANDIDATE]`

| Target | Result |
|---|---|
| Odd-only to standard parity dictionary could have an \(O(1)\) drift | `[EXACT]` — one-positions are exactly \(A_k\) |
| Parity density might miss the López critical boundary | `[EXACT]` — density tends exactly \(\ln2/\ln3\) |
| Candidate relative-height scale could have wrong \(\alpha\) factor | `[EXACT]` — \(n_\ell=(\kappa/\alpha)\log_2\ell+O(1)\) |
| López Result-5 gap-ratio \(<3\) might follow automatically | `[FAIL]` — bounded-error shock schedules produce ratios \(\gg3\) |
| Real-series convergence might require extra gap regularity | `[FALSE]` — each term is exactly \((1/3)2^{-s_k-\{\alpha k\}}\) |
| Critical-log \(\kappa>1\) might still permit series divergence | `[FALSE]` — terms are \(\Theta(k^{-\kappa})\) |
| Positive Task-8A critical density might force López real accumulation | `[FAIL]` — the entire real pseudo-orbit tends to \(-\infty\) |
| The pseudo-orbit escape may hold only at odd times | `[FALSE]` — bounded valuation gaps transfer \(-\Theta(k)\) to all standard times |
| Real-series convergence might itself contradict an ordinary positive start | `[NOT CLAIMED]` — López explicitly warns convergence alone is insufficient |
| Module A might reopen CP19 high-half/cross-adic state | `[NO]` |

## Exact computational checks

`CP20_TASK8B0_MODULE_A_VERIFY.py`:

- 500 positive odd starts;
- 17,500 exact standard-parity block checks;
- 100,000 relative-height floor/ceil identity checks;
- all assertions PASS.

## Adversarial gap-ratio schedules

A phase-valid symbolic controller was generated with fixed-depth shocks at
dyadic indices, followed by phase-valid recovery.

For \(\kappa=1.06,1.5,2.0\):

- the discrepancy remained within a fixed \(O(1)\) band of
  \(\kappa\log_2k\);
- valuations remained bounded;
- López last-level consecutive gap ratios were observed far above 3
  (largest diagnostics around 28,766, 28,766, and 43,148).

This demonstrates why Result-5's ratio condition cannot be inferred from the
critical-log asymptotic alone.

These values are `[NUM]` diagnostics, not theorem evidence.

## Strongest attempted attack on the escape theorem

The tail formula was recomputed from the shifted one-positions
\(A_{k+j}-A_k\).

The only possible multiplicative oscillations come from

\[
\{\alpha k\}-\{\alpha(k+j)\}
\]
and the bounded error difference
\[
e_k-e_{k+j}.
\]

Both are uniformly bounded, leaving the non-summable-in-\(j/k\) shape

\[
(k/(k+j))^\kappa.
\]

For \(\kappa>1\) its infinite sum is \(\Theta(k)\), so no bounded-error
oscillation can stop the linear escape.

No counterexample was found.
