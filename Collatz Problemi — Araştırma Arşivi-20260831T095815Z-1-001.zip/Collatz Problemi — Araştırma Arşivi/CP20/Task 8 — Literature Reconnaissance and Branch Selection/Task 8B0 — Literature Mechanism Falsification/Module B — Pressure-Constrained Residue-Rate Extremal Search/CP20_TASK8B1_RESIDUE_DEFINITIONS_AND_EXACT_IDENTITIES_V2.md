# CP20 TASK 8B1 — RESIDUE DEFINITIONS AND EXACT IDENTITIES

**Canonical V2 status:** `[EXACT][FROZEN SUPPORT]`

## Kramer normalization

For
\[
A_k=\sum_{j<k}a_j,\qquad
B_{k+1}=3B_k+2^{A_k},\quad B_0=0,
\]
define
\[
r_k\equiv-3^{-k}B_k\pmod{2^{A_k}},
\quad 0\le r_k<2^{A_k},
\]
and
\[
M_k\equiv2^{-A_k}B_k\pmod{3^k}.
\]

Kramer's rates use natural logarithms:
\[
\rho_r(k)=\frac{\ln(1+r_k)}k,
\]
\[
\rho_M(k)=
\frac1k
\ln\left(
1+\frac{M_k}{(3/2)^k}
\right).
\]

For \(k\ge1\), the endpoint residue is nonzero because
\[
B_k\equiv2^{A_{k-1}}\not\equiv0\pmod3.
\]

## Affine identity

For any starting value compatible with the prefix,
\[
\boxed{
2^{A_k}n_k=3^kn_0+B_k.
}
\]

## Start congruence and exact cylinder

The terminal integrality condition is
\[
\boxed{
n_0\equiv-3^{-k}B_k\pmod{2^{A_k}}.
}
\]

The exact final-symbol cylinder requires one additional parity bit:
\[
\boxed{
n_0
\equiv
(2^{A_k}-B_k)3^{-k}
\pmod{2^{A_k+1}}.
}
\]

Reduction modulo \(2^{A_k}\) gives \(r_k\).

## Start-residue shadow lemma

For every \(j\le k\),
\[
3^jr_k+B_j\equiv0\pmod{2^{A_j}}.
\]

Thus
\[
x_j^{(k)}
=
\frac{3^jr_k+B_j}{2^{A_j}}
\]
is integral.

For \(j<k\), \(x_j^{(k)}\) is odd; hence \(r_k\) exactly shadows the first
\(k-1\) accelerated exponents. Only the final exponent may be under-divided
unless the one-bit lift is chosen.

## Canonical pseudo-endpoint

Define
\[
X_k=
\frac{3^kr_k+B_k}{2^{A_k}}.
\]

The negative-shadow lemma proves
\[
\boxed{
1\le X_k<3^k
}
\]
for every positive exponent word.

Since
\[
M_k\equiv X_k\pmod{3^k},
\]
\[
\boxed{
M_k=X_k
}
\]
for every \(k\ge1\).

## Fixed ordinary realizer necessary vanishing

If one fixed positive odd \(n_0\) generates an infinite exact exponent code,
then
\[
r_k=n_0
\]
eventually, because the modulus \(2^{A_k}\to\infty\).

Also the actual endpoint is \(M_k=n_k\) eventually, and
\[
n_k+1\le(n_0+1)(3/2)^k.
\]

Therefore
\[
\rho_r(k)\to0,\qquad \rho_M(k)\to0.
\]

The stronger frozen V2 branch closure shows that, under global critical-log,
the second asymptotic condition is not independent of the first.
