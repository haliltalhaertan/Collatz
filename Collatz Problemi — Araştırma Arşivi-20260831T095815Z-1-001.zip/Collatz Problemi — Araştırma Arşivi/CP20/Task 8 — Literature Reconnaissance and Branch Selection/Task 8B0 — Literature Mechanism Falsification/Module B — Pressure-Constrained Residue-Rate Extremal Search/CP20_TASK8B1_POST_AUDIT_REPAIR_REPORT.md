# CP20 TASK 8B1 — POST-AUDIT REPAIR REPORT

**Date:** 2026-08-26  
**Audit verdict:** `[PROOF VALID WITH WORDING REPAIR]`  
**Old package integrity:** `[FAIL][MISSING INPUT]`

## R1 — Negative-shadow lemma

`PASS`.

Added exact prefix-divisibility step
\[
B_k\equiv3^{k-j}B_j\pmod{2^{A_j}}.
\]

Constructed
\[
y_j=
\frac{3^j(-\operatorname{gap}_k)+B_j}{2^{A_j}}.
\]

Proved:

- \(y_j\in\mathbb Z\) for all \(j\le k\);
- \(y_j\) is odd for \(j<k\);
- \(y_0\le-1\);
- negativity is invariant under the accelerated recurrence;
- \(y_k=X_k-3^k\le-1\).

Therefore
\[
\boxed{X_k<3^k}
\]
for every finite positive exponent word.

Sharpness:
all-ones gives
\[
X_k=3^k-1.
\]

## R2 — Exact endpoint identification

`PASS`.

Since
\[
M_k\equiv X_k\pmod{3^k}
\]
and
\[
1\le X_k<3^k,
\]
while
\[
B_k\equiv2^{A_{k-1}}\not\equiv0\pmod3,
\]
the canonical endpoint representative satisfies
\[
\boxed{M_k=X_k}
\]
for every \(k\ge1\).

## R3 — Stronger critical-log rate formula

`PASS`.

Removed the old assumption
\[
\limsup\rho_r<\ln3.
\]

Using only
\[
1/3\le B_k/3^k\le C
\]
and
\[
3^k/2^{A_k}=2^{s_k+\theta_k},
\]
derived
\[
X_k=M_k=k^\kappa\Theta(1)(1+r_k)
\]
and unconditionally inside critical-log
\[
\boxed{
\rho_M(k)
=
\max\{0,\rho_r(k)-\ln(3/2)\}
+
O(\log k/k).
}
\]

## R4 — Actual liminf redundancy corollary

`PASS`.

From the unconditional rate formula:
\[
\boxed{
\liminf\rho_M>0
\Rightarrow
\liminf\rho_r
=
\ln(3/2)+\liminf\rho_M>0.
}
\]

The weaker
\[
\rho_r\to0\Rightarrow\rho_M\to0
\]
is retained only as a corollary.

## R5 — Scope

`PASS`.

Added explicit all-ones warning and stated that critical-log is
load-bearing.

No positive lower bound for \(\rho_r\) is claimed.

No ordinary-realizer exclusion is claimed.

No Collatz solution is claimed.

Task 8A does not by itself force \(\rho_r\) away from zero.

CP19 high-half/cross-adic remains parked.

## R6 — Classification / novelty

`PASS`.

Retired:
`[MAJOR THEOREM CANDIDATE]`.

Canonical structural status:
\[
\boxed{
\texttt{[PROVED][INDEPENDENTLY AUDITED][BRANCH CLOSURE][FROZEN]}
}
\]

Genuine contribution:

1. exact finite-word negative-shadow lemma;
2. exact \(M_k=X_k\);
3. unconditional critical-log Kramer rate relation;
4. liminf redundancy of the 3-adic branch.

## R7 — Package integrity

`PASS`.

The V2 package contains every payload named in `SHA256SUMS_V2.txt`.
The eight files absent from the prior audit ZIP are physically included:

- `CP20_TASK8B1_MODULE_B_MASTER_FINDINGS.md`
- `CP20_TASK8B1_EXTREMAL_SEARCH_ENGINE.py`
- `CP20_TASK8B1_EXTREMAL_RESULTS.json`
- `CP20_TASK8B1_PARETO_FRONTIERS.csv`
- `CP20_TASK8B1_NESTED_FIXED_N0_SEARCH.json`
- `CP20_TASK8B1_SCALING_ANALYSIS.md`
- `CP20_TASK8B1_THEOREM_TRIAGE.md`
- `README.md`

U3/U4 material remains `[NUM]/[B-LEAD]`.

By standard checksum convention, `SHA256SUMS_V2.txt` lists every other
payload file exactly once and does not self-hash.

The ZIP contains exactly:
\[
\{\text{manifest}\}\cup\{\text{manifest-listed payloads}\}.
\]

## Mechanical verification

The V2 verifier was run twice from source.

Logical stdout is byte-identical.

All exact assertions passed.

## Final repair verdict

\[
\boxed{\texttt{ALL REQUIRED POST-AUDIT REPAIRS: PASS}}
\]
