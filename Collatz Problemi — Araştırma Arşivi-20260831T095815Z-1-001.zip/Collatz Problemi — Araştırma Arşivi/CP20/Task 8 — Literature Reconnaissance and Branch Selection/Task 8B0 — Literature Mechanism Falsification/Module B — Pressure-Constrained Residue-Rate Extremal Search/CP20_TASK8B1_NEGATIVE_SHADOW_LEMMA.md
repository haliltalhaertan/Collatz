# CP20 TASK 8B1 — NEGATIVE-SHADOW LEMMA

**Date:** 2026-08-26  
**Status:** `[PROVED][INDEPENDENTLY AUDITED][FROZEN SUPPORTING LEMMA]`

## Setting

Let
\[
a_0,\ldots,a_{k-1}\in\mathbb Z_{\ge1}
\]
be any finite positive exponent word. Define
\[
A_0=0,\qquad A_j=\sum_{i<j}a_i,
\]
and
\[
B_0=0,\qquad
B_{j+1}=3B_j+2^{A_j}.
\]

Equivalently,
\[
B_j=\sum_{i=0}^{j-1}3^{j-1-i}2^{A_i}.
\]

Let
\[
r_k\equiv-3^{-k}B_k\pmod{2^{A_k}},
\qquad
0\le r_k<2^{A_k},
\]
be the canonical least nonnegative start representative, and define
\[
\operatorname{gap}_k=2^{A_k}-r_k.
\]

Since \(B_k\) is odd, \(r_k\) is odd and nonzero, hence
\[
1\le \operatorname{gap}_k<2^{A_k}.
\]

Define
\[
X_k=\frac{3^kr_k+B_k}{2^{A_k}}\in\mathbb Z_{>0}.
\]

## Prefix divisibility

For every \(0\le j\le k\),
\[
\boxed{
B_k\equiv 3^{k-j}B_j\pmod{2^{A_j}}.
}
\]

Indeed,
\[
B_k
=
3^{k-j}B_j
+
\sum_{i=j}^{k-1}3^{k-1-i}2^{A_i},
\]
and every term in the second sum is divisible by \(2^{A_j}\) because
\(A_i\ge A_j\).

The terminal start congruence gives
\[
3^kr_k+B_k\equiv0\pmod{2^{A_k}},
\]
and therefore also modulo \(2^{A_j}\). Using the displayed prefix relation,
\[
3^{k-j}(3^jr_k+B_j)\equiv0\pmod{2^{A_j}}.
\]
Powers of \(3\) are invertible modulo \(2^{A_j}\), so
\[
\boxed{
3^jr_k+B_j\equiv0\pmod{2^{A_j}}.
}
\]

Since
\[
-\operatorname{gap}_k=r_k-2^{A_k}
\equiv r_k\pmod{2^{A_j}},
\]
we also have
\[
3^j(-\operatorname{gap}_k)+B_j
\equiv0\pmod{2^{A_j}}.
\]

Thus
\[
\boxed{
y_j:=
\frac{3^j(-\operatorname{gap}_k)+B_j}{2^{A_j}}
\in\mathbb Z
}
\]
for every \(0\le j\le k\).

## Negative shadow remains odd before the endpoint

For \(j<k\), the recurrence is
\[
2^{a_j}y_{j+1}=3y_j+1.
\]

If \(y_j\) were even, then \(3y_j+1\) would be odd, impossible because
\(a_j\ge1\) and \(y_{j+1}\in\mathbb Z\). Therefore
\[
\boxed{
y_j\text{ is odd for every }j<k.
}
\]

## Negative invariance

At time \(0\),
\[
y_0=-\operatorname{gap}_k\le-1.
\]

Suppose \(j<k\) and \(y_j\le-1\). Then
\[
3y_j+1<0.
\]
Since it is divisible by \(2^{a_j}\), it is a negative nonzero multiple of
\(2^{a_j}\), hence
\[
3y_j+1\le-2^{a_j}.
\]
Therefore
\[
\boxed{
y_{j+1}\le-1.
}
\]

By induction,
\[
y_j\le-1
\qquad(0\le j\le k).
\]

## Endpoint consequence

Because
\[
-\operatorname{gap}_k=r_k-2^{A_k},
\]
\[
y_k
=
\frac{3^k(r_k-2^{A_k})+B_k}{2^{A_k}}
=
X_k-3^k.
\]

Since \(y_k\le-1\),
\[
\boxed{
1\le X_k\le3^k-1.
}
\]

In particular,
\[
\boxed{
X_k<3^k
}
\]
for every finite positive exponent word.

## Sharpness

For the all-ones word
\[
a_0=\cdots=a_{k-1}=1,
\]
one has
\[
r_k=2^k-1
\]
and
\[
\boxed{
X_k=3^k-1.
}
\]

Thus the upper bound is sharp.

## Exact 3-adic endpoint identification

Let
\[
M_k\equiv2^{-A_k}B_k\pmod{3^k}
\]
be Kramer's canonical nonzero representative.

Since
\[
2^{A_k}X_k=3^kr_k+B_k,
\]
\[
X_k\equiv2^{-A_k}B_k\equiv M_k\pmod{3^k}.
\]

Also
\[
B_k\equiv2^{A_{k-1}}\not\equiv0\pmod3,
\]
so \(M_k\ne0\pmod{3^k}\).

Both \(X_k\) and \(M_k\) lie in
\[
\{1,\ldots,3^k-1\},
\]
therefore
\[
\boxed{
M_k=X_k
}
\]
for every \(k\ge1\).
