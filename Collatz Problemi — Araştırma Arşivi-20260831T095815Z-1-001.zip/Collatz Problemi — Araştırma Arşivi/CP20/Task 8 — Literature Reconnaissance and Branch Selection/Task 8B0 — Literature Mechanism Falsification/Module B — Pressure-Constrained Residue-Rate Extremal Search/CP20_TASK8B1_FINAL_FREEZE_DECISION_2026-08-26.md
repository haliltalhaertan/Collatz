# CP20 TASK 8B1 — FINAL FREEZE DECISION — 2026-08-26

## Independent audit

Principal verdict:
\[
\boxed{\texttt{[PROOF VALID WITH WORDING REPAIR]}}.
\]

Previous package integrity:
\[
\boxed{\texttt{[FAIL][MISSING INPUT]}}.
\]

Both the theorem wording and package integrity have now been repaired.

## Mandatory theorem repairs

Negative-shadow lemma:
`PASS`.

Exact
\[
X_k<3^k
\]
for every finite positive exponent word:
`PASS`.

Exact
\[
M_k=X_k
\]
for every \(k\ge1\):
`PASS`.

Unconditional critical-log rate formula:
\[
\rho_M(k)
=
\max\{0,\rho_r(k)-\ln(3/2)\}
+
O(\log k/k)
\]
`PASS`.

Old hypothesis
\[
\limsup\rho_r<\ln3
\]
removed completely from the canonical theorem:
`PASS`.

Liminf redundancy corollary:
`PASS`.

All-ones scope warning:
`PASS`.

Classification repair:
`PASS`.

## Mechanical verification

`CP20_TASK8B1_VERIFY_V2.py` was executed twice from source.

The two logical stdout byte streams are identical.

The verifier independently checks:

- affine recurrence and closed form;
- terminal start congruence;
- prefix divisibility;
- integrality of every negative-shadow prefix state;
- oddness for all preterminal shadow states;
- invariant negativity;
- \(X_k<3^k\);
- all-ones sharpness \(X_k=3^k-1\);
- \(M_k=X_k\);
- nonzero endpoint residue mod 3;
- exact-cylinder one-bit lift;
- exact direct simulation on a finite exhaustive family;
- random larger positive words.

Final logical line:
`ALL V2 FREEZE VERIFIER ASSERTIONS: PASS`.

## Package integrity

The V2 ZIP physically includes all eight files absent from the prior audit
package, plus every canonical repaired theorem/support file.

The checksum manifest and ZIP member list were mechanically cross-checked.

Result:
\[
\boxed{\texttt{PACKAGE INTEGRITY: PASS}}.
\]

## Final structural classification

\[
\boxed{
\texttt{[PROVED][INDEPENDENTLY AUDITED][BRANCH CLOSURE][FROZEN]}
}
\]

## Numerical branch status

\[
\boxed{\texttt{[B-LEAD]}}.
\]

No positive lower bound for \(\rho_r\) has been proved.

## Authorized next branch

\[
\boxed{
\texttt{MODULE D AUTHORIZED — PURE 2-ADIC START-RATE BRANCH}
}
\]

Target mechanism:

Sturmian return words / continued-fraction near-returns

+

Task-6 repeated-factor divisibility/spacing

+

canonical 2-adic start-residue stabilization/rate.

Do not describe Module D as a 2-adic/3-adic conjunction branch.
