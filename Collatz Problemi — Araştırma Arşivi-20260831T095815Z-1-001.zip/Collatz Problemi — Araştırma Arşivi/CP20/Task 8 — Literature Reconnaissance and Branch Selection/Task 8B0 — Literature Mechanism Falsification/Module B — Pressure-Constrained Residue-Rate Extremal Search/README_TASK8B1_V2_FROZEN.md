# CP20 TASK 8B1 — FROZEN V2 PACKAGE

**Structural status:** `[PROVED][INDEPENDENTLY AUDITED][BRANCH CLOSURE][FROZEN]`  
**Numerical residue-obstruction status:** `[B-LEAD]`

## Canonical theorem

For every finite positive exponent word,
\[
M_k=X_k
=
\frac{3^kr_k+B_k}{2^{A_k}}
\]
exactly.

Under
\[
s_k=\kappa\log_2k+O(1),\qquad\kappa>1,
\]
\[
\rho_M(k)
=
\max\{0,\rho_r(k)-\ln(3/2)\}
+
O(\log k/k).
\]

Therefore
\[
\liminf\rho_M>0
\Rightarrow
\liminf\rho_r
=
\ln(3/2)+\liminf\rho_M>0.
\]

The 3-adic endpoint rate is not an independent asymptotic Kramer obstruction
inside this critical-log class.

## Unresolved target

Can a frozen critical-log / Task-8A survivor satisfy
\[
\rho_r(k)\to0?
\]

## Package integrity convention

`SHA256SUMS_V2.txt` lists every other payload in this ZIP exactly once.
It does not list itself, avoiding impossible self-hashing.

The package-builder verifies:
\[
\text{ZIP names}
=
\{\text{manifest}\}
\cup
\{\text{manifest-listed payloads}\}.
\]

## Numerical files

The original extremal engine/results/Pareto/nesting/scaling artifacts are
included for reproducibility and remain `[NUM]/[B-LEAD]`.

## Next branch

Module D is authorized as a **pure 2-adic start-rate** branch only.
