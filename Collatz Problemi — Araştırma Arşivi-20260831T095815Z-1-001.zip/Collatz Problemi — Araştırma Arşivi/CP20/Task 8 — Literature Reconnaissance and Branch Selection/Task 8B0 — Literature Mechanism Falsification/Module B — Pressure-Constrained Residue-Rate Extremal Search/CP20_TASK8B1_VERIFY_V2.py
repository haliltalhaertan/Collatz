#!/usr/bin/env python3
"""
CP20 TASK 8B1 — V2 FREEZE VERIFIER
Date: 2026-08-26

All equality/congruence checks are exact integer arithmetic.
The asymptotic critical-log rate formula is proved analytically in the V2
theorem; this verifier checks its finite algebraic backbone.

No Task-8A finite surrogate, Module D, or CP19 parked high-half state is used.
"""

from itertools import product
import random

def affine(word):
    A=[0]
    B=[0]
    for a in word:
        B.append(3*B[-1] + (1<<A[-1]))
        A.append(A[-1]+a)
    return A,B

def v2(n):
    c=0
    while n%2==0:
        n//=2
        c+=1
    return c

def canonical(word):
    k=len(word)
    A,B=affine(word)
    mod2=1<<A[k]
    r=(-B[k]*pow(3,-k,mod2))%mod2
    gap=mod2-r
    X=(3**k*r+B[k])//mod2
    mod3=3**k
    M=(B[k]*pow(2,-A[k],mod3))%mod3
    return A,B,r,gap,X,M

def exact_lift(word):
    k=len(word)
    A,B=affine(word)
    mod=1<<(A[k]+1)
    R=((1<<A[k])-B[k])*pow(3,-k,mod)%mod
    return R if R else R+mod

def direct(n,depth):
    vals=[]
    for _ in range(depth):
        z=3*n+1
        a=v2(z)
        vals.append(a)
        n=z>>a
    return vals,n

def check_word(word):
    k=len(word)
    A,B,r,gap,X,M=canonical(word)

    # Closed form for B.
    Bclosed=sum(3**(k-1-i)*(1<<A[i]) for i in range(k))
    assert B[k]==Bclosed

    # Terminal congruence.
    assert (3**k*r+B[k])%(1<<A[k])==0

    # r is odd and nonzero for k>=1.
    assert r>0 and r%2==1
    assert 1<=gap<(1<<A[k])

    # Prefix divisibility and negative-shadow states.
    ys=[]
    for j in range(k+1):
        assert (B[k]-3**(k-j)*B[j])%(1<<A[j])==0
        assert (3**j*r+B[j])%(1<<A[j])==0
        num=3**j*(-gap)+B[j]
        assert num%(1<<A[j])==0
        y=num//(1<<A[j])
        ys.append(y)
        assert y<=-1
        if j<k:
            assert y%2!=0

    # Shadow recurrence.
    for j,a in enumerate(word):
        assert 3*ys[j]+1==(1<<a)*ys[j+1]

    # Endpoint bound.
    assert ys[k]==X-3**k
    assert 1<=X<3**k

    # Endpoint representative exact equality.
    assert B[k]%3!=0
    assert 1<=M<3**k
    assert X%3**k==M
    assert M==X

    # Exact one-bit lift realizes the full exponent word.
    R=exact_lift(word)
    assert R%(1<<A[k])==r
    vals,end=direct(R,k)
    assert vals==list(word)
    assert end==X+3**k*((R-r)//(1<<A[k]))

    return len(ys)

def all_ones_sharpness():
    checks=0
    for k in range(1,81):
        word=(1,)*k
        A,B,r,gap,X,M=canonical(word)
        assert X==3**k-1
        assert M==X
        checks+=1
    return checks

def main():
    exact_words=0
    shadow_states=0
    for word in product((1,2,3), repeat=10):
        shadow_states += check_word(word)
        exact_words += 1

    rng=random.Random(20260826)
    random_words=0
    for _ in range(5000):
        L=rng.randint(12,100)
        word=tuple(rng.randint(1,10) for _ in range(L))
        shadow_states += check_word(word)
        random_words += 1

    sharp=all_ones_sharpness()

    print("CP20 TASK 8B1 — V2 FREEZE VERIFIER")
    print("exact words {1,2,3}^10:", exact_words)
    print("random larger positive words:", random_words)
    print("negative-shadow prefix states checked:", shadow_states)
    print("all-ones sharpness checks:", sharp)
    print("prefix divisibility: PASS")
    print("negative-shadow integrality/oddness/negativity: PASS")
    print("X_k < 3^k for checked words: PASS")
    print("M_k = X_k for checked words: PASS")
    print("nonzero mod-3 endpoint residue: PASS")
    print("exact-cylinder one-bit lift/direct realization: PASS")
    print("Task-8A finite surrogate dependency: NONE")
    print("CP19 parked high-half dependency: NONE")
    print("ALL V2 FREEZE VERIFIER ASSERTIONS: PASS")

if __name__=="__main__":
    main()
