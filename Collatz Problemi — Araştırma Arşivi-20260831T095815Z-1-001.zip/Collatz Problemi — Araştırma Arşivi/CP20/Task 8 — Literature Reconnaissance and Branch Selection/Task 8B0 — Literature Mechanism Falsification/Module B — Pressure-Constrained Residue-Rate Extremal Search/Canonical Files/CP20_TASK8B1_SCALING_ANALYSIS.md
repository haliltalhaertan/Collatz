# CP20 TASK 8B1 — SCALING ANALYSIS

**Status:** `[NUM]`

## Main caution

The quantity reported is the **best found**
\[
E_k=\max(\rho_r,\rho_M)
\]
inside a finite heuristic search pool.

Therefore a positive observed value is an upper bound on the unknown true
extremal minimum, not a lower bound.

No asymptotic theorem follows from the apparent plateau.

## Main M=4 U4 results


### kappa=1.06

| k | rho_r | rho_M | E |
|---:|---:|---:|---:|
| 50 | 0.799232 | 0.521973 | 0.799232 |
| 100 | 0.969414 | 0.622841 | 0.969414 |
| 200 | 1.032800 | 0.668898 | 1.032800 |
| 400 | 1.064249 | 0.681285 | 1.064249 |
| 800 | 1.078247 | 0.685753 | 1.078247 |
| 1600 | 1.088740 | 0.689747 | 1.088740 |

### kappa=1.2

| k | rho_r | rho_M | E |
|---:|---:|---:|---:|
| 50 | 0.872080 | 0.594822 | 0.872080 |
| 100 | 0.966434 | 0.640655 | 0.966434 |
| 200 | 1.019752 | 0.662781 | 1.019752 |
| 400 | 1.066015 | 0.683051 | 1.066015 |
| 800 | 1.077689 | 0.686060 | 1.077689 |
| 1600 | 1.089123 | 0.690996 | 1.089123 |

### kappa=1.5

| k | rho_r | rho_M | E |
|---:|---:|---:|---:|
| 50 | 0.801482 | 0.482634 | 0.801482 |
| 100 | 0.953322 | 0.620612 | 0.953322 |
| 200 | 1.020651 | 0.670612 | 1.020651 |
| 400 | 1.060291 | 0.673861 | 1.060291 |
| 800 | 1.076145 | 0.686250 | 1.076145 |
| 1600 | 1.088239 | 0.690979 | 1.088239 |

### kappa=2.0

| k | rho_r | rho_M | E |
|---:|---:|---:|---:|
| 50 | 0.823658 | 0.574125 | 0.823658 |
| 100 | 0.924302 | 0.640111 | 0.924302 |
| 200 | 0.998297 | 0.658655 | 0.998297 |
| 400 | 1.046861 | 0.676028 | 1.046861 |
| 800 | 1.071860 | 0.687164 | 1.071860 |
| 1600 | 1.085217 | 0.690990 | 1.085217 |

### kappa=2.5

| k | rho_r | rho_M | E |
|---:|---:|---:|---:|
| 50 | 0.794668 | 0.586724 | 0.794668 |
| 100 | 0.916515 | 0.632325 | 0.916515 |
| 200 | 0.983741 | 0.661428 | 0.983741 |
| 400 | 1.040041 | 0.679604 | 1.040041 |
| 800 | 1.068429 | 0.687198 | 1.068429 |
| 1600 | 1.080904 | 0.688842 | 1.080904 |

### kappa=2.7

| k | rho_r | rho_M | E |
|---:|---:|---:|---:|
| 50 | 0.711501 | 0.517420 | 0.711501 |
| 100 | 0.911264 | 0.640937 | 0.911264 |
| 200 | 0.995630 | 0.673317 | 0.995630 |
| 400 | 1.035370 | 0.678399 | 1.035370 |
| 800 | 1.067772 | 0.689140 | 1.067772 |
| 1600 | 1.082130 | 0.690935 | 1.082130 |

## Candidate decay models

The requested zero-decay templates
\[
c/\log k,\quad
c/\sqrt{\log k},\quad
c/k^\beta,\quad
\log\log k/\log k
\]
are not visually supported by the best-found data: \(E_k\) generally rises
from the short-prefix values toward roughly \(1.08\).

This does not falsify those asymptotic possibilities because the optimizer
is heuristic and the search space grows exponentially.

## Structural rate prediction

The exact theorem candidate predicts, whenever
\[
\limsup\rho_r<\ln3,
\]
that
\[
\rho_M
=
\max(0,\rho_r-\ln(3/2))+o(1).
\]

At \(k=1600\), the observed differences
\[
\rho_M-\max(0,\rho_r-\ln(3/2))
\]
are small (roughly \(0.006\)–\(0.014\) across the tested kappas), consistent
with the finite polynomial/carry correction.

This agreement is a diagnostic cross-check only; the theorem is proved
analytically, not fitted from these values.

## Corridor sensitivity

At \(k=400\), \(M=2,4,8\) runs change the best-found finite values but do not
produce a family trending to zero.

For the tight \(M=2\) corridor, some high-kappa beam runs did not retain any
candidate to depth 400. This is a search failure / finite feasibility issue,
not an impossibility theorem.

## Interpretation

Finite evidence supports continuing the start-residue obstruction branch,
but the current computation does not justify
\[
\liminf\rho_r>0.
\]

A new structural ingredient is required.
