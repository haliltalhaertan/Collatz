# CP20 TASK 8B1 — RESIDUE DEFINITIONS AND EXACT IDENTITIES

**Status:** `[EXACT + AUDIT-CANDIDATE DEPENDENCY]`

## Kramer convention dictionary

Kramer indexes the accelerated exponents as
\[
(a_1,\ldots,a_k).
\]
CP20 uses
\[
(a_0,\ldots,a_{k-1}).
\]
They are the same symbols with a one-index shift.

Kramer:
\[
A_k=a_1+\cdots+a_k.
\]
CP20:
\[
A_k=\sum_{j<k}a_j.
\]

Both affine formulas are
\[
\boxed{
2^{A_k}n_k=3^kn_0+B_k
}
\]
with
\[
\boxed{
B_0=0,\qquad
B_{k+1}=3B_k+2^{A_k}
}
\]
and
\[
\boxed{
B_k=\sum_{j=0}^{k-1}3^{k-1-j}2^{A_j}.
}
\]

## 2-adic start residue

Every exact realizing start satisfies
\[
3^kn_0+B_k\equiv0\pmod{2^{A_k}},
\]
hence
\[
\boxed{
n_0\equiv-3^{-k}B_k\pmod{2^{A_k}}.
}
\]

Define
\[
\boxed{
r_k\in[0,2^{A_k})
}
\]
as the least nonnegative representative.

Kramer uses
\[
\boxed{
\rho_r(k)=\frac{\ln(1+r_k)}k.
}
\]

### Exact-cylinder one-bit lift

A subtle but important distinction:

The congruence modulo \(2^{A_k}\) guarantees integrality of the terminal
affine state. To force the **last exponent itself to be exact**, the terminal
quotient must be odd:
\[
3^kn_0+B_k\equiv2^{A_k}\pmod{2^{A_k+1}}.
\]

Thus the exact length-\(k\) cylinder is
\[
\boxed{
n_0
\equiv
(2^{A_k}-B_k)3^{-k}
\pmod{2^{A_k+1}}.
}
\]

Its reduction modulo \(2^{A_k}\) is exactly \(r_k\).

This distinction is required for direct-simulation verification.

## Start-residue shadow lemma

Let \(r_k\) be Kramer's canonical residue.

For every \(j\le k\),
\[
3^jr_k+B_j
\]
is divisible by \(2^{A_j}\).

Define
\[
x_j^{(k)}
=
\frac{3^jr_k+B_j}{2^{A_j}}.
\]

For \(j<k\), these intermediate states are odd. If some \(x_j^{(k)}\) with
\(j<k\) were even, then \(3x_j^{(k)}+1\) would be odd, contradicting
integrality at the next positive exponent.

Therefore
\[
\boxed{
r_k\text{ follows }a_0,\ldots,a_{k-2}
\text{ as exact accelerated valuations.}
}
\]

The final selected \(a_{k-1}\) may be smaller than the actual last valuation
of the trajectory starting at \(r_k\). The one-bit exact-cylinder lift
chooses the unique alternative that makes the last quotient odd.

This explains why terminal start-residue optimization is already strongly
coupled to long ordinary-orbit shadowing.

## 3-adic endpoint residue

From the affine identity,
\[
2^{A_k}n_k\equiv B_k\pmod{3^k}.
\]

Hence
\[
\boxed{
n_k\equiv2^{-A_k}B_k\pmod{3^k}.
}
\]

CP20 uses the least representative
\[
M_k\in[0,3^k).
\]

Kramer writes \(1\le M_k\le3^k\). For \(k\ge1\) the residue is nonzero
modulo 3, so the conventions agree numerically.

Kramer:
\[
\boxed{
\rho_M(k)
=
\frac1k
\ln\left(
1+\frac{M_k}{(3/2)^k}
\right).
}
\]

## Necessary vanishing — independently re-derived

If one fixed positive odd integer \(n_0\) generates the infinite exact code,
then
\[
r_k\equiv n_0\pmod{2^{A_k}}.
\]
Since \(A_k\ge k\),
\[
2^{A_k}>n_0
\]
eventually, so
\[
\boxed{r_k=n_0}
\]
eventually and
\[
\rho_r(k)\to0.
\]

The realized endpoint satisfies
\[
n_k\equiv M_k\pmod{3^k}.
\]

For positive odd Syracuse,
\[
n_{k+1}+1
\le\frac32(n_k+1),
\]
hence
\[
n_k+1\le(n_0+1)(3/2)^k.
\]

Thus \(n_k<3^k\) eventually, so
\[
\boxed{M_k=n_k}
\]
eventually and
\[
\rho_M(k)\to0.
\]

This reproduces Kramer's necessary-vanishing theorem without using his
finite experiments.
