# CP20 TASK 8B1 — RESULTS / AUDIT PACKAGE

**Module obstruction triage:** `[B-LEAD]`  
**Structural theorem:** `[MAJOR THEOREM CANDIDATE][AUDIT CANDIDATE]`

## Key computational result

No best-found pressure-surrogate candidate through \(k=1600\) drove both
Kramer rates toward zero. The start rate was the bottleneck.

This is numerical evidence only.

## Key exact result

Inside global critical-log:
\[
\rho_r\to0\Rightarrow\rho_M\to0.
\]

Thus the 3-adic endpoint rate is asymptotically redundant once the 2-adic
start rate vanishes.

## Important exact cylinder distinction

Kramer's start representative is modulo \(2^{A_k}\).

Exact realization of the final exponent requires the one-bit lift modulo
\(2^{A_k+1}\).

Both are documented and exhaustively verified.

## Files

- `CP20_TASK8B1_MODULE_B_MASTER_FINDINGS.md`
- `CP20_TASK8B1_RESIDUE_DEFINITIONS_AND_EXACT_IDENTITIES.md`
- `CP20_TASK8B1_EXTREMAL_SEARCH_ENGINE.py`
- `CP20_TASK8B1_EXTREMAL_RESULTS.json`
- `CP20_TASK8B1_PARETO_FRONTIERS.csv`
- `CP20_TASK8B1_NESTED_FIXED_N0_SEARCH.json`
- `CP20_TASK8B1_COUNTEREXAMPLE_REPORT.md`
- `CP20_TASK8B1_SCALING_ANALYSIS.md`
- `CP20_TASK8B1_THEOREM_TRIAGE.md`
- `CP20_TASK8B1_RESIDUE_REDUNDANCY_THEOREM_AUDIT_CANDIDATE.md`
- `CP20_TASK8B1_RESIDUE_REDUNDANCY_DEPENDENCY_GRAPH.md`
- `CP20_TASK8B1_RESIDUE_REDUNDANCY_VERIFY.py`
- `CP20_TASK8B1_RESIDUE_REDUNDANCY_VERIFY_OUTPUT.txt`
- `CP20_TASK8B1_RESIDUE_REDUNDANCY_ZERO_TRUST_AUDIT_PROMPT.md`
- `SHA256SUMS.txt`

## Stop rule

No Module D/C/E work was started after the load-bearing theorem candidate
was identified.

## Recommendation after audit

**ADD MODULE D RETURN-WORD/REPEATED-FACTOR CONJUNCTION**
