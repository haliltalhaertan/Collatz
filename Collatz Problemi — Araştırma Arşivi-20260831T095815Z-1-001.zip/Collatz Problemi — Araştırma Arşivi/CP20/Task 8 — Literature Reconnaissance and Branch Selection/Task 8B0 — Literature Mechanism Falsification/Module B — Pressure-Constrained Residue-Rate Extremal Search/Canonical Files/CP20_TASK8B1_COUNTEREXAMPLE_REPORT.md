# CP20 TASK 8B1 — COUNTEREXAMPLE / FALSIFICATION REPORT

**Status:** `[B-LEAD]` for the obstruction route.

## Falsification target 1 — residue route without survivor constraints

Killed immediately.

U0 contains the all-2 exponent code, realized by \(n_0=1\), for which both
Kramer residue rates vanish.

Therefore no unrestricted residue-gap theorem is possible.

## Falsification target 2 — finite small start residue equals exact cylinder witness

False.

Kramer's terminal congruence
\[
r_k\pmod{2^{A_k}}
\]
does not force the final quotient to be odd.

Exact final-symbol realization requires
\[
n_0\equiv
(2^{A_k}-B_k)3^{-k}
\pmod{2^{A_k+1}}.
\]

The two possible lifts differ by \(2^{A_k}\).

This distinction was found by exhaustive direct simulation and then proved
algebraically.

## Falsification target 3 — terminal small residue is unrelated to ordinary dynamics

False in a strong sense.

The canonical \(r_k\) itself realizes the first \(k-1\) selected valuations
exactly. Only the last selected exponent can be under-divided.

Hence optimizing \(r_k\) is tightly coupled to searching for a small ordinary
start that shadows the desired symbolic schedule for almost the whole prefix.

## Falsification target 4 — positive best-found plateau proves a gap

Rejected.

At lengths through 1600, best-found U3/U4 \(E_k\) remains clearly positive,
but the search is heuristic. It supplies candidate upper bounds on the true
minimum, never a universal lower bound.

No positive-gap theorem is claimed.

## Falsification target 5 — two independent asymptotic residue obstructions

Rejected inside the global critical-log class.

The new exact candidate theorem gives
\[
\rho_r\to0\implies\rho_M\to0.
\]

Thus a future proof cannot gain an independent asymptotic obstruction merely
by demanding both Kramer rates vanish.

The 3-adic endpoint remains useful for finite search and diagnostics.

## Falsification target 6 — finite pressure is a frozen Task-8A theorem

Rejected.

U3 and U4 are deliberately stronger finite computational surrogates.

The frozen Task-8A theorem only constrains accumulation points on its audited
multiplicative scale families.

## Falsification target 7 — optimized finite witnesses imply LEVEL-3 survival

Rejected.

The engine constructs/identifies exact positive witnesses for long finite
optimized prefixes, including length 1600.

Their ordinary continuation generally exits the imposed critical-log
corridor soon after the optimized horizon.

This is finite LEVEL-2 evidence only.

## Current unresolved obstruction

The surviving question is purely the start-rate problem:
\[
\boxed{
\text{Can an infinite critical-log / Task-8A survivor have }
\rho_r(k)\to0?
}
\]

No counterexample family and no positive lower-bound proof was found.
