# CP20 TASK 8B1 — THEOREM TRIAGE

## Primary Module-B obstruction verdict

\[
\boxed{\texttt{[B-LEAD]}}
\]

Reason:

- persistent positive best-found residue rates through \(k=1600\);
- no scalable vanishing family found;
- no proof of a positive lower bound;
- no nesting obstruction theorem.

## Separate structural theorem candidate

\[
\boxed{
\texttt{[MAJOR THEOREM CANDIDATE][AUDIT CANDIDATE]}
}
\]

Statement:
\[
s_k=\kappa\log_2k+O(1),\ \kappa>1,\ \rho_r(k)\to0
\Longrightarrow
\rho_M(k)\to0.
\]

Stronger form under
\[
\limsup\rho_r<\ln3:
\]
\[
\rho_M(k)
=
\max\{0,\rho_r(k)-\ln(3/2)\}+o(1).
\]

This theorem is load-bearing because it changes future search design:
the endpoint rate is not an independent asymptotic obstruction once the
start rate vanishes.

Therefore the stop/audit rule is triggered even though no positive residue
gap was proved.

## What would upgrade B-LEAD to an exclusion theorem

One still needs a statement such as
\[
\liminf_{k\to\infty}\rho_r(k)\ge c(\kappa)>0
\]
for the true frozen survivor class, or another stabilization obstruction that
prevents one fixed \(n_0\) from realizing the nested prefixes.

The current finite pressure surrogates cannot supply that universally.

## Post-audit branch recommendation

The most promising added structure is repeated-factor / return-word
recurrence, because the 2-adic start-rate problem is now the decisive
asymptotic residue variable.

**ADD MODULE D RETURN-WORD/REPEATED-FACTOR CONJUNCTION**
