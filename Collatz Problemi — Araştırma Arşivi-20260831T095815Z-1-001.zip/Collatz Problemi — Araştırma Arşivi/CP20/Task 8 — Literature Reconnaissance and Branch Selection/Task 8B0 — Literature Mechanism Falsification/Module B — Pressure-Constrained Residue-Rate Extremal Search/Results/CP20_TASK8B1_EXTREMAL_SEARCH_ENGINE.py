#!/usr/bin/env python3
"""
CP20 TASK 8B1 — Pressure-Constrained Residue-Rate Extremal Search
Date: 2026-08-26

Research status:
  finite computation / falsification engine, NOT a theorem prover.

Primary external convention:
  Oliver Kramer, arXiv:2607.10041.
  rho_r(k)=log(1+r_k)/k
  rho_M(k)=log(1+M_k/(3/2)^k)/k
with natural logarithm.

Frozen Task-8A is used only through explicitly-labelled finite surrogates U2-U4.
The unaudited arbitrary-scale extension is not used.

Methods:
  - exact exhaustive identity validation;
  - random larger-prefix validation;
  - adversarial beam search with residue and pressure-guided modes;
  - local compensated mutations;
  - fixed-n0 nesting scan;
  - Pareto extraction.
"""

from dataclasses import dataclass
from itertools import product
from pathlib import Path
import math, random, json, csv, time, hashlib

ALPHA = math.log2(3.0)
M1 = 2.0 - ALPHA
M2 = ALPHA - 1.0
DELTA_F = M1 - M2
LN15 = math.log(1.5)
LN2 = math.log(2.0)

KAPPAS = [1.06, 1.2, 1.5, 2.0, 2.5, 2.7]
CHECKPOINTS = [50,100,200,400,800,1600]
JMIN = 16
MAIN_M = 4.0

def floor_alpha(k):
    return math.floor(ALPHA*k)

def gphase(i):
    return floor_alpha(i+1)-floor_alpha(i)

def v2(n):
    c=0
    while n%2==0:
        n//=2
        c+=1
    return c

def big_ln(n):
    if n <= 0:
        return float("-inf")
    b=n.bit_length()
    if b < 1020:
        return math.log(n)
    shift=b-53
    top=n>>shift
    return math.log(top)+shift*LN2

def softplus(x):
    if x > 40:
        return x
    if x < -40:
        return math.exp(x)
    return max(x,0.0)+math.log1p(math.exp(-abs(x)))

def B_step(B,A):
    return 3*B + (1<<A)

def residues(A,B,k):
    mod2=1<<A
    r=(-B*pow(3,-k,mod2))%mod2
    mod3=3**k
    M=(B*pow(2,-A,mod3))%mod3
    return r,M

def rates_from_residues(r,M,k):
    if r==0:
        rr=0.0
    else:
        lr=big_ln(r)
        rr=(lr + (math.log1p(math.exp(-lr)) if lr<40 else 0.0))/k
    if M==0:
        rm=0.0
    else:
        x=big_ln(M)-k*LN15
        rm=softplus(x)/k
    return rr,rm

def entropy_binom_mass(Mass,rho):
    eps=1e-15
    rho=max(0.0,min(Mass,rho))
    a=Mass-rho
    ans=0.0
    if Mass>eps:
        ans += Mass*math.log2(Mass)
    if a>eps:
        ans -= a*math.log2(a)
    if rho>eps:
        ans -= rho*math.log2(rho)
    return ans

def project_to_F(r1,r2):
    r1=max(0.0,min(M1,r1)); r2=max(0.0,min(M2,r2))
    gap=DELTA_F-(r1-r2)
    if gap>0:
        inc=min(gap,M1-r1)
        r1+=inc; gap-=inc
        if gap>0:
            r2=max(0.0,r2-gap)
    return r1,r2

def pressure_h(rho1,rho2, project=False):
    if project:
        rho1,rho2=project_to_F(rho1,rho2)
    if not (0<=rho1<=M1+1e-12 and 0<=rho2<=M2+1e-12):
        return float("-inf")
    P=M1-rho1; Q=M2-rho2
    if Q < P-1e-12:
        return float("-inf")
    E=entropy_binom_mass(M1,rho1)+entropy_binom_mass(M2,rho2)
    q=Q-P
    if q<=1e-13:
        core=0.0
    else:
        disc=P*P+4*q*(P+Q)
        y=(P+math.sqrt(max(0.0,disc)))/(2*q)
        A=1.0/y
        B=(y*y+y+1.0)/y
        core=P*math.log2(A)+Q*math.log2(B)
    return max(0.0,E+core)

def tau_pressure(k):
    return 2.0*math.log2(k+1.0)/k

def word_stats(word,kappa):
    k=len(word)
    A=0; B=0; s=0; c1=0; c2=0
    prefix_s=[]
    critical=[]
    for i,a in enumerate(word):
        g=gphase(i)
        B=B_step(B,A)
        A+=a
        s+=g-a
        prefix_s.append(s)
        iscrit=(a==g)
        critical.append(1 if iscrit else 0)
        if iscrit:
            if g==1: c1+=1
            else: c2+=1
    r,M=residues(A,B,k)
    rr,rm=rates_from_residues(r,M,k)
    rho1=c1/k; rho2=c2/k
    f_tol=2.0/k
    u2=(rho1<=M1+f_tol and rho2<=M2+f_tol and
        rho1-rho2 >= DELTA_F-f_tol)
    hp=pressure_h(rho1,rho2,project=True) if u2 else float("-inf")
    u3=u2 and hp >= ALPHA/kappa - tau_pressure(k)

    # U4: dyadic multiplicative-window surrogate.
    windows=[]
    u4=u3
    N=16
    while 2*N<=k:
        cc1=cc2=0
        for i in range(N,2*N):
            if critical[i]:
                if gphase(i)==1: cc1+=1
                else: cc2+=1
        p1=cc1/N; p2=cc2/N
        ft=2.0/N
        okF=(p1<=M1+ft and p2<=M2+ft and p1-p2>=DELTA_F-ft)
        hh=pressure_h(p1,p2,project=True) if okF else float("-inf")
        ok=okF and hh>=ALPHA/kappa-tau_pressure(N)
        windows.append({"N":N,"rho1":p1,"rho2":p2,"h":hh,"pass":ok})
        if not ok: u4=False
        N*=2

    maxcorr=max(
        [abs(prefix_s[j-1]-kappa*math.log2(j)) for j in range(JMIN,k+1)]
        or [0.0]
    )

    return {
        "k":k,"A":A,"s":s,"B":str(B),"r":str(r),"Mres":str(M),
        "rho_r":rr,"rho_M":rm,"E":max(rr,rm),
        "rho1":rho1,"rho2":rho2,"pressure_h":hp,
        "pressure_threshold":ALPHA/kappa,
        "pressure_tolerance":tau_pressure(k),
        "U2_fullscale":u2,"U3_fullscale":u3,"U4_multiwindow":u4,
        "windows":windows,"max_corridor_error":maxcorr,
        "alphabet_max":max(word) if word else 0,
        "critical_density":(c1+c2)/k,
    }

def corridor_allowed(s,i,kappa,M,pre_amax=7):
    j=i+1
    g=gphase(i)
    if j<JMIN:
        return list(range(1,pre_amax+1))
    target=kappa*math.log2(j)
    lo=math.ceil(target-M-1e-12)
    hi=math.floor(target+M+1e-12)
    max_s=min(hi,s+g-1)
    if max_s<lo:
        return []
    # s_new runs from lo..max_s => a=s+g-s_new
    return [s+g-sn for sn in range(lo,max_s+1) if s+g-sn>=1]

@dataclass
class State:
    A:int
    B:int
    s:int
    c1:int
    c2:int
    word:bytes
    rr:float
    rm:float
    score:float

def child_state(st,a,i,kappa,eval_residue,mode,pressure_guided):
    g=gphase(i)
    Bn=B_step(st.B,st.A)
    An=st.A+a
    sn=st.s+g-a
    c1=st.c1+(1 if a==g and g==1 else 0)
    c2=st.c2+(1 if a==g and g==2 else 0)
    w=st.word+bytes([a])
    rr=st.rr; rm=st.rm
    if eval_residue:
        r,M=residues(An,Bn,i+1)
        rr,rm=rates_from_residues(r,M,i+1)
    if mode=="r":
        sc=rr+0.15*rm
    elif mode=="M":
        sc=rm+0.15*rr
    else:
        sc=max(rr,rm)
    if i+1<JMIN:
        # Search heuristic only: keep early unconstrained prefixes in reach of
        # the corridor that becomes mandatory at JMIN.
        sc += 0.30*abs(sn-kappa*math.log2(i+2))
    if pressure_guided and i+1>=32:
        rho1=c1/(i+1); rho2=c2/(i+1)
        hh=pressure_h(rho1,rho2,project=True)
        deficit=max(0.0,ALPHA/kappa-tau_pressure(i+1)-hh)
        sc += 0.7*deficit
        # discourage gross infeasibility but do not hard-filter.
        gap=max(0.0, DELTA_F-(rho1-rho2)-2/(i+1))
        sc += 0.4*gap
    return State(An,Bn,sn,c1,c2,w,rr,rm,sc)

def diverse_trim(cands,width,i,kappa):
    # Cheap diversity before expensive residue scoring.
    buckets={}
    target=kappa*math.log2(i+1)
    for st in cands:
        key=(
            st.s,
            st.c1//max(1,(i+1)//16),
            st.c2//max(1,(i+1)//16),
            int(st.rr*20),
            int(st.rm*20),
        )
        old=buckets.get(key)
        if old is None or st.score<old.score:
            buckets[key]=st
    vals=list(buckets.values())
    vals.sort(key=lambda x:x.score)
    return vals[:max(width*3,width)]

def beam_search(kappa,M,width=60,maxk=1600,mode="balanced",
                pressure_guided=True,seed=0):
    rng=random.Random(seed)
    beam=[State(0,0,0,0,0,b"",0.7,0.7,0.7)]
    snapshots={}
    eval_every=8
    for i in range(maxk):
        raw=[]
        for st in beam:
            aa=corridor_allowed(st.s,i,kappa,M)
            for a in aa:
                # First cheap inherit-score child.
                ch=child_state(st,a,i,kappa,False,mode,pressure_guided)
                # deterministic microscopic diversity perturbation
                ch.score += 1e-7*((a*131+(i+1)*17+st.s*7) % 97)
                raw.append(ch)
        if not raw:
            break
        raw=diverse_trim(raw,width,i,kappa)
        need_eval=((i+1)%eval_every==0 or (i+1) in CHECKPOINTS)
        if need_eval:
            rescored=[]
            for st in raw:
                # Rebuild only the residues from stored affine state.
                r,Mres=residues(st.A,st.B,i+1)
                rr,rm=rates_from_residues(r,Mres,i+1)
                st.rr=rr; st.rm=rm
                if mode=="r": st.score=rr+0.15*rm
                elif mode=="M": st.score=rm+0.15*rr
                else: st.score=max(rr,rm)
                if pressure_guided and i+1>=32:
                    rho1=st.c1/(i+1); rho2=st.c2/(i+1)
                    hh=pressure_h(rho1,rho2,project=True)
                    st.score += 0.7*max(0.0,ALPHA/kappa-tau_pressure(i+1)-hh)
                    st.score += 0.4*max(0.0,DELTA_F-(rho1-rho2)-2/(i+1))
                rescored.append(st)
            raw=rescored
        raw.sort(key=lambda x:x.score)
        # Keep a mixed elite/diversity set.
        elite=raw[:max(1,width//2)]
        rest=raw[max(1,width//2):]
        rng.shuffle(rest)
        beam=elite+rest[:width-len(elite)]

        if i+1 in CHECKPOINTS:
            rows=[]
            for st in beam:
                met=word_stats(st.word,kappa)
                met["word"]=list(st.word)
                met["mode"]=mode
                met["M_corridor"]=M
                met["pressure_guided"]=pressure_guided
                rows.append(met)
            snapshots[i+1]=rows
    return snapshots

def pareto(rows):
    pts=sorted(rows,key=lambda x:(x["rho_r"],x["rho_M"]))
    out=[]; bestM=float("inf")
    for x in pts:
        if x["rho_M"]<bestM-1e-15:
            out.append(x); bestM=x["rho_M"]
    return out

def best_by_class(rows,klass):
    if klass=="U1":
        cand=rows
    elif klass=="U2":
        cand=[x for x in rows if x["U2_fullscale"]]
    elif klass=="U3":
        cand=[x for x in rows if x["U3_fullscale"]]
    elif klass=="U4":
        cand=[x for x in rows if x["U4_multiwindow"]]
    else:
        cand=rows
    if not cand: return None
    return min(cand,key=lambda x:x["E"])

def local_compensated_mutation(best,kappa,corridor_M,iterations=1200,seed=1):
    if best is None: return None
    rng=random.Random(seed)
    w=bytearray(best["word"])
    cur=word_stats(bytes(w),kappa)
    k=len(w)

    def corridor_ok(word):
        s=0
        for i,a in enumerate(word):
            s+=gphase(i)-a
            j=i+1
            if j>=JMIN and abs(s-kappa*math.log2(j))>corridor_M+1e-12:
                return False
        return True

    for _ in range(iterations):
        i=rng.randrange(max(JMIN-1,0),k-1)
        delta=rng.choice([-2,-1,1,2])
        a=w[i]+delta
        b=w[i+1]-delta
        if a<1 or b<1 or a>30 or b>30: continue
        olda,oldb=w[i],w[i+1]
        w[i],w[i+1]=a,b
        if not corridor_ok(w):
            w[i],w[i+1]=olda,oldb
            continue
        met=word_stats(bytes(w),kappa)
        # Prefer U3/U4-preserving improvements when current has them.
        if cur["U4_multiwindow"] and not met["U4_multiwindow"]:
            accept=False
        elif cur["U3_fullscale"] and not met["U3_fullscale"]:
            accept=False
        else:
            accept=met["E"]<cur["E"]-1e-12
        if accept:
            cur=met
            cur["word"]=list(w)
        else:
            w[i],w[i+1]=olda,oldb
    return cur

def validate_word_direct(word):
    """
    Kramer's r_k modulo 2^A is the necessary start congruence.
    To verify the FINAL exponent is exact as well, lift one more 2-adic bit:
      3^k n0 + B_k == 2^A (mod 2^(A+1)).
    This exact-cylinder lift reduces to Kramer r_k modulo 2^A.
    """
    A=0;B=0
    for a in word:
        B=B_step(B,A); A+=a
    k=len(word)
    r,_=residues(A,B,k)
    mod_exact=1<<(A+1)
    R_exact=((1<<A)-B)*pow(3,-k,mod_exact)%mod_exact
    assert R_exact % (1<<A) == r
    n0=R_exact if R_exact>0 else R_exact+mod_exact
    n=n0
    got=[]
    for _ in range(k):
        z=3*n+1
        a=v2(z)
        got.append(a)
        n=z//(1<<a)
    return tuple(got)==tuple(word)

def exhaustive_validation():
    # 3^12 = 531441 terminal words.
    count=0
    for w in product((1,2,3), repeat=12):
        if not validate_word_direct(w):
            raise AssertionError(("exhaustive failed",w))
        count+=1
    rng=random.Random(123)
    random_count=0
    for _ in range(1000):
        L=rng.randint(20,120)
        w=tuple(rng.randint(1,8) for _ in range(L))
        if not validate_word_direct(w):
            raise AssertionError(("random failed",w))
        random_count+=1
    return {"alphabet":"{1,2,3}","depth":12,
            "exhaustive_words":count,
            "random_larger_prefixes":random_count}

def u0_baseline():
    # Unrestricted bounded alphabet contains actual fixed-start code a_i=2:
    # n0=1 realizes it forever, so both rates vanish.
    rows=[]
    for k in CHECKPOINTS:
        w=bytes([2])*k
        met=word_stats(w,1.5)
        rows.append({"k":k,"rho_r":met["rho_r"],"rho_M":met["rho_M"],
                     "E":met["E"],"note":"all-2 code, fixed n0=1"})
    return rows

def fixed_n0_scan(max_n0=50000,maxk=800):
    # Scan odd n0 values once, assess corridor survival for all kappas, M=4.
    best={str(k):{"max_depth":0,"n0":None,"reason":None} for k in KAPPAS}
    selected=[]
    for n0 in range(1,max_n0+1,2):
        n=n0; s=0; c1=c2=0
        alive={k:True for k in KAPPAS}
        depths={k:0 for k in KAPPAS}
        failreason={k:None for k in KAPPAS}
        for i in range(maxk):
            z=3*n+1; a=v2(z); n=z//(1<<a)
            g=gphase(i); s+=g-a
            if a==g:
                if g==1:c1+=1
                else:c2+=1
            j=i+1
            for kap in KAPPAS:
                if alive[kap] and j>=JMIN:
                    if abs(s-kap*math.log2(j))>MAIN_M:
                        alive[kap]=False; failreason[kap]="critical-log corridor"
                    else:
                        depths[kap]=j
            if not any(alive.values()) and j>JMIN:
                break
        for kap in KAPPAS:
            if depths[kap]>best[str(kap)]["max_depth"]:
                best[str(kap)]={"max_depth":depths[kap],"n0":n0,
                                "reason":failreason[kap]}
    # Selected larger n0 random diagnostics.
    rng=random.Random(20260826)
    for _ in range(1000):
        n0=rng.randrange(1,1<<40)|1
        n=n0;s=0
        dct={"n0":n0}
        for kap in KAPPAS:
            dct[str(kap)]=0
        alive={kap:True for kap in KAPPAS}
        for i in range(maxk):
            z=3*n+1;a=v2(z);n=z//(1<<a)
            s+=gphase(i)-a;j=i+1
            for kap in KAPPAS:
                if alive[kap] and j>=JMIN:
                    if abs(s-kap*math.log2(j))>MAIN_M:
                        alive[kap]=False
                    else:
                        dct[str(kap)]=j
            if not any(alive.values()) and j>JMIN: break
        selected.append(dct)
    large_best={}
    for kap in KAPPAS:
        row=max(selected,key=lambda d:d[str(kap)])
        large_best[str(kap)]={"max_depth":row[str(kap)],"n0":row["n0"]}
    return {
        "range_scan":{"odd_n0_max":max_n0,"max_depth_tested":maxk,
                      "best":best},
        "random_40bit_scan":{"samples":len(selected),"best":large_best},
        "logical_note":
            "For a fixed n0 the exponent code is unique. r_j=n0 eventually "
            "holds exactly, but surviving the finite critical-log/pressure "
            "surrogates is a separate experimental constraint."
    }

def main():
    t0=time.time()
    validation=exhaustive_validation()
    u0=u0_baseline()

    all_results={
        "metadata":{
            "status":"[NUM/EXTREMAL SEARCH — NOT THEOREM]",
            "alpha":ALPHA,"M1":M1,"M2":M2,
            "kappas":KAPPAS,"checkpoints":CHECKPOINTS,
            "j_min":JMIN,
            "pressure_tolerance":"tau(k)=2 log2(k+1)/k",
            "U3_warning":
              "full-prefix pressure is a finite computational surrogate, not "
              "a theorem-equivalent consequence of frozen Task 8A",
            "U4_warning":
              "dyadic multi-window pressure is a stronger experimental "
              "surrogate, not a frozen Task-8A consequence",
        },
        "exact_validation":validation,
        "U0":u0,
        "runs":[],
    }

    pareto_rows=[]

    # Main scaling: M=4, balanced residue-only and pressure-guided.
    for kap in KAPPAS:
        pooled_by_k={k:[] for k in CHECKPOINTS}
        for pg,seed in [(False,11),(True,29)]:
            snaps=beam_search(kap,MAIN_M,width=55,maxk=1600,
                              mode="balanced",pressure_guided=pg,seed=seed)
            for k,rows in snaps.items():
                pooled_by_k[k].extend(rows)

        # Extra r- and M-focused cross-method runs only through 400.
        for mode,seed in [("r",41),("M",53)]:
            snaps=beam_search(kap,MAIN_M,width=42,maxk=400,
                              mode=mode,pressure_guided=True,seed=seed)
            for k,rows in snaps.items():
                pooled_by_k[k].extend(rows)

        for k in CHECKPOINTS:
            rows=pooled_by_k[k]
            if not rows: continue
            record={"kappa":kap,"corridor_M":MAIN_M,"k":k}
            for klass in ["U1","U2","U3","U4"]:
                b=best_by_class(rows,klass)
                if b is not None:
                    # Local mutation cross-check on the best at <=400 or U3 best at larger.
                    it=700 if k<=400 else 250
                    lm=local_compensated_mutation(b,kap,MAIN_M,it,seed=97+k)
                    if lm and lm["E"] < b["E"] and (
                        klass not in ("U2","U3","U4") or
                        (klass=="U2" and lm["U2_fullscale"]) or
                        (klass=="U3" and lm["U3_fullscale"]) or
                        (klass=="U4" and lm["U4_multiwindow"])
                    ):
                        lm["word"]=lm.get("word",b["word"])
                        b=lm
                    record[klass]={
                        key:b[key] for key in [
                            "rho_r","rho_M","E","rho1","rho2","pressure_h",
                            "U2_fullscale","U3_fullscale","U4_multiwindow",
                            "max_corridor_error","critical_density","alphabet_max"
                        ]
                    }
                    record[klass]["word"]=b.get("word",[])
                else:
                    record[klass]=None

            fr=pareto(rows)
            for x in fr:
                pareto_rows.append({
                    "kappa":kap,"corridor_M":MAIN_M,"k":k,
                    "rho_r":x["rho_r"],"rho_M":x["rho_M"],"E":x["E"],
                    "U2":x["U2_fullscale"],"U3":x["U3_fullscale"],
                    "U4":x["U4_multiwindow"],
                    "critical_density":x["critical_density"],
                    "pressure_h":x["pressure_h"]
                })
            all_results["runs"].append(record)

    # Corridor sensitivity through k=400, balanced pressure-guided.
    sensitivity=[]
    for M in [2.0,8.0]:
        for kap in KAPPAS:
            snaps=beam_search(kap,M,width=38,maxk=400,mode="balanced",
                              pressure_guided=True,seed=int(M*100)+7)
            rows=snaps.get(400,[])
            rec={"kappa":kap,"corridor_M":M,"k":400}
            for klass in ["U1","U2","U3","U4"]:
                b=best_by_class(rows,klass)
                rec[klass]=None if b is None else {
                    "rho_r":b["rho_r"],"rho_M":b["rho_M"],"E":b["E"],
                    "pressure_h":b["pressure_h"],
                    "critical_density":b["critical_density"],
                }
            sensitivity.append(rec)
    all_results["corridor_sensitivity"]=sensitivity

    nesting=fixed_n0_scan()
    all_results["nested_fixed_n0"]=nesting
    all_results["elapsed_seconds"]=time.time()-t0

    out=Path(__file__).with_name("CP20_TASK8B1_EXTREMAL_RESULTS.json")
    out.write_text(json.dumps(all_results,indent=2),encoding="utf-8")

    csvp=Path(__file__).with_name("CP20_TASK8B1_PARETO_FRONTIERS.csv")
    cols=["kappa","corridor_M","k","rho_r","rho_M","E","U2","U3","U4",
          "critical_density","pressure_h"]
    with csvp.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=cols)
        w.writeheader()
        w.writerows(pareto_rows)

    nestp=Path(__file__).with_name("CP20_TASK8B1_NESTED_FIXED_N0_SEARCH.json")
    nestp.write_text(json.dumps(nesting,indent=2),encoding="utf-8")

    print("CP20 TASK 8B1 EXTREMAL SEARCH")
    print("exact exhaustive validation:",validation)
    print("elapsed_seconds:",all_results["elapsed_seconds"])
    print()
    print("BEST E BY KAPPA / LENGTH / CLASS (M=4)")
    for rec in all_results["runs"]:
        vals=[]
        for cl in ("U1","U2","U3","U4"):
            x=rec[cl]
            vals.append(f"{cl}={'NA' if x is None else f'{x['E']:.6f}'}")
        print("kappa",rec["kappa"],"k",rec["k"],*vals)
    print()
    print("FIXED-N0 RANGE BEST DEPTHS")
    for kap,row in nesting["range_scan"]["best"].items():
        print("kappa",kap,row)
    print("ALL ENGINE ASSERTIONS: PASS")

if __name__=="__main__":
    main()
