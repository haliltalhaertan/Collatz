# CP20 TASK 8B1 — REPAIRED DEPENDENCY GRAPH V2

**Status:** `[FROZEN]`

## Exact finite-word layer

Positive exponent word
\[
(a_0,\ldots,a_{k-1})
\]

\[
\Downarrow
\]

\[
A_k,\quad B_{j+1}=3B_j+2^{A_j}
\]

\[
\Downarrow
\]

\[
r_k\equiv-3^{-k}B_k\pmod{2^{A_k}}
\]

\[
\Downarrow
\]

negative-shadow prefix divisibility
\[
B_k\equiv3^{k-j}B_j\pmod{2^{A_j}}
\]

\[
\Downarrow
\]

\[
y_j=
\frac{3^j(r_k-2^{A_k})+B_j}{2^{A_j}}
\in\mathbb Z,\quad y_j\le-1
\]

\[
\Downarrow
\]

\[
X_k-3^k=y_k\le-1
\]

\[
\Downarrow
\]

\[
\boxed{1\le X_k<3^k}
\]

\[
\Downarrow
\]

\[
\boxed{M_k=X_k\text{ for every }k\ge1.}
\]

This entire layer is finite and does not use critical-log, Task 8A, or
probabilistic assumptions.

## Critical-log layer

Standing hypothesis:
\[
s_k=\kappa\log_2k+O(1),\quad\kappa>1.
\]

Then
\[
\frac{3^k}{2^{A_k}}
=
2^{s_k+\{\alpha k\}}
=
k^\kappa\Theta(1).
\]

Also
\[
\frac13\le B_k/3^k\le C,
\]
where the lower bound is trivial and the upper bound follows from the
\(p\)-series comparison
\[
2^{A_j}/3^{j+1}=O(j^{-\kappa}).
\]

Therefore
\[
M_k=X_k
=
k^\kappa\Theta(1)(1+r_k).
\]

\[
\Downarrow
\]

\[
\boxed{
\rho_M(k)
=
\max\{0,\rho_r(k)-\ln(3/2)\}
+
O(\log k/k).
}
\]

\[
\Downarrow
\]

\[
\boxed{
\liminf\rho_M>0
\Rightarrow
\liminf\rho_r
=
\ln(3/2)+\liminf\rho_M>0.
}
\]

## External attribution

Oliver Kramer is the source for:

- the residue variables \(r_k,M_k\);
- the rate normalizations \(\rho_r,\rho_M\);
- the necessary-vanishing framework.

The negative-shadow lemma and the critical-log rate relation are the
canonical CP20 branch-closure statements after independent audit.

## Frozen CP20 dependencies

Task 8A:
not used in the proof; only defines the intended future survivor class.

Task 6:
the affine normalization is compatible with Task 6, but the V2 rate proof
uses only the explicit affine identities plus elementary \(p\)-series
boundedness, not the full frozen Task-6 convergence theorem.

Module A:
not used.

## Non-dependencies

- no U3/U4 finite pressure surrogate as theorem input;
- no unaudited Task-8A full-scale extension;
- no CP19 parked high-half/cross-adic branch;
- no Module D return-word theorem;
- no 3-adic mixing theorem.
