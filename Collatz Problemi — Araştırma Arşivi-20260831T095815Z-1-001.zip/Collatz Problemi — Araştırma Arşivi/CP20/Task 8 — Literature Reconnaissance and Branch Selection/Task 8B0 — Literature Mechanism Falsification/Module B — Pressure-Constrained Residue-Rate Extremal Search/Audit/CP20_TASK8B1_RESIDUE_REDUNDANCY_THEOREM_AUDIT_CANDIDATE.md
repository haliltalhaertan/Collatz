# CP20 TASK 8B1 — CRITICAL-LOG RESIDUE REDUNDANCY THEOREM

**Date:** 2026-08-26  
**Status:** `[AUDIT CANDIDATE]`  
**Trigger:** load-bearing theorem; Module-B stop rule activated.

## 1. Setting

Let
\[
A_k=\sum_{j<k}a_j,\qquad
\alpha=\log_2 3,\qquad
F_k=\lfloor\alpha k\rfloor,\qquad
s_k=F_k-A_k.
\]

Assume an infinite positive-exponent code satisfies
\[
\boxed{
s_k=\kappa\log_2k+O(1),\qquad \kappa>1.
}
\]

Define the affine offset
\[
B_0=0,\qquad
B_{k+1}=3B_k+2^{A_k},
\]
equivalently
\[
B_k=\sum_{j<k}3^{k-1-j}2^{A_j}.
\]

Let the canonical Kramer start representative be
\[
r_k\equiv-3^{-k}B_k\pmod{2^{A_k}},
\qquad
0\le r_k<2^{A_k}.
\]

Define the canonical 3-adic endpoint representative
\[
M_k\equiv2^{-A_k}B_k\pmod{3^k},
\qquad
0\le M_k<3^k.
\]
(The residue is nonzero for \(k\ge1\), so this is equivalent to Kramer's
\(1\le M_k\le3^k\) convention.)

Kramer's rates use natural logarithms:
\[
\rho_r(k)=\frac{\ln(1+r_k)}k,
\]
\[
\rho_M(k)
=
\frac1k
\ln\left(
1+\frac{M_k}{(3/2)^k}
\right).
\]

## 2. Canonical pseudo-endpoint

By definition of \(r_k\),
\[
3^kr_k+B_k
\]
is divisible by \(2^{A_k}\). Define the positive integer
\[
\boxed{
X_k=
\frac{3^kr_k+B_k}{2^{A_k}}.
}
\]

Modulo \(3^k\),
\[
2^{A_k}X_k\equiv B_k,
\]
so
\[
\boxed{
M_k\equiv X_k\pmod{3^k}.
}
\]

## 3. Critical-log factorization

Write
\[
\theta_k=\{\alpha k\}.
\]
Since
\[
\alpha k=F_k+\theta_k
\]
and
\[
A_k=F_k-s_k,
\]
\[
\boxed{
\frac{3^k}{2^{A_k}}
=
2^{s_k+\theta_k}.
}
\]

Therefore
\[
X_k
=
2^{s_k+\theta_k}
\left(
r_k+\frac{B_k}{3^k}
\right).
\]

Frozen CP20 Task 6 proves convergence of
\[
\frac{B_k}{3^k}
=
\sum_{j<k}\frac{2^{A_j}}{3^{j+1}}
\]
under \(\kappa>1\).
In particular there are constants
\[
0<c\le C<\infty
\]
such that eventually
\[
c\le \frac{B_k}{3^k}\le C.
\]

Also
\[
2^{s_k+\theta_k}=k^\kappa\Theta(1).
\]

Hence
\[
\boxed{
X_k
=
k^\kappa\Theta(1)\,(1+r_k).
}
\]

Consequently
\[
\boxed{
\frac{\ln X_k}{k}
=
\rho_r(k)+o(1).
}
\]

## 4. Vanishing-rate redundancy theorem

Assume
\[
\boxed{\rho_r(k)\to0.}
\]

Then
\[
r_k=e^{o(k)}
\]
and therefore
\[
X_k=e^{o(k)}.
\]

Thus
\[
X_k<3^k
\]
for all sufficiently large \(k\).

Since
\[
M_k\equiv X_k\pmod{3^k}
\]
and both are then in \([0,3^k)\),
\[
\boxed{M_k=X_k}
\]
eventually.

Moreover
\[
\frac{M_k}{(3/2)^k}
=
\exp\bigl(-k\ln(3/2)+o(k)\bigr)\to0.
\]

Therefore
\[
\boxed{
\rho_M(k)\to0.
}
\]

### Main conclusion

\[
\boxed{
\text{critical-log }+\ \rho_r(k)\to0
\quad\Longrightarrow\quad
\rho_M(k)\to0.
}
\]

Inside the global critical-log class, the 3-adic necessary-vanishing
condition is asymptotically redundant once the 2-adic start-residue rate
vanishes.

## 5. Stronger rate relation away from the mod-\(3^k\) ceiling

Assume more generally
\[
\limsup_{k\to\infty}\rho_r(k)<\ln3.
\]

Choose \(\delta>0\) such that eventually
\[
\rho_r(k)\le\ln3-\delta.
\]

The relation
\[
\ln X_k
=
k\rho_r(k)+o(k)
\]
then implies
\[
X_k<3^k
\]
eventually, hence again
\[
M_k=X_k.
\]

Therefore
\[
\frac1k\ln M_k
=
\rho_r(k)+o(1).
\]

Using
\[
\frac1k\ln(1+e^{ku})
=
\max(0,u)+o(1)
\]
uniformly along any sequence with bounded \(u\), we obtain
\[
\boxed{
\rho_M(k)
=
\max\{0,\rho_r(k)-\ln(3/2)\}
+o(1).
}
\]

This explains the finite extremal-search geometry: whenever the optimized
start rate stays below \(\ln3\), the endpoint rate is expected to lie near
the shifted graph
\[
\rho_M\approx\max(0,\rho_r-\ln(3/2)).
\]

## 6. What this theorem does NOT say

It does not prove
\[
\rho_r(k)\not\to0.
\]

It therefore does not exclude a positive ordinary realizer.

It does not prove a positive residue gap.

It does not use the finite U2/U3/U4 pressure surrogates as theorem premises.

It does not use the unaudited full-scale Task-8A extension.

It does not reopen CP19 high-half/cross-adic machinery.

## 7. Strategic consequence

A future LEVEL-2→LEVEL-3 obstruction inside critical-log does not need a
separate asymptotic lower bound for both Kramer rates.

The decisive unresolved problem is the 2-adic one:
\[
\boxed{
\text{Can }\rho_r(k)\to0
\text{ occur under the frozen critical-log/Task-8A survivor structure?}
}
\]

The 3-adic rate remains useful as a finite diagnostic, but it supplies no
independent asymptotic necessary condition once \(\rho_r\to0\) is achieved.

Independent zero-trust audit is required before downstream theorem use.
