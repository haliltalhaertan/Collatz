# CP20 TASK 8B1 — RESIDUE REDUNDANCY INDEPENDENT ZERO-TRUST AUDIT

**Candidate status:** `[AUDIT CANDIDATE]`

Try to break the theorem.

## Claimed theorem

Under
\[
s_k=\kappa\log_2k+O(1),\qquad\kappa>1,
\]
with Kramer representatives
\[
r_k\equiv-3^{-k}B_k\pmod{2^{A_k}},
\quad 0\le r_k<2^{A_k},
\]
and
\[
M_k\equiv2^{-A_k}B_k\pmod{3^k},
\]
the candidate claims
\[
\rho_r(k)\to0\Longrightarrow\rho_M(k)\to0.
\]

It further claims that if
\[
\limsup\rho_r(k)<\ln3,
\]
then
\[
\rho_M(k)
=
\max\{0,\rho_r(k)-\ln(3/2)\}+o(1).
\]

## Mandatory checks

1. Verify Kramer's primary-source definitions and log normalization.
2. Re-derive the affine identity and \(B_k\) recurrence.
3. Verify the start congruence sign.
4. Verify the endpoint congruence sign.
5. Verify the difference between Kramer's modulo-\(2^{A_k}\) representative
   and the exact-cylinder modulo-\(2^{A_k+1}\) lift.
6. Prove or refute the start-residue shadow lemma.
7. Verify
   \[
   X_k=(3^kr_k+B_k)/2^{A_k}
   \]
   is always an integer.
8. Verify
   \[
   M_k\equiv X_k\pmod{3^k}.
   \]
9. Verify
   \[
   3^k/2^{A_k}=2^{s_k+\{\alpha k\}}.
   \]
10. Check the exact dependency on frozen Task-6 carry convergence.
11. Verify that \(B_k/3^k\) is bounded above and bounded away from zero as
    used.
12. Prove or refute
    \[
    X_k=k^\kappa\Theta(1)(1+r_k).
    \]
13. Check that Kramer's
    \[
    \rho_r=\ln(1+r_k)/k
    \]
    really implies \(r_k=e^{o(k)}\) when \(\rho_r\to0\).
14. Verify \(X_k<3^k\) eventually.
15. Verify the canonical convention then gives \(M_k=X_k\), not
    \(M_k=X_k+3^k\) or a zero-representative ambiguity.
16. Prove \(\rho_M\to0\).
17. Audit the stronger relation under
    \(\limsup\rho_r<\ln3\).
18. Search for a sequence near the \(3^k\) ceiling that breaks the stronger
    relation.
19. Re-run the supplied exact verifier.
20. Check that no finite U3/U4 pressure assumption is used in the theorem.
21. Check that no positive residue-gap conclusion is smuggled in.
22. Check that no Collatz solution is claimed.

## Required verdict

Return exactly one:

- `[PROOF VALID]`
- `[PROOF VALID WITH WORDING REPAIR]`
- `[FIXABLE GAP]`
- `[MAJOR GAP]`
- `[FALSE — COUNTEREXAMPLE]`

If valid, state whether the redundancy theorem may be frozen and whether
Module D may be opened as a conjunction branch.
