# CP20 TASK 8B1 — RESIDUE REDUNDANCY THEOREM DEPENDENCY GRAPH

**Status:** `[AUDIT CANDIDATE]`

## External convention dependency

Oliver Kramer, arXiv:2607.10041:

- accelerated exponent-code notation;
- canonical \(r_k\);
- canonical \(M_k\);
- natural-log definitions of \(\rho_r,\rho_M\);
- necessary vanishing for fixed positive ordinary starts.

The new theorem does not use Kramer's finite numerical experiments.

## Frozen project dependency

### CP20 Task 6 V3 — frozen

Used:
\[
2^{A_k}n_k=3^kn_0+B_k
\]
and convergence/boundedness of
\[
B_k/3^k
\]
under global critical-log \(\kappa>1\).

### CP20 Task 8A — frozen

Not used in the analytic redundancy proof.

It enters only the intended survivor class for future applications.

### CP20 Module A — frozen

Not needed for the redundancy proof.

Its carry/translation work is consistent with the same affine normalization.

## New proof chain

\[
r_k\equiv-3^{-k}B_k\pmod{2^{A_k}}
\]

\[
\Downarrow
\]

\[
X_k=(3^kr_k+B_k)/2^{A_k}\in\mathbb Z_{>0}
\]

\[
\Downarrow
\]

\[
M_k\equiv X_k\pmod{3^k}
\]

\[
\Downarrow
\]

\[
X_k
=
2^{s_k+\{\alpha k\}}
(r_k+B_k/3^k)
=
k^\kappa\Theta(1)(1+r_k)
\]

\[
\Downarrow
\]

\[
\rho_r\to0
\Rightarrow
X_k=e^{o(k)}<3^k
\Rightarrow
M_k=X_k
\Rightarrow
\rho_M\to0.
\]

## Non-dependencies

- no U3/U4 finite pressure surrogate;
- no unaudited full-scale Task-8A theorem;
- no CP19 high-half/cross-adic state;
- no Module D continued fractions;
- no Tao-style mixing;
- no probabilistic assumption.
