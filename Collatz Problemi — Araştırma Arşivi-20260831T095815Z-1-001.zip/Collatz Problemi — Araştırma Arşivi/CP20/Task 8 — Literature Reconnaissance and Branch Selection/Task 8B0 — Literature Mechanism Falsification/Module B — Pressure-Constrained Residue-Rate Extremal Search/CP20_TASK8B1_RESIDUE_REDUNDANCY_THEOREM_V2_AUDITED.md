# CP20 TASK 8B1 — RESIDUE REDUNDANCY THEOREM V2 — AUDITED

**Date:** 2026-08-26  
**Canonical status:** `[PROVED][INDEPENDENTLY AUDITED][BRANCH CLOSURE][FROZEN]`

Independent audit principal verdict:
`[PROOF VALID WITH WORDING REPAIR]`.

This V2 incorporates the audited negative-shadow strengthening and supersedes
the earlier audit-candidate wording for downstream use.

The numerical residue-obstruction search remains separately `[B-LEAD]`.

---

## 1. Exact finite-word identities

For a finite positive exponent word define
\[
A_k=\sum_{j<k}a_j,
\qquad
B_{k+1}=3B_k+2^{A_k},
\qquad
B_0=0.
\]

The canonical start residue is
\[
r_k\equiv-3^{-k}B_k\pmod{2^{A_k}},
\qquad
0\le r_k<2^{A_k}.
\]

The canonical 3-adic endpoint residue is
\[
M_k\equiv2^{-A_k}B_k\pmod{3^k},
\qquad
1\le M_k\le3^k.
\]

Define
\[
X_k=\frac{3^kr_k+B_k}{2^{A_k}}.
\]

The frozen negative-shadow lemma proves, for **every** finite positive word,
\[
\boxed{
1\le X_k<3^k.
}
\]

Since
\[
M_k\equiv X_k\pmod{3^k}
\]
and the residue is nonzero,
\[
\boxed{
M_k=X_k
}
\]
for every \(k\ge1\).

This exact finite-word identification replaces the earlier “eventually
\(M_k=X_k\)” statement.

---

## 2. Critical-log standing hypothesis

From here onward assume the global critical-log law
\[
\boxed{
s_k=\kappa\log_2k+O(1),
\qquad
\kappa>1,
}
\]
where
\[
\alpha=\log_2 3,
\qquad
F_k=\lfloor\alpha k\rfloor,
\qquad
s_k=F_k-A_k,
\qquad
\theta_k=\{\alpha k\}.
\]

Then
\[
\alpha k=F_k+\theta_k
\]
and therefore
\[
\boxed{
\frac{3^k}{2^{A_k}}
=
2^{s_k+\theta_k}.
}
\]

Hence
\[
\boxed{
X_k
=
2^{s_k+\theta_k}
\left(
r_k+\frac{B_k}{3^k}
\right).
}
\]

---

## 3. Only the required carry bounds

The rate theorem does not require the full frozen Task-6 convergence theorem.

We only need
\[
0<c\le\frac{B_k}{3^k}\le C<\infty.
\]

The lower bound is immediate for \(k\ge1\):
\[
\frac{B_k}{3^k}
=
\sum_{j<k}\frac{2^{A_j}}{3^{j+1}}
\ge\frac13.
\]

For the upper bound, for sufficiently large \(j\),
\[
A_j
=
\lfloor\alpha j\rfloor-s_j,
\]
so
\[
\frac{2^{A_j}}{3^{j+1}}
=
\frac13\,2^{-s_j-\theta_j}
\le C_0j^{-\kappa}.
\]

Because \(\kappa>1\), the \(p\)-series converges, and therefore
\[
\boxed{
\frac13
\le
\frac{B_k}{3^k}
\le C
}
\]
uniformly in \(k\).

Thus
\[
r_k+\frac{B_k}{3^k}
=
\Theta(1+r_k).
\]

Also
\[
2^{s_k+\theta_k}=k^\kappa\Theta(1).
\]

Therefore
\[
\boxed{
X_k
=
k^\kappa\Theta(1)(1+r_k).
}
\]

Since \(M_k=X_k\) exactly,
\[
\boxed{
M_k
=
k^\kappa\Theta(1)(1+r_k).
}
\]

---

## 4. Kramer rate formula

Kramer's natural-log rates are
\[
\rho_r(k)
=
\frac{\ln(1+r_k)}k
\]
and
\[
\rho_M(k)
=
\frac1k
\ln\left(
1+\frac{M_k}{(3/2)^k}
\right).
\]

From the previous section,
\[
\ln M_k
=
\ln(1+r_k)+\kappa\ln k+O(1),
\]
so
\[
\boxed{
\frac{\ln M_k}{k}
=
\rho_r(k)+O\left(\frac{\log k}{k}\right).
}
\]

Put
\[
u_k
=
\frac{\ln M_k}{k}-\ln(3/2).
\]

Then exactly
\[
\rho_M(k)
=
\frac1k\ln(1+e^{ku_k}).
\]

For every real \(u\),
\[
0\le
\frac1k\ln(1+e^{ku})-\max(0,u)
\le
\frac{\ln2}{k}.
\]

Since the map \(x\mapsto\max(0,x)\) is 1-Lipschitz,
\[
\boxed{
\rho_M(k)
=
\max\left\{
0,\,
\rho_r(k)-\ln(3/2)
\right\}
+
O\left(\frac{\log k}{k}\right).
}
\]

This relation is **unconditional inside the stated global critical-log
class**. No assumption
\[
\limsup\rho_r<\ln3
\]
is needed.

---

## 5. Liminf redundancy corollary

Let
\[
L_r=\liminf_{k\to\infty}\rho_r(k),
\qquad
L_M=\liminf_{k\to\infty}\rho_M(k).
\]

The rate formula and continuity/monotonicity of
\[
x\mapsto\max(0,x-\ln(3/2))
\]
give
\[
\boxed{
L_M
=
\max\{0,L_r-\ln(3/2)\}.
}
\]

Therefore, if
\[
\boxed{L_M>0},
\]
then
\[
\boxed{
L_r
=
\ln(3/2)+L_M
>
0.
}
\]

In particular the weaker inequality requested for branch closure holds:
\[
\boxed{
\liminf\rho_r
\ge
\ln(3/2)+\liminf\rho_M
>
0.
}
\]

Thus, inside the critical-log class, a positive asymptotic 3-adic Kramer
obstruction cannot occur independently of a positive 2-adic start-residue
obstruction.

### Weaker vanishing corollary

If
\[
\rho_r(k)\to0,
\]
then
\[
\boxed{
\rho_M(k)\to0.
}
\]

This weaker implication is retained, but it is **not** the main reason the
3-adic branch is redundant. The load-bearing branch-closure statement is the
liminf relation above.

---

## 6. Branch-closure interpretation

Within the global critical-log class:

> The Kramer 3-adic endpoint-rate obstruction supplies no independent
> asymptotic branch beyond the 2-adic canonical start-residue obstruction.

The surviving residue question is therefore purely 2-adic:
\[
\boxed{
\text{Can an infinite critical-log / frozen-Task8A survivor satisfy }
\rho_r(k)\to0?
}
\]

No positive lower bound for \(\rho_r\) is proved here.

---

## 7. Scope and all-ones warning

The global critical-log hypothesis is load-bearing for the displayed rate
formula.

The all-ones word is an explicit warning. It has
\[
\rho_r=\ln2<\ln3,
\]
but its discrepancy \(s_k\) is linear in \(k\), not
\[
\kappa\log_2k+O(1).
\]

Therefore the critical-log rate formula does not apply to the all-ones word.

This theorem does not prove:

- \(\liminf\rho_r(k)>0\);
- exclusion of a positive ordinary realizer;
- the Collatz conjecture;
- that Task 8A alone forces \(\rho_r\) away from zero.

The CP19 parked high-half/cross-adic branch remains parked.

---

## 8. Contextual Kramer-score note

Kramer's finite score
\[
S=d_k+\rho_r+\rho_M
\]
is not used in the proof.

In regimes where
\[
\rho_r-\ln(3/2)
\]
is positively separated from zero, the frozen rate formula gives the
contextual approximation
\[
S
=
d_k+2\rho_r-\ln(3/2)+o(1).
\]

This is only an interpretation of the derived regime; it is not a separate
obstruction theorem.

---

## Final classification

\[
\boxed{
\texttt{[PROVED][INDEPENDENTLY AUDITED][BRANCH CLOSURE][FROZEN]}
}
\]
