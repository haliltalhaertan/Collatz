#!/usr/bin/env python3
"""
CP20 Task 8B1 — Residue Redundancy Theorem Verifier
Status: [AUDIT CANDIDATE]

Exact checks:
- affine B recurrence / closed form
- 2-adic start congruence
- exact-cylinder one-bit lift
- direct realization of every word in {1,2,3}^10
- start-residue shadow lemma
- 3-adic endpoint congruence
- canonical pseudo-endpoint X_k relation
- finite exact rate-geometry ingredients

The asymptotic theorem is analytic; finite verification is not its proof.
"""
from itertools import product
from fractions import Fraction
import random, math

def v2(n):
    c=0
    while n%2==0:
        n//=2;c+=1
    return c

def affine(word):
    A=0;B=0;As=[0];Bs=[0]
    for a in word:
        B=3*B+(1<<A)
        A+=a
        As.append(A);Bs.append(B)
    return A,B,As,Bs

def reps(A,B,k):
    r=(-B*pow(3,-k,1<<A))%(1<<A)
    m3=3**k
    M=(B*pow(2,-A,m3))%m3
    return r,M

def exact_lift(A,B,k):
    mod=1<<(A+1)
    R=((1<<A)-B)*pow(3,-k,mod)%mod
    return R if R else R+mod

def direct_vals(n,k):
    out=[]
    for _ in range(k):
        z=3*n+1
        a=v2(z)
        out.append(a)
        n=z>>(a)
    return out,n

def check_word(word):
    k=len(word)
    A,B,As,Bs=affine(word)

    # closed form
    Bclosed=sum(3**(k-1-j)*(1<<As[j]) for j in range(k))
    assert B==Bclosed

    r,M=reps(A,B,k)
    assert (3**k*r+B)%(1<<A)==0

    R=exact_lift(A,B,k)
    assert R%(1<<A)==r
    got,end=direct_vals(R,k)
    assert got==list(word)

    # shadow lemma: r realizes first k-1 exact valuations.
    if k>=2:
        got_r,end_r=direct_vals(r,k-1)
        assert got_r==list(word[:-1])

    X=(3**k*r+B)//(1<<A)
    assert (3**k*r+B)==(1<<A)*X
    assert M==X%(3**k)

    # every prefix congruence follows from the terminal r.
    for j in range(k+1):
        assert (3**j*r+Bs[j])%(1<<As[j])==0

    # realized exact lift endpoint congruence.
    assert end%(3**k)==M

def main():
    exact=0
    for word in product((1,2,3),repeat=10):
        check_word(word)
        exact+=1

    rng=random.Random(20260826)
    random_checks=0
    for _ in range(3000):
        L=rng.randint(15,100)
        word=[rng.randint(1,9) for _ in range(L)]
        check_word(word)
        random_checks+=1

    # Exact fixed-n0 vanishing precursor checks on actual positive orbits.
    stabilization_checks=0
    for n0 in range(1,5000,2):
        vals,n=direct_vals(n0,40)
        A=B=0
        for k,a in enumerate(vals,1):
            B=3*B+(1<<A);A+=a
            r,M=reps(A,B,k)
            if (1<<A)>n0:
                assert r==n0
                stabilization_checks+=1

    print("CP20 TASK 8B1 RESIDUE REDUNDANCY VERIFIER")
    print("exact words {1,2,3}^10:",exact)
    print("random larger words:",random_checks)
    print("fixed-n0 start stabilization checks:",stabilization_checks)
    print("affine/carry identities: PASS")
    print("exact-cylinder lift: PASS")
    print("start-residue shadow lemma: PASS")
    print("3-adic endpoint congruence: PASS")
    print("canonical pseudo-endpoint X_k: PASS")
    print("ALL AUDIT-CANDIDATE VERIFIER ASSERTIONS: PASS")

if __name__=="__main__":
    main()
