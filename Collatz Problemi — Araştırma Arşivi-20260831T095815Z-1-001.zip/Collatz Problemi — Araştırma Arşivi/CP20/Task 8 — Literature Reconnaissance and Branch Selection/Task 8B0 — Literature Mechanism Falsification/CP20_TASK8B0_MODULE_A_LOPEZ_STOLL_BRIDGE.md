# CP20 TASK 8B0 — MODULE A: LÓPEZ–STOLL CRITICAL-BOUNDARY BRIDGE

**Date:** 2026-08-26  
**Module verdict:** `[MAJOR THEOREM CANDIDATE]`  
**Package status:** `[AUDIT CANDIDATE]`

The mandatory Task-8B0 stop rule is triggered by this module. Modules B–E
and conjunction search were **not started**.

The result has two parts:

1. the critical-log law gives an exact direct proof of absolute convergence
   of the López–Stoll real conjugacy series for every \(\kappa>1\);
2. the same law forces the associated López–Stoll real pseudo-orbit to escape
   to \(-\infty\) linearly, so Task-8A critical density cannot upgrade this
   convergence to real pseudo-orbit accumulation.

No claim toward the Collatz conjecture is made.

---

## A1. Convention dictionary

### CP20 odd-only Syracuse convention

\[
n_{k+1}=\frac{3n_k+1}{2^{a_k}},
\qquad
a_k=v_2(3n_k+1)\ge1.
\]

Define

\[
\alpha_C=\log_2 3,
\qquad
F_k=\lfloor\alpha_C k\rfloor,
\qquad
A_k=\sum_{i<k}a_i,
\qquad
s_k=F_k-A_k.
\]

The frozen hypothesis is

\[
s_k=\kappa\log_2 k+O(1).
\]

### López–Stoll standard Collatz convention

Their single-step map is

\[
T(x)=
\begin{cases}
x/2,&x\text{ even},\\
(3x+1)/2,&x\text{ odd}.
\end{cases}
\]

Their parity word is

\[
v_j=T^j(x)\pmod2.
\]

Let
\[
0=d_0<d_1<d_2<\cdots
\]
be the positions of the \(1\)'s.

Their real interpretation of the conjugacy series is

\[
\boxed{
\Phi_{\mathbb R}(v)
=
-\sum_{i\ge0}\frac{2^{d_i}}{3^{i+1}}.
}
\]

At the critical parity-density boundary they use

\[
\gamma=\frac{\ln2}{\ln3}=\frac1{\alpha_C}.
\]

If \(h(\ell)\) is the number of 1's in the first \(\ell\) parity digits,
their relative height is

\[
n_\ell=h(\ell)-\lceil\gamma\ell\rceil.
\]

They define last level times

\[
\ell_j=\max\{\ell:n_\ell=j\}.
\]

Their Result 5 assumes the parity density tends to \(\gamma\), uses the
condition
\[
2^\ell/3^{\lceil\gamma\ell\rceil+n_\ell}\to0,
\]
and gives sufficient/converse-style tests in terms of the asymptotic ratio of
successive level gaps relative to the threshold \(3\).

The present proof does **not** assume that their gap-ratio condition follows.

### Exact dictionary

One odd-only Syracuse jump of valuation \(a_k\) is exactly the standard
parity block

\[
1\,0^{a_k-1}.
\]

Therefore

\[
\boxed{d_k=A_k}
\]

exactly.

The \(k\)-th odd state occurs at standard time \(A_k\).

With López–Stoll's prefix-height convention,

\[
\boxed{h(A_k)=k}.
\]

If the prefix includes the next odd digit, then
\(h(A_k+1)=k+1\). This is the only indexing correction needed.

---

## A2. Critical parity-density identity

From

\[
A_k
=
\lfloor\alpha_C k\rfloor-s_k
=
\alpha_Ck-\kappa\log_2k+O(1),
\]

we obtain

\[
\boxed{
\frac{k}{A_k}\to\frac1{\alpha_C}
=
\frac{\ln2}{\ln3}.
}
\]

More precisely the approach is from the high-parity side for all sufficiently
large \(k\), because the denominator is
\(\alpha_C k-\kappa\log_2k+O(1)\).

The critical-log hypothesis itself forces bounded valuations. Write

\[
s_k=\kappa\log_2k+e_k,\qquad |e_k|\le M
\]
eventually. Since

\[
g_k-a_k=s_{k+1}-s_k,\qquad g_k\in\{1,2\},
\]

\[
a_k
=
g_k
-
\kappa\log_2(1+1/k)
-
(e_{k+1}-e_k)
\le 2+2M
\]
eventually.

Thus standard parity gaps \(a_k\) are uniformly bounded, so endpoint parity
density and full parity density have the same limit.

**Verdict A2:** `[EXACT]`.

---

## A3. Exact relative-height translation

Let

\[
\theta_k=\{\alpha_Ck\}.
\]

At the odd endpoint \(\ell=A_k\),

\[
n_{A_k}
=
k-\lceil\gamma A_k\rceil.
\]

Because

\[
\gamma A_k
=
k-\gamma(s_k+\theta_k),
\]

the integer identity
\[
\lceil m-x\rceil=m-\lfloor x\rfloor
\]
gives

\[
\boxed{
n_{A_k}
=
\left\lfloor
\frac{s_k+\theta_k}{\alpha_C}
\right\rfloor.
}
\]

Hence

\[
n_{A_k}
=
\frac{\kappa}{\alpha_C}\log_2k+O(1).
\]

Uniform boundedness of \(a_k\) extends this to every standard time:

\[
\boxed{
n_\ell
=
\frac{\kappa}{\alpha_C}\log_2\ell+O(1).
}
\]

In particular \(n_\ell\to+\infty\), so the last level times are eventually
well defined. For

\[
\ell_j=\max\{\ell:n_\ell=j\},
\]

\[
j
=
\frac{\kappa}{\alpha_C}\log_2\ell_j+O(1),
\]
and therefore

\[
\boxed{
\log_2\ell_j
=
\frac{\alpha_C}{\kappa}j+O(1).
}
\]

Equivalently,

\[
\boxed{
\ell_j=3^{j/\kappa}\Theta(1)
}
\]

and the two requested exponential rates coincide:

\[
\boxed{
\lim_{j\to\infty}\frac{\ln\ell_j}{j}
=
\frac{\ln3}{\kappa}.
}
\]

This does **not** force the López–Stoll consecutive gap-ratio hypothesis.
A bounded \(O(1)\) relative-height error may alter \(\ell_j\) by fixed
multiplicative factors.

The diagnostic shock schedules in
`CP20_TASK8B0_MODULE_A_DIAGNOSTICS.json` satisfy
\(s_k=\kappa\log_2k+O(1)\) with phase-valid positive valuations while
producing consecutive level-gap ratios far above \(3\).

**Verdict A3:** `[EXACT]`.

---

## A4. Main real-series convergence theorem

Because \(d_k=A_k\), the \(k\)-th positive term of the López–Stoll real
series is

\[
u_k
=
\frac{2^{A_k}}{3^{k+1}}.
\]

Using

\[
A_k=F_k-s_k,
\qquad
3^k=2^{\alpha_Ck}=2^{F_k+\theta_k},
\]

we obtain the exact identity

\[
\boxed{
u_k
=
\frac13\,2^{-s_k-\theta_k}.
}
\]

If

\[
s_k=\kappa\log_2k+e_k,\qquad |e_k|\le M,
\]

then

\[
\frac{2^{-M-1}}{3}\,k^{-\kappa}
\le
u_k
\le
\frac{2^M}{3}\,k^{-\kappa}
\]

for all sufficiently large \(k\).

Therefore

\[
\boxed{
\Phi_{\mathbb R}(v)
=
-\sum_{k\ge0}\frac{2^{A_k}}{3^{k+1}}
\text{ converges absolutely iff }\kappa>1.
}
\]

Inside the frozen CP20 regime \(\kappa>1\), convergence is automatic.

This bypasses the López–Stoll Result-5 gap-ratio criterion completely.

The paper's preliminary boundary condition is also automatic:

\[
\frac{2^{A_k}}{3^k}
=
2^{-s_k-\theta_k}
=
\Theta(k^{-\kappa})\to0,
\]
and bounded parity gaps extend it from odd endpoints to all standard times.

**Verdict A4:** `[MAJOR THEOREM CANDIDATE]`.

---

## A5. Accumulation bridge — falsified more strongly

The real-series convergence does not create a real pseudo-orbit
accumulation point.

Consider the real López–Stoll value of the parity tail beginning at the
\(k\)-th odd position:

\[
Z_k
:=
\Phi_{\mathbb R}(S^{A_k}v).
\]

The one-positions in this shifted word are
\[
A_{k+j}-A_k,
\]
so

\[
\boxed{
Z_k
=
-\frac13
\sum_{j\ge0}
\frac{2^{A_{k+j}-A_k}}{3^j}.
}
\]

Using
\[
A_m=F_m-s_m
\]
gives the exact ratio identity

\[
\frac{2^{A_{k+j}-A_k}}{3^j}
=
2^{\theta_k-\theta_{k+j}}
2^{s_k-s_{k+j}}.
\]

With
\[
s_m=\kappa\log_2m+e_m,\qquad |e_m|\le M,
\]

\[
2^{-1-2M}
\left(\frac{k}{k+j}\right)^\kappa
\le
\frac{2^{A_{k+j}-A_k}}{3^j}
\le
2^{1+2M}
\left(\frac{k}{k+j}\right)^\kappa.
\]

For \(\kappa>1\),

\[
\frac{k}{\kappa-1}
\le
\sum_{j\ge0}
\left(\frac{k}{k+j}\right)^\kappa
\le
1+\frac{k}{\kappa-1}.
\]

Therefore

\[
\boxed{
\frac{2^{-1-2M}}{3(\kappa-1)}\,k
\le
-Z_k
\le
\frac{2^{1+2M}}3
\left(
1+\frac{k}{\kappa-1}
\right).
}
\]

Hence

\[
\boxed{
Z_k=-\Theta(k)
}
\]

and in particular

\[
\boxed{
Z_k\to-\infty.
}
\]

This is not merely an odd-subsequence statement.

If
\[
A_k\le\ell<A_{k+1},
\qquad
r=\ell-A_k,
\]
then the parity instructions from \(A_k\) are one odd instruction followed by
zeros. For \(r\ge1\),

\[
\Phi_{\mathbb R}(S^\ell v)
=
\frac{3Z_k+1}{2^r}.
\]

Since the critical-log law gives a uniform bound on \(a_k\), the integer
\(r\) is uniformly bounded. Therefore

\[
\boxed{
\Phi_{\mathbb R}(S^\ell v)\to-\infty
\quad(\ell\to\infty).
}
\]

Thus the entire real pseudo-orbit has **no finite real accumulation point**.

### Consequence for Task 8A

Task 8A can force positive critical-site density, split density, and
pressure-feasible local profiles. None of these can upgrade López–Stoll
real-series convergence to real pseudo-orbit accumulation under the exact
global critical-log law, because the pseudo-orbit already escapes to
\(-\infty\) independently of those density statistics.

So the proposed bridge

\[
\text{Task-8A positive critical density}
+
\Phi_{\mathbb R}\text{ convergence}
\Longrightarrow
\text{real pseudo-orbit accumulation}
\]

is false for a structural reason.

**Verdict A5:** `[FAIL]` for the accumulation mechanism, with an exact
escape theorem replacing it.

---

## Computational falsification / diagnostics

`CP20_TASK8B0_MODULE_A_VERIFY.py` independently checked:

- 500 positive odd starting integers;
- 17,500 exact odd-only ↔ standard-parity block identities;
- 100,000 floor/ceil relative-height identity cases.

It also generated phase-valid critical-log symbolic schedules at

\[
\kappa=1.06,\;1.5,\;2.0
\]

with bounded fixed-depth shocks.

All remained in a bounded additive critical-log corridor and had bounded
valuations, while the largest observed consecutive López level-gap ratios
were respectively approximately

\[
28766,\quad 28766,\quad 43148,
\]

showing that a tame ratio-\(<3\) condition is not a consequence of the
critical-log law.

Truncated pseudo-tail diagnostics grow on the predicted linear scale.
These numbers are `[NUM]` only; no theorem uses them.

---

## Module-A final one-line verdict

\[
\boxed{
\texttt{[MAJOR THEOREM CANDIDATE]:
critical-log }\kappa>1
\Rightarrow
\Phi_{\mathbb R}\text{ converges absolutely, but its real pseudo-orbit
escapes to }-\infty.
}
\]

The mandatory Task-8B0 stop/audit rule is therefore triggered.
