# CP20 TASK 8B0 — MODULE A REPAIRED DIAGNOSTICS V2

**Status:** `[NUM/CHECK ONLY]`

## Repair of the V1 tail diagnostic

V1 reported the finite truncation
\[
-\Phi_{\mathbb R}^{(\le N)}(S^{A_k}v)/k.
\]

That column decreases as \(k\) approaches the fixed truncation endpoint
because a growing fraction of the positive tail has simply been omitted.
It is therefore **not evidence against or for** the theorem-scale
\(-Z_k=\Theta(k)\) statement.

V2 removes that interpretation completely.

## Replacement diagnostic

For a synthetic bounded-error critical-log schedule, define the finite
same-horizon shape sums
\[
S_{\rm act}(k,J)
=
\sum_{j=0}^{J}
\frac{2^{A_{k+j}-A_k}}{3^j},
\]
and
\[
S_{\rm ideal}(k,J)
=
\sum_{j=0}^{J}
\left(\frac{k}{k+j}\right)^\kappa.
\]

V2 reports only
\[
S_{\rm act}(k,J)/S_{\rm ideal}(k,J),
\]
using the **same truncation \(J\)** in numerator and denominator.

This diagnostic checks the bounded multiplicative distortion predicted by
\[
\frac{2^{A_{k+j}-A_k}}{3^j}
=
2^{\theta_k-\theta_{k+j}}
2^{s_k-s_{k+j}}
=
\Theta\left((k/(k+j))^\kappa\right).
\]

It is not a proof premise.

## Result-5 diagnostic downgrade

V1 finite gap-ratio spikes do not establish the asymptotic limsup condition
in López–Stoll Result 5.

Canonical status:
\[
\boxed{\texttt{[NOT ESTABLISHED — NOT NEEDED]}.}
\]

The V2 proof does not use Result 5.

## Verification role

The canonical V2 verifier is intended to check exact algebraic identities,
not infer asymptotic theorems from finite plots or ratios.
