# CP20 TASK 8B0 — MODULE A AUDIT PACKAGE

**Status:** `[AUDIT CANDIDATE]`  
**Stop rule:** triggered in Module A.

## Main result

Under
\[
s_k=\kappa\log_2k+O(1),
\]
the standard parity word lies exactly on the classical density boundary
\[
\ln2/\ln3.
\]

For \(\kappa>1\):

\[
\Phi_{\mathbb R}(v)
\]
converges absolutely, but

\[
\Phi_{\mathbb R}(S^\ell v)\to-\infty.
\]

Therefore Task-8A positive critical density cannot repair the López–Stoll
real-pseudo-orbit accumulation bridge.

## Contents

- `CP20_TASK8B0_MASTER_FINDINGS.md`
- `CP20_TASK8B0_MODULE_A_LOPEZ_STOLL_BRIDGE.md`
- `CP20_TASK8B0_LOPEZ_STOLL_CRITICAL_LOG_BRIDGE_THEOREM.md`
- `CP20_TASK8B0_MODULE_A_DEPENDENCY_GRAPH.md`
- `CP20_TASK8B0_MODULE_A_COUNTEREXAMPLE_REPORT.md`
- `CP20_TASK8B0_MODULE_A_VERIFY.py`
- `CP20_TASK8B0_MODULE_A_VERIFY_OUTPUT.txt`
- `CP20_TASK8B0_MODULE_A_DIAGNOSTICS.json`
- `CP20_TASK8B0_MODULE_A_ZERO_TRUST_AUDIT_PROMPT.md`
- `SHA256SUMS.txt`

## Source discipline

Primary external source:
Josefina López and Peter Stoll,
“The 3x+1 Periodicity Conjeture in R,” arXiv:2101.12747 (2021).

Bernstein–Lagarias was used only for parity-conjugacy convention cross-check.

The frozen CP20 Task 8A core is used only as downstream context, not as a
proof premise for the new analytic bridge.

## Not performed

Modules B–E and Module F conjunction search were not performed because the
prompt explicitly requires stopping on a load-bearing theorem candidate.

## Next action

Independent zero-trust audit of Module A.

Do not resume Module B until that verdict is integrated.
