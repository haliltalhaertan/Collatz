# CP20 TASK 8B0 — MODULE A DEPENDENCY GRAPH

**Status:** `[AUDIT CANDIDATE]`

## External primary input

López–Stoll (2021), arXiv:2101.12747:

- standard single-step \(3x+1\) map;
- parity vector;
- conjugacy formula
  \[
  \Phi(v)=-\sum_i2^{d_i}/3^{i+1};
  \]
- critical parity density
  \(\ln2/\ln3\);
- relative height
  \(n_\ell=h(\ell)-\lceil(\ln2/\ln3)\ell\rceil\);
- last-level indices \(\ell_j\);
- Result-5 warning/criterion;
- explicit warning that real-series convergence need not give real
  pseudo-orbit accumulation in general.

Bernstein–Lagarias is used only to cross-check the standard 2-adic parity
conjugacy convention.

## Frozen project inputs

### CP20 Task 8A

Status:
`[PROVED][INDEPENDENTLY AUDITED][POST-AUDIT REPAIRED][FROZEN]`.

Used only for the downstream interpretation that low-\(\kappa\) survivors
must carry critical-site density. It is **not needed** for the analytic
series-convergence or pseudo-orbit-escape proof.

### CP20 Task 6

Status:
`[PROVED][INDEPENDENTLY AUDITED][FROZEN]`.

Its affine/carry framework is consistent with the same normalized series,
but the Module-A proof re-derives the López series identity directly.

### CP20 Task 7

Status:
`[PROVED][INDEPENDENTLY AUDITED][FROZEN]`.

Its wording observation that the critical-log law forces bounded valuations
is re-derived explicitly in Module A.

## New chain

\[
s_k=\kappa\log_2k+O(1)
\]

\[
\Downarrow
\]

\[
d_k^{\rm parity}=A_k,\qquad
\frac{2^{A_k}}{3^{k+1}}
=
\frac13\,2^{-s_k-\{\alpha k\}}
\]

\[
\Downarrow
\]

\[
\kappa>1
\Longrightarrow
\Phi_{\mathbb R}(v)
\text{ absolutely convergent}
\]

\[
\Downarrow
\]

\[
\Phi_{\mathbb R}(S^{A_k}v)
=
-\Theta(k)
\]

\[
\Downarrow
\]

\[
\Phi_{\mathbb R}(S^\ell v)\to-\infty
\]

\[
\Downarrow
\]

\[
\boxed{
\text{Task-8A critical density cannot close the López real-accumulation bridge.}
}
\]

## Non-dependencies

No CP19 high-half state.

No finite residue stabilization theorem.

No 3-adic mixing theorem.

No continued-fraction repeat theorem.

No Task 8B proper.
