# CP20 TASK 8B0 — MODULE A FINAL FREEZE DECISION — 2026-08-26

## Final status

\[
\boxed{
\texttt{[PROVED][INDEPENDENTLY AUDITED][BRANCH CLOSURE][FROZEN]}
}
\]

## Independent audit

Principal verdict:
\[
\boxed{\texttt{[PROOF VALID WITH WORDING REPAIR]}}.
\]

## Mandatory repair checklist

### R1 — Novelty / attribution

`PASS`.

Canonical wording:

> The López–Stoll real-series convergence under critical-log
> \(\kappa>1\) is exactly the frozen CP20 Task-6 carry convergence rewritten
> in López–Stoll notation. It is not a new independent convergence theorem.

Exact identity:
\[
\frac{B_k}{3^k}
=
\sum_{j<k}\frac{2^{A_j}}{3^{j+1}},
\qquad
\Phi_{\mathbb R}(v)
=
-\lim_{k\to\infty}\frac{B_k}{3^k}.
\]

The exact separation identity is now central:
\[
\boxed{
n_k-Z_k
=
(n_0-\Phi_{\mathbb R}(v))
2^{s_k+\theta_k}.
}
\]

### R2 — Diagnostics

`PASS`.

The misleading interpretation of the falling truncated
\(-\Phi/k\) column is removed.

V2 uses same-horizon
\(S_{\rm act}/S_{\rm ideal}\) only as a `[NUM]` shape diagnostic and explicitly
records the finite-tail truncation artifact.

### R3 — Result 5

`PASS`.

Canonical status:
\[
\boxed{\texttt{[NOT ESTABLISHED — NOT NEEDED]}}.
\]

No finite computation is used to falsify an asymptotic Result-5 limsup.

### R4 — Small wording

`PASS`.

V2 explicitly records:

- \(d_0=0\) because the encoding begins from an odd state;
- the general López–Stoll convention only needs \(d_0\ge0\);
- level-time existence follows from
  \(r_{\ell+1}-r_\ell\in\{-1,0,1\}\) and \(r_\ell\to+\infty\);
- two-sided tail constants are used only to prove qualitative
  \(\Theta(k)\), not marketed as sharp.

### R5 — Classification

`PASS`.

The old `[MAJOR THEOREM CANDIDATE]` classification is retired.

## Mechanical verifier

`CP20_TASK8B0_MODULE_A_VERIFY_V2.py` was executed twice from source.

Both runs produced byte-identical stdout.

Exact rational checks include:

- odd-only → standard parity block encoding;
- \(d_k=A_k\);
- carry partial sum identity;
- real-series term rational precursor identity;
- exact finite separation identity;
- exact conjugacy branches;
- shifted ratio rational precursor identity.

Final verifier line:
`ALL V2 MECHANICAL ASSERTIONS: PASS`.

## What Module A genuinely adds

1. Exact translation dictionary between CP20 critical-log notation and
   López–Stoll parity/relative-height notation.
2. Exact identification of the López–Stoll real series with the already
   frozen Task-6 carry series.
3. Exact separation identity between the positive ordinary orbit and the
   López real pseudo-orbit.
4. Negative branch closure:
   \[
   \Phi_{\mathbb R}(S^\ell v)\to-\infty
   \]
   in the global critical-log class.
5. Therefore Task-8A critical density cannot rescue the López real
   accumulation route.

## Safe downstream statement

> Under the global critical-log law
> \(s_k=\kappa\log_2k+O(1)\), \(\kappa>1\), the López–Stoll real series is
> exactly the already-frozen CP20 carry series in López–Stoll notation, and
> the associated real pseudo-orbit has no finite accumulation point; in fact
> it escapes to \(-\infty\). Hence the López–Stoll real-accumulation route is
> closed inside this critical-log class.

## Scope

This freeze does not prove or disprove existence of a positive ordinary
Syracuse realizer.

It does not solve Collatz.

It does not reopen CP19 parked high-half/cross-adic machinery.

## Resume decision

Module A is frozen.

The next reconnaissance module is **Module B: ordinary-start residue
stabilization**, followed in priority by D, C, then E unless a new
load-bearing theorem triggers another audit stop.
