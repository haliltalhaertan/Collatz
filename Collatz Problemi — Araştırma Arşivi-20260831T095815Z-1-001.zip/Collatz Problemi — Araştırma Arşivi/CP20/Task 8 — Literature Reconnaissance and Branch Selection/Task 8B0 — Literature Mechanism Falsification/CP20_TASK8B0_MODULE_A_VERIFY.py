#!/usr/bin/env python3
"""
CP20 Task 8B0 — Module A exact/diagnostic verification
Date: 2026-08-26
Status: [AUDIT CANDIDATE]

The theorem proof is analytic. This script only:
  1) verifies the odd-only <-> standard parity convention on exact integer orbits;
  2) verifies the exact level-height identity numerically at high precision;
  3) constructs a phase-valid critical-log symbolic schedule with bounded shocks
     to falsify any inference from exponential level scale to a tame consecutive
     gap-ratio condition;
  4) checks the predicted linear growth of truncated real pseudo-orbit tails.

No numerical output is used as a theorem premise.
"""

from decimal import Decimal, getcontext, ROUND_FLOOR, ROUND_CEILING
import math, json
from pathlib import Path

getcontext().prec = 90

ALPHA_D = Decimal(3).ln() / Decimal(2).ln()      # log_2 3
GAMMA_D = Decimal(1) / ALPHA_D                   # ln 2 / ln 3
ALPHA = float(ALPHA_D)

def floorD(x):
    return int(x.to_integral_value(rounding=ROUND_FLOOR))

def ceilD(x):
    return int(x.to_integral_value(rounding=ROUND_CEILING))

def v2(n):
    c=0
    while n % 2 == 0:
        n//=2
        c+=1
    return c

def odd_syracuse_prefix(n0, odd_steps):
    assert n0 > 0 and n0 % 2 == 1
    n=n0
    A=[0]
    vals=[]
    states=[n]
    for _ in range(odd_steps):
        z=3*n+1
        a=v2(z)
        n=z >> a
        vals.append(a)
        A.append(A[-1]+a)
        states.append(n)
    return vals,A,states

def standard_parity(n0, length):
    n=n0
    bits=[]
    for _ in range(length):
        bit=n&1
        bits.append(bit)
        if bit:
            n=(3*n+1)//2
        else:
            n//=2
    return bits

def exact_parity_checks(max_start=999, odd_steps=35):
    checked=0
    height_checks=0
    for n0 in range(1,max_start+1,2):
        vals,A,states=odd_syracuse_prefix(n0,odd_steps)
        bits=standard_parity(n0,A[-1]+1)
        for k in range(odd_steps):
            assert bits[A[k]]==1
            for j in range(A[k]+1,A[k+1]):
                assert bits[j]==0
            # h(A_k) = number of ones among indices < A_k = k
            h=sum(bits[:A[k]])
            assert h==k
            height_checks += 1
        checked += 1
    return checked,height_checks

def relative_height_identity_checks(max_k=100000):
    # Algebraic identity:
    # n_{A_k}=k-ceil(gamma A_k)
    # = floor((s_k + {alpha k})/alpha).
    passed=0
    for k in range(1,max_k+1):
        F=floorD(ALPHA_D*Decimal(k))
        theta=ALPHA_D*Decimal(k)-Decimal(F)

        # use a deterministic integer s within a broad bounded-log corridor;
        # this is only testing the floor/ceil identity.
        s=floorD(Decimal("1.7")*(Decimal(k).ln()/Decimal(2).ln())) - 3
        A=F-s
        if A <= 0:
            continue
        lhs=k-ceilD(GAMMA_D*Decimal(A))
        rhs=floorD((Decimal(s)+theta)/ALPHA_D)
        assert lhs==rhs
        passed += 1
    return passed

def synth_shock(kappa=1.5,N=120000,shock_depth=8):
    """
    Phase-valid symbolic valuation schedule.
    It keeps s_k = kappa log2(k)+O(1), but at powers of two inserts a
    fixed-depth downward shock and then greedily recovers at g=2 sites.

    d_k = g_k-a_k <=1 and a_k>=1 exactly.
    """
    s=0
    ss=[0]
    vals=[]
    A=[0]

    for k in range(N):
        g=math.floor(ALPHA*(k+1))-math.floor(ALPHA*k)
        target=math.floor(kappa*math.log2(k+2))
        shock=(k>=1024 and (k & (k-1) == 0))
        if shock:
            d=-shock_depth
        elif s < target and g==2:
            d=1
        elif s > target:
            d=target-s
        else:
            d=0
        a=g-d
        assert a>=1
        vals.append(a)
        s += d
        ss.append(s)
        A.append(A[-1]+a)

    max_err=max(
        abs(ss[k]-kappa*math.log2(k+1))
        for k in range(1,len(ss))
    )

    # Build Lopez-Stoll relative height n_l = h(l)-ceil(gamma*l).
    one_positions=set(A[:-1])
    h=0
    last={}
    for ell in range(A[-1]+1):
        nrel=h-ceilD(GAMMA_D*Decimal(ell))
        last[nrel]=ell
        if ell in one_positions:
            h += 1

    ratios=[]
    jmin=max(0,min(last))
    jmax=max(last)
    for j in range(jmin,jmax-1):
        if j in last and j+1 in last and j+2 in last:
            g1=last[j+1]-last[j]
            g2=last[j+2]-last[j+1]
            if g1>0 and g2>0:
                ratios.append({
                    "j":j,
                    "gap_j":g1,
                    "gap_j1":g2,
                    "ratio":g2/g1,
                })
    ratios.sort(key=lambda x:x["ratio"], reverse=True)

    return {
        "kappa":kappa,
        "N":N,
        "shock_depth":shock_depth,
        "max_abs_log_error":max_err,
        "max_valuation":max(vals),
        "A_N":A[-1],
        "largest_gap_ratios":ratios[:12],
        "vals":vals,
        "A":A,
        "s":ss,
    }

def truncated_tail_diagnostics(schedule, ks=(128,512,2048,8192)):
    """
    Computes finite truncations of
      -Phi_R(S^{A_k}v)
       = (1/3) sum_{j>=0} 2^{A_{k+j}-A_k}/3^j.
    Values are diagnostics only. The theorem proves exact two-sided linear
    bounds for the infinite sum.
    """
    A=schedule["A"]
    N=len(A)-1
    rows=[]
    for k in ks:
        if k>=N:
            continue
        total=0.0
        # log-domain evaluation avoids enormous intermediate integers.
        # stop at N; hence this is a lower bound for -Phi tail.
        for m in range(k,N+1):
            j=m-k
            expo=(A[m]-A[k])-ALPHA*j
            total += 2.0**expo
        total /= 3.0
        rows.append({
            "k":k,
            "truncated_minus_phi":total,
            "truncated_minus_phi_over_k":total/k,
            "truncation_end_odd_index":N,
        })
    return rows

def main():
    starts,height_checks=exact_parity_checks()
    rel_checks=relative_height_identity_checks()

    schedules=[]
    for kap,depth in [(1.06,8),(1.5,8),(2.0,8)]:
        sch=synth_shock(kap,120000,depth)
        tail=truncated_tail_diagnostics(sch)
        schedules.append({
            "kappa":sch["kappa"],
            "N":sch["N"],
            "shock_depth":sch["shock_depth"],
            "max_abs_log_error":sch["max_abs_log_error"],
            "max_valuation":sch["max_valuation"],
            "A_N":sch["A_N"],
            "largest_gap_ratios":sch["largest_gap_ratios"],
            "tail_diagnostics":tail,
        })

    result={
        "status":"[NUM/CHECK ONLY — NOT THEOREM PREMISE]",
        "alpha_log2_3":str(ALPHA_D),
        "gamma_ln2_ln3":str(GAMMA_D),
        "exact_integer_parity_starts_checked":starts,
        "exact_height_endpoint_checks":height_checks,
        "relative_height_floor_ceil_identity_checks":rel_checks,
        "synthetic_critical_log_shock_schedules":schedules,
    }

    out=Path(__file__).with_name("CP20_TASK8B0_MODULE_A_DIAGNOSTICS.json")
    out.write_text(json.dumps(result,indent=2),encoding="utf-8")

    print("CP20 TASK 8B0 MODULE A VERIFICATION")
    print("exact parity starts:",starts)
    print("exact endpoint height checks:",height_checks)
    print("relative-height identity checks:",rel_checks)
    for s in schedules:
        print()
        print("kappa",s["kappa"])
        print("  max |s-kappa log2 k|:",s["max_abs_log_error"])
        print("  max valuation:",s["max_valuation"])
        print("  largest gap-ratio:",s["largest_gap_ratios"][0] if s["largest_gap_ratios"] else None)
        for row in s["tail_diagnostics"]:
            print("  tail",row)
    print()
    print("ALL EXACT/DIAGNOSTIC ASSERTIONS: PASS")

if __name__=="__main__":
    main()
