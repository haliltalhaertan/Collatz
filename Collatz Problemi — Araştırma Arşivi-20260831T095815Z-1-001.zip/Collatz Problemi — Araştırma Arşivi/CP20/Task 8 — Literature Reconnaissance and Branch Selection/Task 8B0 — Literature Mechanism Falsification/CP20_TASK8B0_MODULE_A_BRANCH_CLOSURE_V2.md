# CP20 TASK 8B0 — MODULE A BRANCH CLOSURE V2

**Date:** 2026-08-26  
**Canonical status:** `[PROVED][INDEPENDENTLY AUDITED][BRANCH CLOSURE][FROZEN]`

## 1. Audit integration

Independent zero-trust audit verdict:

`[PROOF VALID WITH WORDING REPAIR]`.

This V2 integrates every mandatory repair. Historical Module-A V1 artifacts
remain unchanged.

The canonical interpretation is deliberately narrower than V1:

- the López–Stoll real-series convergence is **not a new independent CP20
  theorem**;
- it is exactly the already-frozen CP20 Task-6 carry convergence written in
  López–Stoll parity notation;
- the genuinely new Module-A output is the exact notation dictionary and the
  negative branch closure: inside the global critical-log class, the
  López–Stoll real pseudo-orbit has no finite accumulation point and in fact
  escapes to \(-\infty\).

No Collatz solution is claimed.

---

## 2. Setup

Odd-only Syracuse:
\[
n_{k+1}=\frac{3n_k+1}{2^{a_k}},
\qquad
a_k=v_2(3n_k+1)\ge1.
\]

Define
\[
\alpha=\log_2 3,
\qquad
F_k=\lfloor\alpha k\rfloor,
\qquad
A_k=\sum_{i<k}a_i,
\qquad
s_k=F_k-A_k.
\]

Assume the global critical-log law
\[
\boxed{
s_k=\kappa\log_2 k+O(1),
\qquad \kappa>1.
}
\]

The corresponding standard parity word begins at an odd state and is
\[
v
=
1\,0^{a_0-1}
1\,0^{a_1-1}
1\,0^{a_2-1}\cdots.
\]

Because the encoding begins at an odd state, its first one-position is
\[
\boxed{d_0=0}.
\]
López–Stoll's general convention only requires \(d_0\ge0\).

---

## 3. Exact translation to López–Stoll notation

The \(k\)-th parity-one position is exactly
\[
\boxed{d_k=A_k}.
\]

Let
\[
\gamma=\frac{\ln2}{\ln3}=\frac1\alpha
\]
and let \(h(\ell)\) count parity ones among positions \(0,\ldots,\ell-1\).

At odd endpoints,
\[
\boxed{h(A_k)=k}.
\]

Since
\[
A_k
=
\alpha k-\kappa\log_2 k+O(1),
\]
the standard parity-one density tends to
\[
\boxed{
\frac{\ln2}{\ln3}.
}
\]

For López–Stoll relative height
\[
r_\ell
=
h(\ell)-\lceil\gamma\ell\rceil,
\]
write
\[
\theta_k=\{\alpha k\}.
\]
Then at odd endpoints
\[
\boxed{
r_{A_k}
=
\left\lfloor
\frac{s_k+\theta_k}{\alpha}
\right\rfloor.
}
\]

The critical-log law forces the valuations \(a_k\) to be eventually uniformly
bounded, because
\[
g_k-a_k=s_{k+1}-s_k,
\qquad g_k\in\{1,2\},
\]
while \(s_{k+1}-s_k\) is uniformly bounded under
\(s_k=\kappa\log_2k+O(1)\).

Hence the endpoint relation extends to all standard parity times:
\[
\boxed{
r_\ell
=
\frac{\kappa}{\alpha}\log_2\ell+O(1).
}
\]

If
\[
\ell_j=\max\{\ell:r_\ell=j\},
\]
then these level times are well-defined for every sufficiently large \(j\):
\[
r_{\ell+1}-r_\ell\in\{-1,0,1\},
\qquad
r_\ell\to+\infty,
\]
so every sufficiently large integer level is attained and, because the
relative height eventually stays above it, has a last occurrence.

Consequently
\[
\boxed{
\log_2\ell_j
=
\frac{\alpha}{\kappa}j+O(1)
}
\]
and
\[
\boxed{
\lim_{j\to\infty}\frac{\ln\ell_j}{j}
=
\frac{\ln3}{\kappa}.
}
\]

No asymptotic conclusion about the López–Stoll Result-5 consecutive-gap
limsup is made or needed.

---

## 4. Exact Task-6 carry identification

Frozen Task 6 uses
\[
\boxed{
2^{A_k}n_k
=
3^kn_0+B_k
}
\]
with
\[
\boxed{
B_k
=
\sum_{j<k}
3^{k-1-j}2^{A_j}.
}
\]

Divide by \(3^k\):
\[
\boxed{
\frac{B_k}{3^k}
=
\sum_{j<k}
\frac{2^{A_j}}{3^{j+1}}.
}
\]

López–Stoll's real conjugacy series for the parity word is
\[
\boxed{
\Phi_{\mathbb R}(v)
=
-\sum_{j\ge0}
\frac{2^{d_j}}{3^{j+1}}
=
-\sum_{j\ge0}
\frac{2^{A_j}}{3^{j+1}}.
}
\]

Therefore
\[
\boxed{
\Phi_{\mathbb R}(v)
=
-\lim_{k\to\infty}\frac{B_k}{3^k}.
}
\]

This is the canonical novelty attribution:

> **Critical-log \(\kappa>1\) absolute convergence of the López–Stoll real
> series is the frozen CP20 Task-6 carry convergence rewritten in
> López–Stoll notation. It is not a new independent convergence theorem.**

For cross-checking, each individual term also satisfies
\[
\frac{2^{A_k}}{3^{k+1}}
=
\frac13\,2^{-s_k-\theta_k}.
\]
Thus it is \(\Theta(k^{-\kappa})\), exactly consistent with the frozen carry
argument.

---

## 5. Exact separation identity

Define the real pseudo-orbit value at the \(k\)-th odd parity position:
\[
Z_k
=
\Phi_{\mathbb R}(S^{A_k}v).
\]

Its one-positions are
\[
A_{k+j}-A_k,
\]
hence
\[
Z_k
=
-\frac13
\sum_{j\ge0}
\frac{2^{A_{k+j}-A_k}}{3^j}.
\]

Let
\[
\Phi_N
=
-\sum_{j=0}^{N-1}\frac{2^{A_j}}{3^{j+1}}
\]
and
\[
Z_{k,N}
=
-\sum_{j=k}^{N-1}
\frac{2^{A_j-A_k}}{3^{j-k+1}}.
\]

The affine identity gives, **exactly at every finite \(N>k\)**,
\[
\boxed{
n_k-Z_{k,N}
=
\frac{3^k}{2^{A_k}}
\bigl(n_0-\Phi_N\bigr).
}
\]

Passing to the convergent limit,
\[
\boxed{
n_k-Z_k
=
\frac{3^k}{2^{A_k}}
\bigl(n_0-\Phi_{\mathbb R}(v)\bigr).
}
\]

Since
\[
\frac{3^k}{2^{A_k}}
=
2^{\alpha k-A_k}
=
2^{s_k+\theta_k},
\]
we obtain the auditor's structural identity:
\[
\boxed{
n_k-Z_k
=
\bigl(n_0-\Phi_{\mathbb R}(v)\bigr)
2^{s_k+\theta_k}.
}
\]

Under critical-log,
\[
2^{s_k+\theta_k}
=
\Theta(k^\kappa).
\]

Thus the positive ordinary orbit and the real pseudo-orbit separate on a
polynomial scale \(\Theta(k^\kappa)\). This is the clean structural reason
that real-series convergence does not imply real accumulation along the
ordinary orbit.

---

## 6. Real pseudo-orbit branch closure

The shifted-tail identity also gives
\[
\frac{2^{A_{k+j}-A_k}}{3^j}
=
2^{\theta_k-\theta_{k+j}}
2^{s_k-s_{k+j}}.
\]

If
\[
s_m=\kappa\log_2m+e_m,
\qquad |e_m|\le M
\]
eventually, then uniformly in \(j\ge0\)
\[
\frac{2^{A_{k+j}-A_k}}{3^j}
=
\Theta_M
\left(
\frac{k}{k+j}
\right)^\kappa.
\]

For \(\kappa>1\),
\[
\sum_{j\ge0}
\left(
\frac{k}{k+j}
\right)^\kappa
=
\Theta_\kappa(k).
\]

Hence
\[
\boxed{
-Z_k=\Theta(k)
}
\]
and therefore
\[
\boxed{
Z_k\to-\infty.
}
\]

The constants implicit in \(\Theta(k)\) are explicit if desired, but V2
does not present them as numerically sharp.

For the real conjugacy branches,
\[
\Phi_{\mathbb R}(Sv)
=
\begin{cases}
\Phi_{\mathbb R}(v)/2,&v_0=0,\\[1mm]
(3\Phi_{\mathbb R}(v)+1)/2,&v_0=1.
\end{cases}
\]

If
\[
A_k\le\ell<A_{k+1},
\qquad r=\ell-A_k,
\]
then
\[
\Phi_{\mathbb R}(S^\ell v)
=
\begin{cases}
Z_k,&r=0,\\[1mm]
(3Z_k+1)/2^r,&1\le r<a_k.
\end{cases}
\]

The critical-log law gives a uniform upper bound on \(a_k\), so the denominator
\(2^r\) is uniformly bounded. Therefore
\[
\boxed{
\Phi_{\mathbb R}(S^\ell v)\to-\infty
\qquad(\ell\to\infty).
}
\]

The real pseudo-orbit has no finite real accumulation point.

---

## 7. Result-5 status

The V1 finite diagnostic did not establish anything about the asymptotic
Result-5 limsup condition.

Canonical status:
\[
\boxed{\texttt{[NOT ESTABLISHED — NOT NEEDED]}.}
\]

Large finite gap-ratio spikes at small accessible level index \(j\) can be
transient artifacts and do not falsify an asymptotic limsup condition.

The Module-A branch-closure proof does not use Result 5.

---

## 8. Task-8A relation

Frozen Task 8A is **not a premise** of the analytic branch-closure proof.

Task 8A enters only downstream interpretation:

- for low \(\kappa\), pressure can force positive critical-site density;
- nevertheless, within the same global critical-log class, the López–Stoll
  real pseudo-orbit already tends to \(-\infty\);
- therefore positive critical density cannot rescue the López real
  accumulation route.

Thus this attempted conjunction is closed negatively.

---

## 9. Scope

This branch closure does not:

- prove or disprove existence of a positive ordinary Syracuse realizer;
- prove Collatz;
- convert real-series convergence into a rationality contradiction;
- use Task 8A to prove the analytic escape;
- use CP19 parked high-half/cross-adic machinery.

## Final canonical statement

\[
\boxed{
\begin{minipage}{0.91\linewidth}
Under the global critical-log law
\(s_k=\kappa\log_2k+O(1)\), \(\kappa>1\),
the López–Stoll real series is exactly the already-frozen CP20 Task-6 carry
series in López–Stoll notation. The associated real pseudo-orbit has no
finite accumulation point; in fact it escapes to \(-\infty\).
Hence the López–Stoll real-accumulation route is closed inside this
critical-log class.
\end{minipage}
}
\]

**Status:** `[PROVED][INDEPENDENTLY AUDITED][BRANCH CLOSURE][FROZEN]`.
