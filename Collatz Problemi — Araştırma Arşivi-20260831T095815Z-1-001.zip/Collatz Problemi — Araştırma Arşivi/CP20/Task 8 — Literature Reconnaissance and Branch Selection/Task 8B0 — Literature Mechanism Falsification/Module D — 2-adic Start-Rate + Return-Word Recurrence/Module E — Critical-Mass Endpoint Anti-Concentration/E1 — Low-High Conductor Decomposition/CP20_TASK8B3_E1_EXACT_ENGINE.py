#!/usr/bin/env python3
from pathlib import Path
import math,itertools,collections,json,csv,random
import numpy as np
HERE=Path(__file__).resolve().parent
ALPHA=math.log2(3.0)

def compositions(A,r):
    if r==1:
        yield (A,);return
    for cuts in itertools.combinations(range(1,A),r-1):
        prev=0;w=[]
        for c in cuts:w.append(c-prev);prev=c
        w.append(A-prev);yield tuple(w)

def endpoint(w):
    A=0;B=0
    for a in w:B=3*B+(1<<A);A+=a
    return B*pow(2,-A,3**len(w))%(3**len(w))

def dist(r,A):
    c=collections.Counter()
    for w in compositions(A,r):c[endpoint(w)]+=1
    return c

def suffix_tests():
    n=0
    for r in range(1,7):
      for A in range(r,min(12,r+5)):
       for w in compositions(A,r):
        M=endpoint(w)
        for t in range(1,r+1):assert M%(3**t)==endpoint(w[-t:]);n+=1
    rng=random.Random(8282026);m=0
    for _ in range(1000):
        r=rng.randint(2,25);w=tuple(rng.randint(1,7) for _ in range(r));M=endpoint(w)
        for __ in range(2):
            t=rng.randint(1,r);assert M%(3**t)==endpoint(w[-t:]);m+=1
    return n,m

def fft_metrics(r,A,d):
    q=3**r;W=sum(d.values());arr=np.zeros(q,dtype=np.float64)
    for y,n in d.items():arr[y]=n
    mag=np.abs(np.fft.fft(arr)/W)
    cond={}
    for t in range(1,r+1):
        step=3**(r-t);n=3**t
        us=np.arange(1,n,dtype=np.int64);us=us[us%3!=0];xs=us*step;vals=mag[xs]
        mx=float(vals.max());idx=np.where(vals>=mx-1e-14)[0];xbest=int(xs[idx].min())
        cond[str(t)]={'xi':xbest,'abs_phi':mx}
    return cond

def structured_from_fft(r,A,cond_mag,d):
    # Direct exact-support evaluation for the small structured family.
    q=3**r;W=sum(d.values());best=None
    for C in range(A+1):
        xi=pow(2,A-C,q);theta=2*math.pi*xi/q;s=0j
        for y,n in d.items():s+=n*complex(math.cos(theta*y),math.sin(theta*y))
        v=abs(s/W);rec={'C':C,'xi':xi,'abs_phi':v}
        if best is None or v>best['abs_phi']+1e-15 or (abs(v-best['abs_phi'])<=1e-15 and C<best['C']):best=rec
    return best

def interval(d,r,b):
    q=3**r;W=sum(d.values());L=max(1,min(q,int(2**(b*r))));Q=sum(n for y,n in d.items() if y<L);bench=W*L/q
    return {'b':b,'L':L,'Q':Q,'benchmark':bench,'ratio':Q/bench if bench else None,'D':math.log2(Q/bench)/r if Q and bench else None}

def main():
    se,sr=suffix_tests();rows=[]
    for r in range(3,11):
        base=math.floor(ALPHA*r)
        offsets=range(-5,6) if r<=7 else (-3,0,3)
        for off in offsets:
            A=base+off
            if A<r:continue
            d=dist(r,A);cond=fft_metrics(r,A,d)
            rows.append({'r':r,'A':A,'d':off,'W':sum(d.values()),'occupied':len(d),'conductor_best':cond,'structured_power2_best':structured_from_fft(r,A,cond,d),'intervals':[interval(d,r,b) for b in (0.8,1.0,1.2,1.35,1.45,1.52)]})
    # larger r: structured primitive family and intervals only
    larger=[]
    for r in (11,12):
        base=math.floor(ALPHA*r)
        for off in (-3,0,3):
            A=base+off
            if A<r:continue
            d=dist(r,A)
            larger.append({'r':r,'A':A,'d':off,'W':sum(d.values()),'structured_power2_best':structured_from_fft(r,A,None,d),'intervals':[interval(d,r,b) for b in (0.8,1.0,1.2,1.35,1.45,1.52)]})
    res={'alpha':ALPHA,'suffix_exact_checks':se,'suffix_random_checks':sr,'full_scan_rows':rows,'larger_structured_rows':larger}
    (HERE/'CP20_TASK8B3_E1_RESULTS.json').write_text(json.dumps(res,indent=2,sort_keys=True))
    with (HERE/'CP20_TASK8B3_E1_SUMMARY.csv').open('w',newline='') as f:
        fs=['r','A','d','W','t1_abs','primitive_abs','structured_abs','max_interval_D'];wr=csv.DictWriter(f,fieldnames=fs);wr.writeheader()
        for z in rows:
            ds=[x['D'] for x in z['intervals'] if x['D'] is not None]
            wr.writerow({'r':z['r'],'A':z['A'],'d':z['d'],'W':z['W'],'t1_abs':z['conductor_best']['1']['abs_phi'],'primitive_abs':z['conductor_best'][str(z['r'])]['abs_phi'],'structured_abs':z['structured_power2_best']['abs_phi'],'max_interval_D':max(ds) if ds else None})
    print('CP20 TASK 8B3 E1 ENGINE')
    print('suffix exact checks:',se);print('suffix random checks:',sr);print('full scan rows:',len(rows));print('larger structured rows:',len(larger))
    print('critical d=0 primitive trends:')
    for z in rows:
        if z['d']==0:
            v=z['conductor_best'][str(z['r'])]['abs_phi'];gam=-math.log2(max(v,1e-300))/z['r']
            print(z['r'],z['A'],format(v,'.9g'),format(gam,'.7g'),format(z['structured_power2_best']['abs_phi'],'.9g'))
    print('ALL E1 ENGINE ASSERTIONS: PASS')
if __name__=='__main__':main()
