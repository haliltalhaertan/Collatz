# CP20 TASK 8B3 — E1 SUFFIX / CONDUCTOR ANALYSIS

**Status:** `[EXACT — ELEMENTARY BLOCK COROLLARY]`

## Pointwise suffix lemma
Let `1<=t<=r` and split a word `w` into a prefix of length `r-t` and suffix
`z=(a_(r-t),...,a_(r-1))` of length `t`.

Write the suffix partial masses as `C_ell=sum_(h<ell) z_h` and total suffix
mass `C_t`.

The affine sum splits as

`B_r = 3^t B_(r-t) + sum_(ell=0)^(t-1) 3^(t-1-ell) 2^(A_(r-t)+C_ell)`.

Multiplying by `2^(-A_r)=2^(-A_(r-t)-C_t)` and reducing modulo `3^t`
kills the prefix term and cancels `A_(r-t)`. Hence

`M_r(w) mod 3^t = sum_(ell=0)^(t-1) 3^(t-1-ell) 2^(C_ell-C_t) mod 3^t`.

The right side is exactly `M_t(z)`. Therefore

`M_r(w) mod 3^t = M_t(last t valuation letters)`.

This is pointwise, independent of the prefix and independent of total mass.
Edge case `t=r` is tautological; `t=1` recovers the E0 conductor-3 endpoint law.

Exhaustive checks: 2310.
Random larger checks: 2000.

## Fixed-conductor Fourier law
A frequency of conductor `3^t` has the form

`xi = 3^(r-t) u`, with `3` not dividing `u`.

Then

`e_(3^r)(xi M_r) = e_(3^t)(u M_t(suffix))`.

Thus every fixed-conductor coefficient is a boundary functional of only the
last `t` valuation letters.

Under uniform `W_(r,A)` and `r>t`, a specific suffix `z` of mass `C` has
probability

`C(A-C-1,r-t-1) / C(A-1,r-1)`

whenever the remaining prefix mass can support `r-t` positive parts.
Therefore

`phi_(r,A)(3^(r-t)u)`

is exactly the weighted mixture over suffix masses `C` of the finite
`t`-letter coefficients `phi_(t,C)(u)`, with multiplicity
`C(C-1,t-1)`.

This is an elementary block decomposition, not a new foundational theorem;
no audit stop is triggered.
