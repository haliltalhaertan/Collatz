from pathlib import Path
import math,itertools,collections,json
HERE=Path(__file__).resolve().parent
ALPHA=math.log2(3.0)
def comps(A,r):
    for cuts in itertools.combinations(range(1,A),r-1):
        prev=0;w=[]
        for c in cuts:w.append(c-prev);prev=c
        w.append(A-prev);yield w
def endpoint(w):
    A=0;B=0
    for a in w:B=3*B+(1<<A);A+=a
    return B*pow(2,-A,3**len(w))%(3**len(w))
def intervals(r,A):
    q=3**r;W=math.comb(A-1,r-1); counts={b:0 for b in (0.8,1.0,1.2,1.35,1.45,1.52)};Ls={b:int(2**(b*r)) for b in counts}
    for w in comps(A,r):
        y=endpoint(w)
        for b,L in Ls.items():
            if y<L:counts[b]+=1
    out=[]
    for b,Q in counts.items():
        L=Ls[b];bench=W*L/q;ratio=Q/bench if bench else None;D=math.log2(ratio)/r if Q and ratio else None
        out.append({'b':b,'L':L,'Q':Q,'benchmark':bench,'ratio':ratio,'D':D})
    return out
rows=[]
for r in (13,14,15):
    base=math.floor(ALPHA*r)
    for d in (-3,0,3):
        A=base+d
        if A<r:continue
        rows.append({'r':r,'A':A,'d':d,'W':math.comb(A-1,r-1),'intervals':intervals(r,A)})
(HERE/'CP20_TASK8B3_E1_INTERVAL_EXTENSION.json').write_text(json.dumps(rows,indent=2,sort_keys=True))
for z in rows:
    print('r',z['r'],'d',z['d'],'W',z['W'],[(x['b'],round(x['ratio'],5) if x['ratio'] else None,round(x['D'],6) if x['D'] else None) for x in z['intervals']])
