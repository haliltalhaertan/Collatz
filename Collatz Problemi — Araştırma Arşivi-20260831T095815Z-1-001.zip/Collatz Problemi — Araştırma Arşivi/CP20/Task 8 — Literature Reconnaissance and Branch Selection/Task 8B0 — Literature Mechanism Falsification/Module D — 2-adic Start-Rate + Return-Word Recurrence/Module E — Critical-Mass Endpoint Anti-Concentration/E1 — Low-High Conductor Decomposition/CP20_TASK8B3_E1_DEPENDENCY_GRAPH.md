# CP20 TASK 8B3 — E1 DEPENDENCY GRAPH

Frozen E0 branch closure -> low conductors cannot satisfy a global spectral gap.

Exact suffix lemma -> conductor `3^t` character depends only on the last `t` valuations.

Fourier completion + interval Dirichlet L1 -> low block `t<=tau r` is negligible if `tau<b/alpha`, without any low-conductor decay.

Remaining high block -> needs a decay profile satisfying the inequalities in `HIGH_CONDUCTOR_REQUIRED_DECAY`.

No Task6 conjunction is used. No CP18/CP19 parked branch is reopened.
