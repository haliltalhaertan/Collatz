from pathlib import Path
import math,itertools,json
HERE=Path(__file__).resolve().parent
ALPHA=math.log2(3.0)
def comps(A,r):
    for cuts in itertools.combinations(range(1,A),r-1):
        prev=0;w=[]
        for c in cuts:w.append(c-prev);prev=c
        w.append(A-prev);yield w
def endpoint(w,q):
    A=0;B=0
    for a in w:B=3*B+(1<<A);A+=a
    return B*pow(2,-A,q)%q
rows=[]
for r in (16,17,18):
    A=math.floor(ALPHA*r)-3
    if A<r:continue
    q=3**r;W=math.comb(A-1,r-1); bs=(0.8,1.0,1.2,1.35,1.45,1.52);Ls={b:int(2**(b*r)) for b in bs};cnt={b:0 for b in bs}
    for w in comps(A,r):
        y=endpoint(w,q)
        for b,L in Ls.items():
            if y<L:cnt[b]+=1
    ints=[]
    for b in bs:
        bench=W*Ls[b]/q;ratio=cnt[b]/bench if bench else None;D=math.log2(ratio)/r if cnt[b] and ratio else None
        ints.append({'b':b,'Q':cnt[b],'benchmark':bench,'ratio':ratio,'D':D})
    rows.append({'r':r,'A':A,'d':-3,'W':W,'intervals':ints})
    print(r,A,W,[(x['b'],round(x['ratio'],5),round(x['D'],6)) for x in ints])
(HERE/'CP20_TASK8B3_E1_NEGATIVE_OFFSET_EXTENSION.json').write_text(json.dumps(rows,indent=2,sort_keys=True))
