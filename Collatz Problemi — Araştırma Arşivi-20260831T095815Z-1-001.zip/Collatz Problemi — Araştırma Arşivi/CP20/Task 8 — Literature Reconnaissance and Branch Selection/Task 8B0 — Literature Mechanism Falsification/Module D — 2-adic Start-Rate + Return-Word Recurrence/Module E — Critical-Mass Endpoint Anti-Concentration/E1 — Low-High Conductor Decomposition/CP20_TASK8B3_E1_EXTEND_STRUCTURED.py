from pathlib import Path
import math,itertools,json,numpy as np
HERE=Path(__file__).resolve().parent
ALPHA=math.log2(3.0)
def comps(A,r):
    for cuts in itertools.combinations(range(1,A),r-1):
        prev=0;w=[]
        for c in cuts:w.append(c-prev);prev=c
        w.append(A-prev);yield w
def endpoint(w,q):
    A=0;B=0
    for a in w:B=3*B+(1<<A);A+=a
    return B*pow(2,-A,q)%q
rows=[]
for r in (13,14,15):
    base=math.floor(ALPHA*r)
    for d in (-3,0):
        A=base+d
        if A<r:continue
        q=3**r
        ys=np.fromiter((endpoint(w,q) for w in comps(A,r)),dtype=np.int64,count=math.comb(A-1,r-1))
        best=None
        for C in range(A+1):
            xi=pow(2,A-C,q)
            ang=(2*np.pi*xi/q)*ys
            val=abs(np.exp(1j*ang).mean())
            rec={'C':C,'xi':xi,'abs_phi':float(val),'gamma2':float(-math.log2(max(val,1e-300))/r)}
            if best is None or val>best['abs_phi']+1e-14 or (abs(val-best['abs_phi'])<=1e-14 and C<best['C']):best=rec
        rows.append({'r':r,'A':A,'d':d,'W':len(ys),'best':best})
        print(r,d,A,len(ys),best)
(HERE/'CP20_TASK8B3_E1_STRUCTURED_EXTENSION.json').write_text(json.dumps(rows,indent=2,sort_keys=True))
