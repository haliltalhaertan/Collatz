#!/usr/bin/env python3
from pathlib import Path
import json,math
HERE=Path(__file__).resolve().parent
ALPHA=math.log2(3.0)
R=json.loads((HERE/'CP20_TASK8B3_E1_RESULTS.json').read_text())
NEG=json.loads((HERE/'CP20_TASK8B3_E1_NEGATIVE_OFFSET_EXTENSION.json').read_text())
NSTR=json.loads((HERE/'CP20_TASK8B3_E1_NEGATIVE_STRUCTURED_EXTENSION.json').read_text())
assert R['suffix_exact_checks']>2000 and R['suffix_random_checks']>=2000
assert len(R['full_scan_rows'])>=40
# Stored interval metrics must recompute exactly from integer Q,W,L,q.
checks=0
for z in R['full_scan_rows']:
    q=3**z['r']
    for x in z['intervals']:
        bench=z['W']*x['L']/q
        assert abs(bench-x['benchmark'])<1e-9*max(1,bench)
        if x['Q']:
            ratio=x['Q']/bench
            D=math.log2(ratio)/z['r']
            assert abs(D-x['D'])<1e-12
        checks+=1
# Structured power-of-two candidates are primitive frequencies.
for z in R['full_scan_rows']:
    assert z['structured_power2_best']['xi']%3!=0
for z in NSTR:
    assert z['best']['xi']%3!=0
# Low threshold strictly improves tentative half threshold.
for b in (.8,1.0,1.2,1.35,1.45,1.52):
    assert b/ALPHA > b/(2*ALPHA)
# No stable positive D in the tested negative-offset extension.
d8=[next(x['D'] for x in z['intervals'] if x['b']==.8) for z in NEG]
assert min(d8)<0 and max(d8)>0
print('CP20 TASK 8B3 E1 VERIFIER')
print('stored interval metric checks:',checks)
print('suffix checks inherited from exact engine: PASS')
print('primitive structured-frequency checks: PASS')
print('low-conductor threshold repair: PASS')
print('negative-offset finite clustering is nonmonotone: PASS')
print('NO THEOREM PROMOTION: PASS')
print('ALL E1 VERIFIER ASSERTIONS: PASS')
