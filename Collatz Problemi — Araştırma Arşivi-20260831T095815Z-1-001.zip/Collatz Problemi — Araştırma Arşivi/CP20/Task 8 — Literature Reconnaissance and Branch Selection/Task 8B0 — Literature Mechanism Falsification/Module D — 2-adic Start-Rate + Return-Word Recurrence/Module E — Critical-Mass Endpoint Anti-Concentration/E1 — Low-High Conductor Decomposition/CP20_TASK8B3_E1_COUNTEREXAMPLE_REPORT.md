# CP20 TASK 8B3 — E1 COUNTEREXAMPLE / FALSIFICATION REPORT

## F1 — low conductors require their own exponential Fourier decay
`[FAIL]`.

Frozen E0 gives a fixed conductor-3 coefficient >=1/2, but exact Fourier-kernel summation shows all conductors t<=tau r are still negligible relative to a length 2^(br) interval whenever tau<b/alpha. Low-conductor decay is not required.

## F2 — tentative low-conductor threshold tau<b/(2 alpha)
`[FAIL — OVERLY CRUDE]`.

The conductor-wise Dirichlet-kernel L1 sum improves the sufficient threshold to tau<b/alpha.

## F3 — center mass d=0 is enough
`[FAIL AS A PROOF STRATEGY]`.

Finite high-conductor coefficients vary strongly across fixed O(1) mass offsets. Negative d is consistently the most adversarial family in the tested range. Any theorem must be uniform over the required mass band.

## F4 — fixed negative offset already gives an exponential clustering counterfamily
`[FAIL / NOT ESTABLISHED]`.

At b=0.8, d=-3 short-interval benchmark ratios were elevated at r=13..16, but by r=17 the ratio was below 1 and at r=18 about 1.24. The discrepancy rate does not show a stable positive limit in the tested range. No counterfamily is certified.

## F5 — current numerics establish the required high-conductor decay
`[FAIL]`.

All observed decay rates are finite numerics. No uniform asymptotic lower rate is proved.

## Surviving obstruction
For small b, the sufficient rate `alpha-b` is much larger than the worst finite negative-offset structured rates (~0.08-0.10 around r=13..18). This makes a simple uniform exponential theorem quantitatively demanding. Whether those rates increase asymptotically remains `[OPEN]`.
