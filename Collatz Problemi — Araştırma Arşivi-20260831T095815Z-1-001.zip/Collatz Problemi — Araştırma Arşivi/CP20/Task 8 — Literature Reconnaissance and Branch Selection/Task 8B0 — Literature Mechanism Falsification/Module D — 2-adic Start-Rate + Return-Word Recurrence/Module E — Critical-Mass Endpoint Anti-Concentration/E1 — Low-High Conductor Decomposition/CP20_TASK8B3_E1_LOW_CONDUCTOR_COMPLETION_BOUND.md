# CP20 TASK 8B3 — E1 LOW-CONDUCTOR COMPLETION BOUND

**Status:** `[EXACT — ELEMENTARY FOURIER COMPLETION BOUND]`

Let `q=3^r`, `I=[0,L)`, and let `mu` be the endpoint probability measure.
With

`hat_I(xi)=sum_(x=0)^(L-1) e_q(-xi x)`,

Fourier completion gives

`mu(I) = L/q + (1/q) sum_(xi != 0) hat_I(xi) phi(xi)`.

## Group by 3-adic conductor
At conductor `3^t`, write `xi=3^(r-t)u`, `3 not divide u`. Then

`hat_I(xi)=sum_(x=0)^(L-1) e_(3^t)(-u x)`.

Let `n=3^t` and `R=L mod n`. Complete periods cancel exactly, so this equals
the length-`R` geometric sum. Hence

`|hat_I| <= min(R, 1/(2 ||u/n||))`.

Summing over all primitive `u` and then enlarging to all nonzero `u mod n`,
pairing `u` with `n-u`, gives

`sum_(u primitive mod n) |hat_I(3^(r-t)u)| <= n(1+log n)`

(up to an immaterial absolute endpoint constant; the exponent is exact).
Thus the entire low-conductor block `t<=T` obeys

`E_low <= 3^(-r) * poly(T) * 3^T`.

If

`L = 2^(b r + o(r))`, `T=tau r+O(1)`,

then relative to the main term `L/3^r`,

`E_low / (L/3^r) <= 2^((alpha tau - b)r + o(r))`.

Therefore a strict sufficient condition for the entire low-conductor block
to be exponentially negligible is

`tau < b/alpha = b ln2 / ln3`.

This **repairs/refutes** the tentative threshold `b ln2/(2 ln3)`, which comes
from the cruder bound “number of frequencies times the maximum Fourier
kernel” and loses an unnecessary factor of `3^T`.

No decay of fixed-conductor `phi` is needed for this low-block estimate, so
it is fully compatible with the frozen E0 obstruction.

## Numerical thresholds
- b=0.80: tau < 0.504744
- b=1.00: tau < 0.630930
- b=1.20: tau < 0.757116
- b=1.35: tau < 0.851755
- b=1.45: tau < 0.914848
- b=1.52: tau < 0.959013
