# CP20 TASK 8B3 — E2 COUNTEREXAMPLE / FALSIFICATION REPORT

## F1 — E1 finite rate 0.08–0.10 is asymptotically representative

`[FAIL — NUMERICALLY FALSIFIED]`.

For \(d=-8,C=4\), the structured rate falls to about 0.003565 by \(r=2200\), with power-law-like scaling.

## F2 — negative offsets only change a constant inside a common positive exponential rate

`[FAIL AS A FINITE MODEL]`.

Across \(d=-8,\ldots,+8\), fixed-offset families show strongly decreasing base-2 rates. Negative offsets remain quantitatively most adversarial, but the tested behavior does not support a stable positive rate.

## F3 — the structured family supports the simple uniform high-conductor theorem needed by E1

`[FAIL AS CURRENT NUMERIC EVIDENCE]`.

The structured family is primitive/full-conductor, yet its observed \(\gamma_r\) decreases toward zero on the tested range.

## F4 — polynomial/subexponential resonance is proved

`[FAIL — NOT PROVED]`.

The \(r^{-1}\) fit is strong but finite. No infinite-subsequence polynomial lower bound or exact asymptotic theorem was established.

## F5 — continued-fraction denominators alone prove the obstruction

`[FAIL]`.

The tested convergent denominators show the same broad \(1/r\)-scale behavior but no exact lower-bound mechanism.

## Surviving lead

`[LEAD]`: derive a rigorous critical-bridge asymptotic for the exact surplus recursion. The preferred target is either

\[
|F_{r,\lfloor\alpha r\rfloor+d,C}|\ge r^{-K(d,C)}
\]

on an infinite subsequence, or the sharper form

\[
rF_{r,\lfloor\alpha r\rfloor+d,C}
=K_{d,C}(\{\alpha r\})+o(1)
\]

with nonzero amplitude on an infinite phase subsequence.
