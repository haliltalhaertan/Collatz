# CP20 TASK 8B3 — E2 ASYMPTOTIC FALSIFICATION REPORT

**Status:** exact recursion/enumeration checks `[CERTIFIED NUM]`; floating and high-precision magnitudes `[NUM]`.

## Search domain

- critical offsets \(d=-8,\ldots,+8\);
- fixed \(C=-8,\ldots,+12\) through \(r=800\);
- targeted adversarial \(C=2,\ldots,8\) through \(r=2200\);
- the broad run includes the previously observed fixed values \(C=0,1,2,4,5,7,10\);
- direct enumeration independently checks the reduced recursion at small depth;
- an 80-decimal-place implementation independently checks \(d=-8,C=4\) at \(r=100,200,400,600\).

## Hexp falsification attempt

Define

\[
\gamma_r(d,C):=-\frac1r\log_2\left|F_{r,\lfloor\alpha r\rfloor+d,C}\right|.
\]

A stable positive exponential rate would require \(\gamma_r\) to stay bounded away from zero.

The long run does the opposite. At \(r=2200\):

- \(d=-8,C=7\): \(|F|\approx0.004414572232\), \(\gamma_r\approx0.003556141198\);
- \(d=-8,C=4\): \(|F|\approx0.004355076867\), \(\gamma_r\approx0.003565039137\).

For \(d=-8,C=4\):

| r | \(|F|\) | \(\gamma_r\) | \(r|F|\) |
|---:|---:|---:|---:|
| 100 | 0.1132088484 | 0.0314294137 | 11.32088484 |
| 200 | 0.05482726760 | 0.0209448131 | 10.96545352 |
| 400 | 0.02569101261 | 0.0132064811 | 10.27640504 |
| 800 | 0.01235885782 | 0.0079228885 | 9.88708626 |
| 1200 | 0.008118208387 | 0.0057871858 | 9.74185006 |
| 1600 | 0.006037516273 | 0.0046073932 | 9.66002604 |
| 2000 | 0.004801961666 | 0.0038510802 | 9.60392333 |
| 2200 | 0.004355076867 | 0.0035650391 | 9.58116911 |

On \(r=1600,\ldots,2200\):

- exponential fit gives only \(\delta\approx0.0007759\);
- power-law fit gives \(|F|\approx r^{-K}\) with \(K\approx1.0169\).

For \(d=-8,C=7\), the same window gives \(K\approx0.98995\).

The quantity \(r|F|\) is nearly constant. For \(d=-8,C=4\) and \(r\ge1600\), it stays numerically between about 8.54 and 9.72, with mean about 9.12.

This is strong evidence for a \(1/r\)-scale structured resonance, but it is **not a theorem**.

## High-precision cross-check

An independent 80-digit implementation gives:

- \(r=100\): \(|F|=0.1132088484358358689711068289702632640727\)
- \(r=200\): \(|F|=0.05482726760013723324840380262203405533616\)
- \(r=400\): \(|F|=0.02569101260618257254315189441560111942686\)
- \(r=600\): \(|F|=0.01670304394605581364990901668717077031171\)

These agree with the complex128 engine to machine precision at those depths. The polynomial-size coefficients are not a floating-point cancellation-floor artifact.

## Arithmetic-subsequence search

For \(d=-8,C=4\), continued-fraction denominator depths of \(\alpha=\log_2 3\) include

\[
41,53,306,665,\ldots
\]

with \(r|F|\) approximately

\[
12.38,11.41,10.51,8.81.
\]

They do not yield a separate growing resonance subsequence in the tested range.

Local maxima of \(r|F|\) repeatedly occur when \(\{\alpha r\}\) is near 1. This is a `[LEAD]` for a quasiperiodic \(r^{-1}\) amplitude profile, not an exact mechanism yet.

## Competing hypotheses

- **Hexp:** numerically loses support; the observed local rate falls by more than an order of magnitude relative to the early E1 regime.
- **Hsub:** strongly survives; power-law exponents near 1 are stable across several adversarial fixed \(d,C\) pairs.
- stretched-exponential fits are not distinguishable from the cleaner power-law behavior on the available range.

## Theorem attempts

### Positive-rate theorem

`[FAIL — NO PROOF / NUMERICALLY DISFAVORED]`.

No uniform phase-separation inequality was found that yields a fixed contraction. Every fixed positive decay-rate candidate suggested by shallow numerics is undercut by the longer structured-family computation.

### Counter-obstruction theorem

`[OPEN]`.

The data suggest

\[
F_{r,\lfloor\alpha r\rfloor+d,C}
=
\frac{K_{d,C}(\{\alpha r\})+o(1)}{r}
\]

for fixed \(d,C\), with nontrivial quasiperiodic amplitude. No rigorous infinite-subsequence lower bound \(|F|\ge r^{-K}\) was obtained. Therefore the result remains `[CONJ]/[LEAD]`, not a theorem.
