#!/usr/bin/env python3
from pathlib import Path
import argparse, math, cmath, json, itertools
import numpy as np

HERE=Path(__file__).resolve().parent
ALPHA=math.log2(3.0)

def compositions(A,r):
    if r==1:
        yield (A,); return
    for cuts in itertools.combinations(range(1,A),r-1):
        p=0;w=[]
        for c in cuts:
            w.append(c-p);p=c
        w.append(A-p);yield tuple(w)

def endpoint(w):
    A=0;B=0
    for a in w:
        B=3*B+(1<<A);A+=a
    q=3**len(w)
    return B*pow(2,-A,q)%q

def brute_F(r,A,C):
    q=3**r;xi=pow(2,A-C,q);s=0j;n=0
    for w in compositions(A,r):
        M=endpoint(w)
        s+=cmath.exp(2j*math.pi*((xi*M)%q)/q);n+=1
    return s/n

def run(rmax=800,dmin=-8,dmax=8,cmin=-8,cmax=12):
    Cs=list(range(cmin,cmax+1));nc=len(Cs)
    nmax=math.floor((ALPHA-1)*rmax)+dmax+5
    prev=np.empty((nc,nmax+1),dtype=np.complex128)
    for i,C in enumerate(Cs):
        prev[i,:]=cmath.exp(2j*math.pi*pow(2,-C,3)/3)
    vals=[];validation=[]
    for r in range(2,rmax+1):
        q=3**r;cur=np.empty_like(prev);res=[pow(2,r-1-C,q) for C in Cs]
        for n in range(nmax+1):
            ph=np.fromiter((cmath.exp(2j*math.pi*(z/q)) for z in res),np.complex128,count=nc)
            den=r+n-1
            if n==0:
                cur[:,0]=ph*prev[:,0]
            else:
                cur[:,n]=(n/den)*cur[:,n-1]+((r-1)/den)*ph*prev[:,n]
            res=[(2*z)%q for z in res]
        if r<=7:
            for d in range(-2,3):
                A=math.floor(ALPHA*r)+d
                if A<r: continue
                n=A-r
                for C in [x for x in (-2,0,2,4) if x in Cs]:
                    err=abs(cur[Cs.index(C),n]-brute_F(r,A,C));validation.append(err)
                    assert err<2e-11
        if r>=20:
            base=math.floor(ALPHA*r)
            for d in range(dmin,dmax+1):
                A=base+d
                if A<r: continue
                n=A-r
                for i,C in enumerate(Cs):
                    mag=abs(cur[i,n])
                    vals.append({'r':r,'d':d,'C':C,'mag':mag,
                                 'rate':-math.log2(max(mag,1e-300))/r})
        prev=cur
    out={'alpha':ALPHA,'rmax':rmax,'d_range':[dmin,dmax],'C_range':[cmin,cmax],
         'validation_max_error':max(validation) if validation else None,'records':vals}
    (HERE/'CP20_TASK8B3_E2_ENGINE_OUTPUT.json').write_text(
        json.dumps(out,indent=2,sort_keys=True),encoding='utf-8')
    print('validation max error:',max(validation) if validation else None)
    print('records:',len(vals))
    print('ALL E2 ENGINE ASSERTIONS: PASS')

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--rmax',type=int,default=800)
    ap.add_argument('--dmin',type=int,default=-8)
    ap.add_argument('--dmax',type=int,default=8)
    ap.add_argument('--cmin',type=int,default=-8)
    ap.add_argument('--cmax',type=int,default=12)
    a=ap.parse_args();run(a.rmax,a.dmin,a.dmax,a.cmin,a.cmax)
