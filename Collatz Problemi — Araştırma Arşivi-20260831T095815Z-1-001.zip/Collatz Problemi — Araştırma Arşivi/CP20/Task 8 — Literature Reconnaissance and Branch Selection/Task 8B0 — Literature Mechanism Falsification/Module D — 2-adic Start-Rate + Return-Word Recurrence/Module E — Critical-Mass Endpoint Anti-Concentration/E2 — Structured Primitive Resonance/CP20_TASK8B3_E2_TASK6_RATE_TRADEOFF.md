# CP20 TASK 8B3 — E2 TASK 6 RATE TRADE-OFF

**Status:** `[EXACT DIAGNOSTIC]` algebra; use of unconstrained fixed-mass entropy is a conservative sufficient diagnostic, not the final Task8A/type-aware rate theorem.

Let

\[
\alpha=1.584962500721156,\qquad
h_*=1.5056438879463006,
\]

so

\[
\Delta=\alpha-h_*=0.07931861277485552.
\]

Take a Task-6 factor window \(N=2^{cr}\). If the endpoint state scale is \(N^\kappa\), then

\[
b=\kappa c.
\]

A uniform fixed-mass endpoint anti-concentration estimate at interval exponent \(b\) gives the diagnostic upper exponent

\[
h_*+b-\alpha.
\]

To beat the Task-6 required factor exponent \(c=b/\kappa\), it suffices that

\[
h_*+b-\alpha<\frac b\kappa.
\]

Equivalently,

\[
\boxed{
b<\frac{\kappa\Delta}{\kappa-1}.
}
\]

This is an upper ceiling on admissible \(b\). Since E1 requires high-conductor Fourier decay stronger than

\[
\delta>\alpha-b,
\]

the easiest Fourier target chooses \(b\) as large as possible below

\[
b_*(\kappa)=\min\left(\alpha,\frac{\kappa\Delta}{\kappa-1}\right).
\]

Thus the infimum required decay rate is

\[
\boxed{
\delta_*(\kappa)=\max(0,\alpha-b_*(\kappa)).
}
\]

| \(\kappa\) | contradiction ceiling for \(b\) | best diagnostic \(c=b/\kappa\) | infimum required \(\delta\) |
|---:|---:|---:|---:|
| 1.053 | 1.575896212 | 1.496577600 | 0.009066288 |
| 1.100 | 0.872504741 | 0.793186128 | 0.712457760 |
| 1.200 | 0.475911677 | 0.396593064 | 1.109050824 |
| 1.500 | 0.237955838 | 0.158637226 | 1.347006662 |
| 2.000 | 0.158637226 | 0.079318613 | 1.426325275 |
| 2.500 | 0.132197688 | 0.052879075 | 1.452764813 |
| 2.784 | 0.123779719 | 0.044461106 | 1.461182782 |

The crossover where this unconstrained diagnostic first demands a positive \(\delta\) is

\[
\kappa>\alpha/h_*\approx1.052683\ldots
\]

so \(\kappa=1.053\) is barely on the demanding side and already requires

\[
\delta>0.009066288\ldots
\]

At \(r=2200\), the worst targeted structured-family rate is only about \(0.003556\), and the observed rate continues downward. It is already below even the \(\kappa=1.053\) sufficient demand and is far below the demands for \(\kappa\ge1.1\).

This comparison is `[NUM]`, not a theorem-level contradiction, because asymptotic subexponential decay has not been proved.

## Task8A/type caveat

A smaller type-constrained word exponent \(h_{\rm eff}<h_*\) would increase \(\Delta_{\rm eff}=\alpha-h_{\rm eff}\), raise the admissible \(b\) ceiling, and reduce the Fourier rate demanded by E1. Therefore the table is conservative and can be improved only by rigorously importing Task8A/type information.
