# CP20 TASK 8B3 — E2 STRUCTURED PRIMITIVE RECURSION

**Status:** `[EXACT]` for the algebraic reductions below.

Define

\[
F_{r,A,C}:=\phi_{r,A}(2^{A-C}),\qquad C\in\mathbb Z\text{ fixed}.
\]

For a word of total mass \(A\),

\[
M_r\equiv 2^{-A}B_r\pmod{3^r},
\]

so the structured phase has the exact cancellation

\[
2^{A-C}M_r\equiv2^{-C}B_r\pmod{3^r}.
\]

Thus

\[
\boxed{F_{r,A,C}=\mathbb E_{W_{r,A}} e_{3^r}(2^{-C}B_r).}
\]

The explicit phase functional no longer contains \(A\); total mass remains only in the conditioned composition law.

## Last-part recursion

Condition on \(m=a_{r-1}\). Using

\[
M_r\equiv2^{-m}(3M_{r-1}+1)\pmod{3^r},
\]

the child frequency is

\[
2^{A-C}2^{-m}=2^{A-m-C},
\]

which is again in the same structured family. Hence

\[
\boxed{
F_{r,A,C}
=
\sum_{m=1}^{A-r+1}p_{r,A}(m)
\,e_{3^r}(2^{A-m-C})
F_{r-1,A-m,C}.
}
\]

This proves exact invariance of the family under the conditioned recursion.

## Surplus reduction

Set

\[
n=A-r\ge0,
\]

and write

\[
G_{r,n,C}:=F_{r,r+n,C}.
\]

Let

\[
N_{r,n,C}:=\binom{r+n-1}{r-1}G_{r,n,C}
\]

be the unnormalized structured sum. Writing \(k=n-(m-1)\), the last-part recursion becomes

\[
\boxed{
N_{r,n,C}
=
\sum_{k=0}^{n}e_{3^r}(2^{r+k-1-C})N_{r-1,k,C}.
}
\]

Using the hockey-stick identity

\[
\binom{r+n-1}{r-1}=\sum_{k=0}^{n}\binom{r+k-2}{r-2},
\]

one obtains the first-order normalized recursion

\[
\boxed{
G_{r,n,C}
=
\frac{n}{r+n-1}G_{r,n-1,C}
+
\frac{r-1}{r+n-1}
 e_{3^r}(2^{r+n-1-C})G_{r-1,n,C}.
}
\]

For \(n=0\), the first term is absent.

Base case:

\[
\boxed{G_{1,n,C}=e_3(2^{-C})}
\]

for every \(n\ge0\).

The reduced recursion was checked against direct enumeration for 112 small \((r,A,C)\) cases; the maximum complex discrepancy was below \(1.4\times10^{-15}\).

## Classification

`[EXACT — STRUCTURAL REDUCTION]`.

This is a direct consequence of the accepted conditioned recursion plus a binomial cumulative identity. It does not by itself decide exponential versus subexponential decay, so it does not trigger the load-bearing theorem stop rule.
