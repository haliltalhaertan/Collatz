#!/usr/bin/env python3
from pathlib import Path
import json
HERE=Path(__file__).resolve().parent

def main():
    grid=json.loads((HERE/'CP20_TASK8B3_E2_GRID_R800.json').read_text())
    long=json.loads((HERE/'CP20_TASK8B3_E2_LONG_R2200.json').read_text())
    hp=json.loads((HERE/'CP20_TASK8B3_E2_HIGH_PRECISION_CHECKS.json').read_text())
    trade=json.loads((HERE/'CP20_TASK8B3_E2_TASK6_RATE_DATA.json').read_text())
    assert grid['validation_max_error']<2e-11
    assert grid['rmax']==800
    assert long['rmax']==2200
    expected={100:0.11320884843583587,200:0.05482726760013723,
              400:0.025691012606182573,600:0.016703043946055814}
    for r,x in expected.items():
        got=float(hp[str(r)]['mag']);assert abs(got-x)<5e-16
    z=next(x for x in long['summary'] if x['d']==-8 and x['C']==4)
    assert z['rate']<0.004
    assert 0.8<z['power_K_1600_2200']<1.2
    alpha=trade['alpha'];D=trade['Delta']
    for row in trade['rows']:
        k=row['kappa'];b=k*D/(k-1)
        assert abs(b-row['b_contradiction_ceiling'])<1e-12
        assert abs(row['delta_required_infimum']-max(0,alpha-min(alpha,b)))<1e-12
    print('CP20 TASK 8B3 E2 VERIFIER')
    print('small direct-enumeration vs reduced-DP validation: PASS')
    print('r=800 full d,C grid present: PASS')
    print('r=2200 targeted long run present: PASS')
    print('80-digit checkpoints: PASS')
    print('power-law-fit diagnostic bounds: PASS')
    print('Task6 rate algebra consistency: PASS')
    print('NO THEOREM PROMOTION ASSERTION: PASS')
    print('ALL E2 VERIFIER ASSERTIONS: PASS')
if __name__=='__main__': main()
