# CP20 TASK 8B2 — D0 RATE-STABILIZATION DICHOTOMY THEOREM

**Date:** 2026-08-26  
**Status:** `[AUDIT CANDIDATE]`  
**Branch:** Module D / Pure 2-adic Start-Rate  
**Stop rule:** triggered; D1–D5 not executed.

## 1. Setting

Let
\[
a_k\ge1,
\qquad
A_k=\sum_{j<k}a_j,
\]
and
\[
B_0=0,\qquad B_{k+1}=3B_k+2^{A_k}.
\]

Define
\[
\alpha=\log_2 3,\qquad
F_k=\lfloor\alpha k\rfloor,\qquad
s_k=F_k-A_k.
\]

Assume the global critical-log law
\[
\boxed{
s_k=\kappa\log_2k+O(1),
\qquad
\kappa>1.
}
\]

For \(k\ge1\), let
\[
r_k\equiv-3^{-k}B_k\pmod{2^{A_k}},
\qquad
0\le r_k<2^{A_k},
\]
be Kramer's canonical least nonnegative start representative, and
\[
\boxed{
\rho_r(k)=\frac{\ln(1+r_k)}{k}.
}
\]

Let
\[
R_k\in[0,2^{A_k+1})
\]
be the canonical exact valuation-cylinder representative modulo
\(2^{A_k+1}\). Then
\[
\boxed{
R_k\in\{r_k,\ r_k+2^{A_k}\}.
}
\]

Frozen CP18 Task 10 gives:
for a nested infinite valuation word, one fixed positive odd integer realizes
the entire word exactly iff the exact-cylinder representatives \(R_k\) are
eventually constant.

The theorem below strengthens the usable interface by connecting that exact
LEVEL-3 criterion to Kramer's rate.

---

# 2. Kramer residue nesting

For \(v>u\),
\[
B_v
=
3^{v-u}B_u
+
\sum_{i=u}^{v-1}3^{v-1-i}2^{A_i}.
\]

Because \(A_i\ge A_u\) for \(i\ge u\),
\[
\boxed{
B_v\equiv3^{v-u}B_u\pmod{2^{A_u}}.
}
\]

The terminal congruence at depth \(v\) is
\[
3^vr_v+B_v\equiv0\pmod{2^{A_v}},
\]
hence also modulo \(2^{A_u}\). Substituting the previous relation,
\[
3^{v-u}(3^ur_v+B_u)\equiv0\pmod{2^{A_u}}.
\]

Since powers of \(3\) are invertible modulo powers of \(2\),
\[
3^ur_v+B_u\equiv0\pmod{2^{A_u}}.
\]

By uniqueness of the canonical residue class at depth \(u\),
\[
\boxed{
r_v\equiv r_u\pmod{2^{A_u}}.
}
\]

This is exact for every positive exponent word.

---

# 3. Injury jump lemma

Call \(k\) an adjacent injury time if
\[
r_{k+1}\ne r_k.
\]

Compatibility gives
\[
r_{k+1}=r_k+m_k2^{A_k}
\]
for some integer \(m_k\).

Since
\[
0\le r_k<2^{A_k},
\qquad
r_{k+1}\ge0,
\]
a negative \(m_k\) is impossible. Thus
\[
m_k\ge0.
\]

At an injury, \(m_k\ne0\), so
\[
\boxed{
m_k\ge1
}
\]
and
\[
\boxed{
r_{k+1}\ge2^{A_k}.
}
\]

More generally, if \(v>u\) and \(r_v\ne r_u\), then
\[
\boxed{
r_v=r_u+m\,2^{A_u},
\qquad
m\ge1,
}
\]
hence
\[
\boxed{
r_v\ge2^{A_u}.
}
\]

---

# 4. Critical-log injury spikes

At an adjacent injury,
\[
\rho_r(k+1)
=
\frac{\ln(1+r_{k+1})}{k+1}
\ge
\frac{A_k\ln2}{k+1}.
\]

Under critical-log,
\[
A_k
=
\alpha k-\kappa\log_2k+O(1),
\]
so
\[
A_k\ln2
=
k\ln3-\kappa\ln k+O(1).
\]

Therefore every adjacent injury satisfies
\[
\boxed{
\rho_r(k+1)
\ge
\ln3-O\!\left(\frac{\log k}{k}\right).
}
\]

There is also a global sharp one-sided ceiling. Since
\[
r_k\le2^{A_k}-1,
\]
\[
1+r_k\le2^{A_k},
\]
and hence
\[
\boxed{
\rho_r(k)
\le
\frac{A_k\ln2}{k}
=
\ln3-\frac{\kappa\ln k}{k}+O(1/k).
}
\]

Thus
\[
\boxed{
\limsup_{k\to\infty}\rho_r(k)\le\ln3.
}
\]

If injuries occur infinitely often, the injury subsequence gives the reverse
lower bound, hence
\[
\boxed{
\text{infinitely many injuries}
\Longrightarrow
\limsup_{k\to\infty}\rho_r(k)=\ln3.
}
\]

---

# 5. Strict-subceiling stabilization

Suppose
\[
\limsup_{k\to\infty}\rho_r(k)<\ln3.
\]

If infinitely many injuries occurred, the previous section would force
\[
\limsup\rho_r=\ln3,
\]
a contradiction.

Therefore there are only finitely many injuries, and hence
\[
\boxed{
r_k=r_*>0
}
\]
for all sufficiently large \(k\).

The special case
\[
\rho_r(k)\to0
\]
therefore implies eventual constancy.

Conversely, if
\[
r_k=r_*
\]
eventually, then
\[
\rho_r(k)
=
\frac{\ln(1+r_*)}{k}
\to0.
\]

Thus
\[
\boxed{
r_k\text{ eventually constant}
\iff
\rho_r(k)\to0
}
\]
inside critical-log.

---

# 6. Kramer stabilization implies exact-cylinder stabilization

This is the one-bit lift step.

Assume
\[
r_k=r_*
\qquad(k\ge K).
\]

For each such \(k\),
\[
R_k\in\{r_*,r_*+2^{A_k}\}.
\]

Fix any \(k\ge K\) and choose \(j=k+1\). Since \(a_k\ge1\),
\[
A_j\ge A_k+1.
\]

Because exact valuation cylinders are nested,
\[
\boxed{
R_j\equiv R_k\pmod{2^{A_k+1}}.
}
\]

But
\[
R_j\in\{r_*,r_*+2^{A_j}\},
\]
and \(2^{A_j}\) is divisible by \(2^{A_k+1}\). Therefore
\[
R_j\equiv r_*\pmod{2^{A_k+1}}.
\]

Hence
\[
R_k\equiv r_*\pmod{2^{A_k+1}}.
\]

The two possible lifts at depth \(k\) differ by exactly \(2^{A_k}\), which is
not zero modulo \(2^{A_k+1}\). Therefore the upper lift is impossible:
\[
\boxed{
R_k=r_*
}
\]
for every \(k\ge K\).

Thus the exact-cylinder representatives themselves are eventually constant.

Since \(r_k\) is odd and nonzero for every \(k\ge1\),
\[
r_*\in\mathbb Z_{>0}
\]
is a positive odd integer.

By the frozen CP18 exact-cylinder criterion—or directly from nested cylinder
containment—
\[
\boxed{
n_0=r_*
}
\]
realizes the entire infinite valuation word exactly.

Therefore
\[
\boxed{
r_k\text{ eventually constant}
\Longrightarrow
\text{positive ordinary LEVEL-3 realizer exists}.
}
\]

---

# 7. Positive LEVEL-3 realizer implies Kramer stabilization

Conversely, suppose one fixed positive odd integer \(n_0\) realizes the entire
infinite valuation word.

For every \(k\),
\[
n_0\equiv r_k\pmod{2^{A_k}}.
\]

Since \(a_j\ge1\),
\[
A_k\ge k\to\infty.
\]

Thus
\[
2^{A_k}>n_0
\]
for all sufficiently large \(k\).

Because \(r_k\) is the least nonnegative representative,
\[
\boxed{
r_k=n_0
}
\]
eventually.

Hence
\[
\boxed{
\text{positive ordinary LEVEL-3 realizer exists}
\Longrightarrow
r_k\text{ eventually constant}
}
\]
and therefore
\[
\rho_r(k)\to0.
\]

---

# 8. Exact critical-log dichotomy

Combining the previous sections:

\[
\boxed{
\begin{aligned}
&\text{positive ordinary LEVEL-3 realizer exists}\\
\iff\;&r_k\text{ eventually stabilizes}\\
\iff\;&\rho_r(k)\to0\\
\iff\;&\limsup_{k\to\infty}\rho_r(k)<\ln3.
\end{aligned}
}
\]

Equivalently, the complementary branch is

\[
\boxed{
\text{no positive ordinary LEVEL-3 realizer}
\Longrightarrow
\limsup_{k\to\infty}\rho_r(k)=\ln3.
}
\]

Indeed, absence of a positive LEVEL-3 realizer implies \(r_k\) is not
eventually constant, hence adjacent injuries occur infinitely often, and the
injury spike theorem applies.

This is a true dichotomy for the global critical-log class.

---

# 9. The unresolved oscillatory case

The theorem controls the limsup, not the liminf.

The still-open regime is
\[
\boxed{
\liminf_{k\to\infty}\rho_r(k)=0,
\qquad
\limsup_{k\to\infty}\rho_r(k)=\ln3,
}
\]
with infinitely many sparse injuries.

Such a branch would repeatedly return to subexponential canonical starts but
suffer full-ceiling injury spikes forever.

D0 does not exclude this regime.

---

# 10. Scope: critical-log is load-bearing

The equivalence with the strict threshold \(\ln3\) is false without
critical-log.

### All-ones word

For
\[
a_k=1\quad\forall k,
\]
\[
A_k=k,
\qquad
B_k=3^k-2^k,
\]
and
\[
\boxed{
r_k=2^k-1.
}
\]

Thus
\[
\boxed{
\rho_r(k)\to\ln2<\ln3.
}
\]

But the exact cylinders have canonical representatives
\[
\boxed{
R_k=2^{k+1}-1,
}
\]
which converge 2-adically to \(-1\), not to a positive ordinary integer.

The discrepancy is linear:
\[
s_k=(\alpha-1)k+O(1),
\]
not critical-log.

### Alternating word

For
\[
(1,2)^\infty,
\]
at even depths \(k=2m\),
\[
A_{2m}=3m,
\]
and frozen CP18 gives
\[
R_{2m}=2^{3m+1}-5.
\]

Therefore
\[
\boxed{
r_{2m}=2^{3m}-5
}
\]
and
\[
\boxed{
\rho_r(2m)\to\frac32\ln2<\ln3.
}
\]

Again there is no positive LEVEL-3 realizer and the discrepancy is linear,
not logarithmic.

These examples show that critical-log is essential for the
strict-subceiling \(\Rightarrow\) realization implication.

---

# 11. Novelty / redundancy classification

Frozen CP18 Task 10 already proves the exact LEVEL-2/LEVEL-3 statement:
the unique 2-adic realizer is a positive ordinary integer iff the canonical
**exact-cylinder** representatives \(R_k\) are eventually constant.

It also identifies injury/nonzero-lift activity as the unresolved global
coherence issue.

Kramer's 2026 paper proves the one-way necessary condition:
a fixed positive ordinary realizer implies
\[
r_k=n_0
\]
eventually and therefore
\[
\rho_r(k)\to0.
\]

What is not explicit in those sources is the full critical-log equivalence:
\[
\limsup\rho_r<\ln3
\iff
\rho_r\to0
\iff
r_k\text{ stabilizes}
\iff
R_k\text{ stabilizes}
\iff
\text{positive LEVEL-3 realizer}.
\]

Thus this should not be marketed as a new foundational 2-adic compactness
principle. It is a load-bearing synthesis/corollary obtained by combining:

1. exact Kramer-residue nesting;
2. the critical-log ceiling \(A_k\ln2/k\to\ln3\);
3. the one-bit lift from \(r_k\) to the exact cylinders \(R_k\);
4. frozen CP18 eventual exact-cylinder stabilization.

Its research value is architectural: it identifies the only remaining
2-adic escape regime as the oscillatory
\[
\liminf\rho_r=0,\quad\limsup\rho_r=\ln3
\]
branch.

---

# 12. Classification

\[
\boxed{
\texttt{[AUDIT CANDIDATE]}
}
\]

This theorem is load-bearing for all future Module-D work.

D1–D5 must remain stopped until independent zero-trust audit.
