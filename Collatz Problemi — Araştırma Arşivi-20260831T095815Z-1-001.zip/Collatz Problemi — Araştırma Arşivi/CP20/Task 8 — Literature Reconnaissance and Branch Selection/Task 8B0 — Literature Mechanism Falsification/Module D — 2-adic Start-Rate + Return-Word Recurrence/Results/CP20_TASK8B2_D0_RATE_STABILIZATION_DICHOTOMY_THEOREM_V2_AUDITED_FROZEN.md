# CP20 TASK 8B2 — D0 RATE-STABILIZATION DICHOTOMY THEOREM V2

**Date:** 2026-08-27

## Canonical status ledger

### Audited core
`[PROVED][INDEPENDENTLY AUDITED][POST-AUDIT REPAIRED][FROZEN]`

### General ceiling-limit extension
`[PROVED — POST-AUDIT STRENGTHENING][NOT INDEPENDENTLY AUDITED]`

### Novelty classification
`[PROVED SYNTHESIS / RATE FORMULATION]`

The basic inverse-limit/cylinder mechanism is elementary 2-adic algebra and
is close to frozen CP18 Task 6 / Task 10. The useful architectural content is
the Kramer-rate formulation, injury threshold, and the critical-log ceiling
dichotomy.

# I. General stabilization theorem — only \(a_k\ge1\)

Let
\[
a_k\in\mathbb Z_{\ge1},\qquad A_k=\sum_{j<k}a_j,
\]
and
\[
B_0=0,\qquad B_{k+1}=3B_k+2^{A_k}.
\]

For \(k\ge1\), define
\[
r_k\equiv-3^{-k}B_k\pmod{2^{A_k}},
\qquad 0\le r_k<2^{A_k},
\]
and
\[
\rho_r(k)=\frac{\ln(1+r_k)}k.
\]
Set \(r_0=0\).

## Nested Kramer residues

For \(v>u\),
\[
B_v=3^{v-u}B_u+\sum_{i=u}^{v-1}3^{v-1-i}2^{A_i}.
\]
Since \(A_i\ge A_u\),
\[
B_v\equiv3^{v-u}B_u\pmod{2^{A_u}}.
\]
Using the depth-\(v\) residue congruence and invertibility of powers of \(3\),
\[
\boxed{r_v\equiv r_u\pmod{2^{A_u}}.}
\]

## Injury jump

If \(r_{k+1}\ne r_k\), then
\[
r_{k+1}=r_k+m_k2^{A_k}
\]
with \(m_k\ge1\). Hence
\[
\boxed{r_{k+1}\ge2^{A_k}\ge2^k.}
\]

More generally, if \(v>u\) and \(r_v\ne r_u\), then
\[
r_v=r_u+m2^{A_u},\qquad m\ge1.
\]

## Exact-cylinder lift

Let \(R_k\in[0,2^{A_k+1})\) be the canonical exact valuation-cylinder
representative. Then
\[
R_k\in\{r_k,r_k+2^{A_k}\}.
\]

Exact cylinders are nested:
\[
R_v\equiv R_u\pmod{2^{A_u+1}}\qquad(v>u).
\]

Assume \(r_k=r_*\) for all \(k\ge K\). Fix \(k\ge K\) and take \(v=k+1\).
Since \(a_k\ge1\), \(A_v\ge A_k+1\). Both possible values of \(R_v\) reduce
to \(r_*\) modulo \(2^{A_k+1}\). Thus
\[
R_k\equiv r_*\pmod{2^{A_k+1}}.
\]
The upper lift \(r_*+2^{A_k}\) is not congruent to \(r_*\) modulo
\(2^{A_k+1}\), so
\[
\boxed{R_k=r_*}
\]
for every \(k\ge K\).

Conversely, if one positive odd \(n_0\) realizes the entire infinite word,
then
\[
n_0\equiv r_k\pmod{2^{A_k}}
\]
for all \(k\). Since \(A_k\ge k\to\infty\), eventually \(2^{A_k}>n_0\), so
\[
\boxed{r_k=n_0}
\]
eventually.

Using frozen CP18 exact-cylinder stabilization:
\[
\boxed{
\text{positive ordinary LEVEL-3 realizer exists}
\iff
r_k\text{ is eventually constant}.
}
\]

## General rate/stabilization equivalence

If injuries occur infinitely often, then at each injury \(k\),
\[
\rho_r(k+1)\ge \frac{A_k\ln2}{k+1}\ge\frac{k\ln2}{k+1}.
\]
Therefore \(\rho_r(k)\to0\) is impossible.

Conversely, eventual constancy gives
\[
\rho_r(k)=\ln(1+r_*)/k\to0.
\]

Hence under only \(a_k\ge1\),
\[
\boxed{
\text{positive ordinary LEVEL-3 realizer exists}
\iff
r_k\text{ eventually stabilizes}
\iff
\rho_r(k)\to0.
}
\]

# II. General ceiling-limit theorem

**Status:** `[PROVED — POST-AUDIT STRENGTHENING][NOT INDEPENDENTLY AUDITED]`

For every \(k\),
\[
\boxed{\rho_r(k)\le \frac{A_k\ln2}{k}.}
\]
At every injury \(k\),
\[
\boxed{\rho_r(k+1)\ge \frac{A_k\ln2}{k+1}.}
\]

Assume
\[
L=\lim_{k\to\infty}\frac{A_k\ln2}{k}
\]
exists.

If injuries occur infinitely often and \(L<\infty\), then the injury lower
bound tends to \(L\) while the global ceiling has limsup at most \(L\):
\[
\boxed{\limsup\rho_r=L.}
\]

If \(L=+\infty\), the injury subsequence tends to \(+\infty\), hence
\[
\boxed{\limsup\rho_r=+\infty.}
\]

For finite \(L>0\),
\[
\boxed{
\text{positive LEVEL-3 realizer}
\iff
r_k\text{ stabilizes}
\iff
\rho_r(k)\to0
\iff
\limsup\rho_r(k)<L.
}
\]

No analogous claim is made when the limit \(L\) does not exist.

# III. Critical-log sharpening

Assume
\[
s_k=\kappa\log_2k+O(1),\qquad \kappa>1,
\]
with
\[
A_k=\lfloor(\log_2 3)k\rfloor-s_k.
\]

Then
\[
A_k\ln2=k\ln3-\kappa\ln k+O(1),
\]
so
\[
\boxed{A_k\ln2/k\to\ln3.}
\]

The audited critical-log dichotomy is
\[
\boxed{
\text{positive ordinary LEVEL-3 realizer}
\iff
r_k\text{ stabilizes}
\iff
\rho_r(k)\to0
\iff
\limsup\rho_r(k)<\ln3.
}
\]

Equivalently,
\[
\boxed{
\text{no positive ordinary LEVEL-3 realizer}
\iff
\text{infinitely many injuries}
\iff
\limsup\rho_r(k)=\ln3.
}
\]

# IV. Liminf wording repair

D0 alone does not force
\[
\liminf\rho_r=0.
\]

A branch with
\[
\liminf\rho_r>0,\qquad \limsup\rho_r=\ln3
\]
is compatible with D0 itself.

Only after adding Kramer's positive-liminf obstruction as an independent
downstream condition does the hard branch become
\[
\boxed{
\liminf\rho_r=0,\qquad
\limsup\rho_r=\ln3,\qquad
\text{infinitely many injuries}.
}
\]

# V. Scope

No positive lower bound for \(\rho_r\) is proved.

No ordinary-realizer exclusion is proved.

No Collatz solution is claimed.

No 3-adic endpoint rate, Task-8A pressure, or CP19 parked branch is used.
