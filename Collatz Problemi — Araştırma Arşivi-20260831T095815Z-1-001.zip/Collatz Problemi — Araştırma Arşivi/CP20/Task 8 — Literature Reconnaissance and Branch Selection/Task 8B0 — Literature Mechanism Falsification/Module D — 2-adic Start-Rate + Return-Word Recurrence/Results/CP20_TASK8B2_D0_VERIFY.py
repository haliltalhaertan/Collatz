#!/usr/bin/env python3
"""
CP20 TASK 8B2 — D0 exact verifier
Status: [AUDIT CANDIDATE SUPPORT]

Checks:
- B_v affine decomposition
- r_v ≡ r_u mod 2^A_u
- injury jump lower bound
- exact-cylinder lift and nesting
- fixed ordinary-realizer stabilization
- all-ones and alternating outside-critical-log formulas
- random larger words
- finite critical-log injury spike diagnostics

Finite verification is not the proof.
"""

from itertools import product
import random, math, json
from pathlib import Path

ALPHA=math.log2(3.0)
LN2=math.log(2.0)
LN3=math.log(3.0)

def big_ln(n):
    b=n.bit_length()
    if b<1000:
        return math.log(n)
    sh=b-53
    return math.log(n>>sh)+sh*LN2

def affine_prefix(word):
    A=[0];B=[0];r=[0];R=[0]
    for k,a in enumerate(word,1):
        B.append(3*B[-1]+(1<<A[-1]))
        A.append(A[-1]+a)
        mod=1<<A[-1]
        rr=(-B[-1]*pow(3,-k,mod))%mod
        modR=1<<(A[-1]+1)
        RR=((1<<A[-1])-B[-1])*pow(3,-k,modR)%modR
        r.append(rr);R.append(RR)
    return A,B,r,R

def v2(n):
    c=0
    while n%2==0:
        n//=2;c+=1
    return c

def actual_word(n0,k):
    w=[];n=n0
    for _ in range(k):
        z=3*n+1
        a=v2(z)
        w.append(a)
        n=z>>a
    return w

def check_word(word):
    A,B,r,R=affine_prefix(word)
    k=len(word)
    pair_checks=0
    injury_checks=0
    lift_checks=0

    for v in range(1,k+1):
        assert R[v]%(1<<A[v])==r[v]
        assert R[v] in (r[v],r[v]+(1<<A[v]))
        lift_checks+=1

        for u in range(1,v):
            decomp=3**(v-u)*B[u] + sum(
                3**(v-1-i)*(1<<A[i]) for i in range(u,v)
            )
            assert decomp==B[v]
            assert (r[v]-r[u])%(1<<A[u])==0
            assert (R[v]-R[u])%(1<<(A[u]+1))==0
            if r[v]!=r[u]:
                m=(r[v]-r[u])//(1<<A[u])
                assert m>=1
                assert r[v]>=1<<A[u]
                injury_checks+=1
            pair_checks+=1

    for i in range(1,k):
        if r[i+1]!=r[i]:
            assert r[i+1]>=1<<A[i]

    return pair_checks,injury_checks,lift_checks

def check_actual_stabilization():
    checks=0
    for n0 in range(1,3000,2):
        w=actual_word(n0,35)
        A,B,r,R=affine_prefix(w)
        for k in range(1,len(w)+1):
            if (1<<A[k])>n0:
                assert r[k]==n0
                assert R[k]==n0
                checks+=1
    return checks

def outside_scope_checks():
    # all ones
    for k in range(1,60):
        A,B,r,R=affine_prefix([1]*k)
        assert r[k]==(1<<k)-1
        assert R[k]==(1<<(k+1))-1

    # alternating at even depths
    for m in range(1,30):
        w=[1,2]*m
        A,B,r,R=affine_prefix(w)
        k=2*m
        assert A[k]==3*m
        assert r[k]==(1<<(3*m))-5
        assert R[k]==(1<<(3*m+1))-5

def gphase(i):
    return math.floor(ALPHA*(i+1))-math.floor(ALPHA*i)

def critical_log_word(kappa,N):
    s=0;w=[]
    for i in range(N):
        g=gphase(i)
        target=kappa*math.log2(i+2)
        max_s=s+g-1
        sn=min(round(target),max_s)
        a=s+g-sn
        if a<1:
            a=1
            sn=s+g-1
        s=sn
        w.append(a)
    return w

def critical_log_diagnostics():
    rows=[]
    for kap in (1.06,1.5,2.0):
        w=critical_log_word(kap,1800)
        A,B,r,R=affine_prefix(w)
        injuries=[]
        maxerr=0.0
        s=0
        for i,a in enumerate(w):
            s+=gphase(i)-a
            j=i+1
            if j>=16:
                maxerr=max(maxerr,abs(s-kap*math.log2(j)))
            if j>=2 and r[j]!=r[j-1]:
                rate=big_ln(1+r[j])/j
                lower=A[j-1]*LN2/j
                assert rate+1e-15>=lower
                injuries.append((j,rate,lower))
        tail=injuries[-200:] if len(injuries)>=200 else injuries
        rows.append({
            "kappa":kap,
            "max_corridor_error":maxerr,
            "injury_count":len(injuries),
            "max_tail_injury_rate":max(x[1] for x in tail),
            "ln3":LN3,
            "gap_to_ln3":LN3-max(x[1] for x in tail),
            "max_valuation":max(w),
        })
    return rows

def main():
    exact=0
    pairs=injuries=lifts=0
    for w in product((1,2,3),repeat=9):
        p,i,l=check_word(w)
        pairs+=p;injuries+=i;lifts+=l
        exact+=1

    rng=random.Random(20260826)
    random_words=0
    for _ in range(2500):
        L=rng.randint(10,55)
        w=[rng.randint(1,8) for _ in range(L)]
        p,i,l=check_word(w)
        pairs+=p;injuries+=i;lifts+=l
        random_words+=1

    stab=check_actual_stabilization()
    outside_scope_checks()
    diag=critical_log_diagnostics()

    result={
        "exact_words_1_2_3_depth9":exact,
        "random_words":random_words,
        "nested_pair_checks":pairs,
        "injury_checks":injuries,
        "lift_checks":lifts,
        "actual_positive_stabilization_checks":stab,
        "critical_log_diagnostics":diag,
    }
    Path(__file__).with_name("CP20_TASK8B2_D0_VERIFY_RESULTS.json").write_text(
        json.dumps(result,indent=2),encoding="utf-8"
    )

    print("CP20 TASK 8B2 D0 VERIFIER")
    print("exact words {1,2,3}^9:",exact)
    print("random larger words:",random_words)
    print("nested prefix-pair checks:",pairs)
    print("injury jump checks:",injuries)
    print("exact-cylinder lift/nesting checks:",lifts)
    print("actual positive stabilization checks:",stab)
    print("all-ones outside-critical-log formulas: PASS")
    print("alternating outside-critical-log formulas: PASS")
    for row in diag:
        print(
            "critical_log_diag",
            f"kappa={row['kappa']}",
            f"injuries={row['injury_count']}",
            f"maxerr={row['max_corridor_error']:.6f}",
            f"tail_gap_to_ln3={row['gap_to_ln3']:.6f}",
            f"amax={row['max_valuation']}"
        )
    print("ALL D0 VERIFIER ASSERTIONS: PASS")

if __name__=="__main__":
    main()
