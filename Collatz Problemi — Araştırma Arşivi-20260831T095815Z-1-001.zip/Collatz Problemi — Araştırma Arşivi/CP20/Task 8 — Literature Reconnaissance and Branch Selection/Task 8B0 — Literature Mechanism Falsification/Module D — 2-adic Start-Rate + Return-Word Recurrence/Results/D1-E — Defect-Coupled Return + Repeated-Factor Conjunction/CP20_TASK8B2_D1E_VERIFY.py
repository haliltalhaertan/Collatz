#!/usr/bin/env python3
import json, math, hashlib
from pathlib import Path

OUT=Path(__file__).resolve().parent
SRC=Path("/mnt/data/d1d_extract")
R=json.loads((OUT/"CP20_TASK8B2_D1E_RESULTS.json").read_text())
P=json.loads((OUT/"CP20_TASK8B2_D1E_SOURCE_PROVENANCE.json").read_text())
ALPHA=math.log2(3.0)

def g(i):
    return math.floor(ALPHA*(i+1))-math.floor(ALPHA*i)

def affine(word):
    A=[0];B=[0];r=[0];c=[0]
    for k,a in enumerate(word):
        B2=3*B[-1]+(1<<A[-1])
        A2=A[-1]+a
        rr=(-B2*pow(3,-(k+1),1<<A2))%(1<<A2)
        cc=(3**(k+1)*rr+B2)//(1<<A2)
        A.append(A2);B.append(B2);r.append(rr);c.append(cc)
    return A,B,r,c

def main():
    for item in P["sources"]:
        p=SRC/item["name"]
        assert p.exists()
        assert hashlib.sha256(p.read_bytes()).hexdigest()==item["sha256"]

    assert R["status"]=="[NUM]/[LEAD]/[OPEN]"
    assert len(R["records"])==12
    assert R["aggregate"]["all_candidates_task8a_finite_surrogate_pass"] is True
    assert R["aggregate"]["all_exact_plateau_repeats_pass_task6_divisibility"] is True

    one_mismatch=False

    for rec in R["records"]:
        suffix=str(rec["kappa"]).replace(".","p")
        d=json.loads((SRC/f"CP20_TASK8B2_D1D_RESULTS_K{suffix}.json").read_text())
        source=next(b for b in d["beam"] if b["summary"]["M"]==rec["M"])
        word=source["word"]
        A,B,r,c=affine(word)
        p=rec["open_plateau_start"]; end=len(word)
        assert all(r[k]==r[p] for k in range(p,end+1))

        for met in rec["aligned_return_metrics"]:
            q=met["q"]; L=met["phase_lcp"]
            for h in range(L):
                assert g(p+h)==g(p+q+h)
                same_a=(word[p+h]==word[p+q+h])
                same_d=((word[p+h]-g(p+h))==(word[p+q+h]-g(p+q+h)))
                assert same_a==same_d

        e=rec["min_defect_cost_phase_return_ge8"]
        if e and e["defect_mismatches"]==1:
            one_mismatch=True

        rep=rec["best_actual_valuation_repeat_any_shift"]
        if rep:
            u=rep["u"]; v=rep["v"]; L=rep["length"]
            assert word[u:u+L]==word[v:v+L]
            mass=sum(word[u:u+L])
            diff=abs(c[v]-c[u])
            assert diff%(1<<mass)==0

    big=R["aggregate"]["largest_phase_return_event"]
    assert big["phase_lcp"]>=44 and big["valuation_lcp"]==0
    assert one_mismatch

    print("CP20 TASK 8B2 D1-E VERIFIER")
    print("source provenance hashes: PASS")
    print("12 exact D1-D candidate reconstructions: PASS")
    print("phase/defect equivalence on phase-return intervals: PASS")
    print("q=12 phase-LCP 44 / valuation-LCP 0 falsification: PASS")
    print("single-mismatch long phase-return breaker exists: PASS")
    print("Task-6 divisibility on recorded exact valuation repeats: PASS")
    print("inherited finite Task-8A surrogate flags: PASS")
    print("NO THEOREM PROMOTION ASSERTION: PASS")
    print("ALL D1-E VERIFIER ASSERTIONS: PASS")

if __name__=="__main__":
    main()
