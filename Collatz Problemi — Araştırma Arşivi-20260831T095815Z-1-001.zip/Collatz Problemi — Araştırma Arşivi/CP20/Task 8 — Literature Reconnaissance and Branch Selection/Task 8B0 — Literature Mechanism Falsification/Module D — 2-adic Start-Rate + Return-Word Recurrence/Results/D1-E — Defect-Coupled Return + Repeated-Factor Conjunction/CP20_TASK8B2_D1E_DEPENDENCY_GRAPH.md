# CP20 TASK 8B2 — D1-E DEPENDENCY GRAPH

Frozen D0/D1
-> exact injury plateau geometry and finite exact witnesses.

D1-D exact finite candidate words
-> canonical injury schedule already verified.

Mechanical phase `g_k`
+ defect code `d_k = a_k - g_k`
-> on phase-equal intervals, valuation equality iff defect equality.

True valuation repeat
-> frozen Task-6 repeated-factor divisibility.

Frozen Task-8A
-> critical-site density/pressure constraints.

Missing bridge:
no theorem currently converts Task-8A marginal pressure into a lower bound on
the shifted mismatch set `{i : d_i != d_(i+q)}` across all dangerous returns.

No CP19 parked branch.
No 3-adic endpoint rate.
No new theorem dependency.
