# CP20 TASK 8B2 — D1-E COUNTEREXAMPLE / FALSIFICATION REPORT

## F1 — phase near-return forces valuation return
`[FAIL]`.

Exact finite counterexample:
kappa=2.7, M=4, q=12, phase LCP=44, valuation LCP=0.

## F2 — defect masks destroy every valuation recurrence
`[FAIL]`.

Finite exact valuation repeats remain. Longest observed length: 8.

## F3 — Task-6 divisibility cannot activate on a plateau
`[FAIL]`.

Whenever a true valuation repeat occurs, the exact plateau states satisfy the
frozen Task-6 divisibility. All recorded repeats passed.

## F4 — finite Task-8A pressure immediately forbids return-breaking defects
`[FAIL AS A FINITE HEURISTIC]`.

All 12 selected finite candidates pass the inherited finite Task-8A
surrogate while still breaking many phase returns early.

## F5 — positive return-breaking defect density is already established
`[FAIL]`.

One mismatch is logically sufficient for one return constraint. Finite data
contain a length-10 phase return broken with one defect mismatch.

The overlapping simultaneous return-cost problem remains `[OPEN]`.
