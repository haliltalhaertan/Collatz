#!/usr/bin/env python3
"""
CP20 TASK 8B2 — D1-E defect-coupled return / repeated-factor analysis.

Reconstruction basis:
- frozen D1-D exact finite candidate words;
- no new residue optimization;
- exact integer affine/residue/state calculations;
- finite return/defect metrics only.

Status discipline:
all computed asymptotic-looking observations are [NUM]/[LEAD], not theorem.
"""
from pathlib import Path
import json, math, csv, glob

ROOT=Path("/mnt/data/d1d_extract")
OUT=Path(__file__).resolve().parent
ALPHA=math.log2(3.0)
BETA=ALPHA-1.0

def g(i):
    return math.floor(ALPHA*(i+1))-math.floor(ALPHA*i)

def cf_denominators(x, maxq=5000):
    den=[]
    p0,p1=0,1
    q0,q1=1,0
    y=x
    for _ in range(30):
        a=math.floor(y)
        p2=a*p1+p0; q2=a*q1+q0
        if q2>0 and q2 not in den:
            den.append(q2)
        if q2>maxq: break
        frac=y-a
        if abs(frac)<1e-15: break
        y=1.0/frac
        p0,p1=p1,p2; q0,q1=q1,q2
    return [q for q in den if q>=2 and q<=maxq]

def affine_canonical(word):
    # Returns A_k,B_k,r_k,c_k for depths k=0..n.
    A=[0]; B=[0]; r=[0]; c=[0]
    for k,a in enumerate(word):
        B2=3*B[-1]+(1<<A[-1])
        A2=A[-1]+a
        mod=1<<A2
        r2=(-B2*pow(3,-(k+1),mod))%mod
        c2=(3**(k+1)*r2+B2)//mod
        A.append(A2);B.append(B2);r.append(r2);c.append(c2)
    return A,B,r,c

def lcp(seq,i,j,end):
    n=0
    while i+n<end and j+n<end and seq[i+n]==seq[j+n]:
        n+=1
    return n

def phase_lcp(i,j,end):
    n=0
    while i+n<end and j+n<end and g(i+n)==g(j+n):
        n+=1
    return n

def defect(word,i):
    return word[i]-g(i)

def actual_repeat_catalog(word,p,end,A,c):
    # All exact valuation repeats within the plateau, moderate finite lengths.
    best=None
    repeats=[]
    for u in range(p,end):
        for v in range(u+1,end):
            L=lcp(word,u,v,end)
            if L<=0:
                continue
            mass=sum(word[u:u+L])
            diff=abs(c[v]-c[u])
            div_ok=(diff%(1<<mass)==0)
            rec={
                "u":u,"v":v,"length":L,"valuation_mass":mass,
                "spacing":v-u,"state_diff_bitlen":diff.bit_length(),
                "task6_divisibility_exact":div_ok,
            }
            repeats.append(rec)
            if best is None or (L,mass)>(best["length"],best["valuation_mass"]):
                best=rec
    return best,repeats

def analyze_candidate(row,word):
    kap=row["kappa"]; depth=len(word)
    A,B,r,c=affine_canonical(word)
    injuries=[k for k in range(depth) if r[k+1]!=r[k]]
    t=injuries[-1] if injuries else 0
    p=t+1
    end=depth

    # Open plateau witness and exact state consistency.
    witness=r[p] if p<=depth else None
    plateau_const=all(r[k]==witness for k in range(p,end+1))

    qs=[q for q in cf_denominators(BETA, maxq=max(2,end)) if p+q<end]
    aligned=[]
    all_long=[]
    for q in qs:
        # canonical aligned start: post-injury plateau start
        pl=phase_lcp(p,p+q,end)
        vl=lcp(word,p,p+q,end)
        dl=lcp([defect(word,i) for i in range(end)],p,p+q,end)
        mismatch=0
        if pl>0:
            for h in range(pl):
                if defect(word,p+h)!=defect(word,p+q+h):
                    mismatch+=1
        aligned.append({
            "q":q,"phase_lcp":pl,"valuation_lcp":vl,"defect_lcp":dl,
            "defect_mismatches_inside_phase_lcp":mismatch,
            "defect_mismatch_density_inside_phase_lcp":(mismatch/pl if pl else None),
        })

        # Search every start in plateau for long phase returns at this q.
        for i in range(p,end-q):
            P=phase_lcp(i,i+q,end)
            if P>=4:
                V=lcp(word,i,i+q,end)
                mm=sum(defect(word,i+h)!=defect(word,i+q+h) for h in range(P))
                all_long.append({
                    "q":q,"start":i,"phase_lcp":P,"valuation_lcp":V,
                    "defect_mismatches":mm,
                    "defect_mismatch_density":mm/P,
                    "first_defect_mismatch": next(
                        (h for h in range(P)
                         if defect(word,i+h)!=defect(word,i+q+h)), None
                    ),
                })

    best_phase=max(all_long,key=lambda x:x["phase_lcp"],default=None)
    best_val=max(all_long,key=lambda x:x["valuation_lcp"],default=None)
    long8=[x for x in all_long if x["phase_lcp"]>=8]
    min_cost8=min(long8,key=lambda x:(x["defect_mismatches"],x["defect_mismatch_density"]),default=None)
    long16=[x for x in all_long if x["phase_lcp"]>=16]
    min_cost16=min(long16,key=lambda x:(x["defect_mismatches"],x["defect_mismatch_density"]),default=None)

    best_repeat,repeats=actual_repeat_catalog(word,p,end,A,c)
    if repeats and not all(x["task6_divisibility_exact"] for x in repeats):
        raise AssertionError("Task-6 divisibility failed on exact plateau repeat")

    # critical/defect mask statistics on open plateau
    plen=max(0,end-p)
    crit=sum(1 for i in range(p,end) if word[i]==g(i))
    noncrit=plen-crit
    defect_nonzero=sum(1 for i in range(p,end) if defect(word,i)!=0)

    return {
        "kappa":kap,
        "M":row["M"],
        "depth":depth,
        "open_plateau_last_injury":t,
        "open_plateau_start":p,
        "open_plateau_length":end-p,
        "open_plateau_ratio":(end/t if t>0 else None),
        "plateau_witness_bitlen":witness.bit_length() if witness else None,
        "plateau_residue_constant_exact":plateau_const,
        "valuation_alphabet_max":max(word) if word else None,
        "critical_site_density_open_plateau":(crit/plen if plen else None),
        "noncritical_site_density_open_plateau":(noncrit/plen if plen else None),
        "nonzero_defect_density_open_plateau":(defect_nonzero/plen if plen else None),
        "cf_denominators_tested":qs,
        "aligned_return_metrics":aligned,
        "phase_return_events_ge4":len(all_long),
        "best_phase_return":best_phase,
        "best_valuation_return_among_phase_returns":best_val,
        "min_defect_cost_phase_return_ge8":min_cost8,
        "min_defect_cost_phase_return_ge16":min_cost16,
        "best_actual_valuation_repeat_any_shift":best_repeat,
        "actual_valuation_repeat_count":len(repeats),
        "all_actual_repeats_task6_divisibility_pass":all(
            x["task6_divisibility_exact"] for x in repeats
        ),
        "task8a_finite_surrogate_pass_from_D1D":row.get("task8a_pass"),
    }

def main():
    records=[]
    for fn in sorted(ROOT.glob("CP20_TASK8B2_D1D_RESULTS_K*.json")):
        d=json.loads(fn.read_text())
        # use all beam candidates; they are the finite plateau witnesses used in D1-D
        for b in d["beam"]:
            row=b["summary"]
            word=b["word"]
            records.append(analyze_candidate(row,word))

    # aggregate finite falsification evidence
    long_events=[]
    for r in records:
        for e in (r["aligned_return_metrics"]):
            if e["phase_lcp"]>=4:
                long_events.append((r,e))
    phase_big_val_short=[
        {"kappa":r["kappa"],"M":r["M"],**e}
        for r,e in long_events if e["phase_lcp"]>=8 and e["valuation_lcp"]<=1
    ]
    phase_pairs=[(r["best_phase_return"]["phase_lcp"],r)
                 for r in records if r["best_phase_return"]]
    max_phase=max(phase_pairs,key=lambda x:x[0]) if phase_pairs else (None,None)
    val_pairs=[(r["best_actual_valuation_repeat_any_shift"]["length"],r)
               for r in records if r["best_actual_valuation_repeat_any_shift"]]
    max_val=max(val_pairs,key=lambda x:x[0]) if val_pairs else (None,None)

    result={
        "status":"[NUM]/[LEAD]/[OPEN]",
        "candidate_count":len(records),
        "continued_fraction_denominators_beta":cf_denominators(BETA,5000),
        "records":records,
        "aggregate":{
            "aligned_phase_return_ge8_with_valuation_lcp_le1_count":len(phase_big_val_short),
            "examples_phase_return_destroyed_early":phase_big_val_short[:20],
            "largest_phase_return_event":(
                max_phase[1]["best_phase_return"] if max_phase[1] else None
            ),
            "largest_phase_return_candidate":(
                {"kappa":max_phase[1]["kappa"],"M":max_phase[1]["M"]}
                if max_phase[1] else None
            ),
            "largest_actual_valuation_repeat_length":max_val[0],
            "largest_actual_valuation_repeat_candidate":(
                {"kappa":max_val[1]["kappa"],"M":max_val[1]["M"],
                 "repeat":max_val[1]["best_actual_valuation_repeat_any_shift"]}
                if max_val[1] else None
            ),
            "all_candidates_task8a_finite_surrogate_pass":all(
                r["task8a_finite_surrogate_pass_from_D1D"] is True for r in records
            ),
            "all_exact_plateau_repeats_pass_task6_divisibility":all(
                r["all_actual_repeats_task6_divisibility_pass"] for r in records
            ),
        }
    }
    (OUT/"CP20_TASK8B2_D1E_RESULTS.json").write_text(
        json.dumps(result,indent=2),encoding="utf-8"
    )

    cols=[
        "kappa","M","depth","open_plateau_last_injury","open_plateau_length",
        "open_plateau_ratio","plateau_witness_bitlen","valuation_alphabet_max",
        "critical_site_density_open_plateau","nonzero_defect_density_open_plateau",
        "phase_return_events_ge4","actual_valuation_repeat_count",
        "task8a_finite_surrogate_pass_from_D1D"
    ]
    with (OUT/"CP20_TASK8B2_D1E_SUMMARY.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=cols); w.writeheader()
        for r in records:
            w.writerow({k:r[k] for k in cols})

    print("CP20 TASK 8B2 D1-E DEFECT-COUPLED RETURN ENGINE")
    print("finite D1-D candidates analyzed:",len(records))
    print("CF denominators:",result["continued_fraction_denominators_beta"][:12])
    print("phase returns >=8 destroyed to valuation LCP <=1:",
          result["aggregate"]["aligned_phase_return_ge8_with_valuation_lcp_le1_count"])
    print("largest phase return:",result["aggregate"]["largest_phase_return_event"])
    print("largest actual valuation repeat length:",
          result["aggregate"]["largest_actual_valuation_repeat_length"])
    print("all exact valuation repeats satisfy Task-6 divisibility:",
          result["aggregate"]["all_exact_plateau_repeats_pass_task6_divisibility"])
    print("all D1-D selected candidates pass finite Task-8A surrogate:",
          result["aggregate"]["all_candidates_task8a_finite_surrogate_pass"])
    print("ALL D1-E ENGINE ASSERTIONS: PASS")

if __name__=="__main__":
    main()
