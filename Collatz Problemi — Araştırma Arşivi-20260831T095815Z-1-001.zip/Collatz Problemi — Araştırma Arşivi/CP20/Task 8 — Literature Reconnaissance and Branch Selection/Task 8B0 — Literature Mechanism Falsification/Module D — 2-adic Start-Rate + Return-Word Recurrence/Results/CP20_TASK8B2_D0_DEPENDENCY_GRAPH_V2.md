# CP20 TASK 8B2 — D0 DEPENDENCY GRAPH V2

**Audited core:** `[FROZEN]`  
**General L-extension:** `[NOT INDEPENDENTLY AUDITED]`

General exact chain:
\[
r_v\equiv r_u\pmod{2^{A_u}}
\]
→ injury jump
\[
r_{k+1}\ne r_k\Rightarrow r_{k+1}\ge2^{A_k}\ge2^k
\]
→ infinite injuries prevent \(\rho_r\to0\)
→
\[
r_k\text{ stabilizes}\iff\rho_r\to0.
\]

The exact one-bit lift plus frozen CP18 cylinder nesting gives
\[
r_k\text{ stabilizes}
\iff
R_k\text{ stabilizes}
\iff
\text{positive ordinary LEVEL-3 realizer}.
\]

Critical-log gives
\[
A_k\ln2/k\to\ln3,
\]
and hence
\[
\text{infinite injuries}\iff\limsup\rho_r=\ln3.
\]

The post-audit extension
\[
A_k\ln2/k\to L
\Rightarrow
(\text{infinite injuries}\Rightarrow\limsup\rho_r=L)
\]
is proved but not independently audited and is not a D1 dependency.

No Task 8A, Task 6 repeat theorem, 3-adic endpoint rate, or CP19 parked state is used.
