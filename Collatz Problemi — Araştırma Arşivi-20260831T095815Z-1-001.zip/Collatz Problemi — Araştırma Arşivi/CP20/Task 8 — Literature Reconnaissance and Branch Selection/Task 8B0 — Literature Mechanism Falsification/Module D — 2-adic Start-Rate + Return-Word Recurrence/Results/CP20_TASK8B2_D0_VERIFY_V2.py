#!/usr/bin/env python3
from itertools import product
import random, math, json
from pathlib import Path

LN2=math.log(2.0); LN3=math.log(3.0); ALPHA=math.log2(3.0)

def big_ln(n):
    b=n.bit_length()
    if b<1000:
        return math.log(n)
    sh=b-53
    return math.log(n>>sh)+sh*LN2

def v2(n):
    c=0
    while n%2==0:
        n//=2;c+=1
    return c

def affine(word):
    A=[0];B=[0];r=[0];R=[0]
    for k,a in enumerate(word,1):
        B.append(3*B[-1]+(1<<A[-1]))
        A.append(A[-1]+a)
        r.append((-B[-1]*pow(3,-k,1<<A[-1]))%(1<<A[-1]))
        mod=1<<(A[-1]+1)
        R.append(((1<<A[-1])-B[-1])*pow(3,-k,mod)%mod)
    return A,B,r,R

def check_word(word):
    A,B,r,R=affine(word); pairs=inj=0
    for v in range(1,len(word)+1):
        assert R[v]%(1<<A[v])==r[v]
        assert R[v] in (r[v],r[v]+(1<<A[v]))
        for u in range(1,v):
            assert B[v]==3**(v-u)*B[u]+sum(3**(v-1-i)*(1<<A[i]) for i in range(u,v))
            assert (r[v]-r[u])%(1<<A[u])==0
            assert (R[v]-R[u])%(1<<(A[u]+1))==0
            if r[v]!=r[u]:
                m=(r[v]-r[u])//(1<<A[u])
                assert m>=1 and r[v]>=1<<A[u]
                inj+=1
            pairs+=1
    for k in range(1,len(word)):
        if r[k+1]!=r[k]:
            rho=math.log1p(r[k+1])/(k+1)
            assert rho+1e-14>=A[k]*LN2/(k+1)
            assert A[k]>=k
    return pairs,inj

def actual_orbit(n0,K):
    w=[];n=n0
    for _ in range(K):
        z=3*n+1;a=v2(z);w.append(a);n=z>>a
    return w

def fixed_checks():
    c=0
    for n0 in range(1,4000,2):
        A,B,r,R=affine(actual_orbit(n0,45))
        for k in range(1,46):
            if (1<<A[k])>n0:
                assert r[k]==n0 and R[k]==n0
                c+=1
    return c

def g(i): return math.floor(ALPHA*(i+1))-math.floor(ALPHA*i)

def synth(kappa,N):
    s=0;w=[]
    for i in range(N):
        target=kappa*math.log2(i+2)
        sn=min(round(target),s+g(i)-1)
        a=s+g(i)-sn
        if a<1: a=1;sn=s+g(i)-1
        s=sn;w.append(a)
    return w

def main():
    exact=pairs=inj=0
    for w in product((1,2,3),repeat=9):
        p,i=check_word(w);pairs+=p;inj+=i;exact+=1
    rng=random.Random(8272026); rand=0
    for _ in range(3000):
        L=rng.randint(10,60)
        p,i=check_word([rng.randint(1,9) for _ in range(L)])
        pairs+=p;inj+=i;rand+=1
    fixed=fixed_checks()

    for k in (20,50,100,200,400):
        A,B,r,R=affine([1]*k)
        assert r[k]==(1<<k)-1 and R[k]==(1<<(k+1))-1
        assert abs(math.log1p(r[k])/k-LN2)<1e-14
        assert abs(A[k]*LN2/k-LN2)<1e-14

    for m in (10,25,50,100,200):
        A,B,r,R=affine([1,2]*m);k=2*m
        assert A[k]==3*m and r[k]==(1<<(3*m))-5 and R[k]==(1<<(3*m+1))-5

    crit=[]
    for kap in (1.06,1.5,2.0):
        w=synth(kap,2200);A,B,r,R=affine(w)
        rates=[]
        for k in range(2,len(r)):
            if r[k]!=r[k-1]:
                lr=big_ln(r[k])
                # log(1+r)=log r + negligible correction for huge r.
                if lr<40:
                    lr += math.log1p(math.exp(-lr))
                rates.append(lr/k)
        crit.append((kap,len(rates),LN3-max(rates[-300:])))

    data={"exact_words":exact,"random_words":rand,"pairs":pairs,"injuries":inj,
          "fixed_checks":fixed,"critical_log_diag":crit,
          "invalid_last4_stabilization_heuristic_used":False}
    Path(__file__).with_name("CP20_TASK8B2_D0_VERIFY_V2_RESULTS.json").write_text(json.dumps(data,indent=2),encoding="utf-8")
    print("CP20 TASK 8B2 D0 V2 VERIFIER")
    print("exact words:",exact)
    print("random words:",rand)
    print("nested pair checks:",pairs)
    print("injury checks:",inj)
    print("actual fixed-n0 checks:",fixed)
    print("all-ones generalized ceiling check: PASS")
    print("alternating generalized ceiling check: PASS")
    print("critical-log diagnostics:",crit)
    print("last-four-equal stabilization heuristic: NOT USED")
    print("ALL D0 V2 VERIFIER ASSERTIONS: PASS")

if __name__=="__main__":
    main()
