# CP20 TASK 8B2 — D0 AUDIT PACKAGE

**Status:** `[AUDIT CANDIDATE]`

## Main result

Inside global critical-log:
\[
\text{positive LEVEL-3 realizer}
\iff
r_k\text{ stabilizes}
\iff
\rho_r\to0
\iff
\limsup\rho_r<\ln3.
\]

If no positive realizer exists:
\[
\limsup\rho_r=\ln3.
\]

## Open escape regime

The theorem does not control
\[
\liminf\rho_r.
\]

The unresolved oscillatory case is
\[
\liminf\rho_r=0,\qquad
\limsup\rho_r=\ln3
\]
with infinitely many sparse injuries.

## Why D0 triggered the stop rule

This equivalence converts the pure 2-adic rate into an exact LEVEL-3
realization classifier inside critical-log.

Every downstream return-word/repeated-factor argument would now be built on
this theorem, so independent audit is mandatory before D1–D5.

## Files

- `CP20_TASK8B2_D0_RATE_STABILIZATION_DICHOTOMY_THEOREM.md`
- `CP20_TASK8B2_D0_DEPENDENCY_GRAPH.md`
- `CP20_TASK8B2_D0_COUNTEREXAMPLE_REPORT.md`
- `CP20_TASK8B2_D0_VERIFY.py`
- `CP20_TASK8B2_D0_VERIFY_OUTPUT.txt`
- `CP20_TASK8B2_D0_VERIFY_RESULTS.json`
- `CP20_TASK8B2_D0_ZERO_TRUST_AUDIT_PROMPT.md`
- `README.md`
- `SHA256SUMS.txt`

## Status discipline

No D1, D2, D3, D4, or D5 result is present.

No Sturmian return-word claim is made.

No explicit \(n_0\) calibration or repeat-surplus theorem is claimed.

No ordinary critical-log survivor class is excluded beyond the exact
rate/stabilization dichotomy itself.

## Next action

Independent zero-trust audit of D0.
