# CP20 TASK 8B2 — D0 DEPENDENCY GRAPH

**Status:** `[AUDIT CANDIDATE]`

## Exact finite-word layer

\[
B_v
=
3^{v-u}B_u+
\sum_{i=u}^{v-1}3^{v-1-i}2^{A_i}
\]

\[
\Downarrow
\]

\[
B_v\equiv3^{v-u}B_u\pmod{2^{A_u}}
\]

\[
\Downarrow
\]

\[
\boxed{r_v\equiv r_u\pmod{2^{A_u}}}
\]

\[
\Downarrow
\]

injury:
\[
r_{k+1}\ne r_k
\Rightarrow
r_{k+1}\ge2^{A_k}.
\]

## Critical-log layer

\[
s_k=\kappa\log_2k+O(1)
\]

\[
\Downarrow
\]

\[
A_k\ln2
=
k\ln3-\kappa\ln k+O(1).
\]

Thus injury times satisfy
\[
\rho_r(k+1)
\ge
\ln3-O(\log k/k),
\]
while globally
\[
\rho_r(k)
\le
\ln3-\kappa\ln k/k+O(1/k).
\]

Therefore
\[
\text{infinitely many injuries}
\Rightarrow
\limsup\rho_r=\ln3.
\]

## Stabilization layer

\[
\limsup\rho_r<\ln3
\Rightarrow
\text{finitely many injuries}
\Rightarrow
r_k=r_*\text{ eventually}.
\]

Also
\[
r_k=r_*\text{ eventually}
\iff
\rho_r(k)\to0.
\]

## Exact-cylinder lift layer

For every depth,
\[
R_k\in\{r_k,r_k+2^{A_k}\}.
\]

Nested exact cylinders give
\[
R_j\equiv R_k\pmod{2^{A_k+1}}
\qquad(j>k).
\]

If \(r_j=r_k=r_*\) for all large indices and \(A_j\ge A_k+1\),
both possible \(R_j\) reduce to \(r_*\) modulo \(2^{A_k+1}\).

Hence
\[
R_k=r_*
\]
eventually.

## Frozen CP18 input

CP18 Task 10:
\[
R_k\text{ eventually constant}
\iff
\text{unique 2-adic realizer is a positive ordinary integer}.
\]

This is independently audited/frozen project input.

## Kramer external input

Kramer 2026:
a fixed positive integer generating the code implies
\[
r_k=n_0
\]
eventually and
\[
\rho_r(k)\to0.
\]

D0 independently re-derives this direction and adds the converse within
critical-log.

## Final chain

\[
\boxed{
\begin{aligned}
\text{positive LEVEL-3 realizer}
&\iff r_k\text{ eventually constant}\\
&\iff \rho_r(k)\to0\\
&\iff \limsup\rho_r(k)<\ln3.
\end{aligned}}
\]

Complement:
\[
\boxed{
\text{no positive realizer}
\Rightarrow
\limsup\rho_r=\ln3.
}
\]

## Non-dependencies

- no 3-adic endpoint rate;
- no CP19 parked high-half/cross-adic state;
- no Sturmian return-word theorem;
- no Task-6 repeated-factor spacing;
- no Task-8A pressure theorem;
- no D1–D5 computation.
