# CP20 TASK 8B2 — FINDING D EXACT TRIAGE

**Date:** 2026-08-27  
**Status:** post-audit exact triage; not part of the frozen D1 theorem.

Define
\[
c_k:=\frac{3^kr_k+B_k}{2^{A_k}}.
\]

All statements below were re-derived independently from the affine identities.

## D-T1 — local no-injury characterization

`[EXACT]`

For every \(k\ge0\),
\[
\boxed{
r_{k+1}=r_k
\iff
a_k\le v_2(3c_k+1).
}
\]

Proof: write
\[
r_{k+1}=r_k+m_k2^{A_k}.
\]
Then
\[
3^{k+1}r_{k+1}+B_{k+1}
=
2^{A_k}\left(3c_k+1+3^{k+1}m_k\right).
\]

The canonical depth-\(k+1\) congruence determines \(m_k\) modulo \(2^{a_k}\):
\[
m_k\equiv
-(3c_k+1)3^{-(k+1)}
\pmod{2^{a_k}}.
\]

Thus \(m_k=0\) iff
\[
2^{a_k}\mid3c_k+1.
\]

Under no injury,
\[
\boxed{
c_{k+1}=\frac{3c_k+1}{2^{a_k}}.
}
\]

At \(k=0\),
\[
c_0=0,\qquad v_2(3c_0+1)=v_2(1)=0<a_0,
\]
so injury at zero is forced.

## D-T2 — two-step plateau rigidity

`[EXACT]`

If there is no injury at both \(k\) and \(k+1\), then
\[
\boxed{
a_k=v_2(3c_k+1).
}
\]

If strict inequality held, then under D-T1
\[
c_{k+1}=(3c_k+1)/2^{a_k}
\]
would be even. Hence
\[
3c_{k+1}+1
\]
would be odd, so
\[
v_2(3c_{k+1}+1)=0<a_{k+1},
\]
forcing injury at \(k+1\), contradiction.

**Terminal exception.** A final no-injury step may be slack if the next step
is an injury or the finite word stops there.

## D-T3 — exact ordinary meaning of a finite plateau

`[PROVED]`

Let
\[
r_p=r_{p+1}=\cdots=r_q=r_*,
\qquad q>p.
\]

Frozen D1 gives
\[
p\ge1,\qquad r_*>0.
\]

For every \(p\le k\le q\),
\[
c_k=\frac{3^kr_*+B_k}{2^{A_k}}
\]
is the affine state obtained from the **original starting integer** \(r_*\)
after the selected prefix divisions.

For every
\[
p\le k\le q-1,
\]
D-T1 gives
\[
c_{k+1}=(3c_k+1)/2^{a_k}.
\]

For every interior index
\[
p\le k\le q-2,
\]
D-T2 gives the exact Syracuse valuation equality
\[
\boxed{
a_k=v_2(3c_k+1).
}
\]

Hence
\[
c_p,c_{p+1},\ldots,c_{q-1}
\]
is a genuine odd-only Syracuse orbit segment, with exact valuations
\[
a_p,\ldots,a_{q-2}.
\]

The final selected division \(a_{q-1}\) may be slack if an injury occurs at
\(q\).

Separately, the original start \(r_*\) exactly realizes the prefix certified
by the frozen exact-cylinder plateau lemma; the intermediate \(c_k\) are
states of that same finite ordinary trajectory where the exactness conditions
hold.

Thus “plateau shadowing” must always specify:
- start integer \(r_*\);
- intermediate state \(c_k\);
- exact prefix range;
- terminal slack exception.

## D-T4 — overbroad minimal-realizer claim

`[FAIL — OVERBROAD STATEMENT]`

Claim:
“the least positive exact realizer of every length-\(L\) word is \(r_L\)” is
false.

Counterexample:
\[
w=(1),\quad A_1=1,\quad B_1=1,\quad r_1=1.
\]
But
\[
v_2(3\cdot1+1)=2\ne1,
\]
so \(1\) does not exactly realize \(w=(1)\).

The least exact realizer is
\[
\boxed{3}.
\]

### Correct theorem

For a finite length-\(L\) word define the canonical exact-cylinder
representative \(E_L\in[0,2^{A_L+1})\) by the exact valuation congruence.
Then
\[
\boxed{
E_L\in\{r_L,\ r_L+2^{A_L}\}.
}
\]

The least positive exact realizer is \(E_L\).

Moreover,
\[
\boxed{
E_L=r_L
\iff
c_L\text{ is odd}.
}
\]

If the word is extended by a next exponent \(a_L\) and there is no injury at
\(L\), then D-T1 implies \(c_L\) is odd, so \(E_L=r_L\). This no-injury
condition is sufficient, not necessary for an arbitrary separately chosen
next exponent.

This one-bit-lift statement is the exact correction.

## D-T5 — overbroad infinite-plateau/divergence claim

`[FAIL — OVERBROAD STATEMENT]`

Unconditional claim:
“infinite plateau iff divergent non-cycling orbit” is false.

Counterexample:
\[
a_k\equiv2,\qquad n_0=1.
\]
The odd-only Syracuse orbit is the fixed point \(1\), and the Kramer residue
stabilizes forever.

### Correct general theorem

By frozen D0,
\[
\boxed{
\text{eventual infinite plateau}
\iff
\text{one positive ordinary LEVEL-3 realizer exists}.
}
\]

That realizer may be cyclic.

### Critical-log scope

Under global critical-log,
\[
A_k/k\to\alpha=\log_2 3,
\]
which is irrational.

An eventually periodic valuation word would have rational average valuation
over its period, contradicting the above limit. Therefore a critical-log
LEVEL-3 realizer cannot enter an eventual periodic valuation pattern,
including the trivial all-\(2\) fixed point.

Since a bounded positive integer orbit under a deterministic map takes only
finitely many values and is therefore eventually periodic, a critical-log
ordinary realizer, if it exists, must be **unbounded/non-eventually-periodic**.

No claim is made that its state tends monotonically or converges to
\(+\infty\).

## D-T6 — classification

- D-T1: `[EXACT]`
- D-T2: `[EXACT]`
- D-T3: `[PROVED]`
- Auditor minimal-realizer statement: `[FAIL — OVERBROAD STATEMENT]`
- Correct one-bit minimal-exact-realizer theorem: `[EXACT]`
- Auditor unconditional infinite-plateau/divergence statement:
  `[FAIL — OVERBROAD STATEMENT]`
- Correct general eventual-plateau/LEVEL-3 equivalence: `[KNOWN]` from frozen D0
- Critical-log nonperiodicity consequence: `[PROVED]`

### Audit-stop assessment

D-T1/D-T2 are short local affine corollaries; D-T3 is their finite-orbit
interpretation and is not required for the correctness of the D1-D residue
engine.

They do not introduce a new global obstruction theorem and are classified
as close corollaries of frozen D0/D1, so the Phase-1 load-bearing stop is
**not** triggered.

They may be used as diagnostic/interpretive identities in D1-D, while the
canonical frozen global dependencies remain D0/D1.
