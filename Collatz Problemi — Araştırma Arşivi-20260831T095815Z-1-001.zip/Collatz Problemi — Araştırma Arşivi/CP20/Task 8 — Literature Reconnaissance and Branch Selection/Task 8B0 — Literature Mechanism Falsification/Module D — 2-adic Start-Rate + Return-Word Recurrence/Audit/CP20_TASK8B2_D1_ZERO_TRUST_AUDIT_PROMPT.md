# CP20 TASK 8B2 — D1 A/B/C ZERO-TRUST AUDIT PROMPT

Candidate status: `[AUDIT CANDIDATE]`.

Audit the claims:
\[
\liminf_k\rho_r(k)
=
\ln3\liminf_j(t_j/t_{j+1})
\]
for critical-log words with infinitely many injuries, and the finite plateau
lemma
\[
r_p=\cdots=r_q=r_*\Rightarrow R_k=r_*\quad(p\le k\le q-1).
\]

Mandatory checks:

1. exact chunk indexing and \(r_0=0\);
2. \(0\le m_k<2^{a_k}\);
3. telescoping expansion;
4. bounded \(a_k\) without smooth \(O(1)\) error;
5. plateau interval exactly \(t_j+1\le k\le t_{j+1}\);
6. exact power-of-two sandwich;
7. uniform critical-log error;
8. error tends to zero at \(t_{j+1}\);
9. plateau monotonicity;
10. global liminf occurs at plateau endpoints;
11. liminf passage through an \(o(1)\) term;
12. zero liminf means existence of a subsequence with
    \(t_{j+1}/t_j\to\infty\), not full-sequence divergence;
13. prove \(r_{k+1}\equiv R_k\pmod{2^{A_k+1}}\);
14. audit terminal boundary exception;
15. find a finite terminal-injury example with changed \(R_q\) if possible;
16. verify only frozen D0 core is used;
17. check no unaudited L-extension, Task8A, Task6 return theorem, 3-adic rate,
    or CP19 machinery enters;
18. rerun verifier twice and attack all indexing/off-by-one cases.

Return exactly one:
`[PROOF VALID]`,
`[PROOF VALID WITH WORDING REPAIR]`,
`[FIXABLE GAP]`,
`[MAJOR GAP]`,
or `[FALSE — COUNTEREXAMPLE]`.

If valid, state whether D1 A/B/C may be frozen and D1-D may resume.
