# CP20 TASK 8B2 — D1 A/B/C DEPENDENCY GRAPH

**Status:** `[AUDIT CANDIDATE]`

Frozen dependency: D0 V2 audited core only.

New chain:
\[
r_{k+1}=r_k+m_k2^{A_k},
\quad
0\le m_k<2^{a_k}
\]
→ exact chunk expansion.

Critical-log bounded error
→ bounded \(a_k\)
→ bounded chunk alphabet.

Injury times \(t_j\)
→ exact plateau
\[
r_k=r_{t_j+1}\quad(t_j+1\le k\le t_{j+1})
\]
→
\[
2^{A_{t_j}}\le r_k<2^{A_{t_j+1}}
\]
→
\[
\rho_r(k)=\ln3\,t_j/k+O(\log t_j/k)
\]
→
\[
\boxed{
\liminf\rho_r
=
\ln3\liminf(t_j/t_{j+1}).
}
\]

Exact cylinder:
\[
r_{k+1}\equiv R_k\pmod{2^{A_k+1}}
\]
→ no injury at \(k\) implies \(R_k=r_k\)
→ a finite plateau is shadowed by one fixed positive exact realizer through
its penultimate depth.

The unaudited D0 general \(L\)-extension is not used.

No Task 8A, Task 6 return/repeat theorem, Sturmian theorem, 3-adic rate, or
CP19 parked state is used.
