# CP20 TASK 8B2 — D0 INDEPENDENT ZERO-TRUST AUDIT PROMPT

**Candidate status:** `[AUDIT CANDIDATE]`

Audit the claimed critical-log rate/stabilization dichotomy adversarially.

## Claimed theorem

For every infinite positive exponent word satisfying
\[
s_k=\kappa\log_2k+O(1),\qquad\kappa>1,
\]
with Kramer canonical start residue
\[
r_k\equiv-3^{-k}B_k\pmod{2^{A_k}},
\quad 0\le r_k<2^{A_k},
\]
the following are equivalent:
\[
\boxed{
\begin{aligned}
&\text{positive ordinary LEVEL-3 realizer exists}\\
\iff\;&r_k\text{ eventually stabilizes}\\
\iff\;&\rho_r(k)\to0\\
\iff\;&\limsup\rho_r(k)<\ln3.
\end{aligned}}
\]

Complement:
\[
\boxed{
\text{no positive ordinary realizer}
\Rightarrow
\limsup\rho_r(k)=\ln3.
}
\]

## Mandatory checks

1. Re-derive
   \[
   B_v=
   3^{v-u}B_u+
   \sum_{i=u}^{v-1}3^{v-1-i}2^{A_i}.
   \]
2. Prove or refute
   \[
   r_v\equiv r_u\pmod{2^{A_u}}.
   \]
3. Check the sign/uniqueness argument that an injury must be an upward
   positive multiple of \(2^{A_u}\).
4. Verify
   \[
   r_{k+1}\ne r_k\Rightarrow r_{k+1}\ge2^{A_k}.
   \]
5. Re-derive the critical-log injury lower spike.
6. Re-derive the global upper ceiling
   \[
   \rho_r(k)\le A_k\ln2/k.
   \]
7. Check that infinitely many injuries really force
   \[
   \limsup\rho_r=\ln3.
   \]
8. Check that non-eventual constancy is equivalent to infinitely many
   adjacent injuries.
9. Verify the one-bit exact-cylinder relation
   \[
   R_k\in\{r_k,r_k+2^{A_k}\}.
   \]
10. Verify nested exact cylinders imply
    \[
    R_j\equiv R_k\pmod{2^{A_k+1}}.
    \]
11. Audit the quantifiers in the key stabilization argument:
    if \(r_j=r_*\) for all \(j\ge K\), show \(R_k=r_*\) for every \(k\ge K\).
12. Check positivity/nonzero parity of the stabilized \(r_*\).
13. Verify the CP18 attribution:
    exact-cylinder eventual constancy iff positive ordinary LEVEL-3 realizer.
14. Independently prove the converse:
    a fixed positive \(n_0\) implies \(r_k=n_0\) eventually.
15. Try to construct a critical-log counterexample with
    nonstabilizing \(r_k\) but \(\limsup\rho_r<\ln3\).
16. Audit all-ones as an outside-critical-log counterexample to the
    generalized statement.
17. Audit the alternating \((1,2)^\infty\) example.
18. Check whether the theorem controls limsup only, not liminf.
19. Search CP18 Tasks 6–10 and Kramer 2026 for prior explicit statements of
    the full equivalence.
20. Check that no 3-adic endpoint rate is used.
21. Check that no Task-8A pressure or Task-6 repeated-factor theorem is used.
22. Re-run the supplied verifier twice.

## Required verdict

Return exactly one:

- `[PROOF VALID]`
- `[PROOF VALID WITH WORDING REPAIR]`
- `[FIXABLE GAP]`
- `[MAJOR GAP]`
- `[FALSE — COUNTEREXAMPLE]`

If valid, state whether D0 is safe to freeze and whether D1–D5 may then
resume.
