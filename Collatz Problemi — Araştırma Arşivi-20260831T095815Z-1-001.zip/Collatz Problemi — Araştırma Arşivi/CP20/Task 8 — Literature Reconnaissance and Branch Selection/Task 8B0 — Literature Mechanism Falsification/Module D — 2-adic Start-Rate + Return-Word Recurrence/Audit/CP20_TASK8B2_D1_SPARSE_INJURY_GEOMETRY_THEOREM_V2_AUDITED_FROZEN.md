# CP20 TASK 8B2 — D1 SPARSE-INJURY GEOMETRY THEOREM V2 — AUDITED/FROZEN

**Date:** 2026-08-27  
**Canonical status:** `[PROVED][INDEPENDENTLY AUDITED][WORDING REPAIRED][FROZEN]`

Independent audit verdict:
`[PROOF VALID WITH WORDING REPAIR]`.

Novelty is stated conservatively:
- A/B: near-restatements / immediate algebra;
- C/F: structural but close to frozen D0;
- D/E: main new structural corollary;
- G: strategic target list, not theorem content.

No foundational new 2-adic compactness principle is claimed.

## 1. Setup

Let
\[
a_k\ge1,\quad
A_k=\sum_{i<k}a_i,\quad
B_0=0,\quad B_{k+1}=3B_k+2^{A_k}.
\]

Let
\[
r_k\equiv-3^{-k}B_k\pmod{2^{A_k}},
\qquad
0\le r_k<2^{A_k},
\]
with
\[
r_0=0.
\]

Let \(R_k\) denote the canonical exact-cylinder representative modulo
\(2^{A_k+1}\). At depth zero the mathematically correct odd cylinder
representative is
\[
\boxed{R_0=1}.
\]

Assume global critical-log:
\[
s_k=\lfloor(\log_2 3)k\rfloor-A_k
=
\kappa\log_2k+O(1),
\qquad \kappa>1.
\]

## 2. First injury and positivity

At \(k=0\),
\[
r_1\equiv-3^{-1}\pmod{2^{a_0}}.
\]

The inverse of \(3\) modulo a power of two is odd, so \(r_1\) is odd.
Therefore
\[
\boxed{r_1>0=r_0}.
\]

Hence
\[
\boxed{k=0\text{ is always an injury}.}
\]

Every actual plateau
\[
r_p=\cdots=r_q=r_*
\]
therefore has
\[
\boxed{p\ge1,\qquad r_*>0}.
\]

Positivity is derived, not assumed.

## 3. Exact chunk expansion

Compatibility gives
\[
r_{k+1}=r_k+m_k2^{A_k}
\]
with
\[
\boxed{0\le m_k<2^{a_k}}.
\]

Moreover
\[
m_k=0\iff r_{k+1}=r_k.
\]

Thus
\[
\boxed{
r_k=\sum_{j<k}m_j2^{A_j}.
}
\]

## 4. Bounded alphabet under critical-log

Write
\[
s_k=\kappa\log_2k+e_k,\qquad |e_k|\le M
\]
eventually, and
\[
g_k=\lfloor\alpha(k+1)\rfloor-\lfloor\alpha k\rfloor\in\{1,2\},
\qquad \alpha=\log_2 3.
\]

Since
\[
s_{k+1}-s_k=g_k-a_k,
\]
\[
a_k
=
g_k-\kappa\log_2(1+1/k)-(e_{k+1}-e_k),
\]
so \(a_k\) is uniformly bounded. No smoothness of \(e_k\) is assumed.

## 5. Injury plateaus

Let
\[
t_1<t_2<\cdots
\]
be the adjacent injury indices:
\[
r_{t_j+1}\ne r_{t_j}.
\]

Then
\[
r_k=r_{t_j+1}
\qquad
(t_j+1\le k\le t_{j+1}).
\]

Exact canonical ranges imply
\[
\boxed{
2^{A_{t_j}}
\le r_k<2^{A_{t_j+1}}
}
\]
throughout that plateau, and therefore
\[
\boxed{
\frac{A_{t_j}\ln2}{k}
\le
\rho_r(k)
\le
\frac{A_{t_j+1}\ln2}{k}.
}
\]

## 6. Sharpened trough asymptotic

Write
\[
s_t=\kappa\log_2t+e_t,\qquad |e_t|\le M,
\]
and
\[
\theta_t=\{\alpha t\}.
\]

Since
\[
A_t=\alpha t-\theta_t-\kappa\log_2t-e_t,
\]
\[
\boxed{
A_t\ln2
=
t\ln3-\kappa\ln t-(\theta_t+e_t)\ln2.
}
\]

Thus
\[
A_t\ln2=t\ln3-\kappa\ln t+O(1).
\]

At a plateau trough \(t_{j+1}\),
\[
A_{t_j}\ln2
\le
\ln(1+r_{t_{j+1}})
\le
A_{t_j+1}\ln2.
\]

Critical-log boundedness of \(a_{t_j}\) makes the upper/lower difference
\(O(1)\), hence
\[
\boxed{
\rho_r(t_{j+1})
=
\ln3\,\frac{t_j}{t_{j+1}}
-
\kappa\,\frac{\ln t_j}{t_{j+1}}
+
O\!\left(\frac1{t_{j+1}}\right).
}
\]

This is a symbolic consequence of critical-log, not a numerical fit.

## 7. Liminf / multiplicative-gap theorem

Within a plateau \(r_k\) is constant, so \(\rho_r(k)\) decreases as \(k\)
increases.

Therefore
\[
\liminf_k\rho_r(k)
=
\liminf_j\rho_r(t_{j+1}).
\]

The sharpened trough formula yields
\[
\boxed{
\liminf_{k\to\infty}\rho_r(k)
=
\ln3\,
\liminf_{j\to\infty}\frac{t_j}{t_{j+1}}.
}
\]

Hence
\[
\boxed{
\liminf\rho_r=0
\iff
\liminf_j(t_j/t_{j+1})=0.
}
\]

Equivalently, there exists a subsequence \(j_\nu\) with
\[
\boxed{
t_{j_\nu+1}/t_{j_\nu}\to\infty.
}
\]

This is a subsequence statement, not full-sequence divergence.

## 8. Exact finite plateau lemma

If
\[
r_p=r_{p+1}=\cdots=r_q=r_*,
\qquad q>p,
\]
then
\[
p\ge1,\qquad r_*>0.
\]

For every
\[
p\le k\le q-1,
\]
no injury occurs at \(k\), and the exact one-bit cylinder relation gives
\[
\boxed{R_k=r_*}.
\]

Thus **each individual plateau** has its own positive exact witness \(r_*\)
for the corresponding finite prefix range.

Successive post-injury plateau witnesses are not the same integer:
Kramer residues are nondecreasing and strictly increase at every injury.

Therefore the theorem does **not** say that one fixed positive ordinary
integer shadows all exceptionally long plateaus.

## 9. Strategic target, not theorem content

After combining frozen D0/D1 with an independent downstream requirement
\[
\liminf\rho_r=0,
\]
a surviving non-realizer would require arbitrarily large multiplicative
injury gaps.

A future target is to decide whether one infinite LEVEL-2 critical-log word
can sustain such plateaus while respecting canonical residue recurrence and
Task-8A pressure.

No single \(n_0\) across distinct plateaus is assumed.

## 10. Scope

No sparse-injury survivor is excluded.

No Task-8A pressure theorem is used here.

No Sturmian theorem or Task-6 repeated-factor theorem is used here.

No 3-adic endpoint rate is used.

Final status:
\[
\boxed{
\texttt{[PROVED][INDEPENDENTLY AUDITED][WORDING REPAIRED][FROZEN]}
}
\]
