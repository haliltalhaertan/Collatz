#!/usr/bin/env python3
from itertools import product
import random, math, json
from pathlib import Path

ALPHA=math.log2(3.0); LN2=math.log(2.0); LN3=math.log(3.0)

def affine(word):
    A=[0];B=[0];r=[0];R=[0]
    for k,a in enumerate(word,1):
        B.append(3*B[-1]+(1<<A[-1]))
        A.append(A[-1]+a)
        r.append((-B[-1]*pow(3,-k,1<<A[-1]))%(1<<A[-1]))
        mod=1<<(A[-1]+1)
        R.append(((1<<A[-1])-B[-1])*pow(3,-k,mod)%mod)
    return A,B,r,R

def check_word(word):
    A,B,r,R=affine(word)
    chunks=pexact=pbounds=0
    for k,a in enumerate(word):
        diff=r[k+1]-r[k]
        assert diff%(1<<A[k])==0
        m=diff//(1<<A[k])
        assert 0<=m<(1<<a)
        assert (m==0)==(r[k+1]==r[k])
        chunks+=1
        if r[k+1]==r[k]:
            assert (r[k+1]-R[k])%(1<<(A[k]+1))==0
            assert R[k]==r[k]
            pexact+=1

    injuries=[k for k in range(len(word)) if r[k+1]!=r[k]]
    for j in range(len(injuries)-1):
        t=injuries[j]; nxt=injuries[j+1]
        rv=r[t+1]
        assert rv>=1<<A[t]
        assert rv<1<<A[t+1]
        for k in range(t+1,nxt+1):
            assert r[k]==rv
            assert A[t]*LN2<=math.log1p(r[k])+1e-12
            assert math.log1p(r[k])<=A[t+1]*LN2+1e-12
            pbounds+=1

    total=0
    for k,a in enumerate(word):
        m=(r[k+1]-r[k])//(1<<A[k])
        total+=m*(1<<A[k])
        assert total==r[k+1]
    return chunks,pexact,pbounds

def g(i): return math.floor(ALPHA*(i+1))-math.floor(ALPHA*i)

def synth(kappa,N):
    s=0;w=[]
    for i in range(N):
        target=kappa*math.log2(i+2)
        sn=min(round(target),s+g(i)-1)
        a=s+g(i)-sn
        if a<1: a=1;sn=s+g(i)-1
        s=sn;w.append(a)
    return w

def big_ln(n):
    b=n.bit_length()
    if b<1000: return math.log(n)
    sh=b-53
    return math.log(n>>sh)+sh*LN2

def diag():
    out=[]
    for kap in (1.06,1.5,2.0):
        w=synth(kap,3500);A,B,r,R=affine(w)
        injuries=[k for k in range(1,len(w)) if r[k+1]!=r[k]]
        errors=[];ratio_rho=[]
        for j in range(len(injuries)-1):
            t=injuries[j];nxt=injuries[j+1]
            if t<30: continue
            lr=big_ln(r[nxt])
            if lr<40: lr+=math.log1p(math.exp(-lr))
            rho=lr/nxt
            approx=LN3*t/nxt
            errors.append(abs(rho-approx))
            ratio_rho.append((t/nxt,rho))
        out.append({
            "kappa":kap,
            "injuries":len(injuries),
            "max_last500_error":max(errors[-500:]),
            "last_t_ratio":ratio_rho[-1][0],
            "last_rho":ratio_rho[-1][1],
        })
    return out

def main():
    exact=chunks=pexact=pbounds=0
    for w in product((1,2,3),repeat=8):
        a,b,c=check_word(w);chunks+=a;pexact+=b;pbounds+=c;exact+=1
    rng=random.Random(27082026);rand=0
    for _ in range(3500):
        L=rng.randint(10,70)
        a,b,c=check_word([rng.randint(1,9) for _ in range(L)])
        chunks+=a;pexact+=b;pbounds+=c;rand+=1
    dg=diag()
    data={"exact_words":exact,"random_words":rand,"chunk_checks":chunks,
          "noninjury_exact_cylinder_checks":pexact,
          "plateau_bound_checks":pbounds,"critical_log_diag":dg}
    Path(__file__).with_name("CP20_TASK8B2_D1_VERIFY_RESULTS.json").write_text(json.dumps(data,indent=2),encoding="utf-8")
    print("CP20 TASK 8B2 D1 A/B/C VERIFIER")
    print("exact words:",exact)
    print("random words:",rand)
    print("chunk checks:",chunks)
    print("noninjury exact-cylinder checks:",pexact)
    print("plateau sandwich checks:",pbounds)
    print("critical-log diagnostics:",dg)
    print("ALL D1 A/B/C VERIFIER ASSERTIONS: PASS")

if __name__=="__main__":
    main()
