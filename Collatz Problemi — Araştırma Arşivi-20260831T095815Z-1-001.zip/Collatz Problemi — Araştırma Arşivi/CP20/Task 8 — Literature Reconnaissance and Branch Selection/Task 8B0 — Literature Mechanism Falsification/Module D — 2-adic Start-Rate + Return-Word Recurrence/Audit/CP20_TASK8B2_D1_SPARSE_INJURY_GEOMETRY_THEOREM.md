# CP20 TASK 8B2 — D1 A/B/C SPARSE-INJURY GEOMETRY THEOREM

**Date:** 2026-08-27  
**Status:** `[AUDIT CANDIDATE]`

D0 V2 audited core is frozen before this theorem is invoked.

This result uses only:
- D0 residue compatibility / injury algebra;
- exact one-bit cylinder structure;
- global critical-log.

It does **not** use the unaudited D0 general \(L\)-extension.

Because the result materially changes the sparse-injury target, D1-D and
D1-E are stopped pending independent audit.

# A. Exact chunk expansion

Set
\[
r_0=0,\qquad A_0=0.
\]

D0 compatibility gives
\[
r_{k+1}\equiv r_k\pmod{2^{A_k}}.
\]

Therefore
\[
r_{k+1}=r_k+m_k2^{A_k}
\]
for an integer \(m_k\).

Canonical ranges give
\[
0\le r_k<2^{A_k},
\qquad
0\le r_{k+1}<2^{A_k+a_k}.
\]

Thus
\[
\boxed{0\le m_k<2^{a_k}.}
\]

Moreover
\[
\boxed{m_k=0\iff r_{k+1}=r_k}
\]
and
\[
\boxed{m_k>0\iff k\text{ is an injury index}.}
\]

Telescoping:
\[
\boxed{
r_k=\sum_{j=0}^{k-1}m_j2^{A_j}.
}
\]

# B. Critical-log bounds the valuation/chunk alphabet

Assume
\[
s_k=\kappa\log_2k+e_k,
\qquad
|e_k|\le M
\]
for all sufficiently large \(k\).

Let
\[
g_k=\lfloor\alpha(k+1)\rfloor-\lfloor\alpha k\rfloor\in\{1,2\}.
\]

Since
\[
s_{k+1}-s_k=g_k-a_k,
\]
\[
a_k
=
g_k-\kappa\log_2(1+1/k)-(e_{k+1}-e_k).
\]

Hence
\[
a_k<2+2M
\]
eventually. A convenient integer bound is
\[
\boxed{
a_k\le A_{\max}:=\lceil2+2M\rceil
}
\]
eventually.

Therefore
\[
\boxed{
0\le m_k<2^{A_{\max}}
}
\]
eventually.

No smoothness of the \(O(1)\) error is used.

# C. Plateau representation

Assume infinitely many adjacent injuries and enumerate them
\[
t_1<t_2<t_3<\cdots,
\]
where
\[
r_{t_j+1}\ne r_{t_j}.
\]

Between consecutive injuries,
\[
\boxed{
r_k=r_{t_j+1}
\qquad
(t_j+1\le k\le t_{j+1}).
}
\]

At injury \(t_j\),
\[
r_{t_j+1}
=
r_{t_j}+m_{t_j}2^{A_{t_j}},
\qquad
1\le m_{t_j}<2^{a_{t_j}}.
\]

Therefore
\[
r_{t_j+1}\ge2^{A_{t_j}}.
\]

The canonical depth-\(t_j+1\) range also gives
\[
r_{t_j+1}\le2^{A_{t_j+1}}-1.
\]

Hence every point on the plateau obeys
\[
\boxed{
A_{t_j}\ln2
\le
\ln(1+r_k)
\le
A_{t_j+1}\ln2
}
\]
for
\[
t_j+1\le k\le t_{j+1}.
\]

Equivalently,
\[
\boxed{
\frac{A_{t_j}\ln2}{k}
\le
\rho_r(k)
\le
\frac{A_{t_j+1}\ln2}{k}.
}
\]

# D. Critical-log plateau asymptotic

Under
\[
s_k=\kappa\log_2k+O(1),
\]
\[
A_t\ln2
=
t\ln3-\kappa\ln t+O(1).
\]

Since \(a_t\) is eventually bounded,
\[
A_{t+1}\ln2-A_t\ln2=O(1).
\]

Therefore, uniformly over each sufficiently late plateau,
\[
\boxed{
\rho_r(k)
=
\ln3\,\frac{t_j}{k}
+
O\!\left(\frac{\log t_j}{k}\right),
\qquad
t_j+1\le k\le t_{j+1}.
}
\]

At the plateau trough,
\[
\boxed{
\rho_r(t_{j+1})
=
\ln3\,\frac{t_j}{t_{j+1}}
+
O\!\left(\frac{\log t_j}{t_{j+1}}\right).
}
\]

The error tends to zero because
\[
t_{j+1}\ge t_j+1.
\]

# E. Liminf / multiplicative injury-gap theorem

On each plateau the numerator
\[
\ln(1+r_k)
\]
is constant and the denominator \(k\) increases.

Thus \(\rho_r(k)\) is decreasing on the plateau, and its minimum is at
\(k=t_{j+1}\).

Therefore
\[
\boxed{
\liminf_{k\to\infty}\rho_r(k)
=
\liminf_{j\to\infty}\rho_r(t_{j+1}).
}
\]

Using the trough asymptotic,
\[
\boxed{
\liminf_{k\to\infty}\rho_r(k)
=
\ln3\,
\liminf_{j\to\infty}\frac{t_j}{t_{j+1}}.
}
\]

Consequently,
\[
\boxed{
\liminf\rho_r=0
\iff
\liminf_j\frac{t_j}{t_{j+1}}=0.
}
\]

Equivalently, zero liminf occurs iff there exists a subsequence
\(j_\nu\) such that
\[
\boxed{
\frac{t_{j_\nu}}{t_{j_\nu+1}}\to0
}
\]
or
\[
\boxed{
\frac{t_{j_\nu+1}}{t_{j_\nu}}\to+\infty.
}
\]

The theorem does **not** say
\[
t_{j+1}/t_j\to\infty
\]
for the full injury sequence. Only an unbounded subsequence is forced.

Thus the hard branch
\[
\liminf\rho_r=0,\qquad
\limsup\rho_r=\ln3
\]
requires arbitrarily large multiplicative no-injury plateaus.

# F. Finite ordinary-realizer plateau lemma

For every \(k\), the deeper Kramer residue \(r_{k+1}\) lies in the exact
depth-\(k\) valuation cylinder:
\[
\boxed{
r_{k+1}\equiv R_k\pmod{2^{A_k+1}}.
}
\]

A direct derivation starts from
\[
3^{k+1}r_{k+1}+B_{k+1}
=
3(3^kr_{k+1}+B_k)+2^{A_k},
\]
whose divisibility by \(2^{A_{k+1}}\) forces the depth-\(k\) quotient to be
odd.

Suppose a finite plateau satisfies
\[
r_p=r_{p+1}=\cdots=r_q=r_*
\]
with \(q>p\).

For every
\[
p\le k\le q-1,
\]
there is no injury at \(k\), so
\[
r_{k+1}=r_k=r_*.
\]

Since \(r_*<2^{A_k}\), the congruence modulo \(2^{A_k+1}\) forces
\[
\boxed{R_k=r_*}
\]
for every
\[
p\le k\le q-1.
\]

Hence the same positive integer \(r_*\) realizes the exact valuation prefix
through depth \(q-1\).

At the terminal depth \(q\), equality \(R_q=r_*\) is guaranteed only if
the plateau continues:
\[
r_{q+1}=r_q.
\]

If an injury occurs at \(q\), the terminal exact lift may change.

# G. Strategic consequence

After adding the independent downstream condition
\[
\liminf\rho_r=0
\]
to frozen D0, any surviving non-realizer branch must exhibit:

1. infinitely many injuries;
2. injury spikes reaching the \(\ln3\) ceiling;
3. a subsequence with
   \[
   t_{j+1}/t_j\to\infty;
   \]
4. one fixed positive ordinary integer shadowing essentially every such
   exceptionally long plateau.

This is the precise target for later D1-D/D1-E work.

# H. Scope

No such sparse-injury branch is excluded.

No recursive countermodel is produced.

No Task-8A pressure theorem is used.

No Task-6 repeated-factor theorem is used.

No Sturmian/continued-fraction theorem is used.

No 3-adic endpoint rate is used.

Status:
\[
\boxed{\texttt{[AUDIT CANDIDATE]}}.
\]
