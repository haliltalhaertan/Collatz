# CP20 TASK 8B2 — D1 A/B/C FALSIFICATION REPORT

**Status:** `[AUDIT CANDIDATE SUPPORT]`

- Negative chunk attack: `[FAIL]`; canonical ranges force \(m_k\ge0\).
- Oversized chunk attack: `[FAIL]`; exact range gives \(m_k<2^{a_k}\).
- Unbounded \(a_k\) under bounded critical-log error: `[FAIL]`; one gets
  \(a_k<2+2M\) without any smooth error assumption.
- Old-history dependence of plateau rate: `[FAIL]`; latest injury alone traps
  the residue between adjacent powers \(2^{A_t}\) and \(2^{A_{t+1}}\).
- Merely additive sparse injuries sufficient for zero liminf: `[FAIL]`;
  zero liminf requires a subsequence of multiplicative gaps tending to
  infinity.
- Full terminal plateau exactness: `[FAIL AS STATED]`; if an injury occurs at
  the terminal index \(q\), \(R_q\) may change. The correct theorem is
  \(R_k=r_*\) for \(p\le k\le q-1\).

No D1-D recursive countermodel search was started after the universal theorem
triggered the stop rule.

No D1-E Sturmian/return-word machinery was started.
