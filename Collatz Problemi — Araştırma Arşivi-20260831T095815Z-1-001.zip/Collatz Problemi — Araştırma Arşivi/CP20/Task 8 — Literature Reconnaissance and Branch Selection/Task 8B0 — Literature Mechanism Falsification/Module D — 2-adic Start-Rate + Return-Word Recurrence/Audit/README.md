# CP20 TASK 8B2 — D1 A/B/C AUDIT PACKAGE

Status: `[AUDIT CANDIDATE]`.

Main theorem:
\[
\liminf\rho_r
=
\ln3\liminf(t_j/t_{j+1}).
\]

Thus a zero-rate trough subsequence requires arbitrarily large
multiplicative injury gaps.

Finite plateau lemma:
\[
r_p=\cdots=r_q=r_*
\Rightarrow
R_p=\cdots=R_{q-1}=r_*.
\]

D1-D recursive countermodel search and D1-E Sturmian machinery were not
started because the universal theorem triggered the audit stop.
