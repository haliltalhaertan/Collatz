# CP20 TASK 8B0 — MODULE A TRANSLATION DICTIONARY V2

**Status:** `[FROZEN SUPPORTING DOCUMENT]`

| CP20 odd-only Syracuse | López–Stoll / standard parity |
|---|---|
| \(n_{k+1}=(3n_k+1)/2^{a_k}\) | \(T(x)=x/2\) if even, \(T(x)=(3x+1)/2\) if odd |
| one odd-only step with valuation \(a_k\) | parity block \(1\,0^{a_k-1}\) |
| \(A_k=\sum_{i<k}a_i\) | position \(d_k\) of the \(k\)-th parity one |
| encoding starts from odd \(n_0\) | \(d_0=A_0=0\); general López–Stoll only requires \(d_0\ge0\) |
| \(F_k=\lfloor\alpha k\rfloor\), \(\alpha=\log_2 3\) | critical slope \(\gamma=\ln2/\ln3=1/\alpha\) |
| \(s_k=F_k-A_k\) | relative-height control variable |
| \(h(\ell)=\#\{j<\ell:v_j=1\}\) | same parity prefix height |
| \(h(A_k)=k\) | exact odd-endpoint indexing |
| \(\theta_k=\{\alpha k\}\) | endpoint fractional correction |
| \(r_\ell=h(\ell)-\lceil\gamma\ell\rceil\) | López–Stoll relative height |
| \(r_{A_k}\) | \(\lfloor(s_k+\theta_k)/\alpha\rfloor\) |
| \(s_k=\kappa\log_2k+O(1)\) | \(r_\ell=(\kappa/\alpha)\log_2\ell+O(1)\) |
| last level time \(\ell_j\) | \(\log_2\ell_j=(\alpha/\kappa)j+O(1)\) |
| frozen carry partial sum \(B_k/3^k\) | positive partial sum \(\sum_{j<k}2^{d_j}/3^{j+1}\) |
| \(\Phi_{\mathbb R}(v)\) | \(-\lim B_k/3^k\) |
| \(Z_k=\Phi_{\mathbb R}(S^{A_k}v)\) | real pseudo-orbit value at the \(k\)-th odd position |

## Off-by-one convention

With
\[
h(\ell)=\sum_{j=0}^{\ell-1}v_j,
\]
the digit at position \(A_k\) is the \(k\)-th zero-based parity one, so
\[
h(A_k)=k
\]
and
\[
h(A_k+1)=k+1.
\]

All V2 formulas use \(h(A_k)=k\).

## Level-time existence

The relative-height increment obeys
\[
r_{\ell+1}-r_\ell\in\{-1,0,1\}.
\]
Since critical-log gives \(r_\ell\to+\infty\), every sufficiently large
integer level is attained. Since the relative height eventually exceeds
each fixed level permanently, its last occurrence \(\ell_j\) is finite.

## Result-5 status

`[NOT ESTABLISHED — NOT NEEDED]`.

No asymptotic Result-5 gap-ratio statement is inferred from finite
diagnostics.
