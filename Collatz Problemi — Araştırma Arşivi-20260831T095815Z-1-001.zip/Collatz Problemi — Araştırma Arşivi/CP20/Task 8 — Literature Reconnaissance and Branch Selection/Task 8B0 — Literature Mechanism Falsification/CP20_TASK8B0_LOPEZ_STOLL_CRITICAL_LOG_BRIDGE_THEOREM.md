# CP20 TASK 8B0 — CRITICAL-LOG / LÓPEZ–STOLL REAL-SERIES BRIDGE THEOREM

**Date:** 2026-08-26  
**Status:** `[AUDIT CANDIDATE]`  
**Classification:** `[MAJOR THEOREM CANDIDATE]`

## Theorem

Let
\[
\alpha=\log_2 3,
\quad
F_k=\lfloor\alpha k\rfloor,
\quad
A_k=\sum_{i<k}a_i,
\quad
s_k=F_k-A_k,
\]
where \(a_k\ge1\) are integer odd-only Syracuse valuations.

Assume
\[
s_k=\kappa\log_2 k+O(1)
\]
for some real \(\kappa>0\).

Form the corresponding standard parity word
\[
v=1\,0^{a_0-1}1\,0^{a_1-1}1\,0^{a_2-1}\cdots.
\]

Let
\[
\gamma=\frac{\ln2}{\ln3}=\frac1\alpha.
\]

Then:

### (I) Exact parity-boundary translation

The positions \(d_k\) of the ones of \(v\) satisfy
\[
\boxed{d_k=A_k}.
\]

The standard parity-one density satisfies
\[
\boxed{
\lim_{\ell\to\infty}\frac{h(\ell)}{\ell}
=
\gamma.
}
\]

For the López–Stoll relative height
\[
n_\ell=h(\ell)-\lceil\gamma\ell\rceil,
\]
one has
\[
\boxed{
n_\ell
=
\frac{\kappa}{\alpha}\log_2\ell+O(1).
}
\]

If
\[
\ell_j=\max\{\ell:n_\ell=j\},
\]
then
\[
\boxed{
\log_2\ell_j
=
\frac{\alpha}{\kappa}j+O(1)
}
\]
and
\[
\boxed{
\lim_{j\to\infty}\frac{\ln\ell_j}{j}
=
\frac{\ln3}{\kappa}.
}
\]

### (II) Exact real-series criterion

The López–Stoll real conjugacy series is
\[
\Phi_{\mathbb R}(v)
=
-\sum_{k\ge0}\frac{2^{A_k}}{3^{k+1}}.
\]

Writing
\[
\theta_k=\{\alpha k\},
\]
its \(k\)-th term satisfies exactly
\[
\boxed{
\frac{2^{A_k}}{3^{k+1}}
=
\frac13\,2^{-s_k-\theta_k}.
}
\]

Hence
\[
\boxed{
\Phi_{\mathbb R}(v)\text{ converges absolutely iff }\kappa>1.
}
\]

### (III) Real pseudo-orbit escape for \(\kappa>1\)

Assume now \(\kappa>1\), and write
\[
s_k=\kappa\log_2 k+e_k,
\qquad |e_k|\le M
\]
eventually.

At the \(k\)-th odd parity position define
\[
Z_k=\Phi_{\mathbb R}(S^{A_k}v).
\]

Then
\[
Z_k
=
-\frac13
\sum_{j\ge0}
\frac{2^{A_{k+j}-A_k}}{3^j},
\]
and
\[
\boxed{
\frac{2^{-1-2M}}{3(\kappa-1)}k
\le
-Z_k
\le
\frac{2^{1+2M}}3
\left(1+\frac{k}{\kappa-1}\right)
}
\]
for every sufficiently large \(k\).

Consequently
\[
\boxed{Z_k=-\Theta(k)\to-\infty.}
\]

Furthermore the critical-log law forces \(\sup_k a_k<\infty\) eventually.
For every standard parity time
\[
A_k\le\ell<A_{k+1},
\]
the shifted real pseudo-orbit value is either \(Z_k\), or
\[
\frac{3Z_k+1}{2^{\ell-A_k}}.
\]

Thus
\[
\boxed{
\Phi_{\mathbb R}(S^\ell v)\to-\infty
\qquad(\ell\to\infty).
}
\]

In particular the López–Stoll real pseudo-orbit has no finite accumulation
point.

## Corollary for the frozen CP20 branch

Under the frozen CP20 critical-log hypothesis with \(\kappa>1\):

1. López–Stoll real-series convergence is automatic.
2. Task-8A positive critical density cannot by itself upgrade that convergence
   to real pseudo-orbit accumulation, because the pseudo-orbit escapes to
   \(-\infty\) independently of critical-density statistics.

## Scope

This theorem does **not** imply that a positive ordinary Syracuse realizer
exists or does not exist.

It does **not** prove the Collatz conjecture.

It does **not** convert real-series convergence into a rationality
contradiction.

It does **not** use the parked CP19 high-half/cross-adic mechanism.

It is a bridge/branch-closure theorem for the López–Stoll accumulation route
inside the critical-log class.

Independent zero-trust audit is required before downstream theorem use.
