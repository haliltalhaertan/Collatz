# CP20 TASK 6 — CRITICAL E-SEQUENCE ANALYSIS

## General theorem candidate

Let an infinite positive E-sequence satisfy
\[
A_k
=
\alpha k-\kappa\log_2 k+O(1),
\qquad
\alpha=\log_2 3,
\qquad
\kappa>1.
\]

If it is realized by one positive ordinary orbit, its factor complexity
\(p(r)\) must satisfy
\[
\boxed{
\liminf_{r\to\infty}
\frac{\log_2 p(r)}{r}
\ge
\frac{\alpha}{\kappa}.
}
\]

This follows from:
1. \(n_k=O(k^\kappa)\);
2. repeated valuation factors force
   \(2^{A(W)}\mid(n_v-n_u)\);
3. on comparable index scales,
   \(A(W)\ge\alpha r-O(1)\).

## Zero-critical bounded alphabet

If additionally
\[
1\le a_k\le B
\]
and
\[
a_k\ne
g_k=
\lfloor\alpha(k+1)\rfloor-\lfloor\alpha k\rfloor,
\]
then \(g\) is Sturmian and has \(r+1\) length-\(r\) factors.

Given a \(g\)-factor, every position has at most \(B-1\) allowed valuation
symbols. Hence
\[
p(r)\le(r+1)(B-1)^r.
\]

Therefore an ordinary realization requires
\[
\boxed{
\frac{\alpha}{\kappa}
\le
\log_2(B-1).
}
\]

For \(B=3\),
\[
\boxed{\kappa\ge\alpha}.
\]

Thus every zero-critical \(A_{\max}=3\) critical-logarithmic word with
\[
1<\kappa<\alpha
\]
is \(\Omega\)-divergent, subject to independent audit of the Task-6 proof.

This includes the explicit \(\kappa=1.053\) controller.

## Falsification boundaries

The theorem does not cover:
- eventual periodic words (state repeats can make the spacing difference zero);
- \(\kappa\le1\) (the normalized affine carry need not converge);
- \(B\ge4\) in the present exponent range;
- words that permit critical sites;
- unbounded valuations.

These hypotheses are necessary to the stated argument.
