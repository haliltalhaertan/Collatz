# CP20 TASK 6 — ODD-MODULUS OBSTRUCTION

Let \(M\) be odd.

For any prescribed valuation block \(W\), its affine map modulo \(M\) is
\[
x\mapsto
2^{-Q_W}(3^{|W|}x+C_W)\pmod M.
\]

Since \(2\) is invertible modulo every odd \(M\), this map is defined for
every residue \(x\in\mathbb Z/M\mathbb Z\).

Therefore, for any deterministic infinite valuation/block word and any
initial residue modulo \(M\), recursively applying the prescribed maps
produces an infinite residue path.

So a fixed odd modulus by itself cannot delete a finite valuation word or
make the deterministic block path undefined.

The exact valuation condition is 2-adic; an odd modulus alone does not see
the required divisibility by \(2^{a_k}\).

This reproduces the structural lesson of CP20 Task 3 at block scale:

\[
\boxed{
\text{[FAIL: FIXED ODD MODULUS ALONE DOES NOT OBSTRUCT THE WORD].}
}
\]

The major Task-6 theorem therefore uses ordinary-state spacing under repeated
valuation factors instead of an odd-modulus automaton.
