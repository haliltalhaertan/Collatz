#!/usr/bin/env python3
"""CP20 Task 6: fixed odd-modulus block-map structural check."""

def block_affine(word):
    A=0;B=0
    for a in word:
        B=3*B+(1<<A)
        A+=a
    return A,B

def block_map_mod(x,word,M):
    assert M%2==1
    A,B=block_affine(word)
    return ((pow(3,len(word),M)*x+B)*pow(pow(2,A,M),-1,M))%M

def main():
    blocks=[
        (2,1,2,1,1,2,1,2,1,2,1,3,2,1,2,1,1,2,1,2),
        (1,2,1,3,2,1,2,1,1,2,1,2,1,2,1,3,2,1,2,1),
    ]
    for M in [3,5,7,9,11,13,25,27,35,49,81]:
        for W in blocks:
            # Every residue has a defined outgoing image.
            images=[block_map_mod(x,W,M) for x in range(M)]
            assert len(images)==M
            assert all(0<=y<M for y in images)
        # Any prescribed sequence of block maps has an infinite path
        # by recursive evaluation from any initial residue.
        x=1%M
        for j in range(1000):
            x=block_map_mod(x,blocks[j%len(blocks)],M)
            assert 0<=x<M
    print("CP20 TASK6 MODULUS ENGINE: OK")

if __name__=="__main__":
    main()
