# CP20 TASK 6 — MAJOR ZERO-TRUST ADVERSARIAL AUDIT PROMPT

## Target

Audit the claimed theorem in:

`CP20_TASK6_MAJOR_THEOREM.md`

Do not assume any label, computation, or proof step is correct.

Primary claimed theorem:

> If a positive ordinary odd-only Syracuse orbit has
> \[
> A_k=\alpha k-\kappa\log_2 k+O(1),\quad
> \alpha=\log_2 3,\quad \kappa>1,
> \]
> then its valuation factor complexity satisfies
> \[
> \liminf_{r\to\infty}\frac{\log_2 p_a(r)}r\ge\frac{\alpha}{\kappa}.
> \]
>
> If additionally \(1\le a_k\le B\) and
> \(a_k\ne g_k=\lfloor\alpha(k+1)\rfloor-\lfloor\alpha k\rfloor\),
> then
> \[
> p_a(r)\le(r+1)(B-1)^r.
> \]
> Hence ordinary realization requires
> \[
> \alpha/\kappa\le\log_2(B-1).
> \]
>
> In particular, for \(B=3\) and \(1<\kappa<\alpha\), no positive ordinary
> realization exists.

The explicit CP20 controller has \(B=3\), is zero-critical, and has
\(\kappa=1.053<\alpha\), so it is claimed to be excluded.

## Audit doctrine

Try to break the proof, not confirm it.

Do not trust:
- the controller reconstruction;
- the state-growth lemma;
- the repeated-factor divisibility;
- the factor-complexity quantifiers;
- the Sturmian counting step;
- the use of nonperiodicity;
- the numerical value comparisons;
- any project label.

## Required audit tasks

### 1. Indexing and affine formula

Independently derive
\[
2^{A_k}n_k=3^k n_0+B_k
\]
with the exact convention for \(A_k\) and \(B_k\).

For a local word \(W\) occurring at positions \(u\) and \(v\), independently
derive the two local affine identities and check whether the same \(B_W\)
really appears.

Verify or refute:
\[
2^{A(W)}\mid(n_v-n_u).
\]

Check overlapping occurrences.

### 2. Equal-state loophole

If \(n_u=n_v\), verify whether determinism really forces eventual periodicity
of the valuation word.

Then verify whether
\[
A_k/k\to\log_2 3
\]
indeed rules out eventual periodicity.

Look for any loophole caused by indexing, preperiodic behavior, or a
non-minimal period.

### 3. Polynomial state bound

From
\[
A_k=\alpha k-\kappa\log_2 k+O(1),\quad\kappa>1,
\]
independently prove or refute
\[
n_k=O(k^\kappa).
\]

Audit the normalized affine sum
\[
B_k/3^k
=
\frac13\sum_{j<k}2^{A_j-\alpha j}.
\]

Check:
- sign conventions;
- the \(j=0\) term;
- convergence for \(\kappa>1\);
- whether positivity or a hidden lower bound is needed.

### 4. Local valuation mass

Audit
\[
A(u,r)=A_{u+r}-A_u\ge\alpha r-O(1)
\]
uniformly for \(u\ge r\).

Check whether the \(O(1)\) is genuinely independent of both \(u\) and \(r\).

### 5. Factor-complexity lower bound

Audit every quantifier in the choice
\[
N_r=
\lfloor2^{(\alpha/\kappa-\varepsilon)r}\rfloor.
\]

Verify:
- \(r\ll N_r\);
- enough starting positions exist in \([N_r,2N_r]\);
- state upper bounds are uniform on this interval;
- repeated factors would contradict spacing;
- the conclusion is truly a liminf bound.

Search for a sequence satisfying the hypotheses but with smaller factor
complexity.

### 6. Zero-critical upper complexity

Independently prove that
\[
g_k-1
\]
is Sturmian of irrational slope \(\alpha-1\) and has exactly \(r+1\)
length-\(r\) factors.

Then audit:
\[
p_a(r)\le(r+1)(B-1)^r
\]
under
\[
1\le a_k\le B,\qquad a_k\ne g_k.
\]

Check whether an \(a\)-factor can be associated with multiple \(g\)-factors
in a way that invalidates the upper bound.

### 7. Explicit controller hypotheses

Reconstruct the \(\kappa=1053/1000\) controller independently.

Verify:
- \(a_k\in\{1,2,3\}\);
- \(a_k\ne g_k\) at every site;
- \(s_k=\kappa\log_2 k+O(1)\);
- \(\kappa>1\);
- \(\kappa<\alpha\).

Do not accept finite computation as proof of the \(O(1)\) tracking law.
Audit the 20-step tracking argument or replace it with a rigorous proof.

### 8. Counterexample discipline

Test against:
- the actual \(1\)-cycle \(a_k=2\);
- eventually periodic E-sequences;
- \(\kappa\le1\);
- zero-critical alphabets with \(B=4\);
- finite arbitrarily long zero-sheet runs;
- random bounded zero-critical words.

Explain exactly which hypothesis blocks each apparent counterexample.

### 9. Literature overlap

Check whether the theorem is already contained in:
- SanMin Wang's E-sequence theorems, especially Theorem 4.13;
- older return-word/repeated-pattern Collatz literature;
- exponent-code residue literature;
- symbolic-dynamics complexity results combined with standard Collatz
  congruences.

Novelty is not required for proof validity, but a pre-existing equivalent
theorem must be identified.

### 10. Independent computation

Do not trust the supplied engines.

Reproduce:
- controller word generation;
- at least several thousand exact symbols;
- repeated-factor spacing on genuine finite Syracuse orbits;
- the zero-critical factor-count upper bound on small lengths.

The supplied `CP20_TASK6_REPEAT_SPACING_CHECKS.csv` is only a regression
target.

## Verdict format

Return exactly one primary verdict:

1. `PROOF VALID`
2. `PROOF VALID WITH WORDING REPAIR`
3. `FIXABLE GAP`
4. `MAJOR GAP`
5. `FALSE — COUNTEREXAMPLE`

Separately state:

- Is the factor-complexity lower theorem valid?
- Is the zero-critical \(B=3\) corollary valid?
- Is the exact \(\kappa=1.053\) controller excluded?
- Does the result generalize exactly as claimed?
- Is any step secretly the parked high-half argument?
- Is the theorem already known in the literature?
- Can it be frozen and used downstream?

Do not state Collatz is solved.
