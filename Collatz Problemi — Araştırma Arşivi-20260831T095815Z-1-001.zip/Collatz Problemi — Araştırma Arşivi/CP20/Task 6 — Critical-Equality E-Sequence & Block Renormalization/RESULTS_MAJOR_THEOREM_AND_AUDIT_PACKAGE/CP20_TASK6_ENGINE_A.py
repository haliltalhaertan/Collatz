#!/usr/bin/env python3
"""CP20 Task 6 Engine A: exact controller reconstruction + block/factor diagnostics."""
import math, hashlib, collections

P,Q=1053,1000

def controller_condition(s,n):
    if s<=0:
        return True
    return (1 << (Q*s)) <= pow(n,P)

def generate(K):
    p3=1
    prevF=0
    s=0
    word=[]
    gword=[]
    svals=[0]
    for k in range(K):
        p3*=3
        Fnext=p3.bit_length()-1
        g=Fnext-prevF
        prevF=Fnext
        d=1 if (g==2 and controller_condition(s,max(2,k+1))) else -1
        a=g-d
        assert a in (1,2,3)
        assert a!=g
        word.append(a)
        gword.append(g)
        s+=d
        svals.append(s)
    return word,gword,svals

def factor_complexity(word,r):
    return len({tuple(word[i:i+r]) for i in range(len(word)-r+1)})

def main():
    K=100000
    word,g,svals=generate(K)
    assert sum(a==gg for a,gg in zip(word,g))==0
    assert min(word)==1 and max(word)==3
    sha=hashlib.sha256(bytes(word)).hexdigest()
    assert sha=="31d2db3d10ec0610f1c17fc86a6b485f6e8a378ed7696d5b41ad48e51980e1d2"

    blocks=collections.Counter(tuple(word[i:i+20]) for i in range(0,K,20))
    assert len(blocks)==51

    for r in [8,16,32,64]:
        p=factor_complexity(word,r)
        assert p <= (r+1)*(2**r)
        print("r",r,"observed_p",p,"generic_zero_critical_upper",(r+1)*(2**r))

    print("controller_sha256",sha)
    print("20_block_types",len(blocks))
    print("CP20 TASK6 ENGINE A: OK")

if __name__=="__main__":
    main()
