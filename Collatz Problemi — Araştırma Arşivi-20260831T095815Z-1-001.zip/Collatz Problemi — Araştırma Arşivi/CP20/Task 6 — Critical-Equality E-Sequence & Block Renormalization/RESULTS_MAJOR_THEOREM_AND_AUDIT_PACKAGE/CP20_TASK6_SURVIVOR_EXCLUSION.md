# CP20 TASK 6 — EXPLICIT CONTROLLER EXCLUSION CANDIDATE

Assume the exact CP20 controller with
\[
\kappa=1053/1000
\]
is realized by one fixed positive ordinary Syracuse orbit.

The frozen controller satisfies
\[
s_k=\kappa\log_2 k+O(1),
\]
has
\[
a_k\in\{1,2,3\},
\]
and is zero-critical:
\[
a_k\ne g_k,\qquad g_k=\lfloor\alpha(k+1)\rfloor-\lfloor\alpha k\rfloor.
\]

The Task-6 repeated-factor theorem forces the valuation factor complexity to
have binary entropy at least
\[
\frac{\alpha}{\kappa}
=
1.5051875600\ldots.
\]

But the critical driver \(g\) is Sturmian, with only \(r+1\) factors of
length \(r\). Once a \(g\)-factor is fixed, zero-criticality and
\(a_k\in\{1,2,3\}\) leave at most two choices at each site. Hence
\[
p_a(r)\le(r+1)2^r
\]
and the entropy is at most \(1\).

Since
\[
1.5051875600\ldots>1,
\]
the two requirements are incompatible.

Therefore, if the major theorem passes audit,
\[
\boxed{
\text{the exact }\kappa=1.053\text{ symbolic controller is not LEVEL 3.}
}
\]

Status: `[S2 CONSEQUENCE OF S3 CANDIDATE — AUDIT REQUIRED]`.
