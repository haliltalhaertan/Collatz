#!/usr/bin/env python3
"""
CP20 Task 6 Engine B:
independent repeated-factor spacing checker on genuine finite Syracuse orbits.
"""
import collections

def step(n):
    x=3*n+1
    a=(x & -x).bit_length()-1
    return x>>a,a

def affine(word):
    A=0
    B=0
    for a in word:
        B=3*B+(1<<A)
        A+=a
    return A,B

def verify_one_orbit(n0,max_steps=100,max_r=8):
    states=[]
    vals=[]
    seen=set()
    n=n0
    for _ in range(max_steps):
        if n in seen:
            break
        seen.add(n)
        states.append(n)
        n,a=step(n)
        vals.append(a)
    states.append(n)

    checks=0
    for r in range(1,min(max_r,len(vals))+1):
        pos=collections.defaultdict(list)
        for u in range(len(vals)-r+1):
            pos[tuple(vals[u:u+r])].append(u)
        for W,us in pos.items():
            if len(us)<2:
                continue
            A,B=affine(W)
            for i in range(len(us)):
                for j in range(i+1,len(us)):
                    u,v=us[i],us[j]
                    if states[u]==states[v]:
                        continue
                    # Direct affine relation at both locations.
                    assert (3**r*states[u]+B) == (1<<A)*states[u+r]
                    assert (3**r*states[v]+B) == (1<<A)*states[v+r]
                    assert (states[v]-states[u])%(1<<A)==0
                    checks+=1
    return checks

def main():
    total=0
    for n0 in range(3,5000,2):
        total+=verify_one_orbit(n0)
    assert total>100000
    print("spacing_checks",total)
    print("CP20 TASK6 ENGINE B: OK")

if __name__=="__main__":
    main()
