# COLLATZ CP20 — TASK 6 FINDINGS
## Critical-Equality E-Sequence Divergence • Repeated-Factor Complexity

## Final strategic verdict

\[
\boxed{\textbf{E — [NEW GENERAL CRITICAL-EQUALITY E-SEQUENCE THEOREM]}}
\]

**Audit status:** theorem candidate only. The result is not frozen and must not
be used downstream before independent zero-trust audit.

## What changed

Task 6 found a genuinely different global invariant.

The proof does not classify high 2-adic endpoint bits.

Instead it uses exact **repeated valuation factors**.

If the same valuation word \(W\) occurs at two positions \(u<v\) of one
actual Syracuse orbit, then subtracting the two identical affine word maps
gives
\[
\boxed{
2^{A(W)}\mid(n_v-n_u).
}
\]

Thus two distinct ordinary states carrying the same long valuation factor
must be separated by at least \(2^{A(W)}\).

## Critical-logarithmic state law

Under
\[
A_k=\alpha k-\kappa\log_2 k+O(1),\qquad\kappa>1,
\]
the exact affine sum gives
\[
\boxed{n_k=O(k^\kappa).}
\]

For factors of length \(r\) starting at comparable large indices,
\[
A(W)\ge\alpha r-O(1).
\]

Hence an actual polynomially growing orbit cannot repeat length-\(r\)
valuation factors too often.

The resulting factor-complexity theorem is
\[
\boxed{
\liminf_{r\to\infty}
\frac{\log_2 p_a(r)}r
\ge
\frac{\alpha}{\kappa}.
}
\]

## General zero-critical bounded-valuation theorem

Let
\[
g_k=
\lfloor\alpha(k+1)\rfloor-\lfloor\alpha k\rfloor.
\]

The word \(g_k-1\) is Sturmian, so
\[
p_g(r)=r+1.
\]

If
\[
1\le a_k\le B,\qquad a_k\ne g_k,
\]
then for each \(g\)-factor there are at most \(B-1\) valuation choices at
each position:
\[
p_a(r)\le(r+1)(B-1)^r.
\]

Therefore ordinary realization requires
\[
\boxed{
\frac{\alpha}{\kappa}
\le
\log_2(B-1).
}
\]

For \(B=3\):
\[
\boxed{\kappa\ge\alpha.}
\]

So, subject to audit,
\[
\boxed{
1<\kappa<\log_2 3,\quad
a_k\in\{1,2,3\},\quad
a_k\ne g_k
}
\]
is incompatible with one fixed positive ordinary LEVEL-3 realization.

## Explicit controller

The exact controller has
\[
\kappa=1053/1000=1.053,
\]
\[
a_k\in\{1,2,3\},
\qquad
a_k\ne g_k,
\]
and
\[
s_k=\kappa\log_2 k+O(1).
\]

Numerically,
\[
\frac{\alpha}{\kappa}
=
1.505187560039084\ldots>1.
\]

The ordinary-realization lower entropy is therefore \(>1\) bit/symbol,
whereas the zero-critical \(B=3\) language has entropy at most
\(1\) bit/symbol.

Hence the exact controller is excluded if the theorem passes audit.

## Certified computational checks

These are checks, not proof:

- two independent exact controller generators agree on 100000 symbols;
- controller word SHA256:
  `31d2db3d10ec0610f1c17fc86a6b485f6e8a378ed7696d5b41ad48e51980e1d2`;
- zero-critical violations: 0;
- 51 aligned 20-step block types observed in the first 100000 symbols;
- 753763 exact repeated-factor spacing relations were independently checked
  on genuine finite Syracuse orbit segments;
- observed controller factor complexity is far below the general
  \((r+1)2^r\) upper bound.

## Falsification boundaries

The proof correctly does not cover:

- eventually periodic words such as \(a_k=2\);
- \(\kappa\le1\);
- \(B\ge4\) in the present exponent range;
- words with critical sites;
- unbounded valuation escape regimes.

Finite long zero-sheet runs remain possible and do not contradict the
theorem.

## Literature position

SanMin Wang proves several \(\Omega\)-divergence classes, including:
- strict mean valuation above \(\log_2 3\);
- special mechanical words;
- a repeated-prefix theorem with additional hypotheses.

Those statements do not directly supply the Task-6 arbitrary
repeated-factor / polynomial-state complexity theorem.

A targeted search also found the 2026 2–3–infinity exponent-code diagnostic
work, which gives necessary residue-rate conditions but not the present
factor-complexity bound.

Formal novelty is **not certified** and is an explicit audit item.

## Required answers

- Is the exact \(\kappa=1.053\) controller excluded?
  **`[THEOREM CANDIDATE: YES]`, pending audit.**

- Is \(m_k\ne0\) infinitely often proved?
  The theorem excludes any ordinary LEVEL-3 realization without needing to
  prove the sheet statement directly. Under the Task-4 implication, an
  ordinary polynomial realizer would eventually have zero sheets, so the
  exclusion indirectly rules out that possibility if audited.

- Is \(R(k)=o(k)\) proved?
  **No.** It is no longer needed for controller exclusion.

- Did a genuinely compressed invariant appear?
  **Yes:** repeated-factor ordinary spacing + symbolic factor complexity.

- Does it generalize beyond the controller?
  **Yes:** to the stated zero-critical bounded-\(B\) class with the entropy
  inequality
  \[
  \alpha/\kappa\le\log_2(B-1).
  \]

- Does any step use normality/equidistribution?
  **No.**

- Does it reduce to the parked CP19 high-half barrier?
  **No.** No growing endpoint-bit state is propagated.

- Is Collatz solved?
  **No.**

## Stop decision

A new load-bearing general theorem candidate appeared.

Per research doctrine, normal Task-6 research stops here.

Next action:
\[
\boxed{\textbf{INDEPENDENT MAJOR ZERO-TRUST AUDIT}}
\]

Do not proceed to CP20 Task 7 or combine this theorem with other branches
until the audit returns a valid verdict.
