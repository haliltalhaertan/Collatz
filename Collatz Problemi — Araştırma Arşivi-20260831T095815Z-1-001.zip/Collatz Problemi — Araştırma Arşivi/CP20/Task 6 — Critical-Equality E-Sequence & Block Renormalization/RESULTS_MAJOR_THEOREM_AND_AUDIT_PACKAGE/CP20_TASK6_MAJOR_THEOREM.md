# CP20 TASK 6 — MAJOR THEOREM CANDIDATE
## Repeated-Factor Spacing and Factor-Complexity Obstruction

### Status
`[NEW GENERAL CRITICAL-EQUALITY E-SEQUENCE THEOREM CANDIDATE — AUDIT REQUIRED]`

This theorem is not frozen. It must pass an independent adversarial audit before
being used downstream.

---

## 1. Setup

Let
\[
n_{k+1}=\frac{3n_k+1}{2^{a_k}}
\]
be a positive odd-only Syracuse orbit, with positive valuations \(a_k\).

Define
\[
A_k=\sum_{i=0}^{k-1}a_i,\qquad
\alpha=\log_2 3,\qquad
F_k=\lfloor \alpha k\rfloor,
\]
and
\[
s_k=F_k-A_k.
\]

Let \(p_a(r)\) denote the factor complexity of the infinite valuation word:
the number of distinct length-\(r\) factors occurring in
\[
a_0a_1a_2\cdots.
\]

Assume
\[
\boxed{
s_k=\kappa\log_2 k+O(1)
}
\]
for some \(\kappa>1\).

---

## 2. Lemma A — polynomial state bound

The exact affine identity is
\[
2^{A_k}n_k=3^k n_0+B_k,
\]
where
\[
B_k=\sum_{j=0}^{k-1}3^{k-1-j}2^{A_j}.
\]

Hence
\[
\frac{B_k}{3^k}
=
\frac13\sum_{j=0}^{k-1}2^{A_j-\alpha j}.
\]

Because
\[
A_j-\alpha j
=
-s_j-\{\alpha j\}
=
-\kappa\log_2 j+O(1),
\]
we have
\[
2^{A_j-\alpha j}=O(j^{-\kappa}).
\]

Since \(\kappa>1\),
\[
\sum_j j^{-\kappa}<\infty.
\]

Therefore
\[
\frac{B_k}{3^k}=O(1).
\]

Also
\[
\frac{3^k}{2^{A_k}}
=
2^{\alpha k-A_k}
=
2^{s_k+\{\alpha k\}}
=
O(k^\kappa).
\]

Thus
\[
\boxed{
n_k=O(k^\kappa).
}
\]

This uses only the exact affine recurrence and \(\kappa>1\).

---

## 3. Lemma B — repeated-factor spacing

Suppose the same length-\(r\) valuation word
\[
W=(a_u,\ldots,a_{u+r-1})
=
(a_v,\ldots,a_{v+r-1})
\]
occurs at two positions \(u<v\).

Let
\[
A(W)=\sum_{i=0}^{r-1}W_i
\]
and let \(B_W\) be its local affine numerator.

Then
\[
2^{A(W)}n_{u+r}=3^r n_u+B_W,
\]
and
\[
2^{A(W)}n_{v+r}=3^r n_v+B_W.
\]

Subtracting,
\[
2^{A(W)}(n_{v+r}-n_{u+r})
=
3^r(n_v-n_u).
\]

Since
\[
\gcd(2^{A(W)},3^r)=1,
\]
we get
\[
\boxed{
2^{A(W)}\mid (n_v-n_u).
}
\]

If \(n_u\neq n_v\), then
\[
\boxed{
|n_v-n_u|\ge 2^{A(W)}.
}
\]

If \(n_u=n_v\), determinism makes the orbit periodic from time \(u\), hence
the valuation word is eventually periodic. But an eventually periodic
valuation word has rational limiting mean valuation, whereas
\[
\frac{A_k}{k}\to\alpha=\log_2 3
\]
is irrational. Therefore under the present hypotheses \(n_u=n_v\) is
impossible.

So every repeated factor satisfies the strict spacing bound.

---

## 4. Lemma C — local valuation mass in a critical logarithmic window

Write
\[
A(u,r)=A_{u+r}-A_u.
\]

For \(u\ge r\) and sufficiently large \(u\),
\[
A(u,r)
=
F_{u+r}-F_u-(s_{u+r}-s_u).
\]

Since
\[
F_{u+r}-F_u\ge \alpha r-1
\]
and
\[
s_{u+r}-s_u
=
\kappa\log_2\frac{u+r}{u}+O(1)
=
O(1)
\]
uniformly for \(r\le u\), there exists a fixed constant \(C_A\) such that
\[
\boxed{
A(u,r)\ge \alpha r-C_A.
}
\]

---

## 5. Theorem — factor-complexity lower entropy

For every \(\varepsilon>0\), choose
\[
N_r=
\left\lfloor
2^{(\alpha/\kappa-\varepsilon)r}
\right\rfloor.
\]

For large \(r\), \(r\ll N_r\).

Consider the length-\(r\) valuation factors starting at
\[
u\in[N_r,2N_r-r].
\]

If two of these factors were equal, Lemmas B and C would give
\[
|n_v-n_u|
\ge
2^{\alpha r-C_A}.
\]

But Lemma A gives
\[
|n_v-n_u|
\le
O(N_r^\kappa)
=
2^{(\alpha-\kappa\varepsilon)r+O(1)}.
\]

For sufficiently large \(r\),
\[
2^{(\alpha-\kappa\varepsilon)r+O(1)}
<
2^{\alpha r-C_A},
\]
a contradiction.

Hence all these factors are distinct, so
\[
p_a(r)\ge N_r-r.
\]

Therefore
\[
\boxed{
\liminf_{r\to\infty}
\frac{\log_2 p_a(r)}{r}
\ge
\frac{\alpha}{\kappa}.
}
\]

Interpretation: a positive ordinary orbit with critical logarithmic
discrepancy and \(\kappa>1\) must have exponentially many distinct valuation
factors.

---

## 6. Zero-critical bounded-valuation corollary

Define the critical Beatty word
\[
g_k=F_{k+1}-F_k\in\{1,2\}.
\]

Since
\[
g_k-1
=
\lfloor (k+1)(\alpha-1)\rfloor
-
\lfloor k(\alpha-1)\rfloor,
\]
the word \(g\) is Sturmian. Its exact factor complexity is
\[
\boxed{p_g(r)=r+1.}
\]

Assume now that
\[
1\le a_k\le B
\]
and
\[
a_k\ne g_k
\quad\text{for every }k.
\]

For any fixed length-\(r\) factor of \(g\), each site has at most \(B-1\)
possible valuation symbols. Hence
\[
\boxed{
p_a(r)\le (r+1)(B-1)^r.
}
\]

Combining with the factor-complexity lower theorem,
\[
\boxed{
\frac{\alpha}{\kappa}
\le
\log_2(B-1).
}
\]

Equivalently, any ordinary realization must satisfy
\[
\boxed{
\kappa
\ge
\frac{\alpha}{\log_2(B-1)}
}
\]
when \(B>2\).

---

## 7. The \(B=3\) theorem

For
\[
a_k\in\{1,2,3\},
\qquad
a_k\ne g_k,
\]
we have
\[
\log_2(B-1)=1.
\]

Thus an ordinary realization would require
\[
\boxed{\kappa\ge\alpha=\log_2 3.}
\]

Therefore:

\[
\boxed{
1<\kappa<\log_2 3
\quad\Longrightarrow\quad
\text{no positive ordinary LEVEL-3 realization.}
}
\]

This excludes every zero-critical \(A_{\max}=3\) critical-logarithmic
E-sequence in this exponent range.

---

## 8. Explicit CP20 controller

The frozen exact controller has

\[
\kappa=\frac{1053}{1000}=1.053,
\]
\[
a_k\in\{1,2,3\},
\]
\[
a_k\ne g_k
\quad\text{for every }k,
\]
and
\[
s_k=\kappa\log_2 k+O(1).
\]

Numerically,
\[
\alpha=\log_2 3
=
1.584962500721156\ldots
\]
and
\[
\frac{\alpha}{\kappa}
=
1.505187560039084\ldots>1.
\]

The lower theorem requires factor entropy at least
\(1.50518\ldots\) bits/symbol, while the zero-critical \(A_{\max}=3\)
language permits at most \(1\) bit/symbol.

Contradiction.

Hence, subject to independent audit,

\[
\boxed{
\text{the exact }\kappa=1.053\text{ controller has no positive ordinary LEVEL-3 realizer.}
}
\]

---

## 9. Scope

This theorem does **not** prove Collatz.

It does not cover:

- valuation alphabets with \(B\ge4\) in the relevant \(\kappa>1\) range;
- words with critical sites \(a_k=g_k\);
- unbounded valuations;
- arbitrary high-state words without the critical logarithmic discrepancy law.

It is a general theorem for the stated zero-critical bounded-\(3\) class.

---

## 10. Audit status

\[
\boxed{
\textbf{UNAUDITED LOAD-BEARING THEOREM CANDIDATE}
}
\]

Do not use downstream until a zero-trust independent audit returns a valid
verdict.
