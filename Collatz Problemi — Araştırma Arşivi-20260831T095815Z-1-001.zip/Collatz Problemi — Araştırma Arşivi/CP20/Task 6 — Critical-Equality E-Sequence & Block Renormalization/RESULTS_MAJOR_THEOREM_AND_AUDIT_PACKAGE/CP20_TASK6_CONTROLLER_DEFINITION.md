# CP20 TASK 6 — CONTROLLER DEFINITION

## Exact frozen controller

Let
\[
\alpha=\log_2 3,\qquad
F_k=\lfloor\alpha k\rfloor,\qquad
g_k=F_{k+1}-F_k\in\{1,2\}.
\]

Let
\[
\kappa=\frac{1053}{1000}.
\]

The controller carries an integer discrepancy state \(s_k\), with \(s_0=0\).
At step \(k\), put
\[
q_k=
\left\lfloor
\kappa\log_2\max(2,k+1)
\right\rfloor.
\]

Because \(s_k\) is an integer,
\[
s_k\le \kappa\log_2\max(2,k+1)
\iff
s_k\le q_k.
\]

The exact update is
\[
d_k=
\begin{cases}
+1,&g_k=2\text{ and }s_k\le q_k,\\
-1,&\text{otherwise},
\end{cases}
\]
\[
a_k=g_k-d_k,
\qquad
s_{k+1}=s_k+d_k.
\]

Therefore exactly:
- if \(g_k=1\), then \(a_k=2\);
- if \(g_k=2\), then \(a_k\in\{1,3\}\).

Hence
\[
\boxed{a_k\in\{1,2,3\}}
\]
and
\[
\boxed{a_k\ne g_k\quad\forall k.}
\]

This is the zero-critical property.

## Exact rational threshold form

The gain condition is equivalent to
\[
(k+1)^{1053}\ge 2^{1000s_k}
\]
for \(k+1\ge2\).

No floating-point comparison is required.

Two independent exact generators were run to \(K=100000\) and produced the
same word, with SHA256

`31d2db3d10ec0610f1c17fc86a6b485f6e8a378ed7696d5b41ad48e51980e1d2`.

## Bounded tracking lemma

Let
\[
z_k=s_k-q_k.
\]

For \(k\ge2\),
\[
q_{k+1}-q_k\in\{0,1\}.
\]

Also \(z_k\le1\): if \(z_k\le0\) and \(g_k=2\), a gain can increase \(z\) by
at most one; every other move decreases it.

For \(k\ge100\),
\[
q_{k+20}-q_k\le1.
\]

In any 20 consecutive positions,
\[
F_{k+20}-F_k\in\{31,32\},
\]
so the block contains 11 or 12 sites with \(g=2\), and 9 or 8 sites with
\(g=1\).

On a 20-step interval in which \(z_i\le0\) throughout, every \(g=2\) step is
a gain and every \(g=1\) step is a loss. Thus the net \(s\)-increment is at
least \(2\), while \(q\) increases by at most \(1\). Therefore
\[
z_{k+20}\ge z_k+1.
\]

A negative episode can drop by at most \(2\) per single step. Hence its
lowest point occurs within a uniformly bounded initial part of the episode.
A coarse bound such as
\[
-41\le z_k\le1
\]
for all sufficiently large \(k\) follows.

Therefore
\[
\boxed{
s_k=\kappa\log_2 k+O(1).
}
\]

Consequently
\[
A_k=F_k-s_k
=
\alpha k-\kappa\log_2 k+O(1).
\]

## 20-step macro-block reconnaissance

The 20-step scale is useful because its critical driver contains a strict
surplus of \(g=2\) sites.

In the first 100000 exact controller symbols:
- 51 distinct aligned 20-step valuation blocks occur;
- the dominant \((Q,\Delta s,G)\) classes are
  \[
  (32,0,32),\ (31,0,31),\ (30,2,32),\ (33,-2,31).
  \]
- two initial exceptional classes also occur.

The 51-row certified table is in
`CP20_TASK6_BLOCK_TYPE_TABLE.csv`.

The major Task-6 theorem does not rely on this finite classification.
