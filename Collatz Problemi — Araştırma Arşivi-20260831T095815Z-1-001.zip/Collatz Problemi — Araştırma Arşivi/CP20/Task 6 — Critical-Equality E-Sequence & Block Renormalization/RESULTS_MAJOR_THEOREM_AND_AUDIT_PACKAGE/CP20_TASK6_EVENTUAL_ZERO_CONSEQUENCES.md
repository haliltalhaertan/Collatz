# CP20 TASK 6 — EVENTUAL-ZERO CONSEQUENCES

Assume the sheet process is eventually zero. Then after some index the
canonical endpoint is an actual positive Syracuse tail.

The decisive exact consequence is not a fixed-modulus residue condition but
a repeated-factor spacing law.

If a valuation word \(W\) of length \(r\), total valuation \(A(W)\), and
affine numerator \(B_W\) occurs at positions \(u<v\), then
\[
2^{A(W)}n_{u+r}=3^r n_u+B_W,
\]
\[
2^{A(W)}n_{v+r}=3^r n_v+B_W.
\]

Subtracting:
\[
2^{A(W)}(n_{v+r}-n_{u+r})
=
3^r(n_v-n_u).
\]

Hence
\[
\boxed{
2^{A(W)}\mid(n_v-n_u).
}
\]

Under
\[
A_k=\alpha k-\kappa\log_2 k+O(1),
\qquad
\kappa>1,
\]
the actual states satisfy
\[
n_k=O(k^\kappa).
\]

For factors starting at comparable large indices and length \(r\),
\[
A(W)=\alpha r+O(1).
\]

Thus a repeated long factor forces two polynomially sized states to differ by
a multiple of size about
\[
2^{\alpha r}=3^r.
\]

This yields the factor-complexity lower theorem in
`CP20_TASK6_MAJOR_THEOREM.md`.

## Why this is genuinely different from the parked high-half branch

The argument never asks for a sampled high binary digit or an
\(O(r)\)-bit Hensel state.

It uses only:
- the local affine word map;
- ordinary integer subtraction;
- coprimality of powers of 2 and 3;
- global polynomial state size;
- symbolic factor counts.

No growing endpoint-bit state is propagated.
