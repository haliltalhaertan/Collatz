# CP20 TASK 6 — BLOCK RENORMALIZATION

For a finite valuation block
\[
W=(a_0,\ldots,a_{L-1}),
\]
put
\[
Q_W=\sum_{i=0}^{L-1}a_i
\]
and
\[
C_W=\sum_{j=0}^{L-1}3^{L-1-j}2^{A_j(W)}.
\]

If the block is followed by an actual zero-sheet Syracuse segment, then
\[
\boxed{
N_{\rm out}
=
\frac{3^L N_{\rm in}+C_W}{2^{Q_W}}.
}
\]

For \(L=20\), each observed controller macro-block therefore gives one exact
rational affine map.

The first 100000 controller symbols contain 51 aligned 20-step block types.
The full certified list and exact \(Q_W,C_W\) values are in
`CP20_TASK6_BLOCK_TYPE_TABLE.csv`.

## Renormalization search result

The block maps themselves did not produce a bounded-dimensional arithmetic
state that excludes the controller.

Repeated block/factor occurrences instead produced a stronger invariant:
if the same valuation word \(W\) occurs at two positions of one actual orbit,
subtracting the two affine equations gives
\[
\boxed{
2^{Q_W}\mid(n_v-n_u).
}
\]

This repeated-factor spacing law is the load-bearing Task-6 mechanism.
It does not require tracking the binary endpoint state.

Normal block-automaton research was stopped after this theorem appeared, as
required by the Task-6 audit rule.
