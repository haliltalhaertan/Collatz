# CP20 TASK 1 — INDEPENDENT ADVERSARIAL MAJOR AUDIT PROMPT

## ROLE

You are the independent zero-trust mathematical auditor for CP20 Task 1.
Your job is to break the claimed truncated quantile packing / state-excursion
dichotomy if possible.

Do not trust the labels, scripts, decimals, or CP20 self-checks.
The frozen CP19 Task-4 weighted cylinder theorem may be used only after checking
that CP20's subset specialization really follows from its hypotheses.

## CLAIM UNDER AUDIT

The candidate package claims:

1. For any subset `G` of window starts with `n_v<=H`,

\[
|G|\le {H\over2}\sum_{W\in C_G}2^{-A(W)}+|C_G|.
\]

2. With `ell=c log_2 N+o(log N)`, `U=(mu+o(1))ell`, `1<mu<2`,

\[
|G_N|\le N^{\rho+o(1)},
\qquad
\rho=\max\{ch(\mu),\kappa-c\eta(\mu)\}.
\]

3. The optimized values are

\[
c_*=\kappa/\mu,
\qquad
\rho_*=\kappa h(\mu)/\mu,
\qquad
\kappa_*(\mu)=\mu/h(\mu).
\]

4. For `mu=alpha+sigma`, the high-window alternative implies a negative
` s ` excursion of order `sigma ell`, and CP17 carry converts HIGH STATE to
high positive `s_v`.

5. Therefore all but a polynomially small set of starts satisfy the stated
HIGH-STATE / NEGATIVE-EXCURSION morphology.

## REQUIRED ATTACKS

### A. Exact cylinder arithmetic
- independently derive the affine numerator recursion;
- verify exact word depth is `A+1`;
- verify the residue is unique and odd;
- test `H<2^{A+1}` and the necessity of `+1`;
- check repeated words, overlapping windows and boundary starts;
- identify exactly where injectivity is used.

### B. Composition asymptotics
- independently prove `P_ell(U)=C(U,ell)`;
- audit the truncated weighted sum `Z_ell(U)` for `1<mu<2`;
- check monotonicity/dominant endpoint and all `o(ell)` perturbations;
- verify base-2 exponent conversion.

### C. Exponent optimization
- rederive `rho` without copying;
- verify the global minimum over admissible `c>0`;
- check floor `ell=floor(c log_2 N)` and the last `O(log N)` starts;
- verify `kappa_*(alpha)=1.0526808586...` independently.

### D. Quantile logic
- ensure the theorem only bounds LOW-STATE AND LOW-WINDOW starts;
- reject any hidden upgrade to ordinary-most HIGH STATE;
- verify exceptional proportion is `N^{-delta+o(1)}` only when `rho<1`.

### E. Discrepancy transfer
- independently derive
  `F_{v+ell}-F_v=floor(alpha ell+{alpha v})`;
- check strict/non-strict inequalities and floor constants;
- verify that `mu=alpha` gives only `O(1)`, not an order-log excursion.

### F. CP17 carry transfer
- audit uniformity of the CP17 `X_k` bound for all `k<=2N`;
- check the exponent `(theta+eps) log_2 log N` and all `n_0` constants;
- verify the implication direction HIGH STATE => high `s`.

### G. Symbolic-survivor consistency
- independently verify the 20-block construction:
  every 20-block has 11 or 12 `g=2` positions;
- verify the selected-block controller gives `s_k=kappa log_2 k+O(1)`;
- verify all valuations are positive and in `{1,2,3}`;
- verify `a_k!=g_k` everywhere;
- verify `X_infinity<infinity` for `kappa>1`;
- verify CP18 occupation pressure is not contradicted;
- keep LEVEL 2 versus LEVEL 3 distinct.

### H. Ordinary-state search scope
- check the band-packing lemma;
- determine whether CP20 overlooked an elementary argument that actually
  excludes the HIGH-STATE branch;
- do not use the parked CP19 high-half/Hensel branch under renamed variables.

## COUNTEREXAMPLE SEARCH

Implement an independent exact checker.  Search small odd Syracuse segments,
all small positive valuation compositions, arbitrary subsets, state-height
bands, and adversarial symbolic schedules.

A single soundness counterexample makes the relevant theorem FALSE.

## REQUIRED VERDICT

Choose exactly one:

- `PROOF VALID`
- `PROOF VALID WITH WORDING REPAIR`
- `FIXABLE GAP`
- `GAP`
- `FALSE / COUNTEREXAMPLE`

If valid, state precisely which part is genuinely new versus a corollary of
frozen CP19 Task 4.

Do not call Collatz solved.  Do not freeze CP20 Task 1 unless the audit passes.
