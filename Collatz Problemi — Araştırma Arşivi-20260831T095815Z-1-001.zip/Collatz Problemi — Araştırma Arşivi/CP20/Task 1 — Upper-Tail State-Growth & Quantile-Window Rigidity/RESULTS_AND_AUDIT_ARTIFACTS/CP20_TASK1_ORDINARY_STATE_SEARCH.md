# CP20 TASK 1 — ORDINARY-STATE ARITHMETIC SEARCH

## Outcome

[LEAD] one exact multiband extension.

[FAIL] no ordinary-state exclusion of the HIGH-STATE branch was found.

No parked 2-adic high-bit mechanism is used here.

## 1. Exact state-band packing lemma

Let `G_{L,H}` be selected starts satisfying

\[
L<n_v\le H.
\]

For a fixed valuation word `W` with modulus

\[
q_W=2^{A(W)+1},
\]

the number of integers in its exact cylinder lying in an interval of length
`H-L` is at most

\[
{H-L\over q_W}+1.
\]

Hence, by injectivity,

\[
\boxed{
|G_{L,H}|
\le {H-L\over2}\sum_{W\in C_G}2^{-A(W)}+|C_G|.
}
\]

If `A(W)<=U`, then

\[
\boxed{
|G_{L,H}|
\le {H-L\over2}Z_\ell(U)+P_\ell(U).
}
\]

This permits a dyadic decomposition of actual state heights rather than one
global maximum.

## 2. Why the multiband lemma does not yet close the branch

Summing over height bands introduces a separate `+P_ell(U)` occupancy term per
active band.  Without an independent upper-tail theorem controlling how many
bands are occupied, or how the word families correlate with height, the sum
does not exclude a survivor that simply lives in a superlinear band.

The explicit high-turnover symbolic schedule in
`CP20_TASK1_ADVERSARIAL_SCHEDULES.md` demonstrates exactly this escape at the
necessary-condition level.

## 3. Local descent/recovery search

The exact recurrence allows:

- `a=1`: approximately `3/2` multiplicative growth;
- `a=2`: approximately `3/4` descent;
- `a=3`: approximately `3/8` stronger descent.

The adversarial schedule uses all three while maintaining
`s_k=kappa log k+O(1)`.  Thus simple claims such as "a positive fraction of
superlinear states forces long low-valuation runs" are false without an
additional structural hypothesis.

## 4. Mean-valuation attack

Because

\[
A_k=F_k-s_k,
\]

any schedule with `s_k=O(log k)` still has mean valuation `alpha+o(1)`.
Therefore a global mean-valuation constraint cannot distinguish a
near-linear state regime from the superlinear symbolic regime.

## 5. Multiscale quantile attack

No exact inequality was found that links the state quantiles of `[N,2N)` and
`[2N,4N)` strongly enough to exclude exponent `kappa>1` using only
injectivity, the recurrence, and frozen carry control.  Finite-cylinder
realizability continues to defeat any purely local claim.

## 6. Archimedean affine endpoint search

The exact affine identity over a block,

\[
2^{A(v,\ell)}n_{v+\ell}=3^\ell n_v+B_{v,\ell},
\]

provides useful upper/lower comparisons but, for high-turnover words with
`A(v,ell)=alpha ell+O(1)`, both multiplicative factors are order one.  It does
not force a high state back below `N^kappa`.

## Verdict for T4

\[
\boxed{
\text{ORDINARY-STATE EXCLUSION: [OPEN].}
}
\]

The exact multiband lemma is worth retaining for a later independent branch,
but CP20 Task 1 does not use it to claim Side-B closure.
