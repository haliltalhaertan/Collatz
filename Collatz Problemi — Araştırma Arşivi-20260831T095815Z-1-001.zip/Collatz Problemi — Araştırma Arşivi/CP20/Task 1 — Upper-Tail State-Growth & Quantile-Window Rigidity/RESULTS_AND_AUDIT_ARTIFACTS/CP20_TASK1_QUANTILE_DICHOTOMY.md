# CP20 TASK 1 — QUANTILE-WINDOW DICHOTOMY

## Status

[MAJOR LOAD-BEARING THEOREM CANDIDATE — AUDIT REQUIRED]

The exact cylinder mechanism is inherited from frozen CP19 Task 4.  The new
CP20 consequence is the truncated/quantile asymptotic statement.

## Theorem candidate

Fix

\[
1<\mu<2,\qquad \kappa>0,\qquad c>0.
\]

Let

\[
\ell=\lfloor c\log_2N\rfloor,
\]

and let

\[
U_N=\lfloor \mu\ell+r_N\rfloor,
\qquad r_N=o(\ell).
\]

For a positive injective odd-only Syracuse orbit define

\[
G_N=
\{v\in[N,2N-\ell]:
 n_v\le N^\kappa,
\ A(v,\ell)\le U_N\}.
\]

Then

\[
\boxed{
|G_N|\le N^{\rho(\kappa,\mu,c)+o(1)},
}
\]

where

\[
\boxed{
\rho(\kappa,\mu,c)=
\max\{c h(\mu),\kappa-c\eta(\mu)\}.
}
\]

The last `ell-1=O(log N)` starts of `[N,2N)` may be added to the exceptional
set without changing the exponent.

Consequently, all but `N^{rho+o(1)}` starts in the dyadic block satisfy at
least one of

\[
\boxed{n_v>N^\kappa}
\]

or

\[
\boxed{A(v,\ell)>\mu\ell+o(\ell)}.
\]

## Optimized form

With

\[
c_*=\kappa/\mu,
\]

one obtains

\[
\boxed{
|G_N|\le N^{\rho_*+o(1)},
\qquad
\rho_*={\kappa h(\mu)\over\mu}.
}
\]

If

\[
\kappa<\kappa_*(\mu)={\mu\over h(\mu)},
\]

then `rho_*<1`, and the exceptional **proportion** is polynomially small:

\[
\boxed{
{ |G_N|\over N}
\le N^{-\delta+o(1)},
\qquad
\delta=1-{\kappa h(\mu)\over\mu}>0.
}
\]

Thus Task 4's maximum-state hypothesis has genuinely been upgraded:
low-state starts cannot be numerous **simultaneously** with low-total-valuation
windows.  One giant state outlier is no longer the relevant escape.

## What this theorem does NOT say

It does **not** by itself prove

\[
\#\{v\in[N,2N):n_v>N^\kappa\}=N-o(N).
\]

The high-valuation-window alternative may itself occupy many starts.  A
separate theorem controlling that alternative would be required before one
could claim ordinary-most superlinear state growth.
