#!/usr/bin/env python3
from fractions import Fraction
from math import comb
import random, csv
from pathlib import Path
OUT = Path(__file__).resolve().parent

def syr_step(n:int):
    assert n>0 and n%2==1
    m=3*n+1
    a=(m & -m).bit_length()-1
    return m>>a, a

def word_of(n:int, ell:int):
    w=[]
    for _ in range(ell):
        n,a=syr_step(n); w.append(a)
    return tuple(w)

def affine_B(word):
    A=B=0
    for a in word:
        B=3*B+(1<<A); A+=a
    return A,B

def cylinder_residue(word):
    ell=len(word); A,B=affine_B(word); q=1<<(A+1)
    rho=((1<<A)-B)*pow(pow(3,ell),-1,q)%q
    return rho,q,A,B

def compositions(total,length):
    if length==1:
        yield (total,); return
    for first in range(1,total-length+2):
        for tail in compositions(total-first,length-1):
            yield (first,)+tail

def verify_cylinders():
    rows=[]
    for ell in range(1,6):
        for A in range(ell,min(12,ell+7)+1):
            nwords=nlifts=0
            for w in compositions(A,ell):
                rho,q,AA,B=cylinder_residue(w); assert AA==A and rho%2==1
                for m in range(8):
                    n=rho+m*q
                    if n>0:
                        assert word_of(n,ell)==w,(w,n,rho,q,word_of(n,ell)); nlifts+=1
                nwords+=1
            rows.append(("cylinder",ell,A,nwords,nlifts,"PASS"))
    return rows

def orbit_segment(n0,steps):
    arr=[]; seen=set(); n=n0
    for _ in range(steps):
        if n in seen: break
        seen.add(n); arr.append(n); n,_=syr_step(n)
    return arr

def h1_bound(segment,ell,H,selected_idx=None):
    starts=list(range(0,len(segment)-ell+1))
    if selected_idx is not None: starts=[v for v in starts if v in selected_idx]
    G=[v for v in starts if segment[v]<=H]
    by={}
    for v in G:
        w=word_of(segment[v],ell); by.setdefault(w,[]).append(segment[v])
    rhs=Fraction(0,1)
    for w,states in by.items():
        A=sum(w); rhs += Fraction(H,1<<(A+1))+1
        rho,q,_,_=cylinder_residue(w)
        assert all((n-rho)%q==0 for n in states)
        assert len(states)==len(set(states))
        count=0 if H<rho else (H-rho)//q+1
        assert len(states)<=count
    return len(G),rhs,len(by)

def verify_h1():
    random.seed(20260825); rows=[]; cases=0
    for n0 in range(1,401,2):
        seg=orbit_segment(n0,30)
        if len(seg)<3: continue
        for ell in range(1,min(5,len(seg)-1)+1):
            vals=sorted(seg[:len(seg)-ell+1])
            Hs=sorted(set([vals[0],vals[len(vals)//2],vals[-1],max(1,vals[-1]//2)]))
            for H in Hs:
                lhs,rhs,p=h1_bound(seg,ell,H); assert Fraction(lhs,1)<=rhs
                rows.append(("orbit_all",n0,ell,H,lhs,float(rhs),p,"PASS")); cases+=1
            starts=list(range(0,len(seg)-ell+1))
            for _ in range(3):
                sel={v for v in starts if random.random()<0.5}; H=vals[random.randrange(len(vals))]
                lhs,rhs,p=h1_bound(seg,ell,H,sel); assert Fraction(lhs,1)<=rhs
                rows.append(("orbit_subset",n0,ell,H,lhs,float(rhs),p,"PASS")); cases+=1
    return rows,cases

def verify_compositions():
    rows=[]
    for ell in range(1,9):
        for U in range(ell,min(2*ell-1,ell+8)+1):
            p=sum(comb(A-1,ell-1) for A in range(ell,U+1)); assert p==comb(U,ell)
            z=sum(Fraction(comb(A-1,ell-1),1<<A) for A in range(ell,U+1))
            cnt=sum(1 for A in range(ell,U+1) for _ in compositions(A,ell)); assert cnt==p
            rows.append(("composition",ell,U,p,float(z),"PASS"))
    return rows

def main():
    cyl=verify_cylinders(); hrows,hcases=verify_h1(); comp=verify_compositions()
    with (OUT/"CP20_TASK1_SMALL_CASE_CHECKS.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["test","param1","param2","param3","lhs_or_count","rhs_or_value","classes_or_status","status"])
        for kind,ell,A,nwords,nlifts,status in cyl: w.writerow([kind,ell,A,"",nwords,nlifts,"",status])
        for kind,n0,ell,H,lhs,rhs,p,status in hrows: w.writerow([kind,n0,ell,H,lhs,rhs,p,status])
        for kind,ell,U,p,z,status in comp: w.writerow([kind,ell,U,"",p,z,"",status])
    print("Cylinder families checked:",len(cyl)); print("H1 orbit/subset cases:",hcases); print("Composition identity cases:",len(comp)); print("CP20 TASK1 PACKING CHECK: OK")
if __name__=="__main__": main()
