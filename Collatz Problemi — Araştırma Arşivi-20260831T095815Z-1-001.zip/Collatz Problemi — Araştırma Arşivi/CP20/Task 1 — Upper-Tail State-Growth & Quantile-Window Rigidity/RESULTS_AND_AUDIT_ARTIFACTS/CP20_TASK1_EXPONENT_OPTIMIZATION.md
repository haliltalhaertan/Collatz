# CP20 TASK 1 — EXPONENT OPTIMIZATION

## Status

[EXACT] for the algebra/calculus reduction; asymptotic composition estimates use
standard Stirling asymptotics.

For fixed `1<mu<2`, define

\[
h(\mu)=\mu H_2(1/\mu),\qquad
\eta(\mu)=\mu-h(\mu)>0.
\]

Let

\[
\ell=c\log_2N+o(\log N),\qquad
U=(\mu+o(1))\ell,
\qquad H=N^\kappa.
\]

For `U<2 ell` eventually, the summands

\[
T_A={A-1\choose\ell-1}2^{-A}
\]

are increasing up to the relevant upper endpoint at exponential scale.  Thus
Stirling gives

\[
P_\ell(U)=2^{(h(\mu)+o(1))\ell},
\]

\[
Z_\ell(U)=2^{-(\eta(\mu)-o(1))\ell}.
\]

Substitution into the exact truncated packing theorem gives

\[
|G_N|\le
N^{\kappa-c\eta(\mu)+o(1)}
+N^{c h(\mu)+o(1)}.
\]

Hence

\[
\boxed{
\rho(\kappa,\mu,c)=
\max\{c h(\mu),\ \kappa-c\eta(\mu)\}.
}
\]

## Sharp optimization over `c>0`

The first branch is strictly increasing in `c`; the second is strictly
decreasing.  Therefore their maximum is minimized at their unique crossing:

\[
c h(\mu)=\kappa-c\eta(\mu).
\]

Since `h+eta=mu`,

\[
\boxed{c_*=\kappa/\mu}.
\]

At this point

\[
\boxed{
\rho_*(\kappa,\mu)
={\kappa h(\mu)\over\mu}.
}
\]

Polynomial saving occurs iff `rho_*<1`, i.e.

\[
\boxed{
\kappa<\kappa_*(\mu):={\mu\over h(\mu)}.
}
\]

Equivalently, since `h(mu)=mu H_2(1/mu)`,

\[
\kappa_*(\mu)={1\over H_2(1/\mu)}.
\]

At

\[
\alpha=\log_2 3=1.584962500721156\ldots,
\]

the exact formulas give numerically

\[
h(\alpha)=1.5056438879463003\ldots,
\]

\[
\eta(\alpha)=0.07931861277485575\ldots,
\]

\[
\boxed{
\kappa_*(\alpha)=1.0526808586079717\ldots.
}
\]

## Full admissible tradeoff surface

A polynomial exceptional-set saving for a non-optimized `c` is equivalent to
both

\[
c h(\mu)<1,
\qquad
\kappa-c\eta(\mu)<1.
\]

For `kappa>1`, this is

\[
\boxed{
{\kappa-1\over\eta(\mu)}<c<{1\over h(\mu)}.
}
\]

Such a `c` exists exactly when

\[
\kappa<\mu/h(\mu).
\]

This form is useful when one trades exceptional-set exponent against the size
of a discrepancy excursion rather than minimizing `rho` alone.

## Sensitivity

`kappa_*(mu)=1/H_2(1/mu)` is strictly decreasing on `1<mu<2`.
Thus choosing `mu>alpha` creates a genuine negative-discrepancy excursion, but
lowers the allowable state exponent threshold below
`1.0526808586...`.

At `mu=alpha`, the threshold is largest for the critical comparison used here,
but the discrepancy alternative has only `O(1)` floor error and is **not** a
large negative excursion theorem.

The full numerical sensitivity table is in `CP20_TASK1_PARAMETER_TABLE.csv`.
`CP20_TASK1_OPTIMIZER.py` also grid-checks the analytic minimizer.
