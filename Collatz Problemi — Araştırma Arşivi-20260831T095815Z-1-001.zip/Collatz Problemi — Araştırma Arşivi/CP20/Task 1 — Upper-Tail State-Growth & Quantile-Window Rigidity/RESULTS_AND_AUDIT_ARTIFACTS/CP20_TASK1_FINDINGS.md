# COLLATZ CP20 — TASK 1 FINDINGS
## Upper-tail State-Growth & Quantile-Window Rigidity

## Final verdict

\[
\boxed{
\textbf{D — [NEW STATE/EXCURSION DICHOTOMY CANDIDATE — AUDIT REQUIRED]}
}
\]

\[
\boxed{
\textbf{[MAJOR LOAD-BEARING THEOREM CANDIDATE — AUDIT REQUIRED]}
}
\]

No CP20 Task 2 should build on this result before the independent audit.

## What survived

### [EXACT] H1 subset packing

For any selected start set `G` with `n_v<=H`,

\[
|G|\le {H\over2}\sum_{W\in C_G}2^{-A(W)}+|C_G|.
\]

The proof is exact and uses the unique cylinder class modulo
`2^{A(W)+1}` plus injectivity.  It is structurally a subset-local corollary of
the frozen CP19 Task-4 mechanism.

### [EXACT] / asymptotic quantile consequence

For

\[
H=N^\kappa,
\quad
\ell=c\log_2N+o(\log N),
\quad
U=(\mu+o(1))\ell,
\]

\[
|G_N|\le N^{\rho+o(1)},
\qquad
\rho=\max\{ch(\mu),\kappa-c\eta(\mu)\}.
\]

Optimization gives

\[
c_*=\kappa/\mu,
\qquad
\rho_*=\kappa h(\mu)/\mu.
\]

Polynomial exceptional-set saving occurs iff

\[
\kappa<\kappa_*(\mu)=\mu/h(\mu).
\]

At `mu=alpha`,

\[
\boxed{\kappa_*(\alpha)=1.0526808586079717\ldots.}
\]

### [MAJOR LOAD-BEARING THEOREM CANDIDATE — AUDIT REQUIRED]
State/excursion morphology

For `mu=alpha+sigma`, `sigma>0`, and
`kappa<kappa_*(mu)`, all but a polynomially small exceptional set satisfy
either

\[
s_v\ge \kappa\log_2N
-(\theta+\varepsilon)\log_2\log N-O(1),
\]

or over the next logarithmic window

\[
s_{v+\ell}-s_v
\le -\sigma\ell+o(\ell).
\]

At the exponent-optimized window, the negative-drop coefficient is
`sigma*kappa/mu` times `log_2 N`.

## Falsification result

[EXACT] An explicit high-turnover symbolic valuation schedule survives.

It uses only

\[
a_k\in\{1,2,3\},
\]

has

\[
a_k\ne g_k
\]

at every single step, and can be arranged so that

\[
s_k=\kappa\log_2k+O(1)
\]

for any fixed `kappa>1`.

Therefore:

- `X_infinity` converges;
- CP18 occupation pressure is compatible;
- the mean valuation remains `alpha`;
- CP19 long-critical exclusion is avoided completely;
- the CP20 dichotomy is satisfied through the HIGH-STATE morphology if a
  positive ordinary realizer existed.

This is only LEVEL 2 / symbolic.  A single positive LEVEL-3 ordinary realizer
is `[OPEN]`.

## Ordinary-state search

[EXACT][LEAD] A state-band extension holds:

\[
|G_{L,H}|
\le{H-L\over2}Z_\ell(U)+P_\ell(U).
\]

[FAIL] It does not yet exclude the high-state branch.  No T4 ordinary-state
contradiction was obtained.

## Computational falsification

[CERTIFIED NUM]

- 40 small cylinder parameter families verified;
- 6,501 exact H1 orbit/subset cases verified;
- 36 exact composition identities verified;
- analytic optimizer cross-checked against a 20,000-point `c` grid per row;
- 240,000-step high-turnover symbolic schedules checked for representative
  `kappa` values.

These computations support but do not replace the proofs.

## Strongest correct interpretation

Task 4 said roughly: *if every state in the segment is below a state ceiling,
packing wins.*

CP20 Task 1 says: *even if arbitrary huge outliers are discarded, there
cannot be many starts that are simultaneously below `N^kappa` and have a
low-total-valuation logarithmic window.*

So the maximum-state escape has become a genuine **quantile morphology**
constraint.

But it has **not** yet become an unconditional theorem saying ordinary-most
states exceed `N^1.05268`.  The valuation-window / negative-excursion
alternative remains open.

## Next action

Independent adversarial audit of
`CP20_TASK1_BIG_AUDIT_PACKAGE.zip`.

Do not start CP20 Task 2 before that verdict.
