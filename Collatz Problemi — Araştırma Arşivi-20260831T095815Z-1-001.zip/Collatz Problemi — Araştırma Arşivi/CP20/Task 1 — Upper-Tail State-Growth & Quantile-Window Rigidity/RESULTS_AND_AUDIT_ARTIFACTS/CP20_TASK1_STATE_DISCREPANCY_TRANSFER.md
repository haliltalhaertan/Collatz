# CP20 TASK 1 — STATE / DISCREPANCY TRANSFER

## Status

[MAJOR LOAD-BEARING THEOREM CANDIDATE — AUDIT REQUIRED]

This file combines the quantile theorem with exact discrepancy identities and
the frozen CP17 carry bound.

## 1. Exact valuation-window to discrepancy relation

Always

\[
A(v,\ell)
=F_{v+\ell}-F_v-(s_{v+\ell}-s_v).
\]

The floor increment is exactly

\[
F_{v+\ell}-F_v
=
\lfloor\alpha\ell+\{\alpha v\}\rfloor.
\]

Therefore, if

\[
A(v,\ell)\ge U_N+1,
\qquad
U_N=\lfloor\mu\ell+r_N\rfloor,
\]

then

\[
\boxed{
 s_{v+\ell}-s_v
 \le
 \lfloor\alpha\ell+\{\alpha v\}\rfloor-U_N-1.
}
\]

This is the exact floor-error form.

Let

\[
\mu=\alpha+\sigma,
\qquad\sigma>0,
\qquad r_N=o(\ell).
\]

Then the preceding exact inequality implies

\[
\boxed{
 s_{v+\ell}-s_v
 \le -\sigma\ell+o(\ell)+O(1).
}
\]

For `ell=c log_2 N+o(log N)`, the negative excursion has leading size

\[
\boxed{
-\sigma c\log_2N.
}
\]

At `mu=alpha` there is no order-`log N` negative drop; only the floor-scale
`O(1)` alternative remains.

## 2. High ordinary state to high discrepancy

Write the frozen CP17 carry factor as `mathcal U_k` to avoid collision with the
valuation cutoff.  CP17 gives, for each `eps>0`, uniformly for `k<=2N`,

\[
X_k\le C_X(n_0,\varepsilon)
(\log(2N))^{\theta+\varepsilon}.
\]

Hence

\[
\mathcal U_k
=1+{X_k\over3n_0}
\le C_U(n_0,\varepsilon)
(\log(2N))^{\theta+\varepsilon}
\]

for all sufficiently large `N`.

Using the exact identity

\[
n_k=n_0\mathcal U_k2^{s_k+\{\alpha k\}},
\]

if `k in [N,2N)` and

\[
n_k>N^\kappa,
\]

then

\[
\boxed{
 s_k>
 \kappa\log_2N
 -(\theta+\varepsilon)\log_2\log(2N)
 -C(n_0,\varepsilon)-1.
}
\]

Equivalently, after absorbing the harmless `2N` change,

\[
\boxed{
 s_k\ge
 \kappa\log_2N
 -(\theta+\varepsilon)\log_2\log N
 -O_{n_0,\varepsilon}(1).
}
\]

## 3. State/excursion morphology theorem candidate

Fix `sigma>0`, put `mu=alpha+sigma<2`, and choose parameters with

\[
\kappa<\kappa_*(\mu)=\mu/h(\mu).
\]

At the optimized window

\[
\ell=\left\lfloor{\kappa\over\mu}\log_2N\right\rfloor,
\]

all but

\[
N^{\rho_*+o(1)},
\qquad
\rho_*={\kappa h(\mu)\over\mu}<1,
\]

starts satisfy at least one of:

### HIGH-DISCREPANCY / HIGH-STATE MORPHOLOGY

\[
\boxed{
 s_v\ge
 \kappa\log_2N
 -(\theta+\varepsilon)\log_2\log N
 -O_{n_0,\varepsilon}(1)
}
\]

or

\[
\boxed{
 s_{v+\ell}-s_v
 \le
 -{\sigma\kappa\over\mu}\log_2N
 +o(\log N).
}
\]

The exceptional proportion is

\[
N^{-\delta+o(1)},
\qquad
\boxed{
\delta=1-{\kappa h(\mu)\over\mu}.
}
\]

More generally, before optimizing `c`, the tradeoff surface is

\[
\rho=\max\{ch(\mu),\kappa-c\eta(\mu)\},
\]

with negative-drop coefficient `sigma*c`.

## Interpretation

This is a survivor **morphology** theorem, not a contradiction.  It says that
for polynomially almost every start in a dyadic block, a hypothetical survivor
must either already sit at a superlinear ordinary-state scale or undergo a
large negative discrepancy excursion over the next logarithmic window.
