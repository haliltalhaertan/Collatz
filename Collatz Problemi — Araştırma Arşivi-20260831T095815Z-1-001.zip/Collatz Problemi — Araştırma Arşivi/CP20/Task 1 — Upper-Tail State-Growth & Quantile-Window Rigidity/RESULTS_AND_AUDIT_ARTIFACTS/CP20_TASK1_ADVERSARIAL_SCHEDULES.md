# CP20 TASK 1 — ADVERSARIAL SYMBOLIC SURVIVOR SCHEDULES

## Status

[EXACT] symbolic construction and asymptotic checks.

[OPEN] whether one fixed positive ordinary integer realizes the infinite word.

The purpose is to falsify any claim that the new state/excursion dichotomy is
already a contradiction.

## 1. High-turnover construction with no critical sites

Let

\[
g_k=F_{k+1}-F_k\in\{1,2\},
\qquad
d_k=s_{k+1}-s_k=g_k-a_k.
\]

Partition indices into blocks of length 20.
For any start `u`,

\[
\#\{k\in[u,u+20):g_k=2\}
=F_{u+20}-F_u-20.
\]

Since

\[
20\alpha=31.6992500144\ldots,
\]

the floor difference is 31 or 32, hence **every** 20-block contains exactly
11 or 12 sites with `g_k=2`.

Choose every `d_k` in `{+1,-1}`, with `+1` used only at `g_k=2` sites.
Then

\[
a_k=g_k-d_k\in\{1,2,3\}
\]

and, crucially,

\[
\boxed{d_k\ne0\quad\text{for every }k.}
\]

Thus there is not even one exact critical site `a_k=g_k`; the frozen CP19
long-critical-gap mechanism is avoided maximally.

### Ordinary block

Choose 10 plus signs and 10 minus signs.  Net discrepancy change is zero.
This is always feasible because there are at least 11 `g=2` sites.

### Selected growth block

Choose 11 plus signs and 9 minus signs.  Net discrepancy change is `+2`.
Again this is always feasible.

Let the number of selected growth blocks up to block index `J` be

\[
m(J)=\left\lfloor{\kappa\over2}\log_2(J+2)\right\rfloor+O(1).
\]

Select a block precisely when this integer target increases.  Since each
selected block contributes `+2`, at block boundaries

\[
s_{20J}=2m(J)+O(1)=\kappa\log_2J+O(1)
=\kappa\log_2(20J)+O(1).
\]

Inside a 20-block, `s` moves by at most 20, so uniformly

\[
\boxed{s_k=\kappa\log_2k+O(1).}
\]

This construction is deterministic and uses only positive integer valuations
`{1,2,3}`.

## 2. Frozen necessary conditions

For every `kappa>1`,

\[
D_k=-s_k-\{\alpha k\}
\le-\kappa\log_2k+O(1),
\]

so

\[
\boxed{
\sum_k2^{D_k}<\infty.
}
\]

Thus the CP17 carry series is compatible with convergence.

Also

\[
E_k=s_k-\lfloor\log_2k\rfloor
=(\kappa-1)\log_2k+O(1).
\]

Therefore for every fixed `B` and every fixed `b`, the inequalities

\[
E_k\le B,
\qquad
E_k\le b\log_2\log k
\]

are eventually false.  Hence the frozen CP18 Task-5 occupation pressure is
satisfied more strongly than required.

Finally

\[
A_k=F_k-s_k=\alpha k+O(\log k),
\]

so the mean valuation still tends to `alpha`.

## 3. Why this evades the CP20 alternatives

For logarithmic windows, the construction has

\[
s_{v+\ell}-s_v=O(1)
\]

away from deliberately inserted excursions, hence

\[
A(v,\ell)=\alpha\ell+O(1).
\]

For any `mu>alpha`, these are low-total-valuation windows.  Therefore if an
ordinary positive LEVEL-3 realization existed, the CP20 dichotomy would force
it into the **HIGH STATE** branch, exactly as intended:

\[
n_v\asymp v^\kappa
\]

because the carry factor would converge to a finite positive limit.

This is not a contradiction.

## 4. Sparse excursion extension

At dyadic block scales one may replace `O(log k)` ordinary 20-blocks by
all-minus blocks (`d=-1` at every site), producing a negative discrepancy drop
of order `lambda log k`, and then recover using `+2` growth blocks.
All valuations remain in `{1,2,3}`, all `d_k` remain nonzero, and the modified
set of blocks has zero ordinary density.

If the excursion floor still satisfies

\[
s_k\ge(\kappa-\lambda)\log_2k-O(1)
\]

with `lambda<kappa`, its dyadically sparse contribution to the carry sum is
summable as well.

Thus even a high-state / occasional-negative-excursion morphology can be made
symbolically compatible with the known necessary conditions.

## 5. Level distinction

Every finite valuation prefix has positive ordinary cylinder realizers.
That is LEVEL 2.

Nothing here proves that one fixed positive ordinary integer realizes the
full infinite word.  LEVEL 3 remains `[OPEN]`.

`CP20_TASK1_ADVERSARIAL_ENGINE.py` checks the 20-block construction through
240,000 symbolic steps for representative `kappa` values 1.053, 1.06 and 1.10.
No critical positions occur.
