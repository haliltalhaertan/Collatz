#!/usr/bin/env python3
import math,csv
from pathlib import Path
OUT=Path(__file__).resolve().parent
alpha=math.log2(3)
def H2(p): return -p*math.log2(p)-(1-p)*math.log2(1-p)
def h(mu): return mu*H2(1/mu)
def eta(mu): return mu-h(mu)
def kstar(mu): return mu/h(mu)
def rho(kappa,mu,c): return max(c*h(mu),kappa-c*eta(mu))
def main():
    mus=[1.45,1.50,1.55,alpha,1.60,1.65,1.70,1.75,1.80,1.90]
    kappas=[1.01,1.03,1.04,1.05,1.052,1.06]
    rows=[]
    for mu in mus:
        hh,ee,ks=h(mu),eta(mu),kstar(mu)
        for kap in kappas:
            c=kap/mu; rs=kap*hh/mu; delta=1-rs
            best=(1e99,None)
            for j in range(1,20001):
                cg=2*c*j/10000; val=rho(kap,mu,cg)
                if val<best[0]: best=(val,cg)
            assert abs(best[0]-rs)<2e-4
            rows.append({"mu":mu,"sigma_from_alpha":mu-alpha,"h_mu":hh,"eta_mu":ee,"kappa_star":ks,"kappa":kap,"c_star":c,"rho_star":rs,"delta_star":delta,"negative_drop_coeff_at_cstar":max(0.0,mu-alpha)*c,"grid_best_rho":best[0],"grid_best_c":best[1],"admissible_saving":int(rs<1)})
    with (OUT/"CP20_TASK1_PARAMETER_TABLE.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print("alpha",alpha); print("h(alpha)",h(alpha)); print("eta(alpha)",eta(alpha)); print("kappa_star(alpha)",kstar(alpha)); print("rows",len(rows)); print("CP20 TASK1 OPTIMIZER: OK")
if __name__=="__main__": main()
