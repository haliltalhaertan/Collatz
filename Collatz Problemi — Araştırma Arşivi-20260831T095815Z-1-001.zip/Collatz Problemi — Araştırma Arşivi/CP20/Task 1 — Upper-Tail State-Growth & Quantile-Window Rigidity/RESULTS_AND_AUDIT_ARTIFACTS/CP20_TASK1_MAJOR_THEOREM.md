# CP20 TASK 1 — MAJOR THEOREM CANDIDATE
## Truncated Quantile Packing + State/Excursion Dichotomy

[MAJOR LOAD-BEARING THEOREM CANDIDATE — AUDIT REQUIRED]

This file is intentionally compact.  Do not freeze or use it as a dependency
before independent audit.

## Dependency

The exact cylinder-count mechanism is inherited from frozen/audited CP19 Task
4.  CP20's new contribution is the **subset/truncated application and its
optimized quantile consequence**.

## Theorem A — subset packing

For any subset `G` of admissible window starts in a positive injective odd-only
Syracuse orbit, if `n_v<=H` for all `v in G`, then

\[
|G|\le{H\over2}\sum_{W\in C_G}2^{-A(W)}+|C_G|.
\]

The exact cylinder modulus is `2^{A(W)+1}`.

## Theorem B — quantile-window dichotomy

Let

\[
\ell=\lfloor c\log_2N\rfloor,
\qquad
U_N=(\mu+o(1))\ell,
\qquad 1<\mu<2.
\]

Then the starts with both

\[
n_v\le N^\kappa
\quad\text{and}\quad
A(v,\ell)\le U_N
\]

are at most

\[
N^{\rho(\kappa,\mu,c)+o(1)},
\]

where

\[
\rho=\max\{ch(\mu),\kappa-c\eta(\mu)\}.
\]

Optimizing gives

\[
c_*=\kappa/\mu,
\qquad
\rho_*={\kappa h(\mu)\over\mu}.
\]

Thus if

\[
\kappa<{\mu\over h(\mu)},
\]

all but a polynomially small fraction of starts satisfy HIGH STATE or HIGH
VALUATION WINDOW.

At `mu=alpha=log_2 3`,

\[
\kappa_*={\alpha\over h(\alpha)}
=1.0526808586079717\ldots.
\]

## Theorem C — state/excursion morphology

Set

\[
\mu=\alpha+\sigma<2,
\qquad\sigma>0,
\]

and assume

\[
\kappa<\mu/h(\mu).
\]

At `c=kappa/mu`, all but

\[
N^{\kappa h(\mu)/\mu+o(1)}
\]

starts in `[N,2N)` satisfy either

\[
s_v\ge
\kappa\log_2N-(\theta+\varepsilon)\log_2\log N
-O_{n_0,\varepsilon}(1),
\]

or

\[
s_{v+\ell}-s_v
\le
-{\sigma\kappa\over\mu}\log_2N+o(\log N).
\]

The exceptional proportion is

\[
N^{-\delta+o(1)},
\qquad
\delta=1-\kappa h(\mu)/\mu>0.
\]

## Scope

This does **not** prove that ordinary-most states are superlinear, because the
negative-excursion/high-valuation alternative may occur frequently.

It does **not** exclude a symbolic survivor: an explicit high-turnover
valuation schedule with `a_k in {1,2,3}`, no critical sites, and
`s_k=kappa log_2 k+O(1)` survives all presently checked necessary conditions
for every `kappa>1`.

It does **not** solve Collatz.
