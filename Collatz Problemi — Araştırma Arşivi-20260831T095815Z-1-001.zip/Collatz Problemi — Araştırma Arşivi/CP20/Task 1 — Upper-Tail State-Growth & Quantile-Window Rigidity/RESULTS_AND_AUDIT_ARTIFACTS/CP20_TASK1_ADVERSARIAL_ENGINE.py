#!/usr/bin/env python3
import math,csv,json
from pathlib import Path
OUT=Path(__file__).resolve().parent
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
alpha=math.log2(3)
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q; hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def g(k):return F(k+1)-F(k)

def block_schedule(num_blocks=12000,kappa=1.06):
    # Every block has length 20. Exact mechanical-word count gives 11 or 12 sites with g=2.
    # Ordinary blocks have 10 plus and 10 minus d's -> net 0.
    # Selected blocks have 11 plus and 9 minus -> net +2.
    # Number selected up to J is ~ (kappa/2) log2 J, hence s_k=kappa log2 k+O(1).
    s=0; rows=[]; selected=0; prev_goal=int(math.floor((kappa/2)*math.log2(2)))
    for j in range(num_blocks):
        start=20*j
        gs=[g(start+i) for i in range(20)]
        n2=sum(x==2 for x in gs)
        assert n2 in (11,12),(j,n2)
        goal=int(math.floor((kappa/2)*math.log2(j+3)))
        is_sel=goal>prev_goal
        if is_sel:selected+=1
        prev_goal=goal
        plus_need=11 if is_sel else 10
        plus_positions=[i for i,x in enumerate(gs) if x==2][:plus_need]
        plus_set=set(plus_positions)
        net=0
        for i,gg in enumerate(gs):
            d=1 if i in plus_set else -1
            a=gg-d
            assert a in (1,2,3) and d!=0
            s+=d; net+=d
            k=start+i+1
            rows.append((k,j,gg,a,d,s,is_sel,n2))
        assert net==(2 if is_sel else 0)
    return rows,selected

def diagnostics(rows,kappa):
    X=0.0; max_abs=0.0; min_gap=1e9; max_gap=-1e9; samples=[]
    for k,j,gg,a,d,s,is_sel,n2 in rows:
        target=kappa*math.log2(max(2,k))
        gap=s-target; min_gap=min(min_gap,gap); max_gap=max(max_gap,gap); max_abs=max(max_abs,abs(gap))
        frac=(alpha*k)%1.0; X+=2.0**(-s-frac)
        if k in [100,1000,10000,100000,200000]: samples.append((k,s,target,gap,X))
    return X,max_abs,min_gap,max_gap,samples

def main():
    summaries=[]; sample_rows=[]
    for kap in [1.053,1.06,1.10]:
        rows,selected=block_schedule(kappa=kap)
        X,max_abs,mn,mx,samples=diagnostics(rows,kap)
        assert all(r[4]!=0 for r in rows)
        assert all(r[3]!=r[2] for r in rows) # no critical site a_k=g_k
        summaries.append({"kappa":kap,"steps":len(rows),"selected_plus2_blocks":selected,"critical_positions":0,"final_s":rows[-1][5],"target_final":kap*math.log2(len(rows)),"min_tracking_gap":mn,"max_tracking_gap":mx,"max_abs_tracking_gap":max_abs,"X_partial_numeric":X,"valuation_alphabet":[1,2,3],"classification":"LEVEL-2 / symbolic only"})
        for r in samples: sample_rows.append((kap,)+r)
    with (OUT/"CP20_TASK1_ADVERSARIAL_SCHEDULE_SAMPLES.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f);w.writerow(["kappa","k","s_k","target","gap","X_partial_numeric"]);w.writerows(sample_rows)
    (OUT/"CP20_TASK1_ADVERSARIAL_SUMMARY.json").write_text(json.dumps(summaries,indent=2),encoding="utf-8")
    print(json.dumps(summaries,indent=2));print("CP20 TASK1 ADVERSARIAL ENGINE: OK")
if __name__=="__main__":main()
