# CP20 TASK 1 — TRUNCATED / SUBSET WEIGHTED PACKING THEOREM

## Status

[EXACT]

This is a subset-local version of the frozen CP19 Task-4 cylinder count.  It is
not a new cylinder mechanism; the new content of CP20 is the quantile/asymptotic
consequence obtained by applying the same exact cylinder arithmetic only to
low-state starts.

## Theorem 1 — exact subset packing

Let a positive injective odd-only Syracuse orbit be given and let `G` be any
finite set of admissible window starts.  Fix a window length `ell>=1`.  Assume

\[
n_v\le H\qquad(v\in G).
\]

For each start let

\[
W_v=(a_v,\ldots,a_{v+\ell-1}),\qquad
A(W_v)=\sum_{j=0}^{\ell-1}a_{v+j},
\]

and let `C_G` be the set of distinct occurring words.  Then

\[
\boxed{
|G|\le {H\over2}\sum_{W\in C_G}2^{-A(W)}+|C_G|.
}
\]

No disjointness of windows is required.

### Proof

For a positive valuation word `W=(a_0,...,a_{ell-1})`, put

\[
A=\sum_j a_j.
\]

Writing the exact affine iterate as

\[
2^A n_\ell=3^\ell n_0+B_W,
\]

with the recursion

\[
B_{j+1}=3B_j+2^{A_j},\qquad B_0=0,
\]

exactness of the final valuation step is equivalent to `n_ell` being odd.
Therefore

\[
3^\ell n_0+B_W\equiv2^A\pmod{2^{A+1}},
\]

so the starting odd state is pinned to exactly one class

\[
\boxed{
 n_0\equiv \rho_W:=3^{-\ell}(2^A-B_W)
 \pmod{2^{A+1}}.
}
\]

The residue is odd.  Hence the number of positive integers in this class not
exceeding `H` is

\[
\max\left(0,\left\lfloor{H-\rho_W\over2^{A+1}}\right\rfloor+1\right)
\le {H\over2^{A+1}}+1.
\]

Injectivity makes the actual start states `{n_v:v in G}` distinct.  Partition
`G` by its occurring word and sum the preceding per-word bound.  This gives
exactly

\[
|G|\le\sum_{W\in C_G}\left({H\over2^{A(W)+1}}+1\right),
\]

which is the claimed formula.  Overlapping windows never enter the count.

## Boundary audit

- **Cylinder depth:** `A(W)+1`, not `A(W)`, is necessary.  Modulo `2^A` one
  fixes divisibility but not the final odd quotient.
- **Oddness:** the unique exact cylinder residue is odd.
- **Repeated words:** handled by one arithmetic progression for that word.
- **Overlapping windows:** irrelevant because only start states are counted.
- **Injectivity:** essential.  Without it, repeated visits to one start state
  could violate the counting argument.
- **H below the modulus:** the `+1` term is essential.  For `W=(1)`, the
  exact class is `3 mod 4`; with `H=3` there is one state although `H/4=3/4`.
- **Block endpoints:** starts are restricted to those for which the whole
  length-`ell` word is present.

## Exact computational checks

[CERTIFIED NUM]

`CP20_TASK1_PACKING_CHECK.py` independently verified:

- 40 composition/cylinder parameter families, with eight lifts per word;
- 6,501 H1 tests on genuine injective finite odd-Syracuse orbit segments and
  random subsets;
- 36 exact positive-composition identity cases.

No violation was found.  Numerics are diagnostic only; the proof above is
exact.

## Composition corollary

Let all selected words additionally satisfy `A(W)<=U`.  The number of positive
length-`ell` compositions with total at most `U` is exactly

\[
P_\ell(U)=\sum_{A=\ell}^U {A-1\choose\ell-1}={U\choose\ell},
\]

and their total cylinder mass is

\[
Z_\ell(U)=\sum_{A=\ell}^U {A-1\choose\ell-1}2^{-A}.
\]

Therefore

\[
\boxed{
|G|\le {H\over2}Z_\ell(U)+P_\ell(U).
}
\]

This retains the exact `+1` contribution through `P_ell(U)`.
