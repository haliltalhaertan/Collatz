# CP20 TASK 7 — INDEPENDENT ZERO-TRUST MAJOR AUDIT PROMPT

You are an independent adversarial mathematical auditor. Do not trust any theorem, decimal, code path, or label merely because it appears in the package.

Audit the CP20 Task 7 B=4 weighted-pressure result from first principles.

Required checks:

1. Re-derive the local defect supports for B=4 zero-criticality.
2. Verify the exact Sturmian Parikh identity
   n2(u,r)=floor((alpha-1)(u+r))-floor((alpha-1)u)
   and that the two finite-r Parikh possibilities differ by at most 1.
3. Re-derive the positive-coefficient/Chernoff bound and aggressively check the sign and minimization direction.
4. Check that an O(log r) total-defect band contributes only polynomial, not exponential, overhead.
5. Check the passage from
   s_k=kappa log_2 k+O(1)
   to a global factor-complexity upper bound, including the finitely many starts before the asymptotic regime.
6. Recompute the pressure function independently and verify strict convexity, existence/uniqueness of the minimizer, and the interval certificate.
7. Recompute selected exact finite counts without using either provided engine.
8. Verify that the Task-6 frozen lower entropy theorem is combined with the Task-7 upper theorem with the inequality direction correct.
9. Check that no CP19 parked high-half/cross-adic mechanism has been reintroduced.
10. Try to produce an exact counterexample to any claimed lemma.

Return one of:
- [PROOF VALID]
- [PROOF VALID WITH WORDING REPAIR]
- [FAIL — FIXABLE]
- [FAIL — LOAD-BEARING]
- [INCONCLUSIVE]

If valid, state the exact surviving kappa range and whether the decimal threshold certificate is sufficiently rigorous for downstream use.
