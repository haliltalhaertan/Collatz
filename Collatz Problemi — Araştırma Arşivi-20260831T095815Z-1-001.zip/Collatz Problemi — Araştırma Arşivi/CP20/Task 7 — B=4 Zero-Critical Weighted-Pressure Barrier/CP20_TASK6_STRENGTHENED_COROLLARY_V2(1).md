# CP20 TASK 6 — STRENGTHENED COROLLARY V2

**Status:** `[AUDIT CANDIDATE]`  
**Date:** 2026-08-26

## Unchanged lower theorem

The audited Task-6 factor-complexity lower theorem remains:
\[
\liminf_{r\to\infty}\frac{\log_2p_a(r)}r\ge\frac{\alpha}{\kappa}.
\]
Its proof is alphabet-independent; bounded valuation first enters the
historical §6 upper-count corollary.

## Historical §§6–7

The crude estimate
\[
p_a(r)\le(r+1)(B-1)^r
\]
and, for B=3,
\[
\kappa\ge\alpha
\]
remain valid but are now **[VALID BUT SUPERSEDED]**.

## Correct pressure corollary

For finite B define
\[
h_B=
\inf_\lambda\left[
(2-\alpha)\log_2\sum_{a=2}^B e^{\lambda(1-a)}
+
(\alpha-1)\log_2
\sum_{\substack{1\le a\le B\\a\ne2}}
e^{\lambda(2-a)}
\right].
\]
Under \(1\le a_k\le B\), zero-criticality, and the critical-log law,
\[
\kappa\ge\alpha/h_B.
\]

## Chernoff wording repair

Correct:
\[
P(t)=\sum_SN(S)t^S
\Rightarrow
N(S)t^S\le P(t)
\Rightarrow
N(S)\le P(t)t^{-S}.
\]
The earlier draft had the exponent sign reversed. Because
\(|S|=O(\log r)\), this repair does not alter the pressure exponent.

## B=3

The exact-rational certificate proves
\[
h_3<523467/10^6
\]
and
\[
\boxed{\alpha/h_3>3.027}.
\]
Thus the old threshold \(\kappa\ge\alpha\approx1.585\) is superseded by
\[
\boxed{\kappa\ge\alpha/h_3},
\]
with safe rational consequence \(\kappa>3.027\).

## Uniform unbounded-alphabet consequence

For \(\lambda>0\),
\[
S_{1,\infty}=\frac1{e^\lambda-1},\qquad
S_{2,\infty}=e^\lambda+\frac1{e^\lambda-1}.
\]
The certificate proves
\[
h_\infty<56931/100000
\]
and
\[
\boxed{\alpha/h_\infty>348/125=2.784}.
\]
Hence any positive ordinary zero-critical critical-log realizer, with
bounded or unbounded valuations, must satisfy
\[
\boxed{\kappa>2.784}.
\]

## Scope

Still unresolved by this corollary:
- critical sites \(a_k=g_k\);
- non-critical-log discrepancy laws;
- \(\kappa\ge\alpha/h_\infty\);
- the general Collatz conjecture.

Independent audit is required before freezing.
