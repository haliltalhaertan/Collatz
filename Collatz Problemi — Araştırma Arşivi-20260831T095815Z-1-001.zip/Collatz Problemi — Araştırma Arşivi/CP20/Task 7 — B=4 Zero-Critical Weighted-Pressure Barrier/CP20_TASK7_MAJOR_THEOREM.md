# CP20 TASK 7 — MAJOR THEOREM

## B=4 Zero-Critical Weighted-Pressure Exclusion

Date: 2026-08-26
Status: [LOAD-BEARING THEOREM CANDIDATE — INDEPENDENT AUDIT REQUIRED]

Let alpha=log_2 3. Consider a positive ordinary odd-only Syracuse orbit with valuation word a_k and

s_k=floor(alpha k)-sum_(i<k)a_i.

Assume

1. a_k in {1,2,3,4} for every k;
2. a_k != g_k for every k, where
   g_k=floor(alpha(k+1))-floor(alpha k);
3. s_k=kappa log_2 k+O(1);
4. kappa>1.

Define

h_4
= inf_(lambda in R)
[
(2-alpha) log_2(e^-lambda+e^-2lambda+e^-3lambda)
+(alpha-1) log_2(e^lambda+e^-lambda+e^-2lambda)
].

Then the valuation language has

limsup_(r->infinity) log_2 p_a(r)/r <= h_4.

Frozen CP20 Task 6 gives simultaneously

liminf_(r->infinity) log_2 p_a(r)/r >= alpha/kappa.

Therefore ordinary realization requires

kappa >= alpha/h_4.

Certified computation gives

h_4 in [0.56190073413740060119395156059766556163845778099972727303599948476, 0.56190073413740092065965480305841473713218578947883277863159042048],

and

alpha/h_4 in [2.820716194924185985049020194560877701175422912652590127522695231, 2.8207161949241875887523580131287859897252543927746790069674146309].

Consequently,

1 < kappa < alpha/h_4

is impossible.

Numerically,

kappa_4^* = alpha/h_4
= 2.820716194924186786900689103844608291575330206436301457960103238107952...

so the entire range

1 < kappa < 2.820716194924185

is rigorously inside the excluded region given the stated hypotheses and the interval certificate.

The proof uses only:
- exact local defect supports;
- exact Sturmian factor/Parikh structure;
- positive-coefficient generating functions;
- a one-dimensional convex pressure minimization;
- the critical-log discrepancy band;
- the frozen CP20 Task-6 entropy lower bound.

It does not use the parked CP19 high-half/cross-adic branch.

This is not a LEVEL-1 Collatz theorem and does not address the surviving high-kappa, critical-site, unbounded-valuation, or non-critical-log escapes.

STOP: independent zero-trust audit is required before any downstream theorem uses this result.
