# CP20 — PRESSURE GENERALIZATION DEPENDENCY GRAPH

Status: **[AUDIT CANDIDATE]**  
Date: 2026-08-26

This graph records only the dependencies used by the pressure-generalization
candidate. It does not reopen parked branches.

## Dependency chain

### 1. CP17 frozen Syracuse theorem foundation

**Source:** `CP17_MASTER_CHECKPOINT_FROZEN_RECONSTRUCTED_SUMMARY`  
**Independent audit source:** `CP17_FINAL_STANDALONE_V3_ZERO_TRUST_AUDIT.md`  
**Status:** `[PROVED][FROZEN][INDEPENDENTLY AUDITED]`

Role in the present chain: supplies the already-audited ordinary odd-only
Syracuse framework used by later checkpoints. No CP17 numerical coefficient is
reproved in the present package.

↓

### 2. CP18 occupation/global-coherence framework

**Source:** `CP18_MASTER_CHECKPOINT_2026-08-24_RECONSTRUCTED_FROM_AUDITED_ARCHIVE`  
**Audit status:** CP18 BIG ZERO-TRUST AUDIT verdict `CP18 SOUND`; Tasks 1–10
accepted within scope.  
**Status:** `[AUDITED][SOUND]`

Role in the present chain: inherited global-coherence/state framework only.
No failed least-realizer branch is used.

↓

### 3. CP19 surviving classification / park decision

**Source:** `CP19_MASTER_CHECKPOINT_2026-08-25`  
**Status used here:** audited/frozen surviving Task-3/Task-4 structural input;
Task-10 high-half branch remains `[PARK]`.

Role in the present chain: defines the surviving regime in which CP20 operates.
The present proof does not use sampled-high-bit, Hensel high-half, or cross-adic
state information.

↓

### 4. CP20 Task 6 factor-complexity LOWER theorem

**Canonical audited source:** `CP20_TASK6_MAJOR_THEOREM_V2_AUDITED_FROZEN`  
**Historical source:** `CP20_TASK6_MAJOR_THEOREM.md`  
**Exact theorem used:**
\[
\boxed{
\liminf_{r\to\infty}
\frac{\log_2p_a(r)}r
\ge\frac{\alpha}{\kappa}
}
\]
under a positive ordinary odd-only Syracuse orbit with
\[
s_k=\kappa\log_2 k+O(1),\qquad \kappa>1.
\]

**Status:** `[PROVED][AUDITED][FROZEN WITH WORDING REPAIR]`

Critical audit point: its §§1–5 proof is alphabet-independent. Bounded alphabet
enters only the historical §6 crude upper-count corollary.

↓

### 5. CP20 weighted-pressure UPPER theorem

**Source:** `CP20_PRESSURE_GENERALIZATION_RIGOROUS_PROOF.md`  
**Historical special case:** `CP20_TASK7_MAJOR_THEOREM.md`

Exact candidate theorem for finite B:
\[
\boxed{
\limsup_{r\to\infty}
\frac{\log_2p_a(r)}r\le h_B
}
\]
under zero-criticality \(a_k\ne g_k\) and the critical-log law.

**Status:** `[AUDIT CANDIDATE]`

The historical B=4 theorem is retained as a special corollary.
The earlier Chernoff display sign is repaired in the candidate proof.

↓

### 6. General B / B=infinity pressure theorem

**Source:** `CP20_PRESSURE_GENERALIZATION_RIGOROUS_PROOF.md`  
**Certificate:** `CP20_PRESSURE_INTERVAL_CERTIFICATE.py` +
`CP20_PRESSURE_INTERVAL_CERTIFICATE_OUTPUT.txt`

For an unbounded valuation alphabet:
\[
\boxed{
\limsup_{r\to\infty}
\frac{\log_2p_a(r)}r\le h_\infty
}
\]
with pressure domain \(\lambda>0\).

**Status:** `[AUDIT CANDIDATE]`

↓

### 7. Uniform kappa lower threshold

Combining Task 6 lower entropy with the unbounded-alphabet pressure upper
entropy gives
\[
\frac{\alpha}{\kappa}\le h_\infty
\]
and therefore
\[
\boxed{
\kappa\ge\frac{\alpha}{h_\infty}.
}
\]

The exact-rational certificate gives the safe consequence
\[
\boxed{\kappa>2.784}.
\]

For B=3:
\[
\boxed{\kappa\ge\alpha/h_3>3.027}.
\]

**Status:** `[AUDIT CANDIDATE — AWAITING INDEPENDENT ZERO-TRUST AUDIT]`

## Non-dependencies

The candidate does not depend on:

- CP19 parked high-half / cross-adic branch;
- a sampled high-bit variable;
- Hensel-lifting state compression;
- finite numerical DP as theorem evidence;
- the historical Task-6 crude alphabet entropy bound.

The DP reproduction is sanity-check evidence only.
