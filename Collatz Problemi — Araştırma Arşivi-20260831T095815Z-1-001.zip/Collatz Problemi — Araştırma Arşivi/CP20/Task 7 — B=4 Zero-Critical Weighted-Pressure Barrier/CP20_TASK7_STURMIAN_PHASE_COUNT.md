# CP20 TASK 7 — STURMIAN PHASE COUNT

Date: 2026-08-26
Status: [EXACT] analytic statement + finite computational cross-checks

Let beta=alpha-1, alpha=log_2 3.

For
g_k=floor(alpha(k+1))-floor(alpha k),
we have
g_k=1+b_k,
where
b_k=floor(beta(k+1))-floor(beta k) in {0,1}.

For a length-r block starting at u,

n2(u,r)
= sum_(i=0)^(r-1) b_(u+i)
= floor(beta(u+r))-floor(beta u).

For any real x and y,

floor(x+y)-floor(x) in {floor(y), ceil(y)}.

Therefore every length-r Sturmian g-factor has exactly one of two possible g=2 counts:

n2 in {floor(beta r), ceil(beta r)}.

The count n1 of g=1 symbols is r-n2.

Because alpha is irrational, beta is irrational and g is Sturmian, so the exact factor complexity is

p_g(r)=r+1.

The B=4 defect generating function for a fixed g-factor is

(z^-1+z^-2+z^-3)^n1 (z+z^-1+z^-2)^n2,

which depends only on n1,n2. Thus phase ordering cannot alter the exponential pressure; it can only:
1. choose between the two adjacent Parikh counts;
2. multiply the union upper bound by at most r+1.

Finite scans independently verified p_g(r)=r+1 and the two predicted Parikh counts for:
r = 6, 8, 10, 12, 16, 32, 64.

This removes the proposed “worst Sturmian phase” failure mode at exponential scale.
