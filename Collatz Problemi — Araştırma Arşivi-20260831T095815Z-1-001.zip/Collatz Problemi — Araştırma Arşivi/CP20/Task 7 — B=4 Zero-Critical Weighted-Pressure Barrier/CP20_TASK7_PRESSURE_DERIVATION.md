# CP20 TASK 7 — PRESSURE DERIVATION

Date: 2026-08-26
Status: [PROVED CANDIDATE — LOAD-BEARING, REQUIRES INDEPENDENT ZERO-TRUST AUDIT]

## 1. Frozen setup

Let
- alpha = log_2 3,
- F_k = floor(alpha k),
- g_k = F_(k+1)-F_k in {1,2},
- A_k = sum_(i<k) a_i,
- s_k = F_k-A_k,
- d_k = g_k-a_k = s_(k+1)-s_k.

Task 6 is frozen/audited and gives, for a positive ordinary odd-only Syracuse orbit satisfying
s_k = kappa log_2 k + O(1), kappa>1,

liminf_(r->infinity) log_2 p_a(r)/r >= alpha/kappa.

Task 7 assumes B=4 zero-critical:
a_k in {1,2,3,4}, a_k != g_k.

Hence the exact defect supports are:
- g=1: d in {-1,-2,-3};
- g=2: d in {+1,-1,-2}.

## 2. Exact Sturmian Parikh control

Write beta=alpha-1. Then
g_k = 1 + (floor(beta(k+1))-floor(beta k)).

For every start u and length r, the number n2 of g=2 symbols is

n2(u,r)=floor(beta(u+r))-floor(beta u),

hence exactly one of
floor(beta r), ceil(beta r).

Therefore n1=r-n2 and
n1/r -> 2-alpha, n2/r -> alpha-1,
with an O(1) finite-r discrepancy.

The number of distinct length-r g-factors is exactly r+1 because g is Sturmian.

Crucially, the defect generating function depends only on (n1,n2), not on the order of the g-symbols. Thus Sturmian phase variation contributes only the polynomial factor r+1 and an O(1) Parikh perturbation.

## 3. Fixed-phase generating function

For a fixed g-factor,

P_g(z)
= (z^-1+z^-2+z^-3)^n1
  (z^1+z^-1+z^-2)^n2.

For t=e^lambda>0 define

S1(lambda)=e^-lambda+e^-2lambda+e^-3lambda,
S2(lambda)=e^lambda+e^-lambda+e^-2lambda.

If c_D is the coefficient for total defect D, positivity gives

c_D t^D <= P_g(t),

so for |D|<=C_r,

sum_|D|<=C_r c_D
<= (2 C_r+1) exp(|lambda| C_r) P_g(e^lambda).

This is the correct coefficient/Chernoff direction; the sign has been independently checked.

## 4. Pressure

Let
p1=2-alpha,
p2=alpha-1.

Define

H(lambda)
= p1 log_2 S1(lambda)
+ p2 log_2 S2(lambda),

and

h_4 = inf_(lambda in R) H(lambda).

Each log-sum-exp term is strictly convex, so H is strictly convex.
As lambda -> -infinity, H -> +infinity.
As lambda -> +infinity, its asymptotic slope is p2-p1 = 2 alpha-3 > 0, so H -> +infinity.
Hence there is a unique minimizer lambda_*.

Independent decimal computation gives

lambda_* = 1.533013668413908781825346067486102457523532053057323244598183482593890
t_* = exp(lambda_*) = 4.632115468598573217679586294570902852995680413632516229697146099975060
h_4 = 0.5619007341374007609268031818280392747963893519951641235718277174298387

Interval arithmetic brackets the minimizer and value:
lambda_* in [1.5330136684139087, 1.5330136684139089]
h_4 in [0.56190073413740060119395156059766556163845778099972727303599948476, 0.56190073413740092065965480305841473713218578947883277863159042048].

## 5. Fixed or logarithmic defect bands

For any C_r=O(log r), evaluate the coefficient bound at lambda_*.

Because
n1 = p1 r + O(1),
n2 = p2 r + O(1),

log_2 P_g(e^lambda_*)
= r h_4 + O(1).

Also
(2 C_r+1) exp(|lambda_*| C_r)
is polynomial in r when C_r=O(log r).

Multiplying by the r+1 Sturmian phases still contributes only a polynomial factor. Therefore

limsup_(r->infinity) (1/r) log_2 |L_r(C_r)| <= h_4.

This strictly includes the requested fixed-width theorem C_r=C_D.

## 6. Why the actual critical-log orbit lies in an O(log r) band

Suppose for k>=K

|s_k-kappa log_2 k| <= M.

For every u>=K,

|s_(u+r)-s_u|
<= kappa log_2(1+r/u)+2M
<= kappa log_2(1+r/K)+2M
= O(log r).

Thus every length-r valuation factor whose start u>=K lies in an O(log r) defect band. The at most K factors starting before K are negligible.

Therefore the actual valuation language obeys

limsup_(r->infinity) log_2 p_a(r)/r <= h_4.

## 7. Consequence with frozen Task 6

Frozen Task 6 gives the lower bound

liminf log_2 p_a(r)/r >= alpha/kappa.

Hence ordinary realization requires

alpha/kappa <= h_4,

equivalently

kappa >= kappa_4^* := alpha/h_4.

Independent computation:

kappa_4^* = 2.820716194924186786900689103844608291575330206436301457960103238107952

Certified interval:

kappa_4^* in [2.820716194924185985049020194560877701175422912652590127522695231, 2.8207161949241875887523580131287859897252543927746790069674146309].

Therefore

1 < kappa < kappa_4^*

is incompatible with a positive ordinary LEVEL-3 Syracuse realization under B=4 zero-criticality and the critical-log discrepancy law.

This is load-bearing and must be independently audited before downstream use.
