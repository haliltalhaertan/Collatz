#!/usr/bin/env python3
from collections import defaultdict
from decimal import Decimal, getcontext
import math

getcontext().prec=70
D=Decimal
alpha=D(3).ln()/D(2).ln()
beta=float(alpha-D(1))

def multinomial_distributions(n1,n2):
    facts=[math.factorial(i) for i in range(max(n1,n2)+1)]
    d1=defaultdict(int)
    for c2 in range(n1+1):
        for c3 in range(n1-c2+1):
            c1=n1-c2-c3
            mult=facts[n1]//(facts[c1]*facts[c2]*facts[c3])
            d1[-c1-2*c2-3*c3]+=mult
    d2=defaultdict(int)
    for cm1 in range(n2+1):
        for cm2 in range(n2-cm1+1):
            cp=n2-cm1-cm2
            mult=facts[n2]//(facts[cp]*facts[cm1]*facts[cm2])
            d2[cp-cm1-2*cm2]+=mult
    return d1,d2

def band_count(d1,d2,C):
    total=0
    for x,c in d1.items():
        for Dtot in range(-C,C+1):
            total += c*d2.get(Dtot-x,0)
    return total

# Independent optimizer by derivative bisection.
p1=D(2)-alpha; p2=alpha-D(1)
def Hp(l):
    e1=(-l).exp(); e2=(-D(2)*l).exp(); e3=(-D(3)*l).exp(); ep=l.exp()
    m1=(-e1-D(2)*e2-D(3)*e3)/(e1+e2+e3)
    m2=(ep-e1-D(2)*e2)/(ep+e1+e2)
    return p1*m1+p2*m2
def H(l):
    s1=(-l).exp()+(-D(2)*l).exp()+(-D(3)*l).exp()
    s2=l.exp()+(-l).exp()+(-D(2)*l).exp()
    return (p1*s1.ln()+p2*s2.ln())/D(2).ln()

lo,hi=D("1"),D("2")
for _ in range(220):
    m=(lo+hi)/2
    if Hp(m)>0: hi=m
    else: lo=m
lam=(lo+hi)/2
print("alpha",alpha)
print("lambda*",lam)
print("h4",H(lam))
print("kappa*",alpha/H(lam))

for r in (8,16,32,64,128,256):
    for n2 in sorted(set((math.floor(beta*r),math.ceil(beta*r)))):
        n1=r-n2
        d1,d2=multinomial_distributions(n1,n2)
        vals=[(C,band_count(d1,d2,C)) for C in (0,1,2,4,8)]
        print(r,n1,n2,vals)
