# CP20 TASK 7 — GENERALIZED WORDING REPAIR V2

**Status:** `[AUDIT CANDIDATE]`  
**Date:** 2026-08-26

The historical B=4 theorem remains a valid special corollary, but the phrase
“unbounded valuations remain untouched” is too narrow under the same
zero-critical critical-log hypotheses.

## General theorem

For finite B,
\[
\limsup\frac{\log_2p_a(r)}r\le h_B,
\qquad
\kappa\ge\alpha/h_B.
\]

For B=4 specifically,
\[
\boxed{\kappa\ge\alpha/h_4},
\]
with exact-rational safe consequence
\[
\boxed{\kappa>2.82}.
\]

## Unbounded alphabet

For \(\lambda>0\),
\[
S_{1,\infty}=\frac1{e^\lambda-1},
\qquad
S_{2,\infty}=e^\lambda+\frac1{e^\lambda-1}.
\]
The series diverge for \(\lambda\le0\), so the correct pressure domain is
\((0,\infty)\). Strict convexity and boundary divergence give a unique
minimizer, and
\[
\limsup\frac{\log_2p_a(r)}r\le h_\infty.
\]
Combining with Task 6,
\[
\boxed{\kappa\ge\alpha/h_\infty>2.784}.
\]

Thus unbounded valuations are not an untouched escape inside the
zero-critical critical-log class.

## Monotonicity

Pointwise partition-sum monotonicity gives
\[
h_B\le h_{B+1}\le h_\infty.
\]

## Correct surviving scope

The result does not close:
1. critical sites \(a_k=g_k\);
2. discrepancy laws outside \(s_k=\kappa\log_2k+O(1)\);
3. the high-kappa regime \(\kappa\ge\alpha/h_\infty\);
4. the general Collatz conjecture.

No sampled high-bit, Hensel high-half, growing endpoint state, or cross-adic
mechanism is used.

## Chernoff repair

Use
\[
N(S)t^S\le P(t),\qquad N(S)\le P(t)t^{-S},
\]
not the reversed display appearing in the earlier strengthening draft.

Do not mark this V2 frozen before independent audit.
