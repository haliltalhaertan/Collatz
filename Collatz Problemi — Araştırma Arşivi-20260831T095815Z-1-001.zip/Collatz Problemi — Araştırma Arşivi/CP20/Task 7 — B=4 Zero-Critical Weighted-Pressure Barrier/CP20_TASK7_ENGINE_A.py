#!/usr/bin/env python3
from collections import defaultdict
from decimal import Decimal, getcontext
import math

getcontext().prec=70
D=Decimal
alpha=D(3).ln()/D(2).ln()
beta=float(alpha-D(1))

def defect_distribution(n1,n2):
    dp={0:1}
    for _ in range(n1):
        nd=defaultdict(int)
        for s,c in dp.items():
            for d in (-1,-2,-3):
                nd[s+d]+=c
        dp=nd
    for _ in range(n2):
        nd=defaultdict(int)
        for s,c in dp.items():
            for d in (1,-1,-2):
                nd[s+d]+=c
        dp=nd
    return dp

def H(l):
    p1=D(2)-alpha; p2=alpha-D(1)
    s1=(-l).exp()+(-D(2)*l).exp()+(-D(3)*l).exp()
    s2=l.exp()+(-l).exp()+(-D(2)*l).exp()
    return (p1*s1.ln()+p2*s2.ln())/D(2).ln()

def Hp(l):
    p1=D(2)-alpha; p2=alpha-D(1)
    e1=(-l).exp(); e2=(-D(2)*l).exp(); e3=(-D(3)*l).exp(); ep=l.exp()
    m1=(-e1-D(2)*e2-D(3)*e3)/(e1+e2+e3)
    m2=(ep-e1-D(2)*e2)/(ep+e1+e2)
    return p1*m1+p2*m2

lo,hi=D("1"),D("2")
for _ in range(220):
    m=(lo+hi)/2
    if Hp(m)>0: hi=m
    else: lo=m
lam=(lo+hi)/2
h=H(lam)
print("alpha",alpha)
print("lambda*",lam)
print("h4",h)
print("kappa*",alpha/h)

for r in (8,16,32,64,128,256):
    for n2 in sorted(set((math.floor(beta*r),math.ceil(beta*r)))):
        n1=r-n2
        dp=defect_distribution(n1,n2)
        vals=[]
        for C in (0,1,2,4,8):
            vals.append((C,sum(v for d,v in dp.items() if abs(d)<=C)))
        print(r,n1,n2,vals)
