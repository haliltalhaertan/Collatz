# CP20 TASK 7 — FINDINGS

Date: 2026-08-26

## Strategic verdict

C — [THEOREM: B=4 EXCLUDED FOR A NONTRIVIAL kappa RANGE]

Because the result is load-bearing, normal research has been stopped and an independent zero-trust audit package has been prepared.

## What was proved

[PROVED CANDIDATE]
The B=4 zero-critical abstract defect language with a fixed or O(log r) total-defect band has exponential rate at most

h_4
= inf_lambda [
(2-alpha) log_2(e^-lambda+e^-2lambda+e^-3lambda)
+(alpha-1) log_2(e^lambda+e^-lambda+e^-2lambda)
].

[PROVED CANDIDATE]
Under
s_k=kappa log_2 k+O(1),
the actual valuation language satisfies

limsup log_2 p_a(r)/r <= h_4.

Combining with frozen Task 6,

liminf log_2 p_a(r)/r >= alpha/kappa,

gives the necessary condition

kappa >= alpha/h_4.

Therefore the B=4 zero-critical critical-log class has no positive ordinary LEVEL-3 realizer for

1 < kappa < alpha/h_4.

## Certified numerical values

alpha = 1.584962500721156181453738943947816508759814407692481060455752654541098

lambda_* = 1.533013668413908781825346067486102457523532053057323244598183482593890

h_4 = 0.5619007341374007609268031818280392747963893519951641235718277174298387

kappa_4^* = alpha/h_4 = 2.820716194924186786900689103844608291575330206436301457960103238107952

Safe certified threshold statement:

1 < kappa < 2.820716194924185
=> excluded under the Task-7 hypotheses.

## What was falsified / failure modes checked

- [FAIL] “Sturmian phase arrangement might change the pressure exponent.”
  It does not: the generating function depends only on the two Parikh counts, and those differ by at most 1.

- [FAIL] “The hidden O(1) discrepancy constant destroys the pressure saving.”
  It does not. Even an O(log r) defect band adds only polynomial prefactors at fixed lambda_*.

- [FAIL] “Chernoff sign/minimization direction may be reversed.”
  Re-derived from coefficient positivity: c_D t^D <= P(t), so minimization is in the stated direction.

- [FAIL] “Finite data above h_4 for C_D>0 is a counterexample.”
  It is not. A fixed nonzero band contributes the finite multiplicative factor exp(|lambda_*|C_D); its contribution divided by r vanishes asymptotically.

- [PASS] Two independent exact counting engines agree on all 60 cross-check cases through r=256 and C_D in {0,1,2,4,8}.

## Exact finite enumeration

Characteristic Sturmian scans recovered exactly r+1 factors and the predicted two Parikh counts for r=6,8,10,12,16,32,64.

Exact union enumeration over all phases was also performed for r=6,8,10,12 and C_D=0,1,2. No phase/boundary counterexample was found.

## Surviving parameter range

Unclosed:
kappa >= kappa_4^* ≈ 2.820716194924186786900689103844608291575330206436301457960103238107952.

Also untouched:
- critical sites a_k=g_k;
- unbounded valuations;
- non-critical-log discrepancy laws.

## Audit requirement

YES — independent major audit is required now.

## Single highest-information next question

Can an independent zero-trust auditor reproduce the coefficient-pressure theorem and certify that the transition from the critical-log discrepancy law to the global O(log r) defect band introduces no hidden dependence that invalidates the p_a(r) entropy upper bound?
