# CP20 TASK 7 — B=4 PRESSURE THEOREM

Date: 2026-08-26
Status: [THEOREM CANDIDATE][LOAD-BEARING][STOP FOR INDEPENDENT AUDIT]

## Theorem A — B=4 zero-critical pressure upper bound

Let alpha=log_2 3 and
g_k=floor(alpha(k+1))-floor(alpha k).

Let a=(a_k) satisfy
a_k in {1,2,3,4},
a_k != g_k,
and define
s_k=floor(alpha k)-sum_(i<k)a_i.

Assume there exist kappa>0, K and M<infinity such that for all k>=K,

|s_k-kappa log_2 k| <= M.

Let p_a(r) be the number of distinct length-r factors of a.

Define

h_4 = inf_(lambda in R) [
(2-alpha) log_2(e^-lambda+e^-2lambda+e^-3lambda)
+(alpha-1) log_2(e^lambda+e^-lambda+e^-2lambda)
].

Then

limsup_(r->infinity) log_2 p_a(r)/r <= h_4.

### Proof

For g=1 the allowed defects d=g-a are -1,-2,-3.
For g=2 they are +1,-1,-2.

For a fixed length-r g-factor with n1 occurrences of 1 and n2 occurrences of 2, the defect generating function is

P_g(z)
=(z^-1+z^-2+z^-3)^n1
 (z+z^-1+z^-2)^n2.

Since g is Sturmian, it has exactly r+1 length-r factors, and
n2 is either floor((alpha-1)r) or ceil((alpha-1)r).
Thus
n1=(2-alpha)r+O(1),
n2=(alpha-1)r+O(1).

For any t=e^lambda>0 and any coefficient c_D of P_g,

c_D <= t^-D P_g(t).

Hence the total number of choices with |D|<=C_r is at most

(2C_r+1)e^(|lambda|C_r)P_g(e^lambda).

From the discrepancy hypothesis, for u>=K,

|s_(u+r)-s_u|
<= kappa log_2(1+r/u)+2M
<= kappa log_2(1+r/K)+2M
=O(log r).

So every factor starting at u>=K belongs to a defect band C_r=O(log r).
The at most K factors starting before K add only O(1).

Choose lambda=lambda_*, the unique minimizer of H(lambda). Then
P_g(e^lambda_*)=2^(h_4 r+O(1)),
while the band factor and r+1 Sturmian phases are polynomial in r.
Therefore
p_a(r) <= poly(r) 2^(h_4 r+O(1)),
and the claimed limsup follows. QED.

## Numerical certificate

Unique minimizer:
lambda_* in [1.5330136684139087, 1.5330136684139089].

h_4 in
[0.56190073413740060119395156059766556163845778099972727303599948476, 0.56190073413740092065965480305841473713218578947883277863159042048].

Central value:
h_4 = 0.5619007341374007609268031818280392747963893519951641235718277174298387.

The strict convexity of H plus the certified derivative signs at the bracket endpoints isolates the minimizer.

## Theorem B — Syracuse exclusion range

Use frozen CP20 Task 6:

If a positive ordinary odd-only Syracuse orbit satisfies
s_k=kappa log_2 k+O(1), kappa>1,
then

liminf log_2 p_a(r)/r >= alpha/kappa.

Combining with Theorem A gives the necessary condition

alpha/kappa <= h_4.

Thus

kappa >= alpha/h_4.

Certified threshold:

alpha/h_4 in
[2.820716194924185985049020194560877701175422912652590127522695231, 2.8207161949241875887523580131287859897252543927746790069674146309].

Hence, in particular,

1 < kappa < 2.820716194924185

implies no positive ordinary LEVEL-3 Syracuse realization in the B=4 zero-critical class.

Using the exact variational definition, the sharp Task-7 threshold is
kappa_4^*=alpha/h_4
= 2.820716194924186786900689103844608291575330206436301457960103238107952...

## Scope

This does NOT prove Collatz.

It does NOT close:
- B=4 with kappa >= kappa_4^*;
- words containing critical sites a_k=g_k;
- unbounded valuations;
- discrepancy laws outside s_k=kappa log_2 k+O(1).

No CP19 parked high-half/cross-adic mechanism is used.

Because Theorem B is load-bearing, normal research stops here pending independent zero-trust audit.
