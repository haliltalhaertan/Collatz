# CP20 — PRESSURE GENERALIZATION RIGOROUS PROOF

**Status:** `[AUDIT CANDIDATE]`  
**Date:** 2026-08-26  
**Verdict:** `[PROOF VALID AFTER MINOR REPAIR]`

This document independently re-derives the pressure argument. The only defect
found in the supplied strengthening draft is a reversed Chernoff display.
After correcting it, the finite-B theorem, the B=∞ theorem, the uniform
threshold, and the Task-6 B=3 strengthening remain valid.

## 1. Definitions and exact defect supports

Let
\[
\alpha=\log_2 3,\quad F_k=\lfloor\alpha k\rfloor,\quad
g_k=F_{k+1}-F_k\in\{1,2\},
\]
\[
A_k=\sum_{i<k}a_i,\qquad s_k=F_k-A_k,
\qquad d_k=g_k-a_k.
\]

Assume
\[
s_k=\kappa\log_2 k+O(1),\qquad \kappa>1,
\]
and zero-criticality
\[
a_k\ne g_k.
\]

For finite \(B\ge3\), \(1\le a_k\le B\). Then exactly:

- \(g=1\): \(a\in\{2,\ldots,B\}\), so
  \(d\in\{-1,\ldots,-(B-1)\}\).
- \(g=2\): \(a\in\{1,3,\ldots,B\}\), so
  \(d\in\{+1,-1,\ldots,-(B-2)\}\).

For \(B=\infty\), the same supports extend without a lower bound on negative
defect.

## 2. Lemma P1 — uniform factor defect band

For a length-r factor beginning at u,
\[
\sum_{i=0}^{r-1}d_{u+i}
=(F_{u+r}-F_u)-(A_{u+r}-A_u)
=s_{u+r}-s_u.
\]

Choose \(K\ge1\) and \(M<\infty\) such that
\[
|s_k-\kappa\log_2 k|\le M\qquad(k\ge K).
\]

For every \(u\ge K\),
\[
|s_{u+r}-s_u|
\le
\kappa\log_2\left(1+\frac ru\right)+2M
\le \kappa\log_2(r+1)+2M.
\]

Thus the late factors lie uniformly in
\[
|S|\le C_r,\qquad C_r=\kappa\log_2(r+1)+2M=O(\log r).
\]

The requested starting regimes are explicit:

- \(u<K\): only K starts exist, so at most K extra factors for each r.
- \(K\le u<r\): the displayed \(O(\log r)\) bound is uniform.
- \(u\ge r\): the sharper bound
  \[
  |S|\le\kappa+2M
  \]
  holds.

No u-dependent hidden constant remains.

## 3. Lemma P2 — corrected Chernoff/coefficient inequality

For one fixed g-factor, write
\[
P(t)=\sum_S N(S)t^S,\qquad t>0.
\]
All coefficients are nonnegative, hence
\[
\boxed{N(S)t^S\le P(t)}
\]
and therefore
\[
\boxed{N(S)\le P(t)t^{-S}}.
\]

With \(t=e^\lambda\),
\[
N(S)\le P(e^\lambda)e^{-\lambda S}.
\]

Therefore
\[
\sum_{|S|\le C_r}N(S)
\le
(2C_r+1)P(e^\lambda)e^{|\lambda|C_r}.
\]

For fixed \(\lambda\) and \(C_r=O(\log r)\),
\[
e^{|\lambda|C_r}=r^{O(1)},
\]
so the defect band contributes only polynomial overhead:
\[
\frac1r\log_2(\operatorname{poly}(r))\to0.
\]

**Minor repair.** The supplied strengthening draft/task text had the
inequality written as \(N(S)t^{-S}\le P(t)\). That display is reversed.
The corrected form above leaves the pressure exponent unchanged.

## 4. Lemma P3 — exact Sturmian Parikh structure

Put
\[
\beta=\alpha-1\in(0,1).
\]
Then
\[
g_k=1+\lfloor\beta(k+1)\rfloor-\lfloor\beta k\rfloor.
\]

The number of \(g=2\) sites in a length-r factor beginning at u is
\[
n_2(u,r)
=
\lfloor\beta(u+r)\rfloor-\lfloor\beta u\rfloor.
\]

For all real x,y,
\[
\lfloor x+y\rfloor-\lfloor x\rfloor
\in\{\lfloor y\rfloor,\lceil y\rceil\}.
\]
Because beta is irrational,
\[
n_2(u,r)\in\{\lfloor\beta r\rfloor,\lceil\beta r\rceil\},
\]
and these values differ by exactly one. Hence
\[
n_2=(\alpha-1)r+O(1),\qquad
n_1=(2-\alpha)r+O(1).
\]

The word \(g-1\) is Sturmian, so it has exactly r+1 factors of length r.
For fixed \(n_1,n_2\), the defect generating function is a commutative
product and depends only on the Parikh vector, not the ordering. Phase
variation therefore cannot create an exponential factor.

## 5. Lemma P4 — global factor language, finite B

Define
\[
S_{1,B}(\lambda)
=\sum_{a=2}^{B}e^{\lambda(1-a)},
\]
\[
S_{2,B}(\lambda)
=\sum_{\substack{1\le a\le B\\a\ne2}}
e^{\lambda(2-a)},
\]
\[
H_B(\lambda)
=
(2-\alpha)\log_2S_{1,B}(\lambda)
+
(\alpha-1)\log_2S_{2,B}(\lambda),
\]
and
\[
h_B=\inf_{\lambda\in\mathbb R}H_B(\lambda).
\]

For a fixed g-factor,
\[
P_g(e^\lambda)
=
S_{1,B}(\lambda)^{n_1}
S_{2,B}(\lambda)^{n_2},
\]
and therefore
\[
\log_2P_g(e^\lambda)=rH_B(\lambda)+O(1)
\]
uniformly over the two Parikh possibilities.

Combining P1–P3,
\[
p_a(r)
\le
K+(r+1)(2C_r+1)e^{|\lambda|C_r}
2^{rH_B(\lambda)+O(1)}.
\]

Thus for every fixed lambda,
\[
\limsup_{r\to\infty}\frac{\log_2p_a(r)}r
\le H_B(\lambda).
\]
Taking the infimum,
\[
\boxed{
\limsup_{r\to\infty}\frac{\log_2p_a(r)}r
\le h_B.
}
\]

## 6. The B=infinity theorem

Let \(t=e^\lambda\) and \(q=e^{-\lambda}\). The infinite tails converge
exactly when
\[
\boxed{\lambda>0}.
\]

On that domain,
\[
S_{1,\infty}
=
\sum_{a\ge2}e^{\lambda(1-a)}
=
\frac{q}{1-q}
=
\frac1{t-1},
\]
and
\[
S_{2,\infty}
=
\sum_{\substack{a\ge1\\a\ne2}}e^{\lambda(2-a)}
=
e^\lambda+\frac{q}{1-q}
=
t+\frac1{t-1}.
\]

Define
\[
H_\infty(\lambda)
=
(2-\alpha)\log_2S_{1,\infty}
+
(\alpha-1)\log_2S_{2,\infty},
\qquad \lambda>0,
\]
and
\[
h_\infty=\inf_{\lambda>0}H_\infty(\lambda).
\]

Each log-partition has second derivative equal to a positive tilted variance.
Both supports are non-degenerate, so
\[
H_\infty''(\lambda)>0.
\]
Hence \(H_\infty\) is strictly convex.

As \(\lambda\downarrow0\),
\(S_{1,\infty}\to\infty\), hence \(H_\infty\to\infty\).

As \(\lambda\to\infty\),
\[
H_\infty(\lambda)
=
\frac{(2\alpha-3)\lambda}{\ln2}+O(1),
\]
and \(2\alpha-3>0\). Thus \(H_\infty\to\infty\).

So there is a unique interior minimizer.

The same coefficient argument applies because the partition functions are
finite for every \(\lambda>0\). A fixed total defect S also has finite
coefficient multiplicity: positive defects are only +1, so the number of
positive contributions is at most r, forcing the total magnitude of negative
defects to be bounded by r+|S|.

Therefore, with no upper bound on the valuation alphabet,
\[
\boxed{
\limsup_{r\to\infty}\frac{\log_2p_a(r)}r
\le h_\infty.
}
\]

## 7. Exact-rational certificate

`CP20_PRESSURE_INTERVAL_CERTIFICATE.py` uses only exact
`fractions.Fraction` arithmetic for proof decisions.

For rational x>0 it encloses
\[
\log x=
2\sum_{n=0}^{N-1}\frac{y^{2n+1}}{2n+1}+R_N,
\qquad y=\frac{x-1}{x+1},
\]
with exact tail
\[
|R_N|
\le
\frac{2|y|^{2N+1}}{(2N+1)(1-y^2)}.
\]

The script rigorously isolates the unique minimizers for B=3, B=4 and
B=infinity by exact derivative-sign brackets, and produces exact rational
intervals for \(h_B\) and \(\alpha/h_B\).

Small exact downstream certificates are:

\[
\alpha>\frac{792481}{500000}=1.584962,
\]
\[
h_3<\frac{523467}{10^6},
\qquad
\frac{\alpha}{h_3}>
\frac{1584962}{523467}>
\frac{3027}{1000}=3.027,
\]
\[
h_4<\frac{561901}{10^6},
\qquad
\frac{\alpha}{h_4}>
\frac{1584962}{561901}>
\frac{141}{50}=2.82,
\]
and
\[
\boxed{
h_\infty<\frac{56931}{100000}=0.56931
}
\]
with
\[
\boxed{
\frac{\alpha}{h_\infty}>
\frac{792481}{284655}>
\frac{348}{125}=2.784.
}
\]

No proof-critical conclusion depends on binary floating point.

## 8. Task-6 lower theorem is alphabet-independent

The Task-6 factor-complexity lower theorem uses only:

1. the exact affine Syracuse recurrence;
2. \(s_k=\kappa\log_2k+O(1)\), \(\kappa>1\), to get
   \(n_k=O(k^\kappa)\);
3. exact repeated-factor spacing
   \(2^{A(W)}\mid(n_v-n_u)\);
4. local valuation mass on the counting windows.

No bounded alphabet or B=3 assumption appears in these steps.
The bounded-alphabet hypothesis first enters the old Task-6 §6 upper count.

Therefore the Task-6 lower theorem remains unchanged:
\[
\boxed{
\liminf_{r\to\infty}
\frac{\log_2p_a(r)}r
\ge\frac{\alpha}{\kappa}.
}
\]

Combining with the pressure upper theorem,
\[
\frac{\alpha}{\kappa}
\le\liminf
\le\limsup
\le h_B,
\]
so
\[
\boxed{\kappa\ge\frac{\alpha}{h_B}}.
\]

For an unbounded valuation alphabet,
\[
\boxed{
\kappa\ge\frac{\alpha}{h_\infty}>2.784.
}
\]

## 9. Monotonicity

For fixed lambda, enlarging B enlarges both allowed partition sums:
\[
H_B(\lambda)\le H_{B+1}(\lambda).
\]
Taking infima preserves the direction:
\[
\boxed{h_B\le h_{B+1}}.
\]

For every \(\lambda>0\),
\[
H_B(\lambda)\le H_\infty(\lambda).
\]
Evaluating at the unique infinite-alphabet minimizer,
\[
h_B
\le H_B(\lambda_\infty^*)
\le H_\infty(\lambda_\infty^*)
=h_\infty.
\]

Therefore
\[
\boxed{h_B\le h_{B+1}\le h_\infty}.
\]

No exchange of limit and infimum is needed.

## 10. Uniform pressure theorem

**ZERO-CRITICAL CRITICAL-LOG UNIFORM PRESSURE THEOREM — AUDIT CANDIDATE**

If a positive ordinary odd-only Syracuse orbit satisfies
\[
a_k\ne g_k\quad\forall k,
\]
\[
s_k=\kappa\log_2k+O(1),\qquad \kappa>1,
\]
then, with no upper bound on \(a_k\),
\[
\boxed{
\kappa\ge\frac{\alpha}{h_\infty}.
}
\]

The exact rational certificate gives the safe corollary
\[
\boxed{\kappa>2.784}.
\]

This does not cover critical sites \(a_k=g_k\), discrepancy laws outside the
critical-log hypothesis, the high-kappa regime above the threshold, or the
general Collatz conjecture.

## 11. Task-6 B=3 strengthening

Task-6 §5 is unchanged.

The old Task-6 §§6–7 bound
\[
p_a(r)\le(r+1)2^r,\qquad \kappa\ge\alpha
\]
is **[VALID BUT SUPERSEDED]** under the same B=3 zero-critical assumptions.

The pressure corollary gives
\[
\boxed{
\kappa\ge\frac{\alpha}{h_3}>3.027.
}
\]

The informational high-precision boundary is about
\(3.0278192656397885\), but the theorem-critical statement above is exact
rationally certified.

## 12. Final status

\[
\boxed{\textbf{[PROOF VALID AFTER MINOR REPAIR]}}
\]

The package is not frozen. Independent zero-trust audit is required before
downstream theorem use.
