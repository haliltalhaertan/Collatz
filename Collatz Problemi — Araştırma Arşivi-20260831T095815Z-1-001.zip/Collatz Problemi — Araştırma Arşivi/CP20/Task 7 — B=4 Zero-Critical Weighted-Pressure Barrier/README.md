# CP20 PRESSURE GENERALIZATION — AUDIT PACKAGE

**Status:** `[AWAITING INDEPENDENT ZERO-TRUST AUDIT]`  
**Date:** 2026-08-26  
**Do not mark frozen. Do not use downstream before audit.**

## Candidate theorem

For a positive ordinary odd-only Syracuse orbit, let
\[
\alpha=\log_2 3,\quad
F_k=\lfloor\alpha k\rfloor,\quad
g_k=F_{k+1}-F_k,\quad
s_k=F_k-\sum_{i<k}a_i.
\]

Assume
\[
a_k\ne g_k\quad\forall k,
\]
\[
s_k=\kappa\log_2k+O(1),\qquad \kappa>1.
\]

No upper bound on the valuation alphabet is assumed.

The audit candidate claims
\[
\boxed{
\kappa\ge\frac{\alpha}{h_\infty}
}
\]
with rigorously certified safe corollary
\[
\boxed{\kappa>2.784}.
\]

For B=3, the strengthened corollary is
\[
\boxed{\kappa\ge\alpha/h_3>3.027}.
\]

The historical B=4 Task-7 result remains a special corollary.

## Important repair

The previous strengthening draft displayed the Chernoff coefficient inequality
with the exponent sign reversed.

Correct:
\[
N(S)t^S\le P(t),
\qquad
N(S)\le P(t)t^{-S}.
\]

The correction changes no exponential-rate conclusion because the relevant
defect band has size \(O(\log r)\).

## Package contents

- `CP20_PRESSURE_GENERALIZATION_RIGOROUS_PROOF.md`
- `CP20_PRESSURE_INTERVAL_CERTIFICATE.py`
- `CP20_PRESSURE_INTERVAL_CERTIFICATE_OUTPUT.txt`
- `CP20_TASK6_STRENGTHENED_COROLLARY_V2.md`
- `CP20_TASK7_GENERALIZED_WORDING_REPAIR_V2.md`
- `CP20_PRESSURE_COUNTEREXAMPLE_SEARCH_REPORT.md`
- `CP20_PRESSURE_NUMERICAL_REPRODUCTION.md`
- `CP20_PRESSURE_DEPENDENCY_GRAPH.md`
- `CP20_PRESSURE_GENERALIZATION_AUDIT_PROMPT.md`
- `SHA256SUMS.txt`
- `README.md`

## Scope

This package does not prove Collatz and does not exclude:

- critical sites \(a_k=g_k\);
- non-critical-log discrepancy laws;
- the high-kappa regime above the certified pressure threshold;
- all cycles;
- all divergent scenarios.

## Required next step

Independent zero-trust audit using
`CP20_PRESSURE_GENERALIZATION_AUDIT_PROMPT.md`.

Do not start Task 8 before the audit verdict is integrated.
