# CP20 — PRESSURE COUNTEREXAMPLE SEARCH REPORT

**Status:** `[AUDIT CANDIDATE]`

| Attack | Verdict | Result |
|---|---|---|
| A. Chernoff sign reversal | `[BUG]` | Supplied draft has the sign reversed. Correct: `N(S)t^S <= P(t)`, hence `N(S)<=P(t)t^{-S}`. The theorem survives. |
| B. lambda<0 / boundary minimum | `[VALID]` | For B=∞, lambda<=0 is outside the convergence domain; both admissible boundaries send pressure to +∞. Finite B has a unique positive minimum. |
| C. B=∞ series divergence | `[VALID]` | Exact convergence domain is lambda>0; geometric tails converge there. |
| D. Phase-dependent exponential blow-up | `[VALID]` | Only two Parikh vectors occur and there are r+1 Sturmian phases. No exponential phase factor. |
| E. Small-u starts | `[VALID]` | Only finitely many starts occur before the asymptotic index K. |
| F. O(log r) band nonuniformity | `[VALID]` | Uniform bound: `|s_(u+r)-s_u| <= kappa log2(r+1)+2M` for all u>=K. |
| G. Wrong p_a(r) factor definition | `[VALID]` | p_a(r) is distinct length-r factors of the single valuation word; every factor is included in the global union bound. |
| H. Hidden bounded alphabet in Task-6 lower theorem | `[VALID]` | None in §§1–5; bounded B first appears in historical §6. |
| I. h_B monotonicity direction | `[VALID]` | Pointwise H_B<=H_(B+1), so inf H_B<=inf H_(B+1); evaluating at lambda*_∞ also gives h_B<=h_∞. |

## Extra checks

For B=∞, fixed total defect S has finite coefficient multiplicity: positive
defects are only +1, so at most r positive contributions occur and the total
negative magnitude is bounded by r+|S|.

No load-bearing counterexample was found.

The sole actual defect is the Chernoff display sign, classified as a minor
repair rather than a theorem failure.
