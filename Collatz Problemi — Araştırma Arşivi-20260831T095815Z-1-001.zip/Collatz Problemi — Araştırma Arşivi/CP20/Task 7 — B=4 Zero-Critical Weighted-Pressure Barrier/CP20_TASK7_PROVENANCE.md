# CP20 TASK 7 — PROVENANCE

Canonical project folder:
https://drive.google.com/drive/folders/1mRJGjUsali3eOYtRyMnvO19afK_M4SY5

CP20 root:
https://drive.google.com/drive/folders/1AQdsFvnL6ogSUGHxL_FQEoNAXAPNehhz

CP20 Task 7 canonical folder:
https://drive.google.com/drive/folders/1x8WFIySzAF7UQopqkHyp2dMLvW5jzTRG

Frozen/audited inputs read before computation:
- CP20_MASTER_CHECKPOINT_2026-08-26_TASK6_AUDITED
- CP20_TASK6_MAJOR_THEOREM_V2_AUDITED_FROZEN
- CP20_TASK6_FINDINGS_V2_AUDIT_INTEGRATED
- CP20_TASK6_SURVIVOR_EXCLUSION_V2_AUDITED_FROZEN
- CP20_TASK6_RESUPPLY_AUDIT_VERDICT_2026-08-26
- CP20_TASK6_FINAL_FREEZE_DECISION_2026-08-26
- CP20_TASK7_RESEARCH_PROMPT
- CP20_PROMPT_INDEX

Canonical Task-6 wording repairs were respected. Truncated historical BIG_AUDIT_PACKAGE copies were not used as canonical input.
