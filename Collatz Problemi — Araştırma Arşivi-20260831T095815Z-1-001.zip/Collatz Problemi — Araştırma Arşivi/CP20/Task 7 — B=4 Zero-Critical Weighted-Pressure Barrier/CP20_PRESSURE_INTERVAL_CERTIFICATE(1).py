#!/usr/bin/env python3
"""
CP20 pressure generalization exact-rational certificate.
Status: [AUDIT CANDIDATE]

All proof-critical comparisons use fractions.Fraction only.
Natural logarithms of positive rationals are enclosed by the atanh series
with an exact rational remainder bound.
"""
from fractions import Fraction

NLOG = 240

def F(s):
    return Fraction(s)

def log_bounds(x, N=NLOG):
    assert isinstance(x, Fraction) and x > 0
    y = (x - 1) / (x + 1)
    y2 = y*y
    term = y
    partial = Fraction(0)
    for n in range(N):
        partial += term / (2*n + 1)
        term *= y2
    partial *= 2
    rem = 2 * abs(term) / ((2*N + 1) * (1-y2))
    if y >= 0:
        return partial, partial + rem
    return partial - rem, partial

def iadd(A,B): return A[0]+B[0], A[1]+B[1]
def ineg(A): return -A[1], -A[0]
def isub(A,B): return iadd(A, ineg(B))
def imul(A,B):
    v = [A[i]*B[j] for i in (0,1) for j in (0,1)]
    return min(v), max(v)
def idiv(A,B):
    assert B[0] > 0 or B[1] < 0
    if B[0] > 0:
        inv = (Fraction(1,B[1]), Fraction(1,B[0]))
    else:
        inv = (Fraction(1,B[0]), Fraction(1,B[1]))
    return imul(A,inv)
def ipow(T,n):
    lo,hi=T
    if n >= 0:
        return lo**n, hi**n
    k=-n
    return Fraction(1,hi**k), Fraction(1,lo**k)
def ilog(A):
    lo,_=log_bounds(A[0])
    _,hi=log_bounds(A[1])
    return lo,hi

LN2=log_bounds(Fraction(2))
LN3=log_bounds(Fraction(3))
ALPHA=idiv(LN3,LN2)
P1=(2-ALPHA[1],2-ALPHA[0])
P2=(ALPHA[0]-1,ALPHA[1]-1)

def finite_parts(B,T):
    z=(Fraction(0),Fraction(0))
    S1=z
    for a in range(2,B+1):
        S1=iadd(S1,ipow(T,1-a))
    S2=z
    for a in range(1,B+1):
        if a != 2:
            S2=iadd(S2,ipow(T,2-a))
    return S1,S2

def H_finite(B,T):
    S1,S2=finite_parts(B,T)
    l1=idiv(ilog(S1),LN2)
    l2=idiv(ilog(S2),LN2)
    return iadd(imul(P1,l1),imul(P2,l2))

def H_infinity(T):
    one=(Fraction(1),Fraction(1))
    inv=idiv(one,isub(T,one))
    S1=inv
    S2=iadd(T,inv)
    l1=idiv(ilog(S1),LN2)
    l2=idiv(ilog(S2),LN2)
    return iadd(imul(P1,l1),imul(P2,l2))

def mean_finite(B,t,kind):
    support=(list(range(-1,-B,-1)) if kind==1
             else [1]+list(range(-1,-(B-1),-1)))
    Z=Fraction(0); M=Fraction(0)
    for d in support:
        w=t**d if d>=0 else Fraction(1,t**(-d))
        Z += w
        M += d*w
    return M/Z

def dH_finite(B,t):
    m1=mean_finite(B,t,1)
    m2=mean_finite(B,t,2)
    return iadd(imul(P1,(m1,m1)),imul(P2,(m2,m2)))

def dH_infinity(t):
    m1=-t/(t-1)
    S2=t+Fraction(1,t-1)
    m2=t*(1-Fraction(1,(t-1)**2))/S2
    return iadd(imul(P1,(m1,m1)),imul(P2,(m2,m2)))

def outward_decimal(x,digits,upper):
    scale=10**digits
    n=x.numerator*scale
    q=n//x.denominator
    rem=n%x.denominator
    if x>=0:
        if upper and rem: q+=1
    else:
        # Python // floors, so q is already the lower integer.
        if upper and rem: q+=1
    sign="-" if q<0 else ""
    s=str(abs(q)).rjust(digits+1,"0")
    return sign+s[:-digits]+"."+s[-digits:]

def show_interval(name,I,digits=32):
    lo=outward_decimal(I[0],digits,False)
    hi=outward_decimal(I[1],digits,True)
    print(f"{name} in [{lo}, {hi}]")

# Rational brackets around independently recomputed minimizers.
T3=(F("3.6667732426177677"),F("3.6667732426177679"))
T4=(F("4.6321154685985731"),F("4.6321154685985734"))
TI=(F("4.9371845970284872"),F("4.9371845970284876"))

cases=[
    ("B=3",T3,lambda t:dH_finite(3,t),lambda T:H_finite(3,T)),
    ("B=4",T4,lambda t:dH_finite(4,t),lambda T:H_finite(4,T)),
    ("B=infinity",TI,dH_infinity,H_infinity),
]

print("CP20 PRESSURE GENERALIZATION — EXACT RATIONAL CERTIFICATE")
print("Status: [AUDIT CANDIDATE]")
show_interval("alpha=log_2(3)",ALPHA,35)
print()

results={}
for label,T,deriv,hfun in cases:
    dlo=deriv(T[0]); dhi=deriv(T[1])
    assert dlo[1] < 0
    assert dhi[0] > 0
    H=hfun(T)
    K=idiv(ALPHA,H)
    lam=(log_bounds(T[0])[0],log_bounds(T[1])[1])
    print(label)
    print("  t bracket:",T)
    show_interval("  lambda*",lam,32)
    show_interval("  h",H,32)
    show_interval("  alpha/h",K,32)
    print("  derivative(lower)<0: PASS")
    print("  derivative(upper)>0: PASS")
    print()
    results[label]=(H,K)

# Simple exact rational downstream inequalities.
ALPHA_LOW=Fraction(792481,500000)  # 1.584962
H3_UP=Fraction(523467,1000000)
H4_UP=Fraction(561901,1000000)
HI_UP=Fraction(56931,100000)

assert ALPHA[0] > ALPHA_LOW
assert results["B=3"][0][1] < H3_UP
assert results["B=4"][0][1] < H4_UP
assert results["B=infinity"][0][1] < HI_UP

K3=ALPHA_LOW/H3_UP
K4=ALPHA_LOW/H4_UP
KI=ALPHA_LOW/HI_UP

assert K3 > Fraction(3027,1000)
assert K4 > Fraction(141,50)
assert KI > Fraction(348,125)

print("EXACT SMALL-RATIONAL DOWNSTREAM CERTIFICATES")
print("alpha > 792481/500000 = 1.584962")
print("h_3 < 523467/1000000 = 0.523467")
print("alpha/h_3 > 1584962/523467 > 3027/1000 = 3.027")
print("h_4 < 561901/1000000 = 0.561901")
print("alpha/h_4 > 1584962/561901 > 141/50 = 2.82")
print("h_infinity < 56931/100000 = 0.56931")
print("alpha/h_infinity > 792481/284655 > 348/125 = 2.784")
print()
print("ALL PROOF-CRITICAL ASSERTIONS: PASS")
