# CP20 — PRESSURE GENERALIZATION INDEPENDENT ZERO-TRUST AUDIT

Status: **[AWAITING INDEPENDENT ZERO-TRUST AUDIT]**  
Date: 2026-08-26

## Role

You are the independent adversarial proof auditor.

Do not assume any theorem statement, numerical threshold, interval certificate,
or previous audit verdict is correct. Your objective is to break the proof if
possible.

This package is an **audit candidate**, not a frozen checkpoint.

## Claimed theorem to audit

Let
\[
\alpha=\log_2 3,\qquad
F_k=\lfloor\alpha k\rfloor,\qquad
g_k=F_{k+1}-F_k,
\]
and for a positive ordinary odd-only Syracuse orbit let
\[
A_k=\sum_{i<k}a_i,\qquad
s_k=F_k-A_k.
\]

Assume
\[
a_k\ne g_k\quad\forall k,
\]
\[
s_k=\kappa\log_2 k+O(1),\qquad \kappa>1.
\]

No upper bound on \(a_k\) is assumed.

The candidate theorem claims
\[
\boxed{\kappa\ge\alpha/h_\infty},
\]
where
\[
h_\infty
=
\inf_{\lambda>0}
\left[
(2-\alpha)\log_2\frac1{e^\lambda-1}
+
(\alpha-1)\log_2
\left(e^\lambda+\frac1{e^\lambda-1}\right)
\right].
\]

The exact-rational certificate claims the safe corollary
\[
\boxed{\kappa>2.784}.
\]

For bounded B the package also claims
\[
\limsup_{r\to\infty}\frac{\log_2p_a(r)}r\le h_B,
\qquad
\kappa\ge\alpha/h_B,
\]
and for B=3 in particular
\[
\boxed{\kappa>3.027}.
\]

## Mandatory zero-trust checks

1. **Task 6 lower theorem**
   Re-derive from scratch
   \[
   \liminf_{r\to\infty}\frac{\log_2p_a(r)}r\ge\frac{\alpha}{\kappa}.
   \]
   Check specifically whether bounded alphabet, B=3, zero-criticality, or any
   hidden finite-state assumption is used in its proof.

2. **Uniform factor-defect band**
   Starting only from
   \[
   s_k=\kappa\log_2k+O(1),
   \]
   prove or refute a uniform
   \[
   |s_{u+r}-s_u|\le \kappa\log_2(r+1)+C
   \]
   for all sufficiently late u.
   Treat u<K, K<=u<r, and u>=r separately.

3. **Chernoff sign**
   Re-derive the positive-coefficient inequality. The candidate package uses
   \[
   P(t)=\sum_SN(S)t^S,
   \qquad
   N(S)t^S\le P(t),
   \qquad
   N(S)\le P(t)t^{-S}.
   \]
   Check the sign, the convention \(t=e^\lambda\), and the minimization
   direction independently.

4. **Polynomial overhead**
   Verify rigorously that an \(O(\log r)\) defect band contributes only
   \(r^{O(1)}\) for fixed lambda and cannot alter exponential entropy.

5. **Sturmian Parikh theorem**
   Re-derive
   \[
   n_2(u,r)
   =
   \lfloor(\alpha-1)(u+r)\rfloor
   -
   \lfloor(\alpha-1)u\rfloor,
   \]
   and prove that only two Parikh values occur for fixed r.
   Verify exact factor complexity \(p_g(r)=r+1\).

6. **Global factor-language passage**
   Check that per-phase counting really bounds the distinct factors of the
   single valuation word \(a_0a_1\ldots\).
   Inspect:
   - r+1 phase multiplicity,
   - two Parikh vectors,
   - finite early starts,
   - O(log r) defect band,
   - possible collisions/overlaps.

7. **B=infinity convergence**
   Re-derive the infinite partition functions and verify that their exact
   convergence domain is \(\lambda>0\).
   Check that coefficient multiplicities are finite and that use of an
   infinite alphabet introduces no hidden exchange-of-sums gap.

8. **Existence and uniqueness of minimizer**
   Check strict convexity or an equally strong substitute.
   Verify both boundaries:
   \[
   H_\infty(\lambda)\to+\infty
   \quad(\lambda\downarrow0),
   \]
   \[
   H_\infty(\lambda)\to+\infty
   \quad(\lambda\to+\infty).
   \]

9. **Monotonicity**
   Independently check
   \[
   h_B\le h_{B+1}\le h_\infty.
   \]
   Do not assume pointwise monotonicity automatically passes through an
   infimum in the claimed direction.

10. **Exact rational/interval certificate**
    Do not trust the supplied output.
    Re-run or independently reproduce:
    - alpha enclosure,
    - derivative sign brackets for B=3, B=4, B=infinity,
    - h_B bounds,
    - alpha/h_B bounds,
    - the rational consequences
      \[
      \alpha/h_3>3.027,
      \quad
      \alpha/h_4>2.82,
      \quad
      \alpha/h_\infty>2.784.
      \]
    Check that no theorem-critical comparison relies on binary floating point.

11. **Circularity**
    Verify that the pressure upper theorem does not use any conclusion that
    itself depends on the Task-6 crude alphabet upper bound which it is
    superseding.

12. **CP19 park**
    Verify that no parked CP19 high-half / Hensel / cross-adic mechanism has
    been reintroduced under new notation.

13. **Scope inflation**
    Check that the theorem does **not** claim to exclude:
    - critical sites \(a_k=g_k\),
    - non-critical-log discrepancy laws,
    - the high-kappa regime above the threshold,
    - arbitrary cycles or all divergence,
    - the Collatz conjecture itself.

14. **Counterexample-first**
    Attempt exact or constructive counterexamples to every transition before
    accepting it.

## Required audit verdict

Return exactly one principal verdict:

- `[PROOF VALID]`
- `[PROOF VALID WITH WORDING REPAIR]`
- `[MAJOR GAP]`
- `[FALSE / COUNTEREXAMPLE]`

If valid, state whether the package may be frozen as the canonical
CP20 pressure-generalization theorem.

Do not continue to Task 8.
