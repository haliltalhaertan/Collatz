# CP20 TASK 5 — E-SEQUENCE / 3-ADIC TRANSLATION

The controller valuation word is an E-sequence in the classical accelerated \(3x+1\) terminology.

Its cumulative valuation satisfies
\[
A_k=F_k-s_k=\alpha k-\kappa\log_2 k+O(1),
\]
so
\[
\boxed{A_k/k\to\alpha=\log_2 3}
\]
from below.

The Task-4 endpoint \(e_k\) is the canonical finite right-end residue for the same affine E-sequence equations. An eventually zero sheet process is equivalent to the canonical endpoint sequence becoming an actual positive odd Syracuse tail.

## Literature boundary

SanMin Wang's E-sequence results prove \(\Omega\)-divergence for several classes, including a strict average-valuation regime above \(\log_2 3\), plus some special mechanical/repetitive words.

Those hypotheses do not apply to the CP20 controller: its mean approaches exactly the critical value, with logarithmic negative discrepancy, and its high-turnover word is not one of the proved mechanical classes.

Thus no external theorem used here proves infinite sheet activation for the explicit controller.

Status: `[BARRIER: CRITICAL E-SEQUENCE EQUALITY CASE]`.
