# CP20 TASK 5 — LINEAR ZERO-SHEET SUFFIX CONTRAPOSITIVE

Assume a zero-sheet interval \([u,u+r)\). Then
\[
2^{A(u,r)}e_{u+r}=3^r e_u+B_{u,r}.
\]

For the frozen controller,
\[
s_k=\kappa\log_2 k+O(1).
\]
When \(u\) and \(u+r\) are comparable, e.g. \(r=\delta(u+r)\) for fixed \(0<\delta<1\),
\[
s_{u+r}-s_u=O(1).
\]
Hence
\[
A(u,r)=\alpha r+O(1),
\qquad
\frac{3^r}{2^{A(u,r)}}=\Theta(1).
\]
The same local discrepancy control gives
\[
\frac{B_{u,r}}{2^{A(u,r)}}=O(r).
\]
Therefore
\[
\boxed{e_{u+r}=\Theta(e_u)+O(r).}
\]

If a hypothetical actual orbit has \(e_u\asymp u^\kappa\) with \(\kappa>1\), the additive \(O(r)=O(u)\) term is lower order and is compatible with \(e_{u+r}\asymp(u+r)^\kappa\).

Thus a linear zero-sheet suffix does not contradict the Archimedean polynomial state law by affine size alone.

Verdict: `[FAIL: LINEAR-SUFFIX AFFINE SIZE ALONE IS COMPATIBLE]`.
