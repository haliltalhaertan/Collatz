#!/usr/bin/env python3
"""Exact kappa=1053/1000 controller + canonical endpoint sheet recurrence."""
import hashlib
P,Q=1053,1000

def controller_condition(s,n):
    if s<=0:return True
    return (1 << (Q*s)) <= pow(n,P)

def generate(K):
    p3=1;prevF=0;s=0;word=[]
    for k in range(K):
        p3*=3;Fnext=p3.bit_length()-1;g=Fnext-prevF;prevF=Fnext
        d=1 if (g==2 and controller_condition(s,max(2,k+1))) else -1
        a=g-d
        assert a in (1,2,3) and a!=g
        word.append(a);s+=d
    return word

def endpoint_step(e,p3,a):
    M=1<<a
    m=(-(3*e+1)*pow(p3,-1,M))%M
    en=(3*e+1+m*p3)//M
    assert 0<=en<p3
    return en,m

def run(K=100000):
    word=generate(K);e=0;p3=1;zr=mx=nz=0;records=[];hist={};ms={}
    for k,a in enumerate(word):
        p3*=3;e,m=endpoint_step(e,p3,a);ms[m]=ms.get(m,0)+1
        if m==0:zr+=1
        else:
            nz+=1;hist[zr]=hist.get(zr,0)+1
            if zr>mx:mx=zr;records.append((k,zr))
            zr=0
    return {'K':K,'nonzero_sheet_count':nz,'activation_density':nz/K,'max_zero_run':max(mx,zr),'terminal_zero_run':zr,'record_runs':records,'sheet_value_counts':ms,'word_sha256':hashlib.sha256(bytes(word)).hexdigest()}
if __name__=='__main__':
    r=run();print(r);assert r['max_zero_run']==12;print('CP20 TASK5 ENGINE A: OK')
