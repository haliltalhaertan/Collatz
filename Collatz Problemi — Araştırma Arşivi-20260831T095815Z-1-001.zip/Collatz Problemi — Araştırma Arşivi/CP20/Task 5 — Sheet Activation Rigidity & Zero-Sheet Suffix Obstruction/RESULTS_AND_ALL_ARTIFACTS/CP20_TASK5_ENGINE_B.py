#!/usr/bin/env python3
"""Independent threshold-breakpoint controller + direct affine endpoint reconstruction."""
P,Q=1053,1000

def ceil_root_threshold(s):
    if s<=0:return 1
    target=1<<(Q*s);lo,hi=1,2
    while pow(hi,P)<target:hi*=2
    while lo<hi:
        mid=(lo+hi)//2
        if pow(mid,P)>=target:hi=mid
        else:lo=mid+1
    return lo

def generate(K):
    thresholds={};p3=1;prevF=0;s=0;word=[]
    for k in range(K):
        p3*=3;Fnext=p3.bit_length()-1;g=Fnext-prevF;prevF=Fnext
        if s not in thresholds:thresholds[s]=ceil_root_threshold(s)
        cond=max(2,k+1)>=thresholds[s]
        d=1 if (g==2 and cond) else -1
        a=g-d;assert a in (1,2,3) and a!=g
        word.append(a);s+=d
    return word

def direct_endpoint_prefixes(word,limit=2000):
    A=0;B=0;p3=1;out=[]
    for k,a in enumerate(word[:limit]):
        B=3*B+(1<<A);A+=a;p3*=3
        e=(B*pow(pow(2,A,p3),-1,p3))%p3
        prev=out[-1][1] if out else 0
        M=1<<a;m=(-(3*prev+1)*pow(p3,-1,M))%M
        out.append((k+1,e,m,A))
    return out
if __name__=='__main__':
    w=generate(5000);rows=direct_endpoint_prefixes(w,2000);assert len(rows)==2000
    print('word prefix',w[:20]);print('last endpoint bits',rows[-1][1].bit_length());print('CP20 TASK5 ENGINE B: OK')
