# CP20 TASK 5 — SHEET CRITERION

Let
\[
e_k=[2^{-A_k}B_k]_{3^k},\qquad 0\le e_k<3^k,
\]
and append valuation \(a_k\ge1\).

There is a unique
\[
0\le m_k<2^{a_k}
\]
such that
\[
\boxed{
e_{k+1}=\frac{3e_k+1+m_k3^{k+1}}{2^{a_k}}
}
\]
is an integer in \([0,3^{k+1})\).

Since \(3^{k+1}\) is invertible modulo \(2^{a_k}\),
\[
\boxed{
m_k\equiv-(3e_k+1)(3^{k+1})^{-1}\pmod{2^{a_k}}.
}
\]
Therefore
\[
\boxed{m_k=0\iff 2^{a_k}\mid 3e_k+1.}
\]

For the explicit alphabet \(\{1,2,3\}\):

- \(a_k=1\): zero sheet iff \(e_k\) is odd;
- \(a_k=2\): zero sheet iff \(e_k\equiv1\pmod4\);
- \(a_k=3\): zero sheet iff \(e_k\equiv5\pmod8\).

If a zero-sheet step is followed by another zero-sheet step, the intermediate endpoint is odd, so the prescribed valuation is exact:
\[
a_k=v_2(3e_k+1).
\]

Status: `[EXACT]`.
