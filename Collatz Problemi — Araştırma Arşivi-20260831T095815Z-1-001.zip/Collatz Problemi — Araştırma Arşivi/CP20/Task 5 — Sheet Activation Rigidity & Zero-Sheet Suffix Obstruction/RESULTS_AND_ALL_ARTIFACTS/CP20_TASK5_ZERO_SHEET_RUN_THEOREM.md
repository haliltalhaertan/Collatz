# CP20 TASK 5 — ZERO-SHEET RUN THEOREM

Fix a valuation word
\[
W=(a_u,\ldots,a_{u+r-1}),\qquad A=A(W),
\]
with affine numerator
\[
B_W=\sum_{j=0}^{r-1}3^{r-1-j}2^{A_j}.
\]

The run
\[
m_u=\cdots=m_{u+r-1}=0
\]
is equivalent to the divisibility chain
\[
2^{A_j}\mid 3^j e_u+B_j\qquad(1\le j\le r).
\]
Equivalently the entire run is characterized by one congruence:
\[
\boxed{
e_u\equiv-B_W3^{-r}\pmod{2^A}.
}
\]

The modulus is \(2^A\), not \(2^{A+1}\), because the condition asks only that the prescribed divisions occur. If the final endpoint is additionally required to be odd, the exact valuation cylinder refines to modulus \(2^{A+1}\).

## Arbitrarily long finite runs

For every finite positive valuation word \(W\), the congruence above has a unique residue modulo \(2^A\). Hence there are infinitely many ordinary starts
\[
e_u=q_W+t2^A
\]
producing the entire zero-sheet run.

Choosing the time index \(u\) sufficiently large also permits
\[
0<e_u<3^u,
\]
so the start lies inside the canonical endpoint range at depth \(u\).

Therefore bounded valuations do **not** forbid arbitrarily long finite zero-sheet runs.

Any infinite-activation theorem must use the globally inherited canonical endpoint, not the local suffix word alone.

Status: `[EXACT][COUNTEREXAMPLE TO LOCAL RUN-BOUND CLAIMS]`.
