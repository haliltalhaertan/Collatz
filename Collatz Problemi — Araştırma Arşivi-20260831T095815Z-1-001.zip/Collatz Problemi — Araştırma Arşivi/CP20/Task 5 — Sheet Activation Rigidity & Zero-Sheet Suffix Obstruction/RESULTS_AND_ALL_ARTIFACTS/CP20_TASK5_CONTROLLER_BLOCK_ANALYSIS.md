# CP20 TASK 5 — CONTROLLER BLOCK ANALYSIS

The exact \(\kappa=1.053\) controller was reconstructed using the frozen rule and two independent threshold implementations.

At depth \(K=100000\):

\[
\boxed{\text{nonzero-sheet density}=0.63564}
\]

and

\[
\boxed{\text{longest observed zero-sheet run}=12.}
\]

Record zero-run lengths were
\[
1,2,6,8,10,12.
\]
The first run of length 12 ended near index 95635.

Observed sheet counts were:

- \(m=0\): 36436;
- \(m=1\): 36611;
- \(m=2\): 11377;
- \(m=3\): 11325;
- \(m=4\): 1048;
- \(m=5\): 1102;
- \(m=6\): 1057;
- \(m=7\): 1044.

These are `[CERTIFIED NUM]`.

## Block structure

The controller does not reduce to one periodic 20-step block. In the first 100000 steps there are many distinct length-20 valuation factors; grouping into 20-step affine maps is computationally useful but does not remove the globally evolving discrepancy-tracking state.

More importantly, even when a future block word is known exactly, an all-zero-sheet concatenation requires the inherited endpoint to satisfy a binary cylinder whose precision grows by the total valuation of the concatenation.

No theorem
\[
R(k)=O(\log k)
\quad\text{or}\quad
R(k)=o(k)
\]
was obtained.

Status: `[CERTIFIED NUM] + [BARRIER]`.
