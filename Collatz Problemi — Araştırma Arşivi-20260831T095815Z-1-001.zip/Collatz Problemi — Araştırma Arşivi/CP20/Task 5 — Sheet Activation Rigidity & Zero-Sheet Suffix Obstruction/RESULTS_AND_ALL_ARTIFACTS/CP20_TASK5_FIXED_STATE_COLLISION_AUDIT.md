# CP20 TASK 5 — FIXED-STATE COLLISION AUDIT

The next sheet is readable from low bits, but those low bits do not form a closed fixed-width exact state.

On a zero-sheet step of valuation \(a\ge1\),
\[
e'=\frac{3e+1}{2^a}.
\]
Fix \(w\ge a\) and let \(\widetilde e=e+2^w\). Then
\[
\widetilde e\equiv e\pmod{2^w},
\]
and the two inputs have the same zero-sheet decision modulo \(2^a\). But
\[
\boxed{\widetilde e'-e'=3\cdot2^{w-a},}
\]
which is nonzero modulo \(2^w\).

Thus \((\text{controller phase},e_k\bmod2^w)\) cannot update itself exactly even when the valuation and next sheet are already fixed.

Across a zero-sheet word \(W\) of total valuation \(A(W)\), direct exact propagation of the final \(w\) low bits requires initial precision through
\[
\boxed{2^{w+A(W)}}.
\]
For bounded positive valuations, \(A(W)=\Theta(r)\) on an \(r\)-step run, so the natural binary precision grows linearly with run length.

This is the same structural phenomenon as the parked CP19 high-half branch: a bounded-width decision is easy to read locally, but exact iteration consumes new higher bits.

Scope: this disproves the obvious fixed-\(w\) recurrence. It does not prove that no different compressed invariant can ever exist.

Verdict: `[BARRIER: FIXED LOW-BIT STATE DOES NOT CLOSE]`.
