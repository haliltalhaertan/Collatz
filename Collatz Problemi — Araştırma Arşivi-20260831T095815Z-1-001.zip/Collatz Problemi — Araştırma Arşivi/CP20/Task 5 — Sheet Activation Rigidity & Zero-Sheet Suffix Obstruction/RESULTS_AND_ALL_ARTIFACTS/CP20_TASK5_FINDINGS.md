# COLLATZ CP20 — TASK 5 FINDINGS
## Sheet Activation Rigidity • Explicit Controller LEVEL-3 Test

## Final verdict

\[
\boxed{\textbf{C — [BARRIER: REDUCES TO PARKED 2-ADIC HIGH-HALF]}}
\]

The exact \(\kappa=1.053\) controller was attacked directly.

No proof was obtained that
\[
m_k\ne0
\]
infinitely often, and no proof of
\[
R(k)=o(k)
\]
was obtained.

Therefore the explicit LEVEL-3 survivor is **not excluded**.

## Exact results

1. Sheet criterion:
\[
m_k=0\iff2^{a_k}\mid3e_k+1.
\]

2. Zero-sheet run criterion: for a suffix word \(W\) of length \(r\) and total valuation \(A(W)\),
\[
\boxed{e_u\equiv-B_W3^{-r}\pmod{2^{A(W)}}.}
\]

3. Arbitrarily long finite zero-sheet runs exist for suitable canonical starting data. Thus no theorem may forbid long runs from the local valuation word alone.

4. Fixed-width state obstruction: even conditioned on the same valuation and same zero-sheet decision, \(e\bmod2^w\) does not determine the next \(e\bmod2^w\). Across a run, natural exact precision grows to \(w+A(u,r)=w+\Theta(r)\).

This is the same growing binary-information phenomenon that caused the CP19 critical high-half branch to be parked.

## Certified controller computation

For the exact rational controller
\[
\kappa=1053/1000,
\]
two independent controller constructions agree.

At depth \(K=100000\):

- nonzero sheets: 63564;
- activation density: \(0.63564\);
- longest zero-sheet run: 12;
- record run lengths: \(1,2,6,8,10,12\).

The first record run of length 12 appears near index 95635.

This is strong `[CERTIFIED NUM]` evidence for short runs, but not an infinite theorem.

## Falsification

A universal statement “bounded valuations force infinite activation” is false. The bounded word
\[
a_k=2\quad(k\ge0)
\]
has an initial nonzero sheet, then \(e_k=1\) and \(m_k=0\) forever. It does not satisfy the CP20 high-state morphology, so it does not refute the desired controller-specific theorem; it proves boundedness alone is insufficient.

## Linear zero-sheet suffix

If a linear-length zero-sheet suffix occurs while
\[
s_k=\kappa\log_2k+O(1),
\]
the affine multiplier across the suffix is only \(\Theta(1)\), and the additive normalized affine term is \(O(r)\). For \(\kappa>1\), this is compatible with polynomial state \(k^\kappa\). The long-suffix Archimedean map alone gives no contradiction.

## E-sequence route

The controller satisfies
\[
A_k/k\to\log_2 3
\]
from below. Known E-sequence divergence theorems for strict mean above \(\log_2 3\), and the special proved mechanical words, do not cover this high-turnover critical-equality controller. No schedule-specific strengthening was obtained.

## Archimedean limiting-carry route

The convergent carry has a future-tail correction of size \(O(k^{1-\kappa})\). After multiplication by the main \(k^\kappa\) state scale this becomes an \(O(k)\) correction, so a naive fractional-part contradiction does not follow.

## Required answers

- Was \(m_k\ne0\) infinitely often proved for \(\kappa=1.053\)? **No — `[OPEN]`.**
- Was \(R(k)=o(k)\) proved? **No — `[OPEN]`.**
- Is the explicit LEVEL-3 survivor excluded? **No.**
- Does the mechanism generalize? No positive general theorem was obtained.
- Does the route meet the parked high-half barrier? **Yes.** One-step sheet decisions are low-bit, but exact iteration requires linearly growing binary precision.
- Does the E-sequence route independently close it? **No.** It reaches the critical equality regime.

## Recommendation

Do not open a Task 6 that merely computes deeper sheets, enlarges \(w\), or renames the growing binary endpoint residue.

A genuinely new continuation would need either:

1. a schedule-specific theorem using the deterministic controller word without propagating \(2^{\Theta(r)}\) endpoint precision; or
2. a new critical-equality E-sequence theorem applicable to
\[
A_k=\alpha k-\kappa\log_2k+O(1).
\]

Absent one of these, the sheet-activation branch should be parked rather than extended by deeper numerics.

Side B remains open. Collatz is not solved.
