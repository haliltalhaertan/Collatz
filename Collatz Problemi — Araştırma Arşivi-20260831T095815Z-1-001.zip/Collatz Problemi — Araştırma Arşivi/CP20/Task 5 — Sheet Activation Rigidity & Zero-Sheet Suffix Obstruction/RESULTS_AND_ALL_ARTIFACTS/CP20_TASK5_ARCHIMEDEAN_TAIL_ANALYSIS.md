# CP20 TASK 5 — ARCHIMEDEAN CARRY-TAIL ANALYSIS

Assume hypothetically that the explicit controller is realized by one fixed positive ordinary orbit and
\[
s_k=\kappa\log_2k+O(1),\qquad \kappa>1.
\]

The frozen carry identity gives
\[
n_k=n_0U_k2^{s_k+\{\alpha k\}}.
\]
Because \(2^{D_j}\asymp j^{-\kappa}\), the carry converges:
\[
U_k\to U_\infty.
\]
Moreover the discrepancy envelope gives
\[
U_\infty-U_k=O\!\left(\sum_{j\ge k}j^{-\kappa}\right)=O(k^{1-\kappa}).
\]
Therefore
\[
n_k=n_0U_\infty2^{s_k+\{\alpha k\}}-n_0(U_\infty-U_k)2^{s_k+\{\alpha k\}}.
\]
The second term has natural size
\[
\boxed{O(k)}.
\]

The main term has size \(k^\kappa\), with \(\kappa>1\). Hence the future-tail correction is not microscopically small on the integer scale. A naive distance-to-integer contradiction that discards this correction is invalid.

No simultaneous integrality contradiction was derived.

Verdict: `[FAIL: NATURAL TAIL ERROR IS O(k)]`.
