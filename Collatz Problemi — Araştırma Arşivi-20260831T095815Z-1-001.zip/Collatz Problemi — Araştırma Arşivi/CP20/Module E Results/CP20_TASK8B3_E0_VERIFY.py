#!/usr/bin/env python3
from itertools import combinations
from collections import Counter
import math, cmath, json, hashlib
from functools import lru_cache
from pathlib import Path
OUT=Path(__file__).resolve().parent
ALPHA=math.log2(3.0)

def compositions(A,r):
    for cuts in combinations(range(1,A),r-1):
        prev=0; w=[]
        for c in cuts:w.append(c-prev);prev=c
        w.append(A-prev);yield tuple(w)

def endpoint(word):
    A=0;B=0
    for a in word:B=3*B+(1<<A);A+=a
    return (B*pow(2,-A,3**len(word)))%(3**len(word))

@lru_cache(None)
def recdist(r,A):
    if r==1:return ((pow(2,-A,3)%3,1),)
    o=Counter();mod=3**r
    for m in range(1,A-r+2):
        inv=pow(2,-m,mod)
        for y,c in recdist(r-1,A-m):o[(inv*(3*y+1))%mod]+=c
    return tuple(sorted(o.items()))

def phi_direct(r,A,xi):
    vals=[endpoint(w) for w in compositions(A,r)]
    q=3**r
    return sum(cmath.exp(2j*math.pi*xi*y/q) for y in vals)/len(vals)

def phi_rec(r,A,xi):
    if r==1:
        M=pow(2,-A,3)%3
        return cmath.exp(2j*math.pi*(xi%3)*M/3)
    den=math.comb(A-1,r-1);q=3**r;s=0j
    for m in range(1,A-r+2):
        p=math.comb(A-m-1,r-2)/den
        inv=pow(2,-m,q)
        phase=cmath.exp(2j*math.pi*(xi*inv%q)/q)
        s+=p*phase*phi_rec(r-1,A-m,(xi*inv)%(3**(r-1)))
    return s

def main():
    distribution_checks=0; fourier_checks=0; conductor_checks=0
    for r in range(1,8):
        base=math.floor(ALPHA*r)
        for d in range(-3,4):
            A=base+d
            if A<r:continue
            enum=Counter(endpoint(w) for w in compositions(A,r))
            assert dict(enum)==dict(recdist(r,A));distribution_checks+=1
            q=3**r
            # Pointwise endpoint recursion for every word.
            if r>=2:
                for w in compositions(A,r):
                    m=w[-1];prev=w[:-1]
                    M=endpoint(w);Mp=endpoint(prev)
                    assert M==(pow(2,-m,q)*(3*Mp+1))%q
            # Fourier recursion on a deterministic sample of frequencies.
            xis={1,q//3, q-1, (2**(r+1))%q}
            for xi in xis:
                a=phi_direct(r,A,xi);b=phi_rec(r,A,xi)
                assert abs(a-b)<1e-10;fourier_checks+=1
            # Conductor-3 theorem.
            xi=3**(r-1);z=phi_direct(r,A,xi)
            assert abs(z)>=0.5-1e-12
            for w in compositions(A,r):
                assert endpoint(w)%3 in (1,2)
            conductor_checks+=1
    # Bridge law exact ratio + finite convergence diagnostics.
    bridge=[]
    for r in (20,40,80,160):
        A=math.floor(ALPHA*r)
        probs=[]
        for m in range(1,min(12,A-r+1)+1):
            p=math.comb(A-m-1,r-2)/math.comb(A-1,r-1)
            probs.append(p)
            if m<A-r+1:
                pn=math.comb(A-m-2,r-2)/math.comb(A-1,r-1)
                ratio=(A-m-r+1)/(A-m-1)
                assert abs(pn/p-ratio)<1e-14
        geom=[(1/ALPHA)*((ALPHA-1)/ALPHA)**(m-1) for m in range(1,len(probs)+1)]
        bridge.append({'r':r,'max_first11_abs_error':max(abs(a-b) for a,b in zip(probs,geom))})
    # Limiting conductor-3 magnitude numeric check from exact parity law at large r.
    lim=math.sqrt(0.25+0.75/(2*ALPHA-1)**2)
    finite=[]
    for r in (20,50,100,200):
        A=math.floor(ALPHA*r);den=math.comb(A-1,r-1);pe=po=0.0
        for m in range(1,A-r+2):
            p=math.comb(A-m-1,r-2)/den if r>=2 else 1.0
            if m%2==0:pe+=p
            else:po+=p
        mag=math.sqrt(0.25+0.75*(pe-po)**2)
        finite.append({'r':r,'magnitude':mag,'gap_to_limit':abs(mag-lim)})
    data={'distribution_checks':distribution_checks,'fourier_recursion_checks':fourier_checks,
          'conductor3_checks':conductor_checks,'bridge_diagnostics':bridge,
          'conductor3_limit':lim,'finite_limit_diagnostics':finite}
    (OUT/'CP20_TASK8B3_E0_VERIFY_RESULTS.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
    print('CP20 TASK 8B3 E0 VERIFIER')
    print('distribution recursion checks:',distribution_checks)
    print('Fourier recursion checks:',fourier_checks)
    print('conductor-3 theorem cases:',conductor_checks)
    print('bridge ratio/convergence diagnostics:',bridge)
    print('critical conductor-3 limit:',lim)
    print('finite limit diagnostics:',finite)
    print('ALL E0 VERIFIER ASSERTIONS: PASS')
if __name__=='__main__':main()
