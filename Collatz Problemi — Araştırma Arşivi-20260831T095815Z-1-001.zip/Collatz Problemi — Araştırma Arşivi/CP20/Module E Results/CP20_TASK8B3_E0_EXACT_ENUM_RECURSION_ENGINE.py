from pathlib import Path
import math, itertools, collections, json, csv
import numpy as np
from functools import lru_cache
OUT=Path('/mnt/data/cp20_task8b3_e0')
ALPHA=math.log2(3.0)
HSTAR=ALPHA*math.log2(ALPHA)-(ALPHA-1)*math.log2(ALPHA-1)
DELTA=ALPHA-HSTAR

def compositions(A,r):
    for cuts in itertools.combinations(range(1,A), r-1):
        prev=0; w=[]
        for c in cuts:
            w.append(c-prev); prev=c
        w.append(A-prev)
        yield tuple(w)

def endpoint_direct(word):
    A=0; B=0
    for a in word:
        B=3*B+(1<<A); A+=a
    mod=3**len(word)
    return (B*pow(2,-A,mod))%mod

def endpoint_dist_enum(r,A):
    c=collections.Counter()
    for w in compositions(A,r): c[endpoint_direct(w)]+=1
    return c

@lru_cache(None)
def endpoint_dist_rec_tuple(r,A):
    if r==1:
        if A<1: return tuple()
        return ((pow(2,-A,3)%3,1),)
    if A<r: return tuple()
    mod=3**r
    out=collections.Counter()
    for m in range(1,A-r+2):
        prev=dict(endpoint_dist_rec_tuple(r-1,A-m))
        inv2m=pow(2,-m,mod)
        for y,cnt in prev.items(): out[(inv2m*(3*y+1))%mod]+=cnt
    return tuple(sorted(out.items()))

def v3(n):
    j=0
    while n and n%3==0: n//=3; j+=1
    return j

def metrics_for(r,A,dist):
    q=3**r; W=math.comb(A-1,r-1)
    assert sum(dist.values())==W
    arr=np.zeros(q,dtype=np.float64)
    for y,c in dist.items(): arr[y]=c
    ph=np.fft.fft(arr)/W; mags=np.abs(ph)
    worst=int(np.argmax(mags[1:])+1)
    prim=np.arange(1,q,dtype=np.int64); prim=prim[prim%3!=0]
    pbest=int(prim[np.argmax(mags[prim])])
    conductor_best={}
    for k in range(1,r+1):
        j=r-k
        # xi with exact v3=j: xi=3^j*u, 1<=u<3^k, u%3!=0
        base=3**j
        us=np.arange(1,3**k,dtype=np.int64); us=us[us%3!=0]
        xs=base*us
        xb=int(xs[np.argmax(mags[xs])])
        conductor_best[str(k)]={'xi':xb,'abs_phi':float(mags[xb])}
    energy=sum(c*c for c in dist.values())
    maxmult=max(dist.values()); minfiber=min(dist.values()); occ=len(dist)
    collfac=energy*q/(W*W)
    intervals=[]
    for beta in (0.6,0.8,1.0,1.2,1.35,1.45,1.52):
        X=max(1,min(q,int(2**(beta*r))))
        Q=sum(c for y,c in dist.items() if y<X)
        bench=W*(X/q)
        D=None if Q==0 else math.log2(Q/bench)/r
        intervals.append({'beta':beta,'X':X,'Q':Q,'benchmark':bench,'D':D,'ratio':(Q/bench if bench else None)})
    return {'r':r,'A':A,'d':A-math.floor(ALPHA*r),'W':W,'modulus':q,'occupied':occ,
            'max_multiplicity':maxmult,'min_nonzero_fiber':minfiber,'collision_energy':energy,
            'normalized_collision_factor':collfac,
            'worst_nonzero':{'xi':worst,'abs_phi':float(mags[worst]),'v3':v3(worst),'conductor_exp':r-v3(worst)},
            'worst_primitive':{'xi':pbest,'abs_phi':float(mags[pbest])},'conductor_best':conductor_best,'intervals':intervals}

rows=[]; checks=0
for r in range(1,11):
    base=math.floor(ALPHA*r)
    for d in range(-5,6):
        A=base+d
        if A<r: continue
        enum=endpoint_dist_enum(r,A)
        rec=dict(endpoint_dist_rec_tuple(r,A))
        assert enum==rec
        checks+=1
        rows.append(metrics_for(r,A,enum))
res={'alpha':ALPHA,'h_star':HSTAR,'delta':DELTA,'recursion_distribution_checks':checks,'rows':rows}
(OUT/'CP20_TASK8B3_E0_SMALL_EXHAUSTIVE_RESULTS.json').write_text(json.dumps(res,indent=2),encoding='utf-8')
with (OUT/'CP20_TASK8B3_E0_SMALL_EXHAUSTIVE_SUMMARY.csv').open('w',newline='',encoding='utf-8') as f:
    fields=['r','A','d','W','occupied','max_multiplicity','collision_energy','normalized_collision_factor','worst_abs_phi','worst_conductor_exp','primitive_abs_phi']
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    for z in rows:
        w.writerow({'r':z['r'],'A':z['A'],'d':z['d'],'W':z['W'],'occupied':z['occupied'],'max_multiplicity':z['max_multiplicity'],'collision_energy':z['collision_energy'],'normalized_collision_factor':z['normalized_collision_factor'],'worst_abs_phi':z['worst_nonzero']['abs_phi'],'worst_conductor_exp':z['worst_nonzero']['conductor_exp'],'primitive_abs_phi':z['worst_primitive']['abs_phi']})
print('alpha',ALPHA,'h*',HSTAR,'Delta',DELTA)
print('checks',checks)
for z in [x for x in rows if x['d']==0]:
    print('r',z['r'],'A',z['A'],'W',z['W'],'occ',z['occupied'],'collfac',round(z['normalized_collision_factor'],6),'worst',round(z['worst_nonzero']['abs_phi'],6),'cond',z['worst_nonzero']['conductor_exp'],'prim',round(z['worst_primitive']['abs_phi'],6))
print('ALL SMALL EXHAUSTION ASSERTIONS: PASS')
