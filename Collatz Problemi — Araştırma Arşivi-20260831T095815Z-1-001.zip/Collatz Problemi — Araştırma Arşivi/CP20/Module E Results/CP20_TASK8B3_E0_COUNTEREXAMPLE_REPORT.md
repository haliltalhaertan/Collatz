# CP20 TASK 8B3 E0 — COUNTEREXAMPLE / FALSIFICATION REPORT

1. Uniform exponential Fourier decay over all nonzero frequencies: `[FAIL][EXACT]`; conductor 3 is always at least 1/2.
2. Replacing the conditioned bridge by iid Geom(alpha) exactly: `[FAIL]`; only asymptotic TV convergence is proved.
3. Primitive and low-conductor behavior being qualitatively the same: `[FAIL]`.
4. A bad fixed d causing exponential short-interval clustering in tested data: `[FAIL TO FIND]`.
5. Primitive exponential decay clearly surviving: `[OPEN]`; invariant power-of-2 frequencies are a `[LEAD]` against it.
6. Global finite-block spectral gap: `[FAIL]`; high-conductor-only gap remains `[OPEN]`.
7. Collision energy as evidence of huge fibers: `[FAIL AS INTERPRETATION]`; critical r=7..10 had energy/|W| near 1 and max fiber size only 2.
