# CP20 TASK 8B3 — E0 LOW-CONDUCTOR OBSTRUCTION V2 AUDITED/FROZEN

**Date:** 2026-08-28

**Final status:** `[PROVED][INDEPENDENTLY AUDITED][POST-AUDIT REPAIRED][BRANCH CLOSURE][FROZEN]`

This is a negative branch-closure result. It closes only the naive all-nonzero-frequency Fourier-gap branch.

## Definitions
For a positive valuation word `w=(a_0,...,a_(r-1))`, define

`A_j = sum_(i<j) a_i`,

`B_r(w) = sum_(j=0)^(r-1) 3^(r-1-j) 2^(A_j)`,

and

`M_r(w) := 2^(-A_r) B_r(w) mod 3^r`.

## Measure-free conductor-3 obstruction
Modulo 3,

`B_r(w) = 2^(A_(r-1)) (mod 3)`,

so

`M_r(w) = 2^(-a_(r-1)) (mod 3) in {1,2}`.

Hence for every `r>=1` and **every probability measure** on positive valuation words of length `r`, the endpoint modulo 3 is supported on `{1,2}`.

At frequency `xi=3^(r-1)`, if `p_j=P(M_r=j mod 3)`, then

`phi = p_1 omega + p_2 omega^2`, `omega=e^(2 pi i/3)`,

and therefore

`|phi|^2 = 1/4 + (3/4)(p_1-p_2)^2 >= 1/4`.

Thus

`|phi(3^(r-1))| >= 1/2`.

Consequently no all-nonzero-frequency estimate `sup_(xi!=0)|phi(xi)| <= exp(-c r)` with `c>0` can hold.

This obstruction is independent of Task 6, Task 8A, and critical-log assumptions.

## Uniform fixed-mass critical limit
Now specialize to uniform `W_(r,A)`.

For `r>=2`, the last part `m=a_(r-1)` has exact law

`p_(r,A)(m)=C(A-m-1,r-2)/C(A-1,r-1)`, `1<=m<=A-r+1`.

For `r=1`, the unique word is `(A)`, so `m=A` deterministically.

If `A/r -> alpha=log_2 3`, then for every fixed `m`,

`p_(r,A)(m) -> p(1-p)^(m-1)` with `p=1/alpha`.

This is `Geom(p)` on `{1,2,...}`, with mean `alpha`.

For `r>=2`,

`p(m+1)/p(m) = (A-m-r+1)/(A-m-1)`.

This ratio is nonincreasing in `m`. Its maximum is the `m=1` value `(A-r)/(A-2)`, which tends to `(alpha-1)/alpha<1`. Therefore the finite laws have a uniform geometric tail. Pointwise convergence on each fixed truncation plus that common tail bound gives total-variation convergence to `Geom(1/alpha)`.

The resulting conductor-3 magnitude tends to

`0.639752980671987...`.

This numerical limit is only for uniform fixed mass with `A/r->alpha`; the measure-free theorem is only the lower bound `1/2`.

## Branch closure scope
Final classification: `[BRANCH CLOSURE]`.

Closed: naive global spectral gap over every nonzero Fourier frequency.

Still open: conductor-separated completion, high-conductor decay, and direct short-interval anti-concentration.
