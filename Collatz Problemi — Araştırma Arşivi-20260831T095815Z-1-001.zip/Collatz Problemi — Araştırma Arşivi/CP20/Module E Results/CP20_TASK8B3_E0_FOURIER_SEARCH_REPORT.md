# CP20 TASK 8B3 E0 — FOURIER SEARCH REPORT

- all-frequency exponential decay: `[FAIL — EXACT LOW-CONDUCTOR OBSTRUCTION]`;
- primitive/high-conductor exponential decay: `[OPEN]`;
- structured primitive \(\xi=2^{A-C}\): `[LEAD — SUBEXPONENTIAL/POLYNOMIAL RESONANCE CANDIDATE]`.

Full endpoint distributions and every Fourier coefficient were computed for all feasible \(|d|\le5\) through \(r=10\), with recursion-vs-enumeration cross-check. At critical \(d=0\), primitive worst magnitudes were about 0.2321 (r=10), 0.2096 (r=11), 0.1828 (r=12), 0.2042 (r=13), and 0.1733 (r=14), while conductor 3 remained near the exact critical limit 0.639753.

At r=12 the full d=-5,...,+5 band was exact. Primitive worst magnitude ranged from about 0.726 at d=-5 down to 0.011 at d=+5.

The family
\[
\xi=2^{A-C}\pmod{3^r}
\]
is exactly invariant under the conditioned recursion:
\[
\phi_{r,A}(2^{A-C})=\sum_m p_{r,A}(m)e^{2\pi i2^{A-m-C}/3^r}\phi_{r-1,A-m}(2^{A-m-C}).
\]
Exact DP through r=100 gives, at d=0, best magnitude about 0.0262 (C=7), with fitted bit-rate dropping to about 0.0525. For d=-5, magnitude at r=100 is about 0.0722. Fits over r=24..100 are more consistent with a power law than a stable exponential rate. This remains `[LEAD]`, not theorem.
