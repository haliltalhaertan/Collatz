# CP20 TASK 8B3 E0 — LOW-CONDUCTOR ZERO-TRUST AUDIT PROMPT

Claim: for every r>=1,A>=r,
\[
|\phi_{r,A}(3^{r-1})|\ge1/2,
\]
and if A/r->alpha=log_2 3 then the coefficient tends to
\[
-1/2-i\sqrt3/[2(2\alpha-1)]
\]
with magnitude 0.639752980671987.

Audit adversarially:
1. B_r mod3; 2. M_r mod3; 3. character reduction at xi=3^(r-1); 4. omega/omega^2 convex combination; 5. magnitude >=1/2; 6. r=1,A=r edge cases; 7. last-part composition law; 8. consecutive-m ratio; 9. TV convergence to Geom; 10. parity mapping; 11. limiting imbalance; 12. complex sign/magnitude; 13. scope—kills global spectral gap but not direct long-interval anti-concentration; 14. rerun verifier; 15. confirm no Task6/Task8A/critical-log dependency.

Return exactly one of `[PROOF VALID]`, `[PROOF VALID WITH WORDING REPAIR]`, `[FIXABLE GAP]`, `[MAJOR GAP]`, `[FALSE — COUNTEREXAMPLE]`.
