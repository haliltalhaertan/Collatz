# CP20 TASK 8B3 E0 — EXACT CONDITIONED RECURSION

**Status:** `[EXACT]` for the recursion; `[PROVED]` for the bridge limit.

For a positive composition \(w=(a_0,\ldots,a_{r-1})\) of total mass \(A\), let \(m=a_{r-1}\). Then
\[
B_r=3B_{r-1}+2^{A-m},
\]
so
\[
\boxed{M_r\equiv2^{-m}(3M_{r-1}+1)\pmod{3^r}.}
\]
The ambiguity of \(M_{r-1}\pmod{3^{r-1}}\) disappears after multiplication by 3.

Under uniform \(W_{r,A}\),
\[
\boxed{p_{r,A}(m)=\frac{\binom{A-m-1}{r-2}}{\binom{A-1}{r-1}},\quad1\le m\le A-r+1.}
\]
Hence
\[
\boxed{\phi_{r,A}(\xi)=\sum_m p_{r,A}(m)e^{2\pi i\xi2^{-m}/3^r}\phi_{r-1,A-m}(\xi2^{-m}\bmod3^{r-1}).}
\]

## Bridge-to-geometric theorem
If \(A/r\to\alpha>1\), put \(p=1/\alpha\), \(q=(\alpha-1)/\alpha\). Then
\[
p_{r,A}(1)=\frac{r-1}{A-1}\to p,
\]
and
\[
\frac{p_{r,A}(m+1)}{p_{r,A}(m)}=\frac{A-m-r+1}{A-m-1}\to q
\]
for each fixed \(m\). The ratios are eventually uniformly dominated by some \(q_*<1\), giving a uniform geometric tail. Therefore
\[
\boxed{\|p_{r,A}-\operatorname{Geom}(1/\alpha)\|_{TV}\to0.}
\]
If \(A=\alpha r+O(1)\), uniformly for \(m=o(\sqrt r)\),
\[
p_{r,A}(m)=\frac1\alpha q^{m-1}\left(1+O\left(\frac{m^2+1}r\right)\right).
\]

## Verification
Direct enumeration and recursion-generated endpoint distributions agreed in 87 separate \((r,A)\) cases covering every feasible \(|A-\lfloor\alpha r\rfloor|\le5\) for all \(r\le10\).
