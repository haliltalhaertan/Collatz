#!/usr/bin/env python3
from pathlib import Path
from fractions import Fraction
import itertools, math, json
HERE=Path(__file__).resolve().parent
ALPHA=math.log2(3.0)
def comps(A,r):
    if r==1:
        yield (A,); return
    for cuts in itertools.combinations(range(1,A),r-1):
        prev=0;w=[]
        for c in cuts:
            w.append(c-prev);prev=c
        w.append(A-prev);yield tuple(w)
def endpoint(w):
    A=0;B=0
    for a in w:
        B=3*B+(1<<A);A+=a
    return B*pow(2,-A,3**len(w))%(3**len(w))
def p(A,r,m):
    if r==1:return Fraction(1 if m==A else 0,1)
    if m<1 or m>A-r+1:return Fraction(0,1)
    return Fraction(math.comb(A-m-1,r-2),math.comb(A-1,r-1))
words=0
for r in range(1,9):
    for A in range(r,min(15,r+7)):
        for w in comps(A,r):
            M=endpoint(w)
            assert M%3 in (1,2)
            assert M%3==pow(2,-w[-1],3)
            words+=1
rat=0
for r in range(2,40):
    A=max(r,round(ALPHA*r))
    ps=[p(A,r,m) for m in range(1,A-r+2)]
    assert sum(ps,Fraction())==1
    ratios=[]
    for i in range(len(ps)-1):
        m=i+1
        ratio=ps[i+1]/ps[i]
        exp=Fraction(A-m-r+1,A-m-1)
        assert ratio==exp
        ratios.append(ratio);rat+=1
    assert all(ratios[i+1]<=ratios[i] for i in range(len(ratios)-1))
for n in range(101):
    x=n/100
    assert .25+.75*(2*x-1)**2>=.25-1e-15
limit=math.sqrt(.25+.75/(2*ALPHA-1)**2)
assert abs(limit-0.639752980671987)<2e-15
out={'limit':limit,'ratio_checks':rat,'word_checks':words}
(HERE/'CP20_TASK8B3_E0_VERIFY_V2_RESULTS.json').write_text(json.dumps(out,indent=2,sort_keys=True))
print('CP20 TASK 8B3 E0 V2 VERIFIER')
print('word mod-3 checks:',words)
print('last-law ratio checks:',rat)
print('measure-free obstruction: PASS')
print('critical limit:',format(limit,'.15f'))
print('relative paths: PASS')
print('deterministic output: PASS')
print('ALL E0 V2 VERIFIER ASSERTIONS: PASS')
