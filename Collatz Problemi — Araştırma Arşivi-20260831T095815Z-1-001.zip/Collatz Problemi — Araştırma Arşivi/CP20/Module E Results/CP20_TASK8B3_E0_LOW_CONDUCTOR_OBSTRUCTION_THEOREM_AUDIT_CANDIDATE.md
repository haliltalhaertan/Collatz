# CP20 TASK 8B3 E0 — LOW-CONDUCTOR FOURIER OBSTRUCTION THEOREM CANDIDATE

**Status:** `[AUDIT CANDIDATE — LOAD-BEARING NEGATIVE THEOREM]`

For every \(r\ge1\), every \(A\ge r\), and uniform \(w\in W_{r,A}\),
\[
\boxed{|\phi_{r,A}(3^{r-1})|\ge\frac12.}
\]
Consequently no all-nonzero-frequency bound \(\sup_{\xi\ne0}|\phi_{r,A}(\xi)|\le e^{-cr}\) with \(c>0\) can hold.

## Proof
Modulo 3,
\[
B_r\equiv2^{A_{r-1}},\qquad M_r\equiv2^{-a_{r-1}}\pmod3,
\]
so \(M_r\) is always 1 or 2 mod 3. Let \(\omega=e^{2\pi i/3}\), \(P_j=\Pr(M_r\equiv j\pmod3)\). Then
\[
\phi_{r,A}(3^{r-1})=P_1\omega+P_2\omega^2=-\frac12+i\frac{\sqrt3}2(P_1-P_2),
\]
so
\[
|\phi|^2=\frac14+\frac34(P_1-P_2)^2\ge\frac14.
\]

If \(A/r\to\alpha=\log_2 3\), the last-part law converges in total variation to \(\Pr(m=k)=\alpha^{-1}((\alpha-1)/\alpha)^{k-1}\). Since even \(m\) gives \(M\equiv1\) and odd \(m\) gives \(M\equiv2\),
\[
P_1-P_2\to-\frac1{2\alpha-1}.
\]
Hence
\[
\phi_{r,A}(3^{r-1})\to-\frac12-i\frac{\sqrt3}{2(2\alpha-1)}
\]
and
\[
\boxed{|\phi_{r,A}(3^{r-1})|\to0.639752980671987\ldots}
\]

## Scope
This closes only the naive all-frequency spectral-gap branch. A direct short-interval theorem may still survive because a fixed conductor can contribute only constant-scale periodic bias to long contiguous intervals.
