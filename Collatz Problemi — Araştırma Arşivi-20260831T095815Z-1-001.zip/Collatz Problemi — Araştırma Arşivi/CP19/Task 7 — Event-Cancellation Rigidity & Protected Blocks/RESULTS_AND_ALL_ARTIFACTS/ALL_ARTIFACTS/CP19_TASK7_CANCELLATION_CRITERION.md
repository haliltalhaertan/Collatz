# CP19 TASK 7 — CANCELLATION CRITERION

The ordinary-integer criterion from Task 6 is:
\[
x_S\in\mathbb Z_{\ge0}
\iff
\rho_R\text{ is eventually constant}.
\]

At the event scale this is equivalent to an infinite cancellation
requirement.

If \(x_S=n_0\ge0\), choose \(m_0\) so that
\[
2^{q_m}>n_0\qquad(m\ge m_0).
\]
Then
\[
x_S\bmod2^{q_{m+1}}=n_0<2^{q_m},
\]
hence its entire protected block vanishes:
\[
\boxed{
B_m+U_m\equiv0\pmod{2^{L_m}}
\quad(m\ge m_0).
}
\]

Consequently any one of the following is sufficient to exclude
nonnegative ordinary realization:

1. infinitely many \(m\) with
   \[
   B_m+U_m\not\equiv0\pmod2;
   \]
2. for some fixed \(w\),
   \[
   B_m+U_m\not\equiv0\pmod{2^w}
   \]
   infinitely often;
3. any growing widths \(w_m\le L_m\) with infinitely many mismatches;
4. \(z_m<L_m\) infinitely often, where
   \[
   z_m=v_2(B_m+U_m)
   \]
   and exact zero is assigned \(z_m=L_m\).

Finite mismatch at any number of event scales is not sufficient.
