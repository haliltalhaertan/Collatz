# CP19 TASK 7 — EVENT UNIT FORMULA

For event \(m\), let
\[
q_m=A_{\rm ref}(t_m),
\]
and for \(r\ge0\) define
\[
C_r=A_{\rm ref}(t_m+r)-q_m.
\]

Let
\[
h_r=A_S(t_m+r)-A_{\rm ref}(t_m+r)
\]
be the cumulative valuation offset during the surgery.

Source-accurately,
\[
h_0=R_m>0,
\]
and greedy phase-valid recovery makes \(h_r\) decrease to zero after
\(O(m)\) steps.

The finite-surgery correction is
\[
\delta_m=
-\sum_{r:\,h_r\ne0}
\frac{
2^{q_m+C_r+h_r}-2^{q_m+C_r}
}{
3^{t_m+r+1}
}.
\]

Factoring \(2^{q_m}\) gives the exact normalized unit:
\[
\boxed{
U_m=
-\sum_{r:\,h_r\ne0}
2^{C_r}(2^{h_r}-1)3^{-(t_m+r+1)}
\in\mathbb Z_2^\times.
}
\]

Modulo \(2^w\),
\[
\boxed{
U_m\bmod2^w
=
-\sum_{\substack{r:\,h_r\ne0\\C_r<w}}
2^{C_r}(2^{h_r}-1)
3^{-(t_m+r+1)}
\bmod2^w.
}
\]

Thus only terms of local reference valuation depth \(<w\) matter.

Consequences:

- \(U_m\bmod2^w\) is computable without constructing \(q_m\) bits;
- its cost is \(O(\mathrm{poly}(m,w))\) with certified Beatty floors;
- \(U_m\) is odd for every event, because the \(r=0\) term has valuation
  exactly zero and every later normalized term has positive 2-adic
  valuation.

The implementation reproduces Task-6 `correction_unit64` exactly for
\(m=10,\ldots,20\), and computes widths through 32 bits for
\(m\le1000\).
