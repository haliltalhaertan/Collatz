# CP19 TASK 7 — EXACT \(q_m\) RECURSION

Let
\[
t_m=3\cdot2^{m-1},
\qquad
H_m=\lfloor53m/50\rfloor,
\]
and
\[
q_m=F_{t_m}-H_m.
\]

Since
\[
t_{m+1}=2t_m,
\]
define
\[
\varepsilon_m
=
F_{2t_m}-2F_{t_m}
=
\lfloor2\{\alpha t_m\}\rfloor
\in\{0,1\}.
\]

Let
\[
h_m=H_{m+1}-H_m\in\{1,2\}.
\]

Then
\[
\begin{aligned}
q_{m+1}
&=2F_{t_m}+\varepsilon_m-H_{m+1}\\
&=2(q_m+H_m)+\varepsilon_m-H_{m+1}\\
&=\boxed{
2q_m+H_m-h_m+\varepsilon_m
}.
\end{aligned}
\]

Therefore
\[
\boxed{
L_m=q_{m+1}-q_m
=
q_m+H_m-h_m+\varepsilon_m.
}
\]

For \(m\ge10\),
\[
H_m\ge10,\qquad h_m\le2,
\]
so
\[
\boxed{
q_{m+1}>2q_m,
\qquad
L_m>q_m.
}
\]

No floating-point phase comparison is required. The compressed
implementation certifies \(F_k\) using rational upper/lower bounds for
\(\log_2 3\).
