# COLLATZ CP19 — TASK 7 FINDINGS
## Event-Cancellation Rigidity & Protected Binary Blocks

## Final strategic verdict

\[
\boxed{\textbf{B — [LEAD: PROTECTED BLOCK MISMATCH STRUCTURE]}}
\]

The explicit Task-5 survivor is **not** yet excluded from nonnegative ordinary
LEVEL 3.

Task 7 sharpens the obstruction to one exact schedule-specific question:
can the actual pre-event block equal the unique required cancelling block at
every sufficiently large dyadic event?

## 1. Exact event cancellation law

Let
\[
X_{m-1}=x_{\rm ref}+\sum_{j<m}\delta_j,
\qquad
X_m=X_{m-1}+\delta_m,
\]
\[
v_2(\delta_m)=q_m,
\qquad
L_m=q_{m+1}-q_m.
\]

Define
\[
B_m=
\left\lfloor
\frac{X_{m-1}\bmod2^{q_{m+1}}}{2^{q_m}}
\right\rfloor
\bmod2^{L_m},
\]
and
\[
U_m=(\delta_m/2^{q_m})\bmod2^{L_m}.
\]

Because all later events have valuation at least \(q_{m+1}\),
\[
\boxed{
\left\lfloor
\frac{x_S\bmod2^{q_{m+1}}}{2^{q_m}}
\right\rfloor
\equiv B_m+U_m
\pmod{2^{L_m}}.
}
\]

If \(x_S=n_0\ge0\) is an ordinary integer, then for all sufficiently large
\(m\) with \(2^{q_m}>n_0\),
\[
\boxed{B_m+U_m\equiv0\pmod{2^{L_m}}.}
\]

Thus any fixed-width mismatch infinitely often is sufficient for exclusion.

## 2. Exact q-recursion

Let
\[
H_m=\lfloor53m/50\rfloor,\qquad
h_m=H_{m+1}-H_m\in\{1,2\},
\]
and
\[
\varepsilon_m=F_{2t_m}-2F_{t_m}\in\{0,1\}.
\]

Then
\[
\boxed{
q_{m+1}
=
2q_m+H_m-h_m+\varepsilon_m.
}
\]

Hence for every \(m\ge10\),
\[
\boxed{q_{m+1}>2q_m.}
\]

The event bands are therefore extremely well separated. Separation itself
is not the missing theorem.

## 3. Exact local formula for the event unit

Let the reference and survivor cumulative valuation difference after the
special drop be \(h_r\), with
\[
h_0=R_m,\qquad h_r\downarrow0.
\]
Let
\[
C_r=A_{\rm ref}(t_m+r)-q_m.
\]

Then, for every requested width \(w\),
\[
\boxed{
U_m
\equiv
-\sum_{r:\,h_r\ne0}
2^{C_r}(2^{h_r}-1)3^{-(t_m+r+1)}
\pmod{2^w}.
}
\]

Since \(C_r\) strictly increases, terms with \(C_r\ge w\) vanish modulo
\(2^w\). Thus \(U_m\bmod2^w\) uses only \(O(w)\) local post-event valuation
depth and does not require constructing \(q_m\) binary digits.

This compressed formula was certified through \(m=1000\) for widths through
32 bits.

In particular
\[
\boxed{U_m\equiv1\pmod2}
\]
for every event, agreeing with the Task-6 finite-surgery theorem.

## 4. The hard side is genuinely \(B_m\)

The event unit is local, but
\[
B_m
\]
contains the high binary tails of:

- the explicit reference background;
- every previous event correction.

Previous \(\delta_j\) have \(q_j<q_m\), but their rational 2-adic expansions
continue through arbitrarily high binary positions. Therefore they cannot
be discarded when extracting the \(q_m\)-block.

No \(O(\mathrm{poly}(m,w))\) exact recurrence for \(B_m\bmod2^w\) was proved.

This is the exact remaining LEVEL-3 bottleneck.

## 5. Direct cancellation data

For \(m=10,\ldots,20\), exact protected blocks from Task 6 were independently
reduced into \(B_m,U_m\) and cancellation depth
\[
z_m=v_2(B_m+U_m).
\]

The single-bit mismatch sequence is

\[
\boxed{
(c_{10},\ldots,c_{20})
=
(0,1,1,1,0,1,1,0,1,0,0).
}
\]

So:

- "every event mismatches at parity" is false;
- "every event cancels at parity" is also false on the tested range.

Exact cancellation depths are
\[
\boxed{
(2,0,0,0,5,0,0,1,0,2,1).
}
\]

All are tiny compared with
\[
L_m\asymp q_m,
\]
but this remains finite certified evidence only.

## 6. Two-engine status

Fresh Task-7 event-block engines use:

- Engine A: exact affine/canonical residue computation;
- Engine B: independent canonical lift recurrence.

They agree on all moderate overlap regression cases. Task-6's deeper event
records through \(m=20\) are also reproduced on the local \(U_m\) side by the
new compressed formula.

The compressed engine reaches \(m=1000\) exactly for \(q_m\) and \(U_m\)
small-width data, but does not claim to compute the unresolved \(B_m\) tail
there.

## 7. Reference-background search

The pure neutral pair background has
\[
s_{2j}=0,\qquad A_{2j}=F_{2j}.
\]

The Task-5 reference is this high-turnover background plus sparse dyadic
height gains.

This gives a useful structural decomposition, but the pure-neutral/reference
2-adic realizer itself is not exactly classified. Replacing the unknown
reference by another separated correction series merely recreates the
Task-6 cancellation counterexample and does not solve the problem.

## 8. What was falsified

A generic statement such as
\[
q_{m+1}>2q_m,\quad U_m\ \text{odd}
\Longrightarrow
x_S\ \text{nonordinary}
\]
is false.

Separated odd corrections can be exactly pre-cancelled by an appropriate
reference 2-adic number.

The schedule-specific arithmetic of \(B_m\) is indispensable.

## 9. The exact missing lemma

It is enough to prove, for one fixed \(w\ge1\),
\[
\boxed{
B_m\not\equiv-U_m\pmod{2^w}
}
\]
for infinitely many \(m\).

Equivalently, one must prove infinitely many nonzero final protected blocks
of one fixed width.

Task 7 does not prove this.

Therefore
\[
\boxed{x_S\in\mathbb Z_{\ge0}\ ?\quad[\mathrm{OPEN}].}
\]

The next highest-value target is a true recurrence/classification theorem
for the reference/pre-event high binary block, not deeper raw
nonstabilization numerics.


## 10. Required result table

| Question | Verdict | Evidence |
|---|---|---|
| Event cancellation law exact? | `[PROVED]` | protected-block identity |
| Ordinary-positive forces eventual full block cancellation? | `[PROVED]` | ordinary stabilization criterion |
| Exact \(q_m\) recursion? | `[PROVED]` | doubling identity |
| \(q_{m+1}>2q_m\)? | `[PROVED]` for \(m\ge10\) | explicit recursion |
| Exact \(U_m\bmod2^w\) local formula? | `[PROVED]` | finite-surgery factorization |
| \(U_m\) odd? | `[PROVED]` | first changed prefix |
| Compressed \(U_m\) reaches \(m=1000\)? | `[CERTIFIED EXACT COMPUTATION]` | certified rational Beatty floors |
| \(B_m\) has local/poly recurrence? | `[OPEN]` | previous/reference tails remain |
| Single-bit mismatch occurs? | `[CERTIFIED NUM] YES` | \(m=11,12,13,15,16,18\) |
| Single-bit cancellation also occurs? | `[CERTIFIED NUM] YES` | \(m=10,14,17,19,20\) |
| \(z_m\) bounded? | `[OPEN]`; finite max 5 | \(m=10\ldots20\) |
| \(z_m<L_m\) infinitely often? | `[OPEN]` | no infinite recurrence |
| Reference background classified? | `[OPEN]` | no exact ordinary/rational class |
| Explicit survivor \(x_S\notin\mathbb Z_{\ge0}\)? | **NO** | missing infinite mismatch theorem |
| General event-cancellation theorem? | **NO** | schedule-specific block unresolved |
| Side B? | **NO** | high-state survivor still LEVEL-3 open |

### Ne denedik?

Her büyük dyadic event’in çok yüksek bir 2-adic derinlikte eklediği odd
düzeltmenin, daha eski/reference bitlerle her seferinde kusursuz biçimde
silinip silinemeyeceğini test ettik.

### Tek-bit parity yeterli oldu mu?

Hayır. Tek-bit mismatch birçok event’te çıktı, fakat bazı event’lerde parity
tam cancel oldu. Bu yüzden “her event yeni 1 bit bırakır” fikri yanlış.

### Event correction ile eski/reference block sonsuza kadar tam cancel olabiliyor mu?

Bunun için gerekli cancelling block her event’te **tekil**:
\[
B_m\equiv-U_m\pmod{2^{L_m}}.
\]
Event unit \(U_m\) artık lokal ve exact hesaplanabiliyor. Fakat actual
\(B_m\), reference ve bütün eski event tails’ini taşıyor. Sonsuz tam
cancellation’ı henüz theorem seviyesinde dışlayamadık.

### Bu yalnız numerik mi, theorem mi?

Event-block identity, \(q_m\) recursion, separation ve \(U_m\) local formula
theorem seviyesinde. \(m=10\ldots20\) mismatch/cancellation depths ve
\(m\le1000\) compressed small-width data finite certified computation.

### Explicit survivor artık pozitif ordinary integer olmaktan çıktı mı?

Hayır:
\[
\boxed{x_S\in\mathbb Z_{\ge0}\ ?\ [OPEN].}
\]

### Kalan exact lemma ne?

Bir fixed \(w\) için
\[
B_m\not\equiv-U_m\pmod{2^w}
\]
olduğunu sonsuz sayıda \(m\) için kanıtlamak yeterli.

### Sıradaki en yüksek bilgi değerli soru ne?

Reference/pre-event block \(B_m\) için gerçek bir recurrence veya binary-tail
classification bulmak. Daha derin raw lift scan’i aynı darboğazı çözmez.
