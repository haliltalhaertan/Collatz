# CP19 TASK 7 — REFERENCE BLOCKS

The hard quantity is
\[
B_m=
\left\lfloor
\frac{X_{m-1}\bmod2^{q_{m+1}}}{2^{q_m}}
\right\rfloor.
\]

It is not a local event invariant.

## Why previous events remain visible

For \(j<m\),
\[
v_2(\delta_j)=q_j<q_m,
\]
but \(\delta_j\) is a rational 2-adic number with an infinite binary tail.
Its contribution above depth \(q_m\) generally does not vanish.

Therefore it is invalid to divide
\[
\sum_{j<m}\delta_j
\]
by \(2^{q_m}\) term-by-term in \(\mathbb Z_2\). The block must be extracted
from the ordinary representative modulo \(2^{q_m+w}\).

## Reference-background structure

Removing mean-2 events leaves the explicit high-turnover dyadic-height
reference.

Relative to the pure neutral pair background:

- pure neutral pairs have net discrepancy zero;
- at every even pair boundary
  \[
  s_{2j}=0,\qquad A_{2j}=F_{2j};
  \]
- the reference adds only sparse dyadic gain-pair interventions needed to
  track
  \[
  \lfloor53L_k/50\rfloor.
  \]

This is useful structure, but those gains change the cumulative valuation
offset permanently; they are not finite surgeries of the Task-6 type.

No exact classification of the resulting \(x_{\rm ref}\) or a
poly\((m,w)\) recurrence for its block at \(q_m\) was obtained.

## Barrier

For any separated event sequence and any desired cancelling blocks there
exists an abstract 2-adic reference tail that realizes them.

Therefore a successful theorem must use the **specific** neutral/height
reference arithmetic, not separation alone.
