from __future__ import annotations
from array import array

LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537

def F(k:int)->int:
    if k==0:return 0
    lo=k*LOW_P//LOW_Q
    hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1

def L(k:int)->int:
    return k.bit_length()-1 if k else 0

def g(k:int)->int:
    return F(k+1)-F(k)

def b(k:int)->int:
    return g(k)-1

def v2(x:int)->int:
    return (x & -x).bit_length()-1

def neutral_pair(k:int):
    if b(k)==1:return 1,-1
    assert b(k+1)==1
    return -1,1

def gain_pair(k:int):
    x,y=neutral_pair(k)
    if x<0:x=0
    else:y=0
    return x,y

def schedule(N:int,p:int=53,q:int=50,m0:int=10):
    d=array("b",[0])*N
    s=0
    for j in range(0,N-1,2):
        target=p*L(j+2)//q
        x,y=gain_pair(j) if s<target else neutral_pair(j)
        d[j]=x;d[j+1]=y;s+=x+y
    base=array("b",d)
    meta=[]
    for m in range(m0,L(N)+1):
        t=3*(1<<(m-1))
        if t>=N-64:break
        ell=max(2,m//2);v=t-ell
        A0=F(t)-F(v)-sum(base[v:t])
        R=max(1,2*ell-A0)
        drop=t-1
        d[drop]=base[drop]-R
        rem=R;k=t
        while rem:
            cap=b(k)-base[k]
            if cap>0:
                inc=min(rem,cap)
                d[k]=base[k]+inc
                rem-=inc
            k+=1
        assert sum(d[drop:k])-sum(base[drop:k])==0
        meta.append(dict(m=m,t=t,ell=ell,R=R,drop=drop,recovery_end=k))
    return d,base,meta

def lift_blocks(max_m=14,w=16):
    N=3*(1<<(max_m-1))+256
    d,base,events=schedule(N)
    ev={e["m"]:e for e in events if e["m"]<=max_m}
    targets={m:(F(e["t"])-(53*m//50),e["t"]) for m,e in ev.items()}

    rho=1
    y=1
    A=0
    P=1
    out={}
    pending=set(targets)
    for R in range(1,N+1):
        k=R-1
        a=g(k)-d[k]
        found=None
        for lam in range(1<<a):
            yp=y+2*lam*P
            z=3*yp+1
            if v2(z)==a:
                assert found is None
                found=(lam,z>>a)
        assert found is not None
        lam,y=found
        rho += lam<<(A+1)
        A += a
        P *= 3
        for m in list(pending):
            q,t=targets[m]
            if R>=t and A>=q+w:
                out[m]=(rho>>q)&((1<<w)-1)
                pending.remove(m)
        if not pending:break
    assert not pending
    return out

if __name__=="__main__":
    ans=lift_blocks()
    for m in sorted(ans):print(m,hex(ans[m]))
    print("CP19 TASK7 ENGINE B: OK")
