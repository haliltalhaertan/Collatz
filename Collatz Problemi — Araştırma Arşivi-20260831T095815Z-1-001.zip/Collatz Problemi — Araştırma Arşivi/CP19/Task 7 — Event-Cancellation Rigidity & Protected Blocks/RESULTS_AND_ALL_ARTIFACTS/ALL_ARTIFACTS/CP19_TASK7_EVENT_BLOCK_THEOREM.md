# CP19 TASK 7 — EVENT-BLOCK THEOREM

Let
\[
x_S=x_{\rm ref}+\sum_{j\ge10}\delta_j,
\qquad
v_2(\delta_j)=q_j,
\]
with
\[
q_{j+1}>q_j.
\]

For event \(m\), define
\[
X_{m-1}=x_{\rm ref}+\sum_{j<m}\delta_j,
\qquad
X_m=X_{m-1}+\delta_m,
\]
and
\[
L_m=q_{m+1}-q_m.
\]

Define the protected blocks
\[
B_m=
\left\lfloor
\frac{X_{m-1}\bmod2^{q_{m+1}}}{2^{q_m}}
\right\rfloor
\bmod2^{L_m},
\]
\[
U_m=(\delta_m/2^{q_m})\bmod2^{L_m}.
\]

Because every later event \(j>m\) satisfies
\[
v_2(\delta_j)\ge q_{m+1},
\]
we have the exact identity
\[
\boxed{
\left\lfloor
\frac{x_S\bmod2^{q_{m+1}}}{2^{q_m}}
\right\rfloor
\equiv
B_m+U_m
\pmod{2^{L_m}}.
}
\]

Therefore the final event-\(m\) protected block is already fixed after
event \(m\); later events cannot alter it.

Since \(U_m\) is odd, the least protected bit is toggled:
\[
(B_m+U_m)\bmod2=1-(B_m\bmod2)
\]
in \(\mathbb F_2\).

This theorem does not assert that the result is nonzero. Exact cancellation
occurs precisely when
\[
B_m\equiv-U_m\pmod{2^{L_m}}.
\]
