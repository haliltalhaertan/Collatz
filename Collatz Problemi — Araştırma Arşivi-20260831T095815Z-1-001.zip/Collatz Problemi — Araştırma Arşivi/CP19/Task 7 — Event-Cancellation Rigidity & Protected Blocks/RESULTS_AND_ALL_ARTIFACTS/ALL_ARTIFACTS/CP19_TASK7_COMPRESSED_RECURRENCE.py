from __future__ import annotations
from fractions import Fraction
import argparse

def ln_atanh_bounds(z_num,z_den,N):
    z=Fraction(z_num,z_den);z2=z*z;term=z;s=Fraction(0)
    for n in range(N):
        s+=term/(2*n+1)
        term*=z2
    low=2*s
    tail=2*term/Fraction(2*N+1)/(1-z2)
    return low,low+tail

l3,u3=ln_atanh_bounds(1,2,900)
l2,u2=ln_atanh_bounds(1,3,900)
AL=l3/u2;AU=u3/l2
PBITS=1800;DEN=1<<PBITS
ALO=(AL.numerator*DEN)//AL.denominator
AHI=(AU.numerator*DEN+AU.denominator-1)//AU.denominator
assert AHI-ALO==1

def F(k):
    lo=(k*ALO)>>PBITS
    hi=(k*AHI-1)>>PBITS
    if lo!=hi:
        raise ArithmeticError(("uncertified floor",k,lo,hi))
    return lo

def g(k):return F(k+1)-F(k)
def b(k):return g(k)-1

def dneutral(k):
    if k%2==0:return 1 if b(k)==1 else -1
    return -1 if b(k-1)==1 else 1

def event_unit(m,w):
    t=3*(1<<(m-1));ell=max(2,m//2);v=t-ell
    A0=F(t)-F(v)-sum(dneutral(k) for k in range(v,t))
    R=max(1,2*ell-A0)
    q=F(t)-(53*m//50)
    M=1<<w
    h=R;C=0;j=t;U=0
    while h>0:
        if C<w:
            U=(U-(pow(2,C,M)*(pow(2,h,M)-1)*pow(pow(3,j+1,M),-1,M)))%M
        db=dneutral(j)
        cap=b(j)-db
        inc=min(h,cap) if cap>0 else 0
        h-=inc
        C+=g(j)-db
        j+=1
    return q,R,U,j-t

def row(m,w):
    q,R,U,rec=event_unit(m,w)
    H=53*m//50;H2=53*(m+1)//50;h=H2-H
    t=3*(1<<(m-1))
    eps=F(2*t)-2*F(t)
    q2=F(2*t)-H2
    assert q2==2*q+H-h+eps
    return q,q2-q,R,rec,U,eps

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--max-m",type=int,default=1000)
    ap.add_argument("--w",type=int,default=16)
    args=ap.parse_args()
    for m in range(10,args.max_m+1):
        q,Lm,R,rec,U,eps=row(m,args.w)
        if m<=25 or m in (100,500,1000,args.max_m):
            print(m,q,Lm,R,rec,hex(U),eps)
    print("CP19 TASK7 COMPRESSED RECURRENCE: OK")
