# CP19 TASK 10 — INDEPENDENT ZERO-TRUST PARK AUDIT

## Final verdict

\[
\boxed{\textbf{CP19 TASK 10 AUDIT — MATHEMATICS VALID / PARK JUSTIFIED WITH WORDING REPAIR}}
\]

This audit treats two questions separately:

1. Are Task 10's exact mathematical identities/counterexamples correct?
2. Is `[PARK: CRITICAL-DENSITY HIGH-HALF BRANCH]` a justified research-management decision?

Answer:

- the exact core mathematics is valid;
- the tested compressed-state families are genuinely falsified;
- cancellation-run multiplicative-cost reasoning is genuinely redundant;
- the branch park is methodologically justified;
- but Task 10 must **not** be read as proving a universal lower bound saying
  every possible exact invariant requires \(\Theta(F_t)\) bits.

The correct scope is:

> every exact state/recurrence actually constructed in Tasks 8–10 that
> determines the high-half bit carries \(\Theta(F_t)\)-scale information,
> while the specific compressed families tested in Tasks 9–10 have exact
> collisions.

That distinction is the required wording repair.

---

# 0. Package integrity

`CP19_TASK10_SHA256.txt` was checked against the local Task-10 artifact set.

Result:

\[
\boxed{16/16\ \text{manifest entries verified}}
\]

`CP19_TASK10_PACKAGE.zip` passed `unzip -t` with no errors and contains the
16 audited artifacts plus the SHA manifest.

Status:

\[
\boxed{[\mathrm{VALID}]}
\]

No mathematical conclusion below relies on a missing package artifact.

---

# A. Exact high-half / cross-adic identities

Let

\[
n=F_t,\qquad P=3^t,
\]

and let the affine prefix identity be

\[
2^n y = P x+B_t.
\]

Let

\[
r_t\equiv -B_tP^{-1}\pmod{2^n},
\qquad
0\le r_t<2^n,
\]

and

\[
Y_t=\frac{Pr_t+B_t}{2^n}.
\]

Define the canonical odd-modulus endpoint residue

\[
\eta_t=[2^{-n}B_t]_P,\qquad 0\le\eta_t<P.
\]

## A1. Congruence

Modulo \(P\),

\[
2^nY_t\equiv B_t\pmod P,
\]

so

\[
\boxed{Y_t\equiv\eta_t\pmod P.}
\]

Status: `[VALID]`.

The sign conventions in Task 10 are consistent. Since
\(C_t=-Y_t\),

\[
C_t\equiv Y_t\pmod2.
\]

Status: `[VALID]`.

## A2. Task-10 two-sheet bound

For the pure-neutral word,

\[
s_j\in\{-1,0,1\}.
\]

Hence

\[
\frac{B_t}{P}
=
\sum_{j<t}\frac{2^{A_j}}{3^{j+1}}
<\frac{2t}{3}.
\]

Also

\[
1\le\frac{P}{2^n}<2.
\]

Therefore

\[
\frac{B_t}{2^n}<\frac{4t}{3}<3^t=P
\]

for every relevant \(t\ge1\), not merely "sufficiently large" \(t\).

Furthermore

\[
\frac{B_t}{2^n}\le Y_t<P+\frac{B_t}{2^n}<2P.
\]

Thus writing

\[
Y_t=\eta_t+\kappa_tP
\]

does give

\[
\boxed{\kappa_t\in\{0,1\}.}
\]

The threshold claim is also algebraically correct:

\[
\boxed{
\kappa_t=1
\iff
\eta_t<\frac{B_t}{2^n}.
}
\]

Status: `[VALID]`, with a minor repair: the "large \(t\)" qualifier is
unnecessary.

## A3. Stronger audit lemma: the sheet bit is actually zero

The Task-10 two-sheet statement is valid but non-sharp.

For **any finite positive valuation word**, not just the neutral one, let
\(P=3^\ell\), total valuation \(A\), canonical
\(0\le r<2^A\), and

\[
Y=\frac{Pr+B}{2^A}.
\]

Then

\[
\boxed{0<Y<P.}
\]

Proof is by induction on the number of odd steps.

Assume a prefix has endpoint \(0<Y<P\). Append valuation \(a\ge1\).
The extended canonical start is

\[
r'=r+2^A\lambda,\qquad 0\le\lambda<2^a,
\]

where \(\lambda\) is the unique lift making the new numerator divisible by
\(2^a\). The new endpoint is

\[
Y'=
\frac{3Y+1+3P\lambda}{2^a}.
\]

Since \(Y\le P-1\) and \(\lambda\le2^a-1\),

\[
0<3Y+1+3P\lambda
\le
3P2^a-2,
\]

hence

\[
0<Y'<3P.
\]

The base case is immediate.

Therefore the canonical endpoint quotient is already the canonical
odd-modulus representative:

\[
\boxed{Y_t=\eta_t,\qquad \kappa_t=0.}
\]

This strengthens, rather than invalidates, Task 10.

It does **not** solve the high-half problem: the unresolved question becomes
the cross-scale evolution/parity of the canonical endpoint \(Y_t\) itself.

Status: `[VALID BUT NON-SHARP; STRENGTHENED IN AUDIT]`.

## A4. State-size claim

The full representative

\[
\eta_t\bmod3^t
\]

requires

\[
\log_2(3^t)=\Theta(t)=\Theta(F_t)
\]

bits in that representation.

Status: `[VALID]`.

But the implication

\[
\text{"this representation is }\Theta(F_t)\text{"}
\Longrightarrow
\text{"every exact parity invariant is }\Theta(F_t)\text{"}
\]

is not proved.

Fixed states \(\eta_t\bmod3^k\), \(k=1,\ldots,5\), have exact
counterexamples, but this does not rule out every possible nonlocal
\(o(F_t)\) function of the endpoint.

Status of a universal minimal-state claim:

\[
\boxed{[\mathrm{GAP\ / WORDING\ REPAIR}]}
\]

Recommended wording:

> the full endpoint representation costs \(\Theta(F_t)\), and no smaller
> exact endpoint invariant was found among the tested families.

---

# B. Matrix / projective route

A pair block with total valuation \(G\) and affine numerator \(B\) acts by

\[
2^G n_{\rm out}=9n_{\rm in}+B.
\]

The homogeneous affine matrix

\[
M(G,B)=
\begin{pmatrix}
9&B\\
0&2^G
\end{pmatrix}
\]

reproduces the exact concatenation law.

For \(r\) pairs and total valuation \(A\),

\[
\det M=9^r2^A,
\qquad
\operatorname{tr}M=9^r+2^A.
\]

These do not contain \(B\).

The Task-10 counterexample was independently reproduced:

- shifted two-pair block starting at pair 1:
  \[
  A=6,\ B=119,\ \lambda=1;
  \]
- shifted two-pair block starting at pair 2:
  \[
  A=6,\ B=103,\ \lambda=0.
  \]

Both have the same determinant and trace but opposite top-lift parity.

Therefore determinant/trace, and invariants that are functions only of them,
cannot determine the top lift.

Status:

\[
\boxed{[\mathrm{VALID}]}
\]

Scope repair:

This collision kills the **chosen determinant/trace summary**, not every
possible matrix/projective invariant. Task 10's statement "no lower
projective quotient was found" is acceptable as a search result; it must not
be upgraded to a theorem that no such quotient can exist.

---

# C. Borrow / Hensel high-half route

Let

\[
F_{2t}=2n+\varepsilon_t,\qquad P=3^t.
\]

For the shifted second half numerator \(D_t\),

\[
B_{2t}=PB_t+2^nD_t.
\]

With

\[
Pr_t+B_t=2^nY_t
\]

and

\[
r_{2t}=r_t+2^nz_t,
\]

substitution gives

\[
P^2r_{2t}+B_{2t}
=
2^n(PY_t+P^2z_t+D_t).
\]

Thus

\[
\boxed{
z_t\equiv
-(PY_t+D_t)P^{-2}
\pmod{2^{n+\varepsilon_t}}.
}
\]

Status: `[VALID]`.

The canonical borrow state lives modulo

\[
2^{n+\varepsilon_t},
\]

so the **natural exact representation width** is
\(n+\varepsilon_t=\Theta(F_t)\).

Wording repair:

It is safer to say "the canonical state is specified modulo an
\(n+\varepsilon_t\)-bit modulus" than "every individual \(z_t\) has exactly
\(n+\varepsilon_t\) ordinary significant bits."

The Task-10 bounded-borrow collisions were independently reproduced:

- top 1 borrow bit: \(t=2,14\);
- top 2 bits: \(t=14,26\);
- top 4 bits: \(t=8,44\);
- top 8 bits: \(t=84,122\).

Same tested descriptor, opposite next parity.

Status:

\[
\boxed{[\mathrm{VALID}]}
\]

But these collisions establish only:

> the tested bounded leading-borrow summaries fail.

They do not exclude every more sophisticated sublinear borrow invariant.

Any broader interpretation is `[GAP / WORDING REPAIR]`.

---

# D. Eventual cancellation / nested-cylinder rigidity

A full cancellation at event \(j\) means that the final survivor has zero
bits on

\[
[q_j,q_{j+1}).
\]

For consecutive events \(j=m,\ldots,m+k-1\), the intervals concatenate, so
the conjunction is exactly

\[
\boxed{
x_S\bmod2^{q_{m+k}}
=
x_S\bmod2^{q_m}.
}
\]

Status: `[VALID]`.

These are nested precision conditions, not independent CRT moduli.

If the lower residue is a fixed

\[
0\le a<2^{q_m},
\]

then the same \(a\) satisfies the entire zero-block run at every deeper
modulus.

Therefore the zero-block conditions alone do not force multiplicative
least-realizer growth.

Status:

\[
\boxed{[\mathrm{VALID}][\mathrm{FAIL}][\mathrm{PARK\text{-}SUPPORTING}]}
\]

This conclusion must be scoped carefully:

It does not prove that no **schedule-specific** arithmetic consequence can
ever be extracted from a cancellation run. It proves that merely counting
the nested zero blocks as independent cylinders is invalid.

Under a fixed ordinary \(x_S=n_0\), no additional Archimedean cost follows
from the zero-block constraints themselves: once the modulus exceeds
\(n_0\), the same ordinary representative persists.

No hidden independent CRT cost was found in the audit.

---

# E. Collision certificates

The collision table was not accepted on trust.

An independent audit implementation used exact integer arithmetic, with

\[
F_t=\lfloor t\log_2 3\rfloor
=
\operatorname{bitlength}(3^t)-1
\]

for every tested \(t\); no floating-point floor decision was used.

All 24 numerical Task-10 collision rows were reproduced, plus the matrix
counterexample.

Verified families:

- centered residue sign;
- top \(1,2,4,8\) bits of \(r_t\);
- complement top bits;
- leading quotient class;
- top \(1,2,4,8\) borrow bits;
- endpoint states \(\eta_t\bmod3^k\), \(k=1,\ldots,5\);
- phase-block + centered-sign summaries;
- determinant/trace.

Each certificate has:

\[
\text{same declared compressed descriptor}
\quad+\quad
\text{different next top-lift parity}.
\]

Status:

\[
\boxed{[\mathrm{VALID}]}
\]

What they kill:

only the precisely declared descriptor family.

They do not prove the nonexistence of all \(O(1)\), \(O(\log t)\), or
\(o(F_t)\) invariants.

### Additional adversarial order-statistic checks

The audit also tested several unlisted compact states, including

\[
v_2(Y_t),\quad
v_2(Y_t\pm1),\quad
v_3(Y_t),\quad
v_3(Y_t\pm1),
\]

together with the phase/pair labels.

Exact collisions again occur, e.g. \(t=2,4\) for several such descriptors.

This strengthens the empirical park case, but it remains family-by-family
falsification, not a universal lower bound.

---

# F. Critical-density boundary

For the pure-neutral schedule,

\[
A_{2r}=F_{2r}.
\]

Therefore

\[
\lim_{r\to\infty}\frac{A_{2r}}{2r}
=
\alpha=\log_2 3.
\]

In the full parity vector, one odd symbol is followed by \(a_k-1\) even
symbols, so the one-density is

\[
\lim\frac{r}{A_r}
=
\frac1{\log_2 3}
=
\boxed{\frac{\ln2}{\ln3}}.
\]

Status: `[VALID]`.

The parity vector is aperiodic: eventual periodicity would give a rational
limiting symbol density, whereas \(\ln2/\ln3\) is irrational.

The literature boundary used by Task 10 is correctly stated at the level
needed here:

- López–Stoll (2021) prove preservation of aperiodicity under the strict
  lower-density condition
  \[
  \underline{\lim}(h/\ell)>\ln2/\ln3;
  \]
- their theorem does not cover equality;
- López–Stoll (2009) explicitly state the broader aperiodic-to-eventually-
  periodic conjugacy question as unknown.

The audit does **not** infer that the present special neutral schedule is
equivalent to the full Periodicity Conjecture.

Status:

\[
\boxed{[\mathrm{VALID\ BACKGROUND\ BOUNDARY}]}
\]

No newer theorem found in the targeted literature search supplied the
missing equality-case classification for this specific branch.

---

# G. Adversarial countersearch against the PARK decision

The audit actively attempted to find a concrete reason to reopen the branch.

## G1. Mahler / automatic / 2-kernel route

No theorem was found that converts the dyadically sampled high-half sequence
of the neutral conjugacy realizer into a finite 2-kernel or automatic
sequence.

The known Sturmian-conjugacy continued-fraction results concern special
mechanical/Sturmian parity words and do not furnish a recurrence for the
present sampled high-half observable.

No copy-paste-ready theorem route emerged.

Status: `[NO REOPEN TRIGGER]`.

## G2. Odd/even mixed modulus route

The audit actually sharpened Task 10 to

\[
Y_t=\eta_t
\]

for canonical finite positive valuation words.

This removes the sheet ambiguity but leaves the same unresolved cross-scale
endpoint parity.

Fixed odd-modulus summaries have certified collisions; the full endpoint
still has \(\Theta(F_t)\)-scale representation.

Status: `[LEAD STRENGTHENING, NOT A REOPEN TRIGGER]`.

## G3. Valuation/order-statistic route

Compact statistics of \(Y_t\), \(Y_t\pm1\), centered residues, and borrow
states have exact collisions.

Status: `[FAIL FOR TESTED FAMILIES]`.

## G4. Two-scale / lacunary route

No exact implication of the form

\[
\text{eventual cancelling sampled parity}
\Longrightarrow
\text{forbidden eventual phase state}
\]

was derived.

Task-9/10 exact doubling still requires growing Hensel precision.

Status: `[OPEN, NO CONCRETE REOPEN THEOREM]`.

## G5. Continued-fraction / rotation coding

The neutral symbolic driver has low rotation complexity, but no exact
sublinear arithmetic state for the affine high-half was obtained.

A statement of the form "perhaps continued fractions compress it" is not
enough to overturn PARK under the audit prompt's standard.

Status: `[NO REOPEN TRIGGER]`.

## G6. Full cancellation + Archimedean contradiction

The consecutive zero blocks collapse to one deeper nested congruence.
No additional ordinary-size lower bound follows from those blocks alone.

Status: `[FAIL][PARK-SUPPORTING]`.

---

# H. Survivor and Collatz status

Task 10 correctly preserves all required logical distinctions.

- Finite LEVEL-2 realizability does not imply a fixed positive ordinary
  LEVEL-3 realizer.
- Task 10 does not exclude the explicit survivor.
- PARK does not prove the survivor exists.
- Side B remains open.
- Collatz is not solved.

The correct status remains

\[
\boxed{
x_S\in\mathbb Z_{\ge0}\ ?\quad[\mathrm{OPEN}].
}
\]

Status: `[VALID]`.

---

# I. Park-decision audit

## Did Tasks 8–10 merely rename the same test?

No.

They converged on the same bottleneck but tested materially different
mechanisms:

- reference/gain decomposition and rational Hensel;
- critical carry and dyadic renormalization;
- centered high-half, odd-modulus, matrix, borrow, and cancellation-run
  formulations.

## Were the Task-10 candidate families meaningfully different?

Yes, enough to support a research-management decision that marginal value
inside this exact branch has fallen.

They are not exhaustive enough to support a universal impossibility theorem.

## Is PARK logically justified?

Yes, as:

> stop allocating the next task to the same high-half mechanism unless a
> genuinely new invariant/theorem appears.

Not as:

> no \(o(F_t)\) invariant can exist.

## Required wording repairs

Recommended replacements in Task 10:

1. Replace  
   "all exact recurrences that determine the bit retain \(\Theta(F_t)\)
   state"  
   with  
   "all exact recurrences constructed in Tasks 8–10 that determine the bit
   retain \(\Theta(F_t)\)-scale state."

2. Replace  
   "the parity of \(\eta_t\) requires \(\Theta(F_t)\) information"  
   with  
   "the full canonical endpoint representation uses
   \(\Theta(F_t)\) bits; no smaller parity invariant was found among the
   tested endpoint summaries."

3. Replace  
   "the full \(z_t\) has \(n+\varepsilon_t\) bits"  
   with  
   "\(z_t\) is specified modulo \(2^{n+\varepsilon_t}\); the natural exact
   state space has \(n+\varepsilon_t\)-bit width."

4. Interpret  
   "mechanism exhausted under current mathematics"  
   operationally as  
   "the tested high-half mechanisms now have low marginal information
   value."

With these repairs:

\[
\boxed{\textbf{[PARK JUSTIFIED WITH WORDING REPAIR]}}
\]

---

# Required summary table

| Claim | Verdict | Reason |
|---|---|---|
| Odd-modulus bridge | `[VALID, NON-SHARP]` | \(Y\equiv\eta\pmod{3^t}\) is correct; audit strengthens to canonical \(Y=\eta\) for positive finite valuation words |
| Matrix collision conclusions | `[VALID WITH SCOPE]` | determinant/trace collision reproduced; does not exclude every projective invariant |
| Borrow collision conclusions | `[VALID WITH SCOPE]` | exact \(z_t\) congruence and collisions reproduced; only tested bounded summaries are excluded |
| Cancellation-run redundancy | `[VALID][PARK-SUPPORTING]` | consecutive zero blocks merge into one nested congruence; no generic multiplicative least-realizer cost |
| State-size statements | `[WORDING REPAIR]` | known full states are \(\Theta(F_t)\); universal minimal-state lower bound is not proved |
| Critical-density boundary wording | `[VALID]` | mean/density exact; strict-density literature theorem does not cover equality |
| Survivor LEVEL-3 status | `[OPEN][VALID]` | Task 10 neither proves nor excludes a fixed positive ordinary realizer |
| Formal park decision | `[PARK JUSTIFIED WITH WORDING REPAIR]` | broad exact negative search + nested redundancy support stopping this mechanism, not impossibility |

---

# Final verdict

\[
\boxed{
\textbf{CP19 TASK 10 AUDIT — MATHEMATICS VALID / PARK JUSTIFIED WITH WORDING REPAIR}
}
\]

No big mathematical error was found that reopens the branch.

The audit did find one useful strengthening (\(Y_t=\eta_t\), not merely a
two-sheet alternative), but it does not produce an infinite mismatch theorem
or survivor exclusion.

The next branch may therefore move away from 2-adic high-half
classification.

Recommended next direction only:

\[
\boxed{
\textbf{CP20 — Upper-tail state-growth / quantile-window rigidity}
}
\]

This audit does not attempt the CP20 proof.
