# CP19 TASK 10 — FORMAL BRANCH PARK

\[
\boxed{\textbf{[PARK: CRITICAL-DENSITY HIGH-HALF BRANCH]}}
\]

## Parked question

For the pure-neutral critical-density realizer \(x_0\), classify or
recursively control the sampled bits
\[
\operatorname{bit}_{F_{3\cdot2^{m-1}}}(x_0)
\]
well enough to force infinitely many survivor event mismatches.

## Why parked

Tasks 8–10 progressively reduced the problem to one critical Hensel
high-half decision.

Task 10 tested:

- high-half order/sign variables;
- complement variables;
- odd-modulus endpoints;
- cross-adic quotient sheets;
- matrix invariants;
- borrow cocycles;
- lacunary cancellation runs;
- direct ordinary-integrality consequences.

Every exact successful state remains \(\Theta(F_t)\) bits. Every tested
genuinely compressed substitute has exact collisions or loses the affine
numerator that controls the top lift.

Consecutive cancellation constraints are nested and do not create
multiplicative least-realizer cost.

The remaining general theory stops at the exact critical parity-density
boundary.

## Reopen condition

Reopen this branch only if a genuinely new external/internal theorem
provides at least one of:

1. an \(o(F_t)\) high-half invariant;
2. a theorem for the exact critical-density conjugacy equality case;
3. a schedule-specific theorem forcing infinitely many sampled top-lift
   changes;
4. a new cross-adic rigidity theorem not equivalent to endpoint residue
   tracking.

Deeper raw numerics, larger fixed-width automata, or renamed Hensel carry
states are not reopen conditions.

## Status of explicit survivor

\[
x_S\in\mathbb Z_{\ge0}
\]
remains `[OPEN]`.

Parking means "this mechanism is exhausted under current mathematics", not
"the survivor exists".
