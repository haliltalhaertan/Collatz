# CP20 RECOMMENDED START
## Upper-Tail State-Growth / Quantile-Window Rigidity

## Why this is the recommended new branch

Do not continue classifying \(x_{\rm neutral}\) high bits.

The Task-5 abstract survivor escapes Tasks 3–4 by maintaining a
super-near-linear baseline state exponent and paying for mean-2 excursions
inside harmonically tiny cores.

Task 5 also proved a useful quantile packing lemma, but there is no theorem
controlling how often an **actual positive injective Syracuse orbit** may
occupy the very-high-state tail.

That missing upper-tail statement is independent of the parked neutral
high-half problem.

## Primary CP20 question

Can one prove a deterministic theorem of the form:

> A positive injective odd-only Syracuse orbit satisfying the frozen CP17
> carry/occupation constraints cannot have logarithmic density one in a
> state regime
> \[
> n_k\ge k^{\kappa}
> \]
> for every fixed \(\kappa>\kappa_*\),
> or cannot simultaneously maintain such a high-state baseline and the
> local valuation windows required to evade Task-4 packing?

The exact exponent/form should be derived, not assumed.

## Suggested attacks

1. Quantile state packing across many overlapping windows rather than the
   single maximum \(H_N\).
2. Exact telescoping of
   \[
   \log n_{k+1}-\log n_k
   \]
   together with the positive \(+1\) correction, but falsify any route that
   merely reproduces the already-known carry identity.
3. Reciprocal-state sums and ordinary integer spacing.
4. Multi-window injective packing with state quantiles.
5. Cross-scale excursions in ordinary state space, without reading binary
   digits of the initial 2-adic realizer.
6. Explicit adversarial abstract schedules first: if the proposed
   upper-tail theorem is already false symbolically/arithmetically, kill it
   early.

## Success target

A theorem forcing a positive logarithmic proportion of starts into a state
quantile where the audited Task-4 weighted packing theorem applies.

Such a result would attack the entire high-state escape mechanism rather
than one handcrafted survivor.

## What not to do

- no more \(x_{\rm neutral}\) high-bit scans;
- no larger fixed-width automata;
- no assumed normality/equidistribution;
- no rebranding of Task-5 global occupation;
- no Side-B claim unless every remaining positive injective regime is
  actually covered.
