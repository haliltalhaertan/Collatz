# CP19 TASK 10 — EVENTUAL CANCELLATION RIGIDITY

Assume the explicit survivor is a fixed nonnegative ordinary integer
\[
x_S=n_0.
\]

For all sufficiently large events,
\[
2^{q_m}>n_0,
\]
so every final protected block vanishes:
\[
x_S\bmod2^{q_{m+1}}=n_0<2^{q_m}.
\]

Equivalently,
\[
B_m+U_m\equiv0\pmod{2^{L_m}}.
\]

## Consecutive cancellations

Suppose full cancellation holds for
\[
m,m+1,\ldots,m+k-1.
\]

On the final survivor itself, these conditions simply say that the bit
intervals
\[
[q_j,q_{j+1})
\]
are all zero. Therefore
\[
\boxed{
x_S\bmod2^{q_{m+k}}
=
x_S\bmod2^{q_m}.
}
\]

This is one deeper nested congruence, not \(k\) independent congruences.

If the lower residue is \(a<2^{q_m}\), the canonical least nonnegative
representative satisfying the entire run is still exactly
\[
\boxed{a.}
\]

There is no multiplicative least-realizer growth.

## Translation to the neutral background

Task 8 rewrites each event condition using an \(m\)-dependent rational
correction:
\[
x_0+\mathcal R_m
\equiv
2^{H_m}n_0-2^{F_{t_m}}U_m
\pmod{2^{F_{t_m}+w}}.
\]

The corrections \(\mathcal R_m\) themselves change with scale. After this
translation, the conditions are not a monotone sequence of cylinders for
one fixed neutral residue to which an independence product can be applied.

Subtracting consecutive identities reproduces the same growing-depth
high-half relation that Tasks 8–9 failed to compress.

No new ordinary-integer recurrence with sublinear state was obtained.

## Verdict

Eventual cancellation is indeed extremely rigid in the tautological sense
that an ordinary integer has zero high bits. But the run conditions do not
create a new arithmetic cost beyond eventual constancy itself.

\[
\boxed{\text{[FAIL: NO NEW CANCELLATION-RUN RIGIDITY]}}.
\]
