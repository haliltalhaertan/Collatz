# COLLATZ CP19 — TASK 10 FINDINGS
## Critical-Density Barrier Escape or Formal Branch Park

## Final verdict

\[
\boxed{\textbf{F — [PARK: CRITICAL-DENSITY HIGH-HALF BRANCH]}}
\]

Task 10 was the last-chance search for a genuinely compressed arithmetic
invariant controlling the pure-neutral sampled top-lift parity.

No such invariant was found.

All exact successful formulations either:

1. retain \(\Theta(F_t)\) bits; or
2. reduce to the already-open critical-density high-half/periodicity
   problem; or
3. are nested/redundant and create no new LEVEL-3 cost.

The explicit Task-5 survivor therefore remains LEVEL-3 open, but this
specific high-half branch is formally parked.

## What was tested

Task 10 did not repeat Task 9's low-carry automaton search.

It tested genuinely different high-half candidates:

- centered/signed canonical residue;
- leading bits of \(r_t\);
- complement \(2^{F_t}-r_t\);
- leading ordinary quotient classes;
- odd-modulus endpoint residues;
- exact two-sheet odd-modulus bridge;
- product/gcd constraints;
- pair-affine matrix determinant/trace/projective data;
- Hensel borrow/high-half descriptors;
- lacunary eventual-cancellation assumptions;
- consecutive cancellation-run cylinders;
- fixed ordinary-integer hypothesis directly.

## Main exact negative conclusions

### High-half/order invariants

Centered sign and bounded leading digits do not determine next parity.
Exact collisions exist.

### Odd-modulus route

There is an exact identity
\[
Y_t=\eta_t+\kappa_t3^t,\qquad\kappa_t\in\{0,1\}
\]
for large \(t\), with
\[
\eta_t=[2^{-F_t}B_t]_{3^t}.
\]

This is a clean cross-adic bridge, but the parity of the canonical
\(\eta_t\) representative still requires \(\Theta(F_t)\)-scale odd-modulus
information. Fixed \(3^k\) states have exact collisions.

### Matrix route

Determinant and trace ignore the affine numerator \(B\). Shifted neutral
blocks with identical determinant/trace can have opposite top lifts.

### Borrow route

The exact borrow variable \(z_t\) has \(F_t+O(1)\) bits. Bounded leading
borrow descriptors have exact collisions.

### Cancellation runs

Consecutive full cancellations are nested:
\[
x_S\bmod2^{q_{m+k}}=x_S\bmod2^{q_m}.
\]

Their least positive representative need not grow at all. This route is
nested-cylinder redundancy, not an independent cost mechanism.

## State-size conclusion

Every exact state currently known to determine the next high-half parity is
one of:

- \(r_t\bmod2^{F_t}\);
- full affine numerator \(B_t\);
- full Hensel borrow \(z_t\);
- full odd-modulus endpoint \(\eta_t\bmod3^t\).

Each has
\[
\boxed{\Theta(F_t)}
\]
bit complexity.

All tested \(O(1)\) and \(O(\log t)\) substitutes fail by exact collision.

No \(o(F_t)\) invariant survived.

## Eventual cancellation

The bad hypothesis
\[
B_m\equiv1\pmod2
\]
eventually cannot be contradicted with the available neutral arithmetic.

Assuming full eventual cancellation merely reproduces the statement that a
fixed ordinary integer has eventually zero high bits. Cross-scale
subtraction returns to the same growing-depth Hensel quotient.

Therefore
\[
\boxed{x_S\in\mathbb Z_{\ge0}\ ?\quad[\mathrm{OPEN}].}
\]

## Literature boundary

The neutral parity density is exactly
\[
\ln2/\ln3.
\]

Known general 3x+1 conjugacy aperiodicity theorems apply under a strict
density inequality above this value, not at equality. Task 10 found no
schedule-specific arithmetic invariant that crosses this boundary.

No normality, equidistribution or random-lift assumption is used.

## Decision

The formal park condition from the Task-10 prompt is met:

- all exact recurrences that determine the bit retain \(\Theta(F_t)\) state;
- cancellation-run rigidity reduces to nested redundancy;
- the remaining classification route returns to the critical-density
  periodicity boundary.

\[
\boxed{\text{[PARK: CRITICAL-DENSITY HIGH-HALF BRANCH]}}
\]

Do not open Task 11 on the same high-half mechanism.

## User-facing summary

### Ne denedik?

Task 9'da taşıyamadığımız dev \(F_t\)-bit state'in yerine, yalnız gerekli
yüksek biti belirleyecek daha küçük bir aritmetik özet aradık.

### Task 9 bariyerini gerçekten aştık mı?

Hayır. Yeni exact dönüşümler bulduk, ama hiçbiri gereken bilgiyi
\(o(F_t)\) boyuta sıkıştırmadı.

### Yeni invariant kaç bit state istiyor?

Exact çalışan bütün seçenekler hâlâ yaklaşık
\[
\Theta(F_t)
\]
bit istiyor. Sabit veya \(O(\log t)\) adaylar exact collision'larla kırıldı.

### Eventual cancellation'ı theorem olarak kırabildik mi?

Hayır.

### Explicit survivor artık ordinary integer olamaz mı?

Henüz hayır. LEVEL 3 statüsü açık.

### Bu branch devam etmeye değer mi?

Aynı mekanizmayla hayır. Task 10'un formal park koşulları sağlandı.

### CP20'de neye geçmeliyiz?

2-adic high-bit classification'dan bağımsız yeni bir branch:
**upper-tail state-growth / quantile-window rigidity**.

Hedef, gerçek positive injective Syracuse orbit'in logarithmic-most-time
\(n_k\) veya \(s_k\) seviyesini Task-4 packing eşiğinin üstünde tutup
tutamayacağını doğrudan ordinary-state arithmetic ile sınamak olmalı.
Bu, explicit \(x_{\rm neutral}\) bitlerini sınıflandırmayı gerektirmez.
