from __future__ import annotations

def combined_zero_block(low_residue:int,q_start:int,q_end:int)->int:
    assert 0<=low_residue<(1<<q_start)
    # Zeroing every protected bit in [q_start,q_end) leaves the same low representative.
    return low_residue

def verify_run(low_residue:int,depths:list[int]):
    q0=depths[0]
    assert 0<=low_residue<(1<<q0)
    for q in depths[1:]:
        assert low_residue%(1<<q)==low_residue
        assert low_residue<(1<<q)
    return low_residue

def main():
    # Synthetic separated event depths.
    qs=[20,45,97,201,409]
    for a in [1,7,12345,(1<<19)-1]:
        out=verify_run(a,qs)
        assert out==a

    # No multiplicative least-realizer growth: arbitrarily many zero blocks preserve a=7.
    for k in range(1,len(qs)):
        assert combined_zero_block(7,qs[0],qs[k])==7

    print("CP19 TASK10 CANCELLATION RUN ENGINE: OK")

if __name__=="__main__":main()
