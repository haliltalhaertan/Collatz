# CP19 FRONTIER AFTER TASK 10

## Frozen / proved

- CP17 collision-energy / harmonic theorem package: frozen and audited.
- CP18 Tasks 1–10: frozen big-audit sound.
- CP19 Task 3: long critical / sparse-critical positive LEVEL-3 obstruction,
  audited.
- CP19 Task 4: weighted-cylinder packing and canonical Construction-B
  exclusion, audited and frozen.

## Falsified / closed mechanisms

- global least-realizer growth;
- local first-passage minimum-state monotonicity;
- first-passage entropy saving;
- bounded-run forcing;
- fixed-depth modular/CRT obstruction;
- popcount/binary-support as a general obstruction;
- static 3-adic endpoint compression;
- phase synchronization / turnover-only cost;
- abstract compactness / nested-branch obstruction;
- global occupation + carry inequalities alone;
- phase-compatible entropy improvement beyond mean 2;
- bounded low-carry automata for the neutral high half;
- centered/top-bit/complement high-half summaries;
- fixed low odd-modulus endpoint summaries;
- matrix determinant/trace summaries;
- bounded borrow cocycles;
- cancellation-run least-realizer multiplication.

## Parked deep branch

### Critical-density high-half branch

The explicit Task-5 high-state survivor reduces to a pure-neutral
critical-density 2-adic high-half problem.

Tasks 8–10 show the unresolved high bit is nonlocal in all known exact
representations and sits at the \(\ln2/\ln3\) equality boundary of existing
general conjugacy theorems.

Status:
\[
\boxed{[\mathrm{PARK}]}
\]

## Genuinely open independent questions

1. Can a real positive injective Syracuse orbit sustain the high-state
   upper-tail regime used by the Task-5 abstract survivor on logarithmic-most
   times?
2. Can Task-4 quantile packing be coupled to a new deterministic upper-tail
   theorem for actual integer states?
3. Is there a global ordinary-state recurrence/invariant, not a 2-adic
   high-bit classifier, that rules out super-near-linear baseline state
   growth with recurrent mean-2 excursions?
4. Can CP17 occupation pressure be complemented by an independent upper
   occupation constraint?

## Side B

Still open.

The important CP19 outcome is not a full Collatz proof. It is a map of which
mechanisms are genuinely dead, which are frozen theorems, and which remaining
obstruction has reached a known/deep arithmetic boundary.
