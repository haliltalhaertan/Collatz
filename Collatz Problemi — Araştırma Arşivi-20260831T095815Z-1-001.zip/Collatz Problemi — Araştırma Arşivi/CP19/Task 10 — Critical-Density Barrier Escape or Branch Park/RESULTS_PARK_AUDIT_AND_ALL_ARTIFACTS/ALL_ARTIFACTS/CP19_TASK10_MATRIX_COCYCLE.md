# CP19 TASK 10 — PAIR-AFFINE MATRIX COCYCLE

A neutral pair with total valuation \(G\) and affine numerator \(B\) acts as
\[
2^G n_{\rm out}=9n_{\rm in}+B.
\]

Use the upper-triangular affine matrix
\[
M(G,B)=
\begin{pmatrix}
9&B\\
0&2^G
\end{pmatrix}.
\]

The three pair types are
\[
(3,7),\qquad(3,5),\qquad(4,5).
\]

Composition is exact matrix multiplication and reproduces
\[
B_{\rm total}=P_2B_1+2^{A_1}B_2.
\]

## Classical matrix invariants fail

For a block of \(r\) pairs and total valuation \(A\),
\[
\det M=9^r2^A,
\qquad
\operatorname{tr}M=9^r+2^A.
\]

Both are independent of the affine numerator \(B\).

But the top cylinder lift depends on \(B\).

Exact counterexample from shifted neutral blocks:

- two-pair block starting at pair 1:
  \[
  A=6,\quad B=119,\quad \lambda=1;
  \]
- two-pair block starting at pair 2:
  \[
  A=6,\quad B=103,\quad \lambda=0.
  \]

They have identical determinant and trace, but opposite top-lift parity.

Hence determinant, trace and discriminant derived from them cannot be the
required invariant.

## Projective coordinate

Retaining a projective coordinate that still remembers the full affine
numerator \(B\) restores exactness, but \(B\) has
\[
\Theta(F_t)
\]
bits on the dyadic prefixes.

No lower-dimensional projective quotient invariant determining the top lift
was found.

\[
\boxed{\text{[FAIL: MATRIX COCYCLE REMAINS FULL-AFFINE]}}.
\]
