# CP19 TASK 10 — HIGH-HALF ARITHMETIC INVARIANTS

## Status

All natural compressed high-half candidates tested here fail to determine the
next neutral top-lift parity.

The exact high-half itself remains available, but every known exact
renormalization retains \(\Theta(F_t)\) bits.

## 1. Centered residue

Let
\[
n=F_t,\qquad 0\le r_t<2^n,
\]
and define
\[
\sigma_t=\mathbf 1_{r_t>2^{n-1}},
\qquad
\bar r_t=r_t-\sigma_t2^n.
\]

Then
\[
\bar Y_t
=
\frac{3^t\bar r_t+B_t}{2^n}
=
Y_t-\sigma_t3^t.
\]

Since \(3^t\) is odd,
\[
\boxed{
Y_t\equiv \bar Y_t+\sigma_t\pmod2.
}
\]

Thus centered sign removes one top bit of \(r_t\), but leaves the parity of
another large quotient \(\bar Y_t\). It is not a compression theorem.

Exact collision: the same
\[
(\varepsilon_t,\text{boundary pair type},\operatorname{sign}\bar r_t)
\]
occurs at \(t=2\) and \(t=12\), but the next top-lift parities differ.

## 2. Leading bits of the residue

Keeping the first \(k\) leading binary digits of \(r_t\), together with
\(\varepsilon_t\) and boundary pair type, also fails.

Smallest exact collisions found:

- \(k=1,2\): \(t=2,12\);
- \(k=4\): \(t=12,24\);
- \(k=8\): \(t=4,24\).

Therefore bounded leading residue information is `[FAIL]`.

## 3. Complement variable

Let
\[
c_t=2^n-r_t.
\]
Then
\[
3^tc_t-B_t=2^n(3^t-Y_t).
\]

So replacing \(r_t\) by its complement merely replaces the endpoint
quotient by
\[
3^t-Y_t.
\]

This is exact, but the quotient is still \(F_t\)-scale. Fixed leading bits
of \(c_t\) have exact collisions and do not determine the next parity.

## 4. Leading class of the quotient

The ordinary bitlength of \(|C_t|=Y_t\) is \(\Theta(F_t)\) in general.
Keeping its bitlength offset plus a fixed number of leading digits loses the
least significant parity information.

Exact collisions occur for one, two and four retained leading quotient
digits, even after including the phase/pair descriptors.

## 5. Exact terminal-state relation

The depth-\(F_t+1\) top lift
\[
\lambda_t
\]
satisfies
\[
\boxed{
\lambda_t=1+C_t\pmod2.
}
\]

This is an exact reformulation, not a compressed invariant: the terminal
oddness condition asks for the same quotient parity.

## Verdict

No candidate in this family has state size \(o(F_t)\) and determines the
sampled parity.

\[
\boxed{\text{[FAIL: HIGH-HALF ORDER/SIGN VARIABLES DO NOT COMPRESS]}}
\]
