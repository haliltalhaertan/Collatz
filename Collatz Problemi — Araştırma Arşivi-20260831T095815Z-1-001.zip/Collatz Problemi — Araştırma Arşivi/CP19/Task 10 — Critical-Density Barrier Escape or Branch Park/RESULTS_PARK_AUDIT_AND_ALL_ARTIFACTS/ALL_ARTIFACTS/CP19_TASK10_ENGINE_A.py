from __future__ import annotations

LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537

def F(k:int)->int:
    if k==0:return 0
    lo=k*LOW_P//LOW_Q
    hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1

def g(k:int)->int:return F(k+1)-F(k)
def b(k:int)->int:return g(k)-1

def pair_data(r:int):
    k=2*r
    if b(k)==0:return 3,7,"P1=(2,1)"
    a2=g(k+1)+1
    if a2==2:return 3,5,"P2=(1,2)"
    assert a2==3
    return 4,5,"P3=(1,3)"

def combine(X,Y):
    A1,P1,B1=X;A2,P2,B2=Y
    return A1+A2,P1*P2,P2*B1+(1<<A1)*B2

def pair_block(start:int,count:int):
    stack=[]
    for r in range(start,start+count):
        G,Bp,_=pair_data(r)
        cur=(G,9,Bp);lv=0
        while lv<len(stack) and stack[lv] is not None:
            cur=combine(stack[lv],cur);stack[lv]=None;lv+=1
        if lv==len(stack):stack.append(cur)
        else:stack[lv]=cur
    T=None
    for lv in range(len(stack)-1,-1,-1):
        if stack[lv] is not None:
            T=stack[lv] if T is None else combine(T,stack[lv])
    return T

def carry_data(t:int):
    assert t%2==0
    n=F(t)
    A,P,B=pair_block(0,t//2)
    assert A==n
    r=(-B*pow(P,-1,1<<n))%(1<<n)
    Y=(P*r+B)>>n
    return n,P,B,r,Y,-Y

def next_parity(t:int)->int:
    return (1+carry_data(2*t)[5])&1

def descriptor(t:int,k:int=8):
    n,P,B,r,Y,C=carry_data(t)
    eps=F(2*t)-2*n
    _,_,ptype=pair_data(t//2)
    centered=r-(1<<n) if r>(1<<(n-1)) else r
    top=(r>>max(0,n-k))&((1<<min(k,n))-1)
    return (eps,ptype,(centered>0)-(centered<0),top),next_parity(t)

def main():
    # Exact centered/top-bit collision.
    seen={}
    found=None
    for t in range(2,2049,2):
        st,out=descriptor(t,8)
        if st in seen and seen[st][1]!=out:
            found=(seen[st][0],t,st,seen[st][1],out)
            break
        seen[st]=(t,out)
    assert found is not None

    # Direct top-lift parity equals 1+C mod2.
    for t in [2,4,10,32,128,512]:
        n,P,B,r,Y,C=carry_data(t)
        mod=1<<(n+1)
        rho=((1<<n)-B)*pow(P,-1,mod)%mod
        lam=(rho>>n)&1
        assert lam==(1+C)&1

    print("collision",found)
    print("CP19 TASK10 ENGINE A: OK")

if __name__=="__main__":main()
