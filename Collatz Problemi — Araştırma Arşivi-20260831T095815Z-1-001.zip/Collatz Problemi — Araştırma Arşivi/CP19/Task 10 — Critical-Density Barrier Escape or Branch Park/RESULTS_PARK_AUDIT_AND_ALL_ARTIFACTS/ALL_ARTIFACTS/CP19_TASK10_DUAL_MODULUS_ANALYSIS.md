# CP19 TASK 10 — DUAL-MODULUS / CROSS-VALUATION ANALYSIS

Let
\[
n=F_t,\qquad P=3^t,
\qquad
Y_t=\frac{Pr_t+B_t}{2^n}.
\]

Define the canonical odd-modulus endpoint residue
\[
\boxed{
\eta_t=[2^{-n}B_t]_P,\qquad 0\le\eta_t<P.
}
\]

Then
\[
\boxed{Y_t\equiv\eta_t\pmod P.}
\]

## 1. Exact two-sheet reduction

For the pure-neutral word,
\[
s_j\in\{-1,0,1\}.
\]
Hence
\[
\frac{B_t}{P}
=
\sum_{j<t}\frac{2^{A_j}}{3^{j+1}}
\le\frac{2t}{3}.
\]

Also
\[
1\le \frac P{2^n}<2.
\]
Therefore
\[
\frac{B_t}{2^n}<\frac{4t}{3}.
\]

For all sufficiently large \(t\), this is \(<P\), and since
\[
0<Y_t<P+\frac{B_t}{2^n},
\]
we obtain
\[
\boxed{
Y_t=\eta_t+\kappa_tP,\qquad \kappa_t\in\{0,1\}.
}
\]

The sheet bit is explicitly
\[
\boxed{
\kappa_t=1
\iff
\eta_t<\frac{B_t}{2^n}.
}
\]

Thus
\[
\boxed{
C_t\equiv Y_t\equiv\eta_t+\kappa_t\pmod2.
}
\]

This is a genuine exact real/odd-modulus bridge.

## 2. Why it does not compress

The threshold deciding \(\kappa_t\) is only \(O(t)\), but the parity of the
canonical representative \(\eta_t\in[0,3^t)\) remains unresolved.

A residue modulo an odd modulus has no parity invariant independent of the
chosen ordinary representative: adding \(3^t\) flips parity.

Fixed low ternary information is insufficient. Exact collisions were found
for states
\[
(\varepsilon_t,\text{pair type},\eta_t\bmod3^k)
\]
for each \(k=1,2,3,4,5\), with different next top-lift parity.

Keeping the full \(\eta_t\bmod3^t\) costs
\[
\log_2 3^t=\Theta(t)=\Theta(F_t)
\]
bits, so it is not compression.

## 3. Product-formula / gcd information

Modulo three,
\[
B_t\equiv2^{A_{t-1}}\not\equiv0\pmod3.
\]
Consequently
\[
2^nY_t\equiv B_t\not\equiv0\pmod3,
\]
so
\[
\boxed{3\nmid Y_t.}
\]

This cross-adic unit fact is exact but places no restriction on the parity of
\(Y_t\).

No elementary product-formula/gcd contradiction arises from eventual fixed
top-lift parity.

## 4. Relation to earlier endpoint geometry

The variable \(\eta_t\) is precisely the odd-modulus endpoint residue type
already encountered in CP13/CP18 Task 8. The new two-sheet identity clarifies
its relation to \(C_t\), but it does not remove the full-size endpoint state.

Therefore the odd-modulus route is:

\[
\boxed{\text{[REDUNDANT/FAIL AS COMPRESSION]}}.
\]
