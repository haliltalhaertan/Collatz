# CP19 TASK 10 — CANCELLATION-RUN CYLINDERS

Let
\[
q_m<q_{m+1}<\cdots
\]
be the protected depths.

A full cancelling event \(j\) imposes
\[
\operatorname{HB}_{q_j,L_j}(x_S)=0,
\qquad
L_j=q_{j+1}-q_j.
\]

For a run \(j=m,\ldots,m+k-1\), the conjunction is exactly
\[
\boxed{
x_S\bmod2^{q_{m+k}}
=
x_S\bmod2^{q_m}.
}
\]

Thus the combined cylinder has the same low representative and merely a
larger modulus.

## Least-positive representative

Fix any odd
\[
1\le a<2^{q_m}.
\]

Then
\[
a
\]
satisfies all \(k\) zero-block conditions simultaneously, for every \(k\).
The least positive representative is therefore at most \(a\), independent
of the run length.

This is an explicit falsification of a generic claim that separated
zero-block constraints multiply the least-realizer cost.

## Relation to CP18 Task 10

This is the same structural phenomenon as nested-cylinder redundancy:
compatible higher-depth constraints can add precision without increasing the
canonical ordinary representative.

Therefore cancellation-run least-realizer growth does not supply a new
LEVEL-3 obstruction.

Any successful use of event runs would have to prove a
**schedule-specific forced nonzero block**, not count zero-block conditions
as independent.

Status:
\[
\boxed{\text{[REDUNDANT WITH NESTED-CYLINDER BARRIER]}}.
\]
