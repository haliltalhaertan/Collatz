# CP19 TASK 10 — COMPLEMENT / BORROW COCYCLE

Task 9's exact doubling step writes
\[
F_{2t}=2n+\varepsilon_t,
\]
and introduces the Hensel lift block
\[
z_t\in[0,2^{n+\varepsilon_t})
\]
satisfying
\[
z_t
\equiv
-(3^tY_t+D_t)3^{-2t}
\pmod{2^{n+\varepsilon_t}}.
\]

This \(z_t\) is the exact borrow/carry information required to lift the
depth-\(n\) cylinder into the new half.

## Bounded borrow descriptors

Task 10 tested:

- lower/upper half of \(z_t\);
- first 2, 4 and 8 leading bits of \(z_t\);

together with \(\varepsilon_t\) and the boundary pair type.

All have exact state collisions with different next top-lift parity.

Examples include:

- top 1 borrow bit: \(t=2,14\);
- top 2 borrow bits: \(t=14,26\);
- top 4 borrow bits: \(t=8,44\);
- top 8 borrow bits: \(t=84,122\).

Thus bounded high-borrow information is not enough.

## Exact state cost

The full \(z_t\) has
\[
n+\varepsilon_t=\Theta(F_t)
\]
bits.

Keeping it gives the exact Task-9 recurrence, but no compression.

The same conclusion holds for a carry-run descriptor that is enlarged until
it uniquely reconstructs \(z_t\): once its information content reaches
\(\Theta(F_t)\), it is merely a renamed full Hensel state.

\[
\boxed{\text{[FAIL: NO BOUNDED BORROW COCYCLE]}}.
\]
