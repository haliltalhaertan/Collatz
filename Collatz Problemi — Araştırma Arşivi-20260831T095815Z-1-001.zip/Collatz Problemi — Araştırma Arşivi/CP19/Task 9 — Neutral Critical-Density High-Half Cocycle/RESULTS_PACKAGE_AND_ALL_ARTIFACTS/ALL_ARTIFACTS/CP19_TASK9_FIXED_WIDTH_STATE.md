# CP19 TASK 9 — FIXED-WIDTH STATE FALSIFICATION

Task 9 tested increasingly rich proposed neutral dyadic states.

A generic candidate was
\[
Z_t^{(k)}
=
(
\varepsilon_t,\,
\text{boundary pair type at }t,\,
C_t\bmod2^k
).
\]

If such a state determined the next neutral parity, equal states would have
equal outputs at \(2t\).

Exact pure-neutral prefixes give the following counterexamples:

| carry bits \(k\) | \(t_1\) | \(t_2\) | same state | parity at \(2t_1\) | parity at \(2t_2\) |
|---:|---:|---:|---|---:|---:|
| 1 | 2 | 4 | \((0,P_1,0)\) | 1 | 0 |
| 2 | 2 | 4 | \((0,P_1,2)\) | 1 | 0 |
| 3 | 2 | 4 | \((0,P_1,6)\) | 1 | 0 |
| 4 | 10 | 22 | \((1,P_3,8)\) | 0 | 1 |
| 8 | 54 | 80 | \((1,P_2,53)\) | 1 | 0 |

Thus these recurrence classes are
\[
\boxed{[\mathrm{COUNTEREXAMPLE}]}.
\]

The collisions are actual prefixes of the frozen pure-neutral word, not
random surrogate phases.

## Scope

This does **not** prove that no finite automaton of any larger design exists.
It shows that:

- phase doubling bit \(\varepsilon_t\);
- local pair type;
- up to eight low critical-carry bits

are insufficient as a Markov state.

Adding \(m\bmod50\) is relevant to the full survivor correction process, but
it does not resolve the pure-neutral high-half cocycle itself.

The exact dyadic recurrence derived in Task 9 retains a state whose
precision grows like \(F_t\).
