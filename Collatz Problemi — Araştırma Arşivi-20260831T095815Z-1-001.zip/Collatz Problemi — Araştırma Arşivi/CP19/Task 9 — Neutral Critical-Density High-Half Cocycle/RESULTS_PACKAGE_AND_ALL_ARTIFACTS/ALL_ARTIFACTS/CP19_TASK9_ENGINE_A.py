from __future__ import annotations
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537

def F(k:int)->int:
    if k==0:return 0
    lo=k*LOW_P//LOW_Q
    hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1

def g(k:int)->int:return F(k+1)-F(k)
def b(k:int)->int:return g(k)-1

def pair_data(r:int):
    k=2*r
    if b(k)==0:return 3,7
    a2=g(k+1)+1
    return (3,5) if a2==2 else (4,5)

def neutral_a(k:int)->int:
    G,Bp=pair_data(k//2)
    if G==3 and Bp==7:return 2 if k%2==0 else 1
    if G==3:return 1 if k%2==0 else 2
    return 1 if k%2==0 else 3

def combine(X,Y):
    A1,P1,B1=X;A2,P2,B2=Y
    return A1+A2,P1*P2,P2*B1+(1<<A1)*B2

def pair_block(start_pair:int,count:int):
    stack=[]
    for r in range(start_pair,start_pair+count):
        G,Bp=pair_data(r);cur=(G,9,Bp);lv=0
        while lv<len(stack) and stack[lv] is not None:
            cur=combine(stack[lv],cur);stack[lv]=None;lv+=1
        if lv==len(stack):stack.append(cur)
        else:stack[lv]=cur
    T=None
    for lv in range(len(stack)-1,-1,-1):
        if stack[lv] is not None:
            T=stack[lv] if T is None else combine(T,stack[lv])
    return T

def neutral_high_direct(t:int,w:int):
    assert t%2==0
    n=F(t);M=1<<(n+w)
    inv3=pow(3,-1,M)
    ip=inv3
    A=0;x=0;j=0
    while A<n+w:
        x=(x-(pow(2,A,M)*ip))%M
        A+=neutral_a(j)
        ip=(ip*inv3)%M
        j+=1
    return (x>>n)&((1<<w)-1),j,A

def main():
    for m in range(10,13):
        t=3*(1<<(m-1))
        hb,j,A=neutral_high_direct(t,16)
        print(m,t,hex(hb),j,A)
    print("CP19 TASK9 ENGINE A: OK")

if __name__=="__main__":main()
