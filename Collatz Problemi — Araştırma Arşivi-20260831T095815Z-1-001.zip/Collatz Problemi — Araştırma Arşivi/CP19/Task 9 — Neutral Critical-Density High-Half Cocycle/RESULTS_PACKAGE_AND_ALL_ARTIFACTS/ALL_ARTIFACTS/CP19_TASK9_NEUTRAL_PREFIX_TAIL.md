# CP19 TASK 9 — NEUTRAL PREFIX–TAIL DECOMPOSITION

Let \(a_j\) be the frozen pure-neutral valuation word and
\[
A_j=\sum_{i<j}a_i.
\]
For every even \(t\),
\[
\boxed{A_t=F_t=:n.}
\]

Define the exact affine prefix numerator
\[
\boxed{
B_t=\sum_{j=0}^{t-1}3^{t-1-j}2^{A_j}
}
\]
so that
\[
2^{A_t}n_t=3^t n_0+B_t.
\]

The finite inverse prefix is
\[
\boxed{
Q_t=
-\sum_{j<t}\frac{2^{A_j}}{3^{j+1}}
=
-\frac{B_t}{3^t}.
}
\]

The infinite pure-neutral realizer is
\[
x_0=Q_t+T_t,
\]
where
\[
T_t=
-\sum_{j\ge t}\frac{2^{A_j}}{3^{j+1}}.
\]

Because the first tail term has valuation \(A_t=n\), while every later
term has strictly larger valuation,
\[
\boxed{v_2(T_t)=n.}
\]

For fixed width \(w\), define the normalized tail
\[
\tau_{t,w}
=
2^{-n}T_t\bmod2^w.
\]
Then exactly
\[
\boxed{
\tau_{t,w}
=
-\sum_{\substack{j\ge t\\A_j-n<w}}
2^{A_j-n}3^{-(j+1)}
\pmod{2^w}.
}
\]

Since every \(a_j\ge1\), at most \(w\) tail symbols are required. Thus the
tail side is genuinely local:
\[
\boxed{\text{tail depth }=O(w).}
\]

If
\[
\operatorname{HB}_{n,w}(y)
=
\left\lfloor
\frac{y\bmod2^{n+w}}{2^n}
\right\rfloor\bmod2^w,
\]
then no lower-bit carry enters from \(T_t\), because \(2^n\mid T_t\). Hence
\[
\boxed{
\operatorname{HB}_{n,w}(x_0)
=
\operatorname{HB}_{n,w}(Q_t)+\tau_{t,w}
\pmod{2^w}.
}
\]

At parity width \(w=1\), only the first tail term remains and
\[
\boxed{\tau_{t,1}=1.}
\]
