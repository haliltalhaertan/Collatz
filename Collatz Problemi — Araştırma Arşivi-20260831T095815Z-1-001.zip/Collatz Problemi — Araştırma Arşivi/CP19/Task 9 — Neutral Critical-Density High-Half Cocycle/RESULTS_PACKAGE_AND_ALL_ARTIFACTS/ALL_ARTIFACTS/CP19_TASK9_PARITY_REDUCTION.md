# CP19 TASK 9 — PARITY REDUCTION

For event depths
\[
t_m=3\cdot2^{m-1},
\qquad
n_m=F_{t_m},
\]
define the neutral sampled bit
\[
b_m^{(0)}
=
\operatorname{bit}_{n_m}(x_0).
\]

The prefix-tail theorem and critical carry theorem give
\[
\boxed{
b_m^{(0)}
=
1+C_{t_m}\pmod2.
}
\]

Task 8 reduces the actual pre-event block to
\[
B_m
=
\operatorname{HB}_{n_m,1}(x_0+\mathcal R_m),
\]
where \(\mathcal R_m\) is rational but lower-bit carries matter. Thus one
must not write
\[
B_m=b_m^{(0)}+\operatorname{HB}(\mathcal R_m)
\]
without an addition-carry state.

For finite diagnostics we define the **effective rational-plus-carry parity**
by
\[
e_m=B_m-b_m^{(0)}\pmod2.
\]
This is an exact diagnostic decomposition, not the raw high bit of
\(\mathcal R_m\).

## Exact event data

Direct neutral computation gives
\[
(b_m^{(0)})_{m=10}^{18}
=
\boxed{
(1,1,0,1,1,1,1,0,0).
}
\]

The exact Task-8 pre-event parities are
\[
(B_m)_{m=10}^{20}
=
\boxed{
(1,0,0,0,1,0,0,1,0,1,1).
}
\]

Since
\[
U_m\equiv1\pmod2,
\]
ordinary nonnegative stabilization would require \(B_m=1\) eventually.

Finite data contain many \(B_m=0\), but Task 9 does not prove infinitely
many such \(m\).

## No simple phase-bit formula

The neutral bit is not equal to \(\varepsilon_m\), its complement, or the
current pair-type label on the exact overlap range.

More generally, actual neutral prefixes produce collisions where
\[
(\varepsilon_t,\text{boundary pair type},C_t\bmod2^k)
\]
is identical but the parity at \(2t\) differs.

Therefore the cheapest low-state parity recurrences are falsified.
