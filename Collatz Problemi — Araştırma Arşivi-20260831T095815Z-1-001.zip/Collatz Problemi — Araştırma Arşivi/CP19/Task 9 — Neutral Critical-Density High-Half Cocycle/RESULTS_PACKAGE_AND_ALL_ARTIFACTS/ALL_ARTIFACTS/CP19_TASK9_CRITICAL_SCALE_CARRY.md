# CP19 TASK 9 — CRITICAL-SCALE CARRY

Let
\[
n=F_t=A_t
\]
for even \(t\), and let
\[
r_t\equiv Q_t\pmod{2^n},
\qquad
0\le r_t<2^n.
\]

Since
\[
Q_t=-B_t/3^t,
\]
\[
3^t r_t+B_t
\]
is divisible by \(2^n\).

Define
\[
\boxed{
Y_t=\frac{3^t r_t+B_t}{2^n}
}
\]
and the signed critical-scale Hensel carry
\[
\boxed{
C_t=
\frac{-B_t-3^t r_t}{2^n}
=-Y_t.
}
\]

Thus \(C_t\) has the exact endpoint/affine-quotient interpretation requested
in Task 9.

## High-half formula

Write
\[
Q_t\bmod2^{n+w}=r_t+2^n h_t.
\]
Then
\[
3^t h_t\equiv C_t\pmod{2^w},
\]
so
\[
\boxed{
\operatorname{HB}_{n,w}(Q_t)
\equiv
C_t3^{-t}\pmod{2^w}.
}
\]

Combining with the local tail:
\[
\boxed{
\operatorname{HB}_{n,w}(x_0)
\equiv
C_t3^{-t}+\tau_{t,w}
\pmod{2^w}.
}
\]

## Parity

Modulo two, \(3^{-t}\equiv1\) and \(\tau_{t,1}=1\), hence
\[
\boxed{
\operatorname{bit}_{F_t}(x_0)
=
1+C_t\pmod2.
}
\]

## Cylinder top-lift interpretation

Let
\[
\rho_t=r_t+\lambda_t2^n
\]
be the exact depth-\(n+1\) positive cylinder representative. Its terminal
state is
\[
\frac{3^t\rho_t+B_t}{2^n}
=
Y_t+3^t\lambda_t.
\]

Exact terminal oddness gives
\[
Y_t+\lambda_t\equiv1\pmod2.
\]
Therefore
\[
\boxed{
\lambda_t=1+C_t\pmod2
=
\operatorname{bit}_{F_t}(x_0).
}
\]

So the neutral sampled high bit is exactly the top cylinder lift bit.

## Ordinary magnitude

The carry is not confined to a small ordinary interval. Since
\[
0\le r_t<2^n,\qquad 1\le3^t/2^n<2,
\]
the contribution \(3^tr_t/2^n\) alone may have \(n+1\) ordinary binary
bits.

For the neutral word, \(s_j\in\{-1,0,1\}\), so
\[
B_t/3^t=O(t),
\]
but this does not make \(Y_t\) or \(C_t\) \(O(t)\). Exact computations show
critical carries with ordinary bitlength comparable to \(F_t\).

Thus the hoped-for "small carry state" does not emerge.
