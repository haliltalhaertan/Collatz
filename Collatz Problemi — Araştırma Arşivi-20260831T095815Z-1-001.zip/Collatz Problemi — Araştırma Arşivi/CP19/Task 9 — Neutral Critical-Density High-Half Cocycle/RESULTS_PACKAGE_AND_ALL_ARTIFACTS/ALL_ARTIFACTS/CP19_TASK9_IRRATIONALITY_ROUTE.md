# CP19 TASK 9 — IRRATIONALITY-ONLY ROUTE

A particularly attractive route would express the eventual survivor parity
as
\[
B_m=c_m\oplus d_m,
\]
where \(c_m\) is eventually periodic and \(d_m\) is a fixed binary digit
observable of a doubling orbit
\[
\{2^m\xi\}
\]
for an explicit irrational \(\xi\).

If eventual cancellation forced the binary expansion of \(\xi\) to become
eventually periodic, irrationality alone would give a contradiction.

Task 9 did not obtain such a reduction.

## What is exact

The symbolic neutral pair type is a three-interval coding of the irrational
rotation
\[
\theta_r=\{r(2\alpha-3)\}.
\]

At dyadic pair indices the phase evolves by
\[
\theta\mapsto\{2\theta\}.
\]

The floor bit
\[
\varepsilon_m
=
F_{2t_m}-2F_{t_m}
\]
is also a simple doubling-phase observable.

## What is not exact

The high bit
\[
\operatorname{bit}_{F_{t_m}}(x_0)
\]
is not shown to be a fixed finite digit/block of that phase.

Small-state collisions already show it is not a memoryless function of the
simplest phase/carry labels.

Therefore:

- irrationality of \(\log_2 3\) alone does not presently imply infinitely
  many parity mismatches;
- no normality/equidistribution assumption is permitted;
- no visit-frequency statement for the specific doubling orbit is used.

Status:
\[
\boxed{[\mathrm{OPEN\ IRRATIONALITY\ ROUTE}]}.
\]
