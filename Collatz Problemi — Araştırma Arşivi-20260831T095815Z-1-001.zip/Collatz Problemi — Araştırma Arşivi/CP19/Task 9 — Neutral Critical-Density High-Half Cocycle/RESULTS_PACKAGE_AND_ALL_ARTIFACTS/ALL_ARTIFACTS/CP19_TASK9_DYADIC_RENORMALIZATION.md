# CP19 TASK 9 — DYADIC RENORMALIZATION

Let \(t\) be even,
\[
n=F_t,
\qquad
F_{2t}=2n+\varepsilon,
\qquad
\varepsilon\in\{0,1\}.
\]

Write
\[
P=3^t
\]
and let \(B_t\) be the first-half affine numerator.

For the shifted neutral block \([t,2t)\), define
\[
\boxed{
D_t=
\sum_{j=0}^{t-1}
3^{t-1-j}2^{A_{t+j}-A_t}.
}
\]
Its total valuation is
\[
A_{2t}-A_t=n+\varepsilon.
\]

Exact affine composition gives
\[
\boxed{
B_{2t}=P B_t+2^nD_t.
}
\]

Let
\[
r_t\equiv -B_tP^{-1}\pmod{2^n},
\qquad
Y_t=\frac{Pr_t+B_t}{2^n}=-C_t.
\]

Because the longer prefix extends the shorter cylinder,
\[
r_{2t}=r_t+2^n z_t
\]
for a unique
\[
0\le z_t<2^{n+\varepsilon}.
\]

Substitution into the \(2t\)-block identity gives
\[
P^2r_{2t}+B_{2t}
=
2^n(PY_t+P^2z_t+D_t).
\]

Therefore
\[
\boxed{
z_t
\equiv
-(PY_t+D_t)P^{-2}
\pmod{2^{n+\varepsilon}},
}
\]
and
\[
\boxed{
C_{2t}
=
-\frac{PY_t+D_t+P^2z_t}{2^{n+\varepsilon}}.
}
\]

This is an exact dyadic renormalization/cocycle formula.

## Why it is not the desired fixed-width cocycle

To obtain only
\[
C_{2t}\bmod2^w,
\]
the quotient above still requires the numerator through precision
\[
n+\varepsilon+w.
\]

Equivalently, one must know approximately \(n=F_t\) bits of the previous
carry/affine state. The shifted block \(D_t\) itself also contains
\(\Theta(n)\) bits.

No reduction to
\[
C_t\bmod2^{w+O(1)}
\]
plus a bounded phase descriptor was found.

The exact cocycle therefore has growing state size
\[
\boxed{\Theta(F_t)}
\]
in the natural formulation.

Task-9 collision tests show that several proposed low-width truncations of
this state are genuinely insufficient even for predicting the next parity.
