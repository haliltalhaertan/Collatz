from __future__ import annotations
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537

def F(k:int)->int:
    if k==0:return 0
    lo=k*LOW_P//LOW_Q
    hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1

def g(k:int)->int:return F(k+1)-F(k)
def b(k:int)->int:return g(k)-1

def pair_data(r:int):
    k=2*r
    if b(k)==0:return 3,7
    a2=g(k+1)+1
    return (3,5) if a2==2 else (4,5)

def neutral_a(k:int)->int:
    G,Bp=pair_data(k//2)
    if G==3 and Bp==7:return 2 if k%2==0 else 1
    if G==3:return 1 if k%2==0 else 2
    return 1 if k%2==0 else 3

def combine(X,Y):
    A1,P1,B1=X;A2,P2,B2=Y
    return A1+A2,P1*P2,P2*B1+(1<<A1)*B2

def pair_block(start_pair:int,count:int):
    stack=[]
    for r in range(start_pair,start_pair+count):
        G,Bp=pair_data(r);cur=(G,9,Bp);lv=0
        while lv<len(stack) and stack[lv] is not None:
            cur=combine(stack[lv],cur);stack[lv]=None;lv+=1
        if lv==len(stack):stack.append(cur)
        else:stack[lv]=cur
    T=None
    for lv in range(len(stack)-1,-1,-1):
        if stack[lv] is not None:
            T=stack[lv] if T is None else combine(T,stack[lv])
    return T

def carry_data(t:int):
    assert t%2==0
    n=F(t)
    A,P,Bt=pair_block(0,t//2);assert A==n
    r=(-Bt*pow(P,-1,1<<n))%(1<<n)
    Y=(P*r+Bt)>>n
    return n,P,Bt,r,Y

def doubled_carry(t:int):
    n,P,Bt,r,Y=carry_data(t)
    n2=F(2*t);eps=n2-2*n
    G,P2,D=pair_block(t//2,t//2)
    assert G==n+eps and P2==P
    z=(-(P*Y+D)*pow(P*P,-1,1<<(n+eps)))%(1<<(n+eps))
    C2=-(P*Y+D+P*P*z)//(1<<(n+eps))
    return C2

def direct_carry(t:int):
    n,P,Bt,r,Y=carry_data(t)
    return -Y

def main():
    for t in [32,64,128,256,512,1536]:
        c2=doubled_carry(t)
        direct=direct_carry(2*t)
        assert c2==direct,(t,c2,direct)
        print(t,c2&0xffff)
    print("CP19 TASK9 COCYCLE ENGINE: OK")

if __name__=="__main__":main()
