# CP19 TASK 9 — BARRIER ANALYSIS

Task 9 isolates the remaining neutral problem more sharply than Task 8.

## Solved layers

1. Prefix rational part:
   \[
   Q_t=-B_t/3^t.
   \]

2. Critical Hensel carry:
   \[
   C_t=(-B_t-3^tr_t)/2^{F_t}.
   \]

3. Local infinite tail:
   at width \(w\), only \(O(w)\) neutral symbols are required.

4. Pair symbolic driver:
   exact three-interval irrational-rotation coding.

5. Exact dyadic composition:
   an explicit formula for \(C_{2t}\) from the first-half carry and shifted
   block.

## Remaining nonlocality

The natural exact dyadic step requires precision roughly
\[
F_t
\]
to produce the new critical high-half carry.

This is not an implementation accident: the new carry is itself a quotient
after solving a Hensel congruence at depth
\[
F_{2t}-F_t
=
F_t+\varepsilon_t.
\]

No theorem compresses the actual neutral orbit's input from that growing
precision to \(O(\operatorname{poly}(w,\log t))\).

## Critical-density boundary

The pure-neutral valuation mean is exactly
\[
\alpha=\log_2 3,
\]
so its associated full parity density is
\[
\ln2/\ln3.
\]

Available general 3x+1 conjugacy results prove preservation of aperiodicity
under a strict density inequality above this value, but not at equality.
The earlier Sturmian-conjugacy literature also records the general
aperiodic-to-eventually-periodic question as open.

Task 9 does not claim equivalence to the full Periodicity Conjecture.
It records only that the general literature does not classify this exact
critical-density object.

## Final barrier

The explicit survivor would be excluded if one proved
\[
B_m=0\pmod2
\]
for infinitely many \(m\).

After Tasks 8–9, this requires controlling a dyadically sampled critical
high-half carry of one fixed neutral 2-adic object.

No fixed-width recurrence or irrationality-only coding theorem was found.

This matches Task-9 failure condition:
\[
\boxed{
\text{A — state remains essentially of depth }F_t.
}
\]
