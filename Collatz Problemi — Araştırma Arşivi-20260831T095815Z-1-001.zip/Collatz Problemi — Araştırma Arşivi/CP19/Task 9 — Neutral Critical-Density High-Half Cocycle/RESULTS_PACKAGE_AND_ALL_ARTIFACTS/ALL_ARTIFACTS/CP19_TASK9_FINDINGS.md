# COLLATZ CP19 — TASK 9 FINDINGS
## Pure-Neutral Critical-Density High-Half Cocycle

## Final strategic verdict

\[
\boxed{\textbf{A — [FAIL: DYADIC HIGH-HALF REMAINS NONLOCAL]}}
\]

Task 9 obtains exact prefix-tail, carry, endpoint and dyadic composition
formulas, but no fixed-width/sublinear-state recurrence for the sampled
neutral high bits.

No infinite parity mismatch theorem is proved.

Therefore the explicit Task-5 survivor remains ordinary-positive/nonnegative
LEVEL-3 open.

## Main exact results

For even \(t\), with \(n=F_t=A_t\),
\[
x_0=Q_t+T_t,
\qquad
Q_t=-B_t/3^t,
\qquad
v_2(T_t)=n.
\]

At width \(w\),
\[
\boxed{
\operatorname{HB}_{n,w}(x_0)
=
C_t3^{-t}+\tau_{t,w}
\pmod{2^w},
}
\]
where
\[
C_t=
\frac{-B_t-3^tr_t}{2^n}
\]
is the exact critical-scale Hensel carry and \(\tau_{t,w}\) uses at most
\(w\) local tail symbols.

At parity,
\[
\boxed{
\operatorname{bit}_{F_t}(x_0)
=
1+C_t\pmod2.
}
\]

This bit is also the top-lift bit of the finite neutral cylinder.

## Dyadic renormalization

If \(F_{2t}=2F_t+\varepsilon_t\), the exact two-half composition gives a
closed algebraic formula for \(C_{2t}\).

However the formula requires a Hensel solve at depth approximately \(F_t\).
No reduction to \(C_t\bmod2^{O(w)}\) plus bounded phase data was found.

So the new cocycle is exact but **growing-depth**, not fixed-width.

## Adversarial automaton tests

Actual pure-neutral prefixes falsify the proposed low-state families.

Even after including:

- \(\varepsilon_t\);
- boundary pair type;
- \(C_t\bmod2^k\);

the same state can have different next neutral parity.

Exact collisions exist for \(k=1,2,3,4,8\).

Therefore these naive finite-state recurrences are dead.

## Event parity

Direct neutral sampled parity for \(m=10,\ldots,18\):
\[
\boxed{
(1,1,0,1,1,1,1,0,0).
}
\]

Exact full pre-event parity from Task 8 for \(m=10,\ldots,20\):
\[
\boxed{
(1,0,0,0,1,0,0,1,0,1,1).
}
\]

Because \(U_m\equiv1\pmod2\), ordinary nonnegative stabilization requires
\(B_m=1\) eventually.

Finite mismatches exist, but Task 9 does not prove infinitely many.

## Literature boundary

The neutral full parity density is exactly
\[
\ln2/\ln3.
\]
Known general conjugacy aperiodicity results use a strict inequality above
this critical value; they do not settle this equality case.

No literature theorem was imported to classify \(x_0\).

## Required result table

| Question | Verdict | Evidence |
|---|---|---|
| Prefix-tail high-block decomposition exact? | `[PROVED]` | exact inverse-series split |
| Critical-scale carry \(C_t\) exact? | `[PROVED]` | rational Hensel quotient |
| Local tail mod \(2^w\) uses \(O(w)\) depth? | `[PROVED]` | \(a_j\ge1\) |
| \(C_t\) has endpoint interpretation? | `[PROVED]` | \(C_t=-Y_t\) |
| Dyadic \(C_{2t}\) recurrence exists? | `[EXACT BUT GROWING-DEPTH]` | two-half affine formula |
| Fixed-width neutral high-half recurrence exists? | **NO** | no compression; collisions |
| \(B_m\) parity has closed recurrence? | **NO** | rational correction + neutral high-half unresolved |
| \(B_m\) parity eventually periodic? | `[OPEN]` | finite data only |
| \(B_m=0\) infinitely often proved? | **NO** | finite mismatches only |
| Fixed-width mismatch infinitely often proved? | **NO** | `[OPEN]` |
| Explicit survivor excluded? | **NO** | LEVEL 3 remains open |
| \(x_{\rm neutral}\) classified? | **NO** | critical-density boundary |
| Deep/open periodicity barrier encountered? | **YES, boundary encountered** | general theorems stop at equality |
| Side B? | **NO** | no survivor exclusion |

## Ne denedik?

Task 8'de kalan tek zor nesne olan pure-neutral \(x_0\)'ın event
derinliklerindeki yüksek bitini doğrudan parçaladık ve \(t\mapsto2t\)
renormalization aradık.

## Darboğaz küçüldü mü?

Evet. Infinite tail lokal hale geldi ve prefix tarafı tek carry \(C_t\)'ye
indi. Ama carry'nin dyadic güncellemesi hâlâ yaklaşık \(F_t\) bitlik state
istiyor.

## Gerçek fixed-width recurrence bulduk mu?

Hayır. Exact recurrence var fakat state derinliği her doubling'de yaklaşık
ikiye katlanıyor.

## Parity sonsuz kez mismatch oluyor mu?

Finite exact veride birçok mismatch var. Sonsuzluk theorem'i yok.

## Explicit survivor artık ordinary integer olamaz mı?

Hayır:
\[
\boxed{x_S\in\mathbb Z_{\ge0}\ ?\ [OPEN].}
\]

## Kalan exact lemma

Bir fixed \(w\), ideal olarak \(w=1\), için sampled critical carry/rational
correction cocycle'ının sonsuz sayıda cancelling state dışına çıktığını
kanıtlamak.

## Sıradaki tek en yüksek bilgi değerli soru

Growing-depth carry'nin **yüksek yarısını** doğrudan takip eden bir
arithmetic invariant bulmak: full \(F_t\)-bit residue'yi taşımadan
\(C_{2t}\bmod2\)'yi belirleyebilen yeni bir invariant yoksa bu branch artık
critical-density periodicity bariyerinde park edilmelidir.
