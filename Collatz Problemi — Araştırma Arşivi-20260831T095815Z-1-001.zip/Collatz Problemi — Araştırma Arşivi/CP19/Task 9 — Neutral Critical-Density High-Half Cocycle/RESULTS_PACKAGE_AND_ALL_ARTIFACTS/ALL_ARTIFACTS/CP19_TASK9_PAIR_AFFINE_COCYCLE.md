# CP19 TASK 9 — PAIR AFFINE COCYCLE

The pure-neutral word is naturally pair-coded.

For pair index \(r\), put
\[
\theta_r=\{r\gamma\},
\qquad
\gamma=2\alpha-3,
\qquad
\delta=2-\alpha.
\]

The exact pair types are
\[
P_1=(2,1),\quad
P_2=(1,2),\quad
P_3=(1,3),
\]
selected on
\[
[0,\delta),\quad
[\delta,2\delta),\quad
[2\delta,1).
\]

For a two-step valuation pair \((a_0,a_1)\),
\[
2^{a_0+a_1}n_{\rm out}
=
9n_{\rm in}+3+2^{a_0}.
\]

Therefore the exact affine triples \((G,P,B)\) are
\[
\boxed{
P_1:(3,9,7),\qquad
P_2:(3,9,5),\qquad
P_3:(4,9,5).
}
\]

For affine triples
\[
X=(A_1,P_1,B_1),\qquad
Y=(A_2,P_2,B_2),
\]
meaning "first \(X\), then \(Y\)", composition is
\[
\boxed{
Y\circ X
=
(A_1+A_2,\,
P_2P_1,\,
P_2B_1+2^{A_1}B_2).
}
\]

For a shifted neutral block \(M(\phi,L)\), this gives the exact cocycle law
\[
\boxed{
M(\phi,L_1+L_2)
=
M(\phi+\!L_1\gamma,L_2)
\circ
M(\phi,L_1),
}
\]
with phase interpreted modulo one at pair level.

At doubling,
\[
\theta_{2r}=\{2\theta_r\}.
\]

This pair cocycle is exact and low-symbolic-complexity, but the affine
numerator accumulated over \(r\) pairs has \(\Theta(F_{2r})\) bits. The
symbolic three-state driver therefore does not by itself compress the
critical high-half arithmetic.
