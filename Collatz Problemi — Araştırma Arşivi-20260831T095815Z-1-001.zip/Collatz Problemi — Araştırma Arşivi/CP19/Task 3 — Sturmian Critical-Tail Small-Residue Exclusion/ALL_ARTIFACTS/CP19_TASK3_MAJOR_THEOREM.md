# CP19 TASK 3 — MAJOR LOAD-BEARING THEOREM CANDIDATE

## Status

\[
\boxed{\textbf{[MAJOR LOAD-BEARING THEOREM CANDIDATE — INDEPENDENT AUDIT REQUIRED]}}
\]

Not frozen yet.

## Theorem

For a positive injective odd-only Syracuse orbit segment that follows the exact critical Beatty word for `r>=16` consecutive odd steps,
\[
\boxed{
n_u\ge
\frac{r^{1+\log_2 3}}{24\log_2 r}-\frac{2r}{3}.
}
\]

The proof uses only:

1. exact Sturmian factor complexity `p(ell)=ell+1`;
2. exact valuation cylinders modulo `2^{A+1}`;
3. balanced total valuation `A>=floor(alpha ell)`;
4. injectivity of the states;
5. the exact real critical-block ceiling `n_j<2n_u+4r/3`.

Choosing `ell=floor(log2 r)` converts these facts into the displayed polynomial lower bound.

## Construction-A consequence

Construction A has `r_m/u_m -> 1`, while under a positive fixed realization Task 2 proved
\[
n_{u_m}=O_{n_0}(u_m\log u_m\log\log u_m).
\]
The theorem forces
\[
n_{u_m}=\Omega(u_m^{1+\log_2 3}/\log u_m),
\]
a contradiction. Hence
\[
\boxed{x_A\notin\mathbb Z_{>0}}.
\]
Together with Task 1:
\[
\boxed{x_A\notin\mathbb Z}.
\]

## Scope warning

This does not prove a universal lower bound for `M(u,r)` and does not give Side B. High-turnover Task-5 branches remain untouched.
