#!/usr/bin/env python3
from fractions import Fraction
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q; hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def g(k):return F(k+1)-F(k)
def v2(x):return (x&-x).bit_length()-1

import math
from fractions import Fraction

def rho_direct(u,r):
    A=B=0; P=1
    for k in range(u,u+r):
        a=g(k); B=3*B+(1<<A); A+=a; P*=3
    mod=1<<(A+1)
    return (((1<<A)-B)*pow(P,-1,mod))%mod,A,mod

def orbit(n,u,r):
    states=[n]
    for k in range(u,u+r):
        z=3*n+1
        if v2(z)!=g(k): return None
        n=z>>g(k); states.append(n)
    return states

def exact_bound(r,ell):
    a=F(ell)
    return Fraction((1<<a)*(r-2*ell),ell+1)-Fraction(2*r,3)

def check_small():
    tests=0
    for u in range(40):
      for r in range(4,21):
        rho,A,mod=rho_direct(u,r)
        for q in range(5):
          n=rho+q*mod; states=orbit(n,u,r); assert states is not None
          if len(set(states))!=len(states): continue
          for ell in range(1,r//2+1):
            if 2*ell>=r: continue
            assert Fraction(n,1)>=exact_bound(r,ell),(u,r,q,n,ell,exact_bound(r,ell))
          tests+=1
    return tests

def factor_count(ell):
    seen=set()
    for u in range(200000):
        seen.add(tuple(g(u+j) for j in range(ell)))
        if len(seen)==ell+1: break
    assert len(seen)==ell+1
    totals={sum(w) for w in seen}
    assert totals.issubset({F(ell),F(ell)+1})
    return len(seen)

def main():
    for ell in [2,3,4,5,8,13,21]: factor_count(ell)
    t=check_small()
    print('CP19 TASK3 MAJOR PROOF CHECK: OK; injective witnesses tested =',t)
if __name__=='__main__':main()
