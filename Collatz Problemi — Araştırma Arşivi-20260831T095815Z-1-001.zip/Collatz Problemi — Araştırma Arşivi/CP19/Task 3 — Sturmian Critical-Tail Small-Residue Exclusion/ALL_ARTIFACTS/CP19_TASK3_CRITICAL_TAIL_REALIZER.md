# CP19 TASK 3 — CRITICAL-TAIL REALIZER

For phase `u`, put
\[
G_j=F_{u+j}-F_u.
\]
The infinite pure-critical valuation tail is
\[
g_u,g_{u+1},\ldots
\]
and its unique 2-adic realizer is
\[
\boxed{
x_u^{\rm crit}=-\sum_{j\ge0}\frac{2^{G_j}}{3^{j+1}}
}
\]
in `Z_2`.

The series converges 2-adically because `G_j >= j -> infinity`.

For the length-r prefix, let
\[
q_r=-\sum_{j<r}\frac{2^{G_j}}{3^{j+1}}=-B_{\rm crit}/3^r.
\]
The exact finite cylinder is
\[
\rho_r\equiv q_r+2^{G_r}\pmod {2^{G_r+1}}.
\]
The infinite tail beyond `r` begins with a term of exact 2-adic valuation `G_r`, and its odd coefficient is congruent to `-1` modulo 2. Therefore
\[
\boxed{x_u^{\rm crit}\equiv \rho_r\pmod {2^{G_r+1}}.}
\]
Thus `M(u,r)` is exactly the canonical positive truncation of `x_u^crit` at depth `G_r+1`.

## New consequence from Task 3

A shifted pure-critical tail cannot be realized forever by one positive ordinary integer. Indeed, if a positive ordinary integer realized arbitrarily long critical prefixes, its odd-only trajectory is aperiodic/injective and the Critical Segment Packing Theorem would force its fixed starting value to exceed
\[
\frac{r^{1+\log_2 3}}{24\log_2 r}-\frac{2r}{3}
\]
for every large `r`, which diverges.

This does **not** classify the 2-adic realizer as rational/irrational or positive/negative in the real sense. It only excludes a positive ordinary integer.
