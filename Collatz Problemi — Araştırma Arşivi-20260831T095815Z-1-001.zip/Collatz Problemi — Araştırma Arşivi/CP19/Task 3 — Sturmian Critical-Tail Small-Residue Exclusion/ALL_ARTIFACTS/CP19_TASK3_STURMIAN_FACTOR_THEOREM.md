# CP19 TASK 3 — STURMIAN FACTOR / CRITICAL SEGMENT PACKING THEOREM

## Theorem (exact finite form)

Let a positive odd-only Syracuse orbit contain an **injective** critical segment
\[
n_0,n_1,\ldots,n_r
\]
whose valuations are
\[
a_j=g_{u+j}=F_{u+j+1}-F_{u+j}
\]
for `0<=j<r`.

For any integer `ell` with
\[
1\le \ell<r/2,
\]
put
\[
a_{min}(\ell)=\lfloor \alpha\ell\rfloor,
\qquad \alpha=\log_2 3.
\]
Then the starting state `N=n_0` obeys
\[
\boxed{
N\ge
2^{\lfloor\alpha\ell\rfloor}
\frac{r-2\ell}{\ell+1}
-\frac{2r}{3}.
}
\]

## Proof

### 1. Critical factors have only `ell+1` types

Write
\[
b_k=g_k-1.
\]
Then `b` is the lower mechanical word of irrational slope
\[
\beta=\alpha-1.
\]
For a variable intercept `theta`, a length-`ell` factor can change only when `theta` crosses one of
\[
\{-j\beta\}\pmod1,
\qquad 0\le j\le\ell.
\]
Because `beta` is irrational, these are `ell+1` distinct points. The factor is constant between consecutive points and changes at every boundary. Hence exactly `ell+1` length-`ell` factors occur.

### 2. Each factor has a deep exact cylinder

For any such factor `W`, its total valuation is
\[
A(W)=F_{v+\ell}-F_v
=\lfloor\alpha\ell+\{\alpha v\}\rfloor
\in\{\lfloor\alpha\ell\rfloor,\lfloor\alpha\ell\rfloor+1\}.
\]
The exact valuation-word cylinder is one residue class modulo
\[
2^{A(W)+1},
\]
so its spacing is at least
\[
Q_{min}=2^{\lfloor\alpha\ell\rfloor+1}.
\]
Therefore, below any real height `H`, one factor contributes at most
\[
H/Q_{min}+1
\]
positive integer states.

### 3. A critical block stays in a controlled real interval

Let
\[
G_j=F_{u+j}-F_u,
\qquad
c_j=2^{G_j}/3^j.
\]
Since
\[
G_j=\alpha j+\{\alpha u\}-\{\alpha(u+j)\},
\]
we have
\[
1/2<c_j<2.
\]
The exact affine formula divided by `3^j` gives
\[
c_j n_j=N+S_j,
\qquad
S_j=\sum_{i<j}\frac{c_i}{3}.
\]
Since `c_i<2`,
\[
S_j<2j/3,
\]
and because `c_j>1/2`,
\[
\boxed{n_j<2N+4j/3\le 2N+4r/3.}
\]
Set
\[
H=2N+4r/3.
\]

### 4. Packing the injective states

For each
\[
0\le j\le r-\ell,
\]
the distinct state `n_j` realizes one of the `ell+1` critical length-`ell` factors. Hence there are `r-ell+1` distinct positive states below `H` lying in the union of those `ell+1` exact cylinders. Thus
\[
r-\ell+1
\le
(\ell+1)\left(\frac{H}{2^{\lfloor\alpha\ell\rfloor+1}}+1\right).
\]
Rearranging and substituting `H=2N+4r/3` yields exactly
\[
N\ge
2^{\lfloor\alpha\ell\rfloor}
\frac{r-2\ell}{\ell+1}-\frac{2r}{3}.
\]
QED.

## Closed asymptotic corollary

Choose
\[
\ell=\lfloor\log_2 r\rfloor.
\]
For `r>=16`,
\[
2^{\lfloor\alpha\ell\rfloor}\ge r^\alpha/6,
\qquad
\frac{r-2\ell}{\ell+1}\ge\frac{r}{4\log_2 r}.
\]
Therefore
\[
\boxed{
N\ge
\frac{r^{1+\log_2 3}}{24\log_2 r}
-\frac{2r}{3}.
}
\]

This is a **state lower bound for injective critical realizations**, not a universal lower bound on the canonical minimum `M(u,r)`. Small finite-cylinder representatives may still exist if their finite trajectories are non-injective.
