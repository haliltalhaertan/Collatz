#!/usr/bin/env python3
from fractions import Fraction
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q; hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def g(k):return F(k+1)-F(k)
def v2(x):return (x&-x).bit_length()-1

def distinct_factors(ell,max_scan=1000000):
    seen={}
    for u in range(max_scan):
        w=tuple(g(u+j) for j in range(ell))
        seen.setdefault(w,u)
        if len(seen)==ell+1:return seen
    raise RuntimeError('factor collection incomplete')
if __name__=='__main__':
    for ell in [4,8,16,32]:
        s=distinct_factors(ell); assert len(s)==ell+1
        totals={sum(w) for w in s}; print(ell,len(s),sorted(totals))
