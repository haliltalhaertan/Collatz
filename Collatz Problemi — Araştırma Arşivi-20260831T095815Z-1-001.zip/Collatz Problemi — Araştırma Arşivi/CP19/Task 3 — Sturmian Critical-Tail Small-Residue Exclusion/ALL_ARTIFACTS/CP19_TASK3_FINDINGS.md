# COLLATZ CP19 — TASK 3 FINDINGS
## Sturmian Critical-Tail Small-Residue Exclusion

## Final strategic verdict

\[
\boxed{\textbf{E — [NEW GENERAL SPARSE-CRITICAL THEOREM]}}
\]

and therefore

\[
\boxed{\textbf{[MAJOR LOAD-BEARING THEOREM CANDIDATE — AUDIT REQUIRED]}}.
\]

Construction A is rigorously excluded from positive ordinary LEVEL 3 **provided the new packing theorem passes independent adversarial audit**.

## What happened to the original M(u,r) target?

The universal statement
\[
M(u,r)\ge2^{cr}
\]
was **not proved**. No infinite small-residue collapse family was found either.

Instead, the successful lower bound applies to the **actual start of an injective critical orbit segment**, which is exactly what LEVEL 3 needs.

This distinction is essential: a finite critical cylinder may have a small positive canonical witness if that witness later repeats. CP18 finite-satisfiability is therefore not contradicted.

## New theorem

If `N` begins a positive injective critical block of length `r`, then for every `1<=ell<r/2`,
\[
\boxed{
N\ge
2^{\lfloor\alpha\ell\rfloor}\frac{r-2\ell}{\ell+1}-\frac{2r}{3}.
}
\]
Choosing `ell=floor(log2 r)` gives, for `r>=16`,
\[
\boxed{
N\ge
\frac{r^{1+\log_2 3}}{24\log_2 r}-\frac{2r}{3}.
}
\]

## Why the theorem works

A length-`ell` critical word has only `ell+1` possible Sturmian factor types. Each type can start only in one residue class with spacing at least
\[
2^{\lfloor\alpha\ell\rfloor+1}.
\]
During a critical block all states stay below
\[
2N+4r/3.
\]
But injectivity demands `r-ell+1` distinct states. Packing that many distinct states into only `ell+1` sparse arithmetic progressions forces `N` large.

## Construction A collision

Construction A has
\[
R_m/u_m\to1.
\]
Thus the new theorem forces
\[
n_{u_m}=\Omega(u_m^{1+\alpha}/\log u_m).
\]
Task 2 under a fixed positive realizer proved
\[
n_{u_m}=O_{n_0}(u_m\log u_m\log\log u_m).
\]
Since
\[
\frac{u_m^\alpha}{(\log u_m)^2\log\log u_m}\to\infty,
\]
the two are incompatible. Hence
\[
\boxed{x_A\notin\mathbb Z_{>0}}.
\]
Task 1 had already excluded zero and negative ordinary integers, so
\[
\boxed{x_A\notin\mathbb Z}.
\]

## Required claim table

| Claim | Status | Exact evidence |
|---|---|---|
| Sturmian factor count `ell+1` | `[PROVED]` | intercept partition by `ell+1` irrational rotation boundaries |
| Critical-tail inverse-limit identity | `[EXACT]` | 2-adic series + finite-cylinder congruence |
| Adjacent-factor exact jump formula | `[EXACT]` | single `12<->21` exchange changes one B-term |
| Universal small-residue collapse exists? | `[OPEN]` | no infinite family found |
| Universal `M>=2^{cr}`? | `[OPEN]` | not needed for final theorem |
| Universal polynomial-deficit bound? | `[OPEN]` | finite evidence only through r=16384 |
| Continued-fraction scales anomalous? | `[CERTIFIED NUM: NO COLLAPSE FOUND]` | certified CF prefix; not load-bearing |
| Construction-A `Delta_m` growth | `[CERTIFIED NUM]` | Task2/Task3 CSV |
| Construction-A `M_m` superpolynomial? | `[OPEN AS M STATEMENT]` | bypassed by injective-state theorem |
| Task-2 Archimedean collision closes? | `[PROVED CANDIDATE] YES` | new lower + frozen upper |
| Construction A positive LEVEL 3 excluded? | `[NEW EXACT EXCLUSION CANDIDATE] YES` | subject to independent audit |
| General sparse-critical class excluded? | `[PROVED CANDIDATE] YES` | delta(1+alpha)>kappa criterion |
| Side B? | **NO** | high-turnover regimes untouched |

## Ne denedik?

Critical boşlukların başındaki minimum sayının neden hep çok büyük kaldığını anlamaya çalıştık.

## Küçük residue çökmesi bulduk mu?

Hayır; fakat daha önemlisi artık `M`'nin hiç çökmeyeceğini kanıtlamak zorunda değiliz. Küçük bir finite witness varsa bile, uzun injective critical orbit onu kullanamıyor.

## Hesap mı, teorem mi?

Ana yeni sonuç theorem-level bir sayma argümanı. Büyük exhaustive numerikler yalnız destekleyici.

## Construction A artık imkânsız mı?

Yeni proof doğruysa evet: bir fixed positive ordinary integer Construction A'yı sonsuza kadar gerçekleştiremez.

## Bu Collatz'ın ne kadarını kapatıyor?

Yalnız Construction A'yı ve benzer uzun-critical-gap sparse family'leri. Task-9 high-turnover branch'leri hâlâ açık. Bu Side B değildir.

## Sıradaki en yüksek bilgi değerli soru ne?

Önce bağımsız adversarial audit. Audit geçmeden Task 4'e inşa yapılmamalı. Audit geçerse sonraki soru: Task-5 uyumlu genel path'lerin zorunlu olarak bu tür düşük-complexity/costly interval'ler içerip içermediği.
