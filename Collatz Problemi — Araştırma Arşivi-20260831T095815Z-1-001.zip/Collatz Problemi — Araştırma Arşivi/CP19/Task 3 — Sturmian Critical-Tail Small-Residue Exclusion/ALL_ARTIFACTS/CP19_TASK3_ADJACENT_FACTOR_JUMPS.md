# CP19 TASK 3 — ADJACENT FACTOR JUMPS

Let a length-r valuation word contain `(1,2)` at positions `p,p+1`, and let
\[
H=A_p
\]
be the cumulative valuation before position `p`. Replace that pair by `(2,1)`. The total valuation `A` is unchanged.

Only the `j=p+1` term of
\[
B=\sum_{j=0}^{r-1}3^{r-1-j}2^{A_j}
\]
changes, so exactly
\[
\boxed{
B_{21}-B_{12}=3^{r-p-2}2^{H+1}.
}
\]
For the same modulus `2^{A+1}`,
\[
\boxed{
\rho_{21}-\rho_{12}
\equiv
-2^{H+1}3^{-p-2}
\pmod {2^{A+1}}.
}
\]
The reverse exchange changes the sign.

For the lower mechanical word of irrational slope `beta=log2(3/2)`, the length-r factor changes only at the `r+1` intercept boundaries `{-j beta}`. Crossing an interior boundary changes two adjacent coding symbols by `01 <-> 10`, hence the critical valuations by `12 <-> 21`. The two endpoint boundaries account for the two possible total-valuation groups.

## Strategic verdict

The jump formula is `[EXACT]`, but it does not by itself give an ordinary minimum-spacing theorem: the odd factor `3^{-p-2}` can wrap around the power-of-two modulus. This route is not load-bearing in the final proof.
