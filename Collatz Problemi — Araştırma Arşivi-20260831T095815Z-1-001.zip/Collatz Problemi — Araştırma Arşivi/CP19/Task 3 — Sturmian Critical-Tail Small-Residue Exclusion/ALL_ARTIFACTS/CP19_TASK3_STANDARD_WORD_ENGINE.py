#!/usr/bin/env python3
from fractions import Fraction
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q; hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def g(k):return F(k+1)-F(k)
def v2(x):return (x&-x).bit_length()-1

# Certified CF prefix for beta=log2(3/2) from the exact rational bracket.
CERTIFIED_CF=[0,1,1,2,2,3,1,5,2,23,2,2]

def affine(word):
    r=A=B=0
    for a in word:
        B=3*B+(1<<A); A+=a; r+=1
    return r,A,B

def compose(U,V):
    rU,AU,BU=U; rV,AV,BV=V
    return rU+rV,AU+AV,pow(3,rV)*BU+(1<<AU)*BV

def check_compose():
    W1=(1,2,1); W2=(2,1)
    assert compose(affine(W1),affine(W2))==affine(W1+W2)
if __name__=='__main__':
    check_compose(); print('AFFINE MONOID CHECK: OK'); print(CERTIFIED_CF)
