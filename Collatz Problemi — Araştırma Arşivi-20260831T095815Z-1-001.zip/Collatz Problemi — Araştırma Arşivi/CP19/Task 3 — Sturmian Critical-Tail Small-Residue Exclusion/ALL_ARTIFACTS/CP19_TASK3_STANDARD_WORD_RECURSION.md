# CP19 TASK 3 — STANDARD WORD / AFFINE RECURSION

Let
\[
\beta=\log_2(3/2).
\]
The exact rational bracket inherited from CP19 Task 1 certifies the common continued-fraction prefix
\[
\boxed{[0;1,1,2,2,3,1,5,2,23,2,2,\ldots]}.
\]
The next partial quotient is not certified by that bracket and is not used.

For any valuation block `W`, store
\[
Q(W)=(r,A,B)
\]
with
\[
2^A n_{out}=3^r n_{in}+B.
\]
For concatenation `UV`, exact composition is
\[
\boxed{
Q(UV)=
(r_U+r_V,\ A_U+A_V,\ 3^{r_V}B_U+2^{A_U}B_V).
}
\]
This was independently checked against direct composition on short words.

Standard/semistandard Sturmian recursions can therefore be propagated using this affine monoid without replaying every Syracuse state.

## Task-3 outcome

No continued-fraction collapse family was found in the certified finite scales. However, the final Construction-A exclusion does not rely on standard-word asymptotics: a simpler factor-complexity packing theorem supersedes this route.
