# CP19 TASK 3 — GENERAL SPARSE-CRITICAL EXCLUSION THEOREM

## General critical-segment lower theorem

Every positive injective odd-only Syracuse orbit segment of critical length `r>=16` satisfies
\[
\boxed{
n_u\ge
\frac{r^{1+\log_2 3}}{24\log_2 r}-\frac{2r}{3}.
}
\]

## General sparse-gap corollary

Consider a positive injective orbit with critical gaps `(u_m,r_m)` and suppose
\[
r_m\ge u_m^\delta
\]
eventually for some `delta>0`, while along those starts
\[
n_{u_m}=O\bigl(u_m^\kappa L(u_m)\bigr)
\]
where `L(u)=u^{o(1)}` is subpolynomial.

The critical lower bound is
\[
n_{u_m}\ge
u_m^{\delta(1+\alpha)-o(1)}.
\]
Therefore such an orbit is impossible whenever
\[
\boxed{\delta(1+\alpha)>\kappa.}
\]

Construction A has `delta=1` and the Task-2 upper bound has `kappa=1`, so the inequality is strict because `alpha=log2 3>0`.

## Scope

This is a genuine general sparse-critical family theorem. It does not say that Task 5 forces such gaps. Task 9 explicitly allows high-turnover paths with no long critical intervals. Therefore this theorem is not Side B.
