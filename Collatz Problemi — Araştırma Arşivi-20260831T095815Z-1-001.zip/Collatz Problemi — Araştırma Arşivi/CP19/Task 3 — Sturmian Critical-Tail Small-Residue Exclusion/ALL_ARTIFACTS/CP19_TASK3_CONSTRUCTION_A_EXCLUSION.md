# CP19 TASK 3 — CONSTRUCTION-A LOWER BOUND AND COLLISION

Assume for contradiction that the exact Construction-A inverse-limit realizer is one positive ordinary integer `n0`.

## 1. The orbit is injective

Construction A has
\[
A_N/N\to\alpha=\log_2 3,
\]
because its defect count is `o(N)`. If an odd state repeated, deterministic Syracuse dynamics would make the later valuation sequence periodic, whose mean valuation would be rational. This contradicts the irrational limiting mean `alpha`.

Thus every Construction-A critical gap is an injective critical segment.

## 2. Critical-gap state lower bound

For a gap of length `R_m>=16`, the Task-3 packing theorem gives
\[
\boxed{
n_{u_m}\ge
\frac{R_m^{1+\alpha}}{24\log_2 R_m}-\frac{2R_m}{3}.
}
\]

## 3. Construction-A geometry

The frozen schedule gives
\[
R_m/u_m\to1.
\]
Hence eventually `R_m>=u_m/2`, and the lower bound is
\[
n_{u_m}=\Omega\!\left(\frac{u_m^{1+\alpha}}{\log u_m}\right).
\]

## 4. Task-2 upper bound

Under the same positive-realization assumption, CP19 Task 2 proved
\[
n_k=O_{n_0}(k\log k\log\log k)
\]
with an explicit quantitative bound.
Therefore
\[
n_{u_m}=O_{n_0}(u_m\log u_m\log\log u_m).
\]

## 5. Collision

The ratio of the lower scale to the upper scale is
\[
\frac{u_m^{1+\alpha}/\log u_m}
{u_m\log u_m\log\log u_m}
=
\frac{u_m^\alpha}{(\log u_m)^2\log\log u_m}
\to\infty.
\]
No fixed `n0`-dependent constant can survive this ratio.

Thus
\[
\boxed{x_A\notin\mathbb Z_{>0}.}
\]

CP19 Task 1 already proved `x_A != 0` and `x_A` is not a negative ordinary integer. Therefore
\[
\boxed{x_A\notin\mathbb Z.}
\]

This is the first exact LEVEL-3 exclusion in this branch for the explicit nonperiodic Construction-A valuation sequence. It is **not Side B** and does not exclude the high-turnover Task-9 families.
