#!/usr/bin/env python3
from fractions import Fraction
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q; hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def g(k):return F(k+1)-F(k)
def v2(x):return (x&-x).bit_length()-1

def rho_lift(u,r):
    rho=1; y=1; A=0; P=1
    for k in range(u,u+r):
        a=g(k); found=None
        for lam in range(1<<a):
            yp=y+2*lam*P; z=3*yp+1
            if v2(z)==a:
                if found is not None: raise RuntimeError('nonunique')
                found=(lam,z>>a)
        if found is None: raise RuntimeError('no lift')
        lam,y=found; rho += lam<<(A+1); A+=a; P*=3
    return rho,A
if __name__=='__main__':
    for u,r in [(53,41),(95,77),(173,143),(1095,954)]:
        M,A=rho_lift(u,r); print(u,r,A,M.bit_length(),M&((1<<64)-1))
