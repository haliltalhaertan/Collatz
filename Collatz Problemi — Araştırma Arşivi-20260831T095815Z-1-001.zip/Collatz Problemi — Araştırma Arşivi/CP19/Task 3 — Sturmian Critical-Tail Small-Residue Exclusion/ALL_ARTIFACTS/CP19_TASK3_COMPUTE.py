#!/usr/bin/env python3
from fractions import Fraction
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q; hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def g(k):return F(k+1)-F(k)
def v2(x):return (x&-x).bit_length()-1

from fractions import Fraction
from CP19_TASK3_RESIDUE_ENGINE_A import rho_direct
from CP19_TASK3_RESIDUE_ENGINE_B import rho_lift

def main():
    for u,r in [(53,41),(95,77),(173,143),(317,269),(1095,954)]:
        assert rho_direct(u,r)==rho_lift(u,r)
    print('CP19 TASK3 RESIDUE CROSS-CHECKS: OK')
if __name__=='__main__':main()
