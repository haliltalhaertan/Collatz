# CP19 TASK 3 — INDEPENDENT ADVERSARIAL AUDIT PROMPT

Audit the attached CP19 Task 3 package zero-trust. Your job is to BREAK the new theorem, not to confirm it.

Main candidate:
\[
n_u\ge r^{1+\log_2 3}/(24\log_2 r)-2r/3
\]
for every positive injective odd-only Syracuse segment of length `r>=16` whose valuation word equals a length-r factor of the critical Beatty word.

Then audit the Construction-A exclusion obtained by combining this with Task-2 upper bound and `R_m/u_m->1`.

Check especially:

1. Is `b_k=g_k-1` really a Sturmian mechanical word with exactly `ell+1` factors?
2. Does every length-ell factor have total valuation at least `floor(alpha ell)`?
3. Does a finite valuation word really restrict positive starts to one residue class mod `2^{A+1}`? Is the `+1` depth correct?
4. Is the count `<= H/Q+1` applied to the right set, with no hidden overlap/phase issue?
5. Does injectivity really supply `r-ell+1` distinct states? Is Construction A injective if positively realized?
6. Is the real critical-block ceiling `n_j<2N+4r/3` correct for every phase/intercept?
7. Re-derive the algebra leading to the exact finite bound and the constant 24.
8. Check the use of `ell=floor(log2 r)` for every `r>=16`.
9. Check that Construction-A lower and Task-2 upper are applied to the SAME states `n_{u_m}` and indexing of gaps is consistent.
10. Check that the unknown fixed constant depending on `n0` is legitimately beaten asymptotically.
11. Check for redundancy/contradiction with CP18 finite-satisfiability: the theorem is about injective witnesses, not `M(u,r)` itself.
12. Try explicit small counterexamples by brute force.

Required verdict:
- PROOF VALID
- FIXABLE GAP
- GAP
- FALSE / COUNTEREXAMPLE

Do not promote to Side B. High-turnover Task-5 branches are outside the theorem.
