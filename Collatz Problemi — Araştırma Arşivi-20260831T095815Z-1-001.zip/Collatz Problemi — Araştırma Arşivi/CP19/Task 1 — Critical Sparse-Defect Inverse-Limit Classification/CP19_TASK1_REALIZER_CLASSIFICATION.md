# CP19 TASK 1 — CONSTRUCTION-A REALIZER CLASSIFICATION

## 1. Object

Let `w^A=(a_0,a_1,...)` be the frozen CP18 Task-9 Construction A defined in `CP19_TASK1_CONSTRUCTION_A_DEFINITION.md`.

For every finite prefix length `R`, let

\[
2^{A_R}n_R=3^R n_0+B_R,
\qquad
B_R=\sum_{j<R}3^{R-1-j}2^{A_j}.
\]

The unique exact odd start cylinder is

\[
\boxed{
 n_0\equiv\rho_R
 =3^{-R}(2^{A_R}-B_R)
 \pmod{2^{A_R+1}}.
}
\]

The cylinders are nested and `A_R>=R`, so there is one unique

\[
\boxed{x_A\in\mathbb Z_2}
\]

satisfying all prefixes.

Equivalently, with

\[
X_R=\sum_{j<R}2^{D_j},
\]

Task-6 normalization gives

\[
q_R=-X_R/3=-B_R/3^R
\]

and

\[
q_R\to x_A\quad\text{in }\mathbb Z_2.
\]

Moreover

\[
\rho_R\equiv q_R+2^{A_R}\pmod{2^{A_R+1}},
\]

because `(x_A-q_R)/2^{A_R}` is an odd 2-adic unit.

`CP19_TASK1_REALIZER_A.py` and `CP19_TASK1_REALIZER_B.py` independently reproduce this relation at `R=10000` exactly.

## 2. Exact deep computation

At

\[
R=10^6,
\]

Construction A has

\[
F_R=1,584,962,
\qquad s_R=36,
\qquad A_R=1,584,926,
\]

\[
L_R=19,
\qquad E_R=17.
\]

The canonical truncation has

- modulus depth: **1,584,927 bits**;
- `rho_R` bit length: **1,584,926**;
- popcount: **792,063**;
- low 64 bits: **4838348622506491903**;
- SHA256 of the fixed-length little-endian truncation:  
  `533c71db59ed620ef4eda71c1c9d8416b60380cebbff625254492c21026c3e72`.

The first `10^6` valuation extensions contain

\[
\boxed{646,277}
\]

nonzero canonical lifts, although Construction A has only 36 defect sites.

The longest observed consecutive zero-lift run is only

\[
\boxed{12}.
\]

The last observed nonzero lift in this computation is at `k=999999`.

These are `[CERTIFIED NUM]`; they do not prove infinitely many future lifts.

## 3. Ordinary-integer tests

### Zero

`x_A` is an odd 2-adic realizer, so

\[
\boxed{x_A\ne0.}
\]

Status: `[PROVED]`.

### Negative ordinary integer

`CP19_TASK1_SPARSE_DEFECT_THEOREM.md` proves

\[
X_R\to\infty
\]

for Construction A and consequently

\[
\boxed{x_A\notin\mathbb Z_{<0}.}
\]

Status: `[PROVED]`.

### Positive ordinary integer

A nonnegative ordinary 2-adic integer is characterized by eventual constancy of the canonical truncations.

At `R<=10^6`, Construction A shows extensive continued lifting, but finite nonstabilization is not a theorem of future nonstabilization.

No exact recurrence was found that forces infinitely many future nonzero lifts.

Therefore

\[
\boxed{x_A\in\mathbb Z_{>0}\text{ remains OPEN}.}
\]

This is the central unresolved classification branch.

## 4. Rationality test

A rational 2-adic with odd denominator has an eventually periodic binary expansion.

Finite diagnostics on the `10^6` prefix found:

- no rational candidate with odd `q<=100000` and centered `|p|<2^64` modulo `2^512`;
- no binary period `p<=4096` on the exact bit window `[1,000,000,1,262,143]`.

These are only `[CERTIFIED NUM]` exclusions of small/simple rational forms.

They do not prove

\[
x_A\notin\mathbb Q\cap\mathbb Z_2.
\]

### Critical-density literature barrier

The odd-only valuation word has

\[
\frac{A_R}{R}\to\log_2 3
\]

because `s_R=O(log R)`. Its standard parity sequence therefore has one-density

\[
\boxed{
\frac{R}{A_R}\to\frac1{\log_2 3}=\frac{\ln2}{\ln3}.
}
\]

The valuation word is aperiodic: eventual periodicity would force `A_R/R` to converge to a rational period mean, contradicting the irrationality of `log_2 3`.

Known 3x+1 conjugacy results of López–Stoll exclude rational images of certain aperiodic parity vectors when the lower one-density is **strictly greater** than `ln2/ln3`. Construction A lies exactly at the equality boundary. Their work also identifies this equality as the necessary density for any hypothetical rational 2-adic with a non-cyclic trajectory.

Therefore the general density theorem does not classify `x_A`; doing so as rational/nonrational at this critical boundary intersects the still-open Periodicity-Conjecture territory.

## 5. Negative integer pattern check

For a negative integer `-C`, the canonical truncations would eventually have

\[
\rho_R=2^{A_R+1}-C.
\]

The centered sign of the exact Construction-A truncations is already nonmonotone:

- `R=1000`: negative-centered;
- `R=10000`: negative-centered;
- `R=100000`: negative-centered;
- `R=1000000`: positive-centered.

The theorem in §3, rather than this finite observation, is what excludes negative integers.

## 6. Critical-word calibration

For the defect-free critical word

\[
a_k^*=g_k,
\qquad s_k=0,
\]

the same computation at `R=10^6` gives a highly nontrivial binary truncation with hundreds of thousands of nonzero lifts. Its carry mass grows at least linearly because every term `2^{D_k}` lies between `1/2` and `1`.

Thus its realizer is also nonzero and not a negative ordinary integer.

Positive ordinary/rational classification of the critical realizer was **not** solved here. This calibration reinforces that the hard part is the critical-density positive/rational boundary, not merely the sparse defects.

## 7. Same envelope, different realizers

Three exact schedules were compared to `R=10^6`:

| schedule | defects | `A_R` | `s_R` | `E_R` | low64 | SHA256 |
|---|---:|---:|---:|---:|---:|---|
| frozen FIRST | 36 | 1,584,926 | 36 | 17 | 4838348622506491903 | `533c71db...c3e72` |
| SECOND phase-one | 36 | 1,584,926 | 36 | 17 | 2793530590232575 | `c8bf725c...77971` |
| alternating FIRST/SECOND | 36 | 1,584,926 | 36 | 17 | 15434686520576966655 | `ab9aeac6...b72f8` |

Thus the same defect-count / `E` envelope does **not** determine the 2-adic realizer value.

This is an exact high-information negative result about coarse occupation data. It does not yet prove that the three realizers have different ordinary/rational **classes**.

## 8. Final classification

Using the categories requested in Task 1:

- **A. positive ordinary integer:** `[OPEN]`;
- **B. zero:** `[PROVED FALSE]`;
- **C. negative ordinary integer:** `[PROVED FALSE]`;
- **D. rational nonordinary 2-adic:** `[OPEN]`;
- **E. algebraic/structured nonordinary 2-adic:** `[OPEN]`;
- **F. genuinely nonperiodic/no simple closed form:** finite data strongly resemble this, but `[NOT PROVED]`.

Therefore there is no complete A–F classification theorem yet.

The rigorous classification statement is

\[
\boxed{
x_A\in\mathbb Z_2^\times\setminus\mathbb Z_{<0},}
\]

with positive-ordinary versus nonordinary/rational status unresolved.
