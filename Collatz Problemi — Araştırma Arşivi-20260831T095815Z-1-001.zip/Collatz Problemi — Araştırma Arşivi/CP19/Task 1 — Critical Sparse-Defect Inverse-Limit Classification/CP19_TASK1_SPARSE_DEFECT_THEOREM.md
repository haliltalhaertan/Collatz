# CP19 TASK 1 — DIVERGENT-CARRY NEGATIVE-INTEGER EXCLUSION

## Scope

This theorem is exact but **does not exclude positive ordinary integers**. It is therefore not Side B.

## Theorem 1 — general negative ordinary exclusion

Let an infinite positive valuation word have unique 2-adic realizer `x` and define

\[
X_R=\sum_{j<R}2^{D_j},
\qquad
D_j=A_j-j\log_2 3.
\]

The exact finite-prefix affine identity gives

\[
\frac{2^{A_R}}{3^R}n_R
=
 x+\frac{B_R}{3^R}
=
 x+\frac{X_R}{3}.
\]

If

\[
\boxed{X_R\to+\infty,}
\]

then

\[
\boxed{x\notin\mathbb Z_{<0}.}
\]

### Proof

Assume `x=-C` for an ordinary integer `C>=1`.

Starting from a negative odd integer, every finite odd-only Syracuse step remains negative, because

\[
3n+1<0
\]

for every negative odd `n`, and division by a positive power of two preserves the sign. Thus every ordinary state `n_R` is negative.

But the prefactor `2^{A_R}/3^R` is positive in the ordinary real ordering. Therefore the affine identity implies

\[
\operatorname{sign}(n_R)
=
\operatorname{sign}\left(-C+\frac{X_R}{3}\right).
\]

If `X_R->infinity`, the right-hand side is eventually positive, contradiction. ∎

## Theorem 2 — Construction A has divergent carry mass

For Construction A, after the fixed initial buffer the scheduled defect positions satisfy

\[
p_m=\text{first phase-one site at or after }\max(r_m,p_{m-1}+1),
\]

where

\[
r_m=\left\lceil\frac{2^m}{m+1}\right\rceil.
\]

For `m>=9`, the exact construction has

\[
p_m\in\{r_m,r_m+1\}.
\]

Also

\[
\frac{2^{m+1}}{m+2}-\frac{2^m}{m+1}
=
\frac{2^m m}{(m+1)(m+2)}.
\]

For `m>=2`, `(m+1)(m+2)<=4m^2`, hence

\[
r_{m+1}-r_m
\ge
\frac{2^m}{4m}-1.
\]

Combining the one-step phase adjustment with the ceiling error yields, for `m>=9`,

\[
\boxed{
p_{m+1}-p_m\ge\frac{2^{m-3}}m.}
\]

Between defects `p_m` and `p_{m+1}`, the cumulative defect has the constant value

\[
s_j=12+m
\]

(up to the endpoint convention, which changes at most one term).

Since

\[
D_j=-s_j-\{j\log_2 3\},
\]

we have

\[
2^{D_j}\ge 2^{-s_j-1}=2^{-m-13}.
\]

Therefore the contribution of the `m`-th long gap to `X` is at least

\[
\frac{2^{m-3}}m\,2^{-m-13}
=
\boxed{\frac1{2^{16}m}}.
\]

Summing over `m` gives a divergent harmonic lower bound:

\[
\boxed{X_R\to+\infty.}
\]

## Corollary — Construction A classification progress

Let `x_A` be the unique Construction-A inverse-limit realizer. Then

\[
\boxed{x_A\notin\mathbb Z_{<0}.}
\]

Also `x_A` is odd, hence `x_A!=0`.

Thus categories “zero” and “negative ordinary integer” are rigorously excluded.

The theorem does **not** decide whether

- `x_A` is a positive ordinary integer;
- `x_A` is a rational nonordinary 2-adic;
- `x_A` is irrational/algebraic/nonordinary.

Those are the remaining LEVEL-3/rationality questions.
