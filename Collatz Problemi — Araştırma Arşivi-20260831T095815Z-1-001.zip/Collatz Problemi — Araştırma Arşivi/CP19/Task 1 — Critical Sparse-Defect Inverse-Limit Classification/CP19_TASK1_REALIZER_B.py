#!/usr/bin/env python3
"""CP19 Task 1 — Implementation B.
Independent Task-6 q_R/series computation modulo 2^(A_R+1).
Intended as a proof-critical cross-check at moderate depth.
"""
import argparse, hashlib
from CP19_TASK1_REALIZER_A import valuation_word


def rho_via_q_series(N: int, mode: str = "first"):
    word, S, info, A = valuation_word(N, mode)
    bits = A + 1
    M = 1 << bits
    mask = M - 1
    inv3 = pow(3, -1, M)
    inv3pow = inv3
    qsum = 0
    A_j = 0
    for a in word:
        qsum = (qsum + ((1 << A_j) * inv3pow)) & mask
        A_j += a
        inv3pow = (inv3pow * inv3) & mask
    q_R = (-qsum) & mask
    # n0-q_R = 2^A*(odd 2-adic unit), so modulo 2^(A+1)
    # the extra unit contributes exactly the bit 2^A.
    rho = (q_R + (1 << A)) & mask
    return rho, q_R, A, word, S, info


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--N", type=int, default=10000)
    ap.add_argument("--mode", choices=["first", "second", "alternating"], default="first")
    args = ap.parse_args()
    rho, q, A, word, S, info = rho_via_q_series(args.N, args.mode)
    raw = rho.to_bytes((A + 8) // 8, "little")
    print({"N": args.N, "A": A, "defects": len(info), "rho_bits": rho.bit_length(),
           "low64": rho & ((1 << 64) - 1), "sha256_le": hashlib.sha256(raw).hexdigest(),
           "q_congruence_bits": A})

if __name__ == "__main__":
    main()
