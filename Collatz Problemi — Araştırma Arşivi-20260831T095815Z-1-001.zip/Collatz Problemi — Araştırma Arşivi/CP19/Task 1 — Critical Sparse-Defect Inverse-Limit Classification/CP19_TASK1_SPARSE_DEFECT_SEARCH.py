#!/usr/bin/env python3
"""CP19 Task 1 finite falsification search over microscopic defect choices.
This script never promotes finite stabilization plateaux to LEVEL-3 claims.
"""
import argparse, csv
from CP19_TASK1_REALIZER_A import rho_python, construction_a, F, L


def lift_stats(rho, N, S):
    A = 0; nonzero = 0; zero_run = 0; max_zero = 0; final_zero = 0
    for k in range(N):
        a = (F(k+1)-F(k)) - (1 if k in S else 0)
        lam = (rho >> (A+1)) & ((1 << a)-1)
        if lam:
            nonzero += 1; zero_run = 0
        else:
            zero_run += 1; max_zero = max(max_zero, zero_run)
        A += a
    final_zero = zero_run
    return nonzero, max_zero, final_zero


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--N", type=int, default=4096)
    ap.add_argument("--output", default="CP19_TASK1_SPARSE_SEARCH_REPRO.csv")
    args = ap.parse_args()
    rows = []
    for mode in ["first", "second", "alternating"]:
        rho, A, word, S, info = rho_python(args.N, mode)
        nz, mz, fz = lift_stats(rho, args.N, S)
        s = len(info)
        rows.append({"mode": mode, "N": args.N, "defects": s, "A_N": A,
                     "E_N": s-L(args.N), "rho_bits": rho.bit_length(), "popcount": rho.bit_count(),
                     "low64": rho & ((1<<64)-1), "nonzero_lifts": nz,
                     "max_zero_lift_run": mz, "final_zero_lift_run": fz,
                     "status": "CERTIFIED NUM / finite only"})
    with open(args.output, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    print(args.output)

if __name__ == "__main__":
    main()
