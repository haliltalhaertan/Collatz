# CP19 TASK 1 — CONSTRUCTION A EXACT DEFINITION

## Provenance

This file freezes the **operational** CP18 Task-9 low-turnover construction used by the frozen reproducer `CP18_TASK9_COMPUTE.py`.

The CP18 theorem text states the asymptotic construction as follows:

- `g_k = F_{k+1}-F_k in {1,2}`;
- `b_k = g_k-1`;
- choose sparse positive defects only at `b_k=1` locations;
- targets `r_m = ceil(2^m/(m+1))`;
- choose `p_m` as the first phase-one location at or after `max(r_m,p_{m-1}+1)`;
- finitely many additional initial +1 defects are allowed as normalization.

The frozen reproducer resolves that finite-normalization ambiguity exactly.

## Exact operational schedule

Let

\[
F_k=\lfloor k\log_2 3\rfloor,
\qquad
 g_k=F_{k+1}-F_k,
\qquad
 b_k=g_k-1\in\{0,1\}.
\]

### Stage 0 — fixed buffer

Set `buffer = 12`.

Starting at `k=0`, scan upward and choose the **first 12** indices with

\[
b_k=1.
\]

These are exactly

\[
\boxed{
1,3,5,6,8,10,11,13,15,17,18,20.
}
\]

Call the selected set `S` and let `prev=20`.

### Stage 1 — sparse schedule

For

\[
m=1,2,3,\ldots
\]

define

\[
\boxed{
r_m=\left\lceil\frac{2^m}{m+1}\right\rceil.}
\]

Let

\[
q_m=\max(r_m,\,prev+1).
\]

Then define `p_m` to be the **first** integer `k>=q_m` satisfying

\[
b_k=1.
\]

Insert `p_m` into `S` and replace `prev` by `p_m`.

There is no random tie-breaking and no optimization step.

### Defect word

Define

\[
d_k=
\begin{cases}
1,&k\in S,\\
0,&k\notin S.
\end{cases}
\]

and

\[
\boxed{a_k=g_k-d_k.}
\]

Because every selected site has `b_k=1`, hence `g_k=2`, each defect simply changes the critical valuation from `2` to `1`. Therefore

\[
a_k\in\{1,2\}
\]

for all `k` and every valuation is positive.

The cumulative defect is

\[
s_k=F_k-A_k=\#\{t\in S:t<k\}.
\]

Thus

\[
E_k=s_k-L_k.
\]

## Exact schedule through R=10^6

The defect positions below `10^6` are

\[
\boxed{
\begin{aligned}
&1,3,5,6,8,10,11,13,15,17,18,20,22,23,25,27,29,30,32,34,\\
&52,94,172,316,586,1094,2049,3856,7282,13799,26215,49933,\\
&95327,182362,349526,671089.
\end{aligned}
}
\]

There are exactly **36** defects below `10^6`.

The full machine-readable schedule is in `CP19_TASK1_DEFECT_TIMES.csv`.

## Asymptotic schedule theorem

Every pair of consecutive phase sites contains at least one `b=1` location, since

\[
F_{k+2}-F_k\in\{3,4\}
\]

and therefore

\[
b_k+b_{k+1}\in\{1,2\}.
\]

Consequently the selected `p_m` is at most one position after the active target once `r_m` dominates the previous-defect constraint.

Since

\[
\frac{2^{m+1}}{m+2}-\frac{2^m}{m+1}
=
\frac{2^m m}{(m+1)(m+2)},
\]

the target gaps grow like `2^m/m`. After the finite transient,

\[
\boxed{p_m=\frac{2^m}{m+1}+O(1).}
\]

Inverting gives

\[
\boxed{
\#\{t\in S:t<k\}
=
\log_2 k+\log_2\log_2 k+O(1),
}
\]

and hence

\[
\boxed{E_k=\log_2\log k+O(1).}
\]

This is the exact Construction A studied in CP19 Task 1. No alternate schedule is silently substituted.
