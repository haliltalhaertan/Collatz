#!/usr/bin/env python3
"""CP19 Task 1 smoke/regression suite."""
from fractions import Fraction
from CP19_TASK1_REALIZER_A import rho_python, construction_a, F, L
from CP19_TASK1_REALIZER_B import rho_via_q_series

EXPECTED_DEFECTS_1M = [1,3,5,6,8,10,11,13,15,17,18,20,22,23,25,27,29,30,32,34,
                       52,94,172,316,586,1094,2049,3856,7282,13799,26215,49933,
                       95327,182362,349526,671089]


def verify_forward(n, word):
    for a in word:
        x=3*n+1; aa=(x & -x).bit_length()-1
        assert aa==a
        n=x>>aa


def main():
    # Exact frozen schedule regression.
    S, info = construction_a(1_000_000)
    assert [x[0] for x in info] == EXPECTED_DEFECTS_1M
    # Two conceptually different realizer implementations.
    rhoA, A, word, S10, info10 = rho_python(10000)
    rhoB, q, A2, word2, S2, info2 = rho_via_q_series(10000)
    assert A==A2 and word==word2 and S10==S2 and rhoA==rhoB
    assert rhoA & ((1<<64)-1) == 4838348622506491903
    # Frozen finite-prefix realization.
    rho256, A256, word256, *_ = rho_python(256)
    verify_forward(rho256, word256)
    assert rho256 == 1793691733637540156850745748128437338648024253505058266735175566986193403225688714612350677270444827570601967222783
    # Analytic gap inequality used in X_R divergence proof.
    sched = {m:(k,r) for k,src,m,r,rank in info if src=="schedule"}
    for m in range(9,24):
        if m+1 in sched:
            gap=sched[m+1][0]-sched[m][0]
            assert gap*8*m >= (1<<m)
    # Same-envelope finite counterexample: exact value depends on microscopic phase choice.
    r1,A1,_,_,i1 = rho_python(4096,"first")
    r2,A2,_,_,i2 = rho_python(4096,"second")
    assert len(i1)==len(i2) and A1==A2 and r1!=r2
    print("CP19 TASK1 SMOKE TESTS: OK")
    print("A/B exact agreement at R=10000; frozen schedule and finite witness verified.")

if __name__ == "__main__":
    main()
