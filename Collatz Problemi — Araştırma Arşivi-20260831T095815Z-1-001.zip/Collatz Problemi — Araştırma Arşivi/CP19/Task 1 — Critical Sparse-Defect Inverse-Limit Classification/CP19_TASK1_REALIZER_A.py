#!/usr/bin/env python3
"""CP19 Task 1 — Implementation A.
Exact Construction-A generator + direct affine-cylinder realizer.

Default Python backend is intended for moderate depths (e.g. 10^4).
The --backend cpp option embeds/compiles a Boost cpp_int backend and was used
for the exact R=10^6 run.
"""
from __future__ import annotations
import argparse, hashlib, subprocess, tempfile
from pathlib import Path

# Exact certified rational bracket for alpha=log_2(3):
# 1686221/1063887 < alpha < 301994/190537.
# The two inequalities are equivalent to 2^1686221 < 3^1063887 and
# 2^301994 > 3^190537, respectively.
LOW_P, LOW_Q = 1686221, 1063887
UP_P, UP_Q = 301994, 190537


def F(k: int) -> int:
    """Exact floor(k log_2 3) for 0<=k<=1e6 using certified rational bounds."""
    if k == 0:
        return 0
    lo = k * LOW_P // LOW_Q
    hi = k * UP_P // UP_Q
    if lo == hi:
        return lo
    # Up to 1e6 the only ambiguous k are multiples of UP_Q.
    # Since alpha is STRICTLY below UP_P/UP_Q, k*alpha is strictly below
    # the integer hi, while the lower bound gives >=lo=hi-1.
    if (k * UP_P) % UP_Q == 0 and hi == lo + 1:
        return lo
    # Generic exact fallback outside the certified target range.
    return pow(3, k).bit_length() - 1


def L(k: int) -> int:
    return k.bit_length() - 1 if k else 0


def g(k: int) -> int:
    return F(k + 1) - F(k)


def b(k: int) -> int:
    return g(k) - 1


def first_phase_one(start: int, rank: int = 1) -> int:
    got = 0
    k = start
    while True:
        if b(k) == 1:
            got += 1
            if got == rank:
                return k
        k += 1


def construction_a(N: int, buffer: int = 12, mode: str = "first"):
    """Frozen CP18 Task-9 Construction A operational schedule.

    mode='first' is the frozen schedule. 'second' and 'alternating' are
    CP19 falsification variants with the same defect-count envelope.
    """
    selected = set()
    info = []
    k = 0
    while len(selected) < buffer and k < N:
        if b(k) == 1:
            selected.add(k)
            info.append((k, "buffer", None, None, 1))
        k += 1
    prev = max(selected) if selected else -1
    m = 1
    while True:
        r = ((1 << m) + m) // (m + 1)  # ceil(2^m/(m+1))
        if mode == "first":
            rank = 1
        elif mode == "second":
            rank = 2
        elif mode == "alternating":
            rank = 2 if (m & 1) else 1
        else:
            raise ValueError(mode)
        p = first_phase_one(max(r, prev + 1), rank)
        if p >= N:
            break
        selected.add(p)
        info.append((p, "schedule", m, r, rank))
        prev = p
        m += 1
    return selected, info


def valuation_word(N: int, mode: str = "first"):
    S, info = construction_a(N, mode=mode)
    word = []
    A = 0
    for k in range(N):
        a = g(k) - (1 if k in S else 0)
        assert a >= 1
        word.append(a)
        A += a
    return word, S, info, A


def combine(left, right):
    # 2^A n_v = 3^r n_u + B
    r1, A1, P1, B1 = left
    r2, A2, P2, B2 = right
    return (r1 + r2, A1 + A2, P1 * P2, P2 * B1 + (B2 << A1))


def affine_stack(word):
    stack = []
    for a in word:
        z = (1, a, 3, 1)
        while stack and stack[-1][0] == z[0]:
            z = combine(stack.pop(), z)
        stack.append(z)
    z = stack[0]
    for q in stack[1:]:
        z = combine(z, q)
    return z


def rho_python(N: int, mode: str = "first"):
    word, S, info, A0 = valuation_word(N, mode)
    r, A, P, B = affine_stack(word)
    assert r == N and A == A0
    M = 1 << (A + 1)
    rho = (((1 << A) - B) * pow(P % M, -1, M)) % M
    return rho, A, word, S, info

# Embedded high-performance exact backend used for the 10^6 calculation.
CPP = r'''
#include <boost/multiprecision/cpp_int.hpp>
#include <boost/multiprecision/integer.hpp>
#include <boost/multiprecision/cpp_int/import_export.hpp>
#include <vector>
#include <set>
#include <fstream>
#include <iostream>
using namespace boost::multiprecision; using namespace std;
const long long PL=1686221,QL=1063887,PU=301994,QU=190537;
long long F(long long k){if(!k)return 0;long long lo=(__int128)k*PL/QL,hi=(__int128)k*PU/QU;if(lo==hi)return lo;if(((__int128)k*PU)%QU==0&&hi==lo+1)return lo;exit(3);}int b(long long k){return F(k+1)-F(k)-1;}
struct D{long long k;};
vector<D> defs(long long N,int mode){set<long long>S;vector<D>I;long long k=0;while(S.size()<12&&k<N){if(b(k)==1){S.insert(k);I.push_back({k});}k++;}long long prev=S.empty()?-1:*S.rbegin();for(long long m=1;;m++){long long r=(((cpp_int(1)<<m)+m)/(m+1)).convert_to<long long>();int want=mode==2?2:(mode==3?((m&1)?2:1):1);long long q=max(r,prev+1);int got=0;while(true){if(b(q)==1&&++got==want)break;q++;}if(q>=N)break;S.insert(q);I.push_back({q});prev=q;}return I;}
struct Z{long long r,A;cpp_int P,B;}; Z comb(const Z&x,const Z&y){return{x.r+y.r,x.A+y.A,x.P*y.P,y.P*x.B+(y.B<<x.A)};}
cpp_int inv2(cpp_int a,unsigned bits){cpp_int x=1;unsigned cur=1;while(cur<bits){unsigned nb=min(bits,cur*2);cpp_int mask=(cpp_int(1)<<nb)-1;x=(x*(2-a*x))&mask;cur=nb;}return x&((cpp_int(1)<<bits)-1);}
int main(int argc,char**argv){long long N=stoll(argv[1]);string fn=argv[2];int mode=stoi(argv[3]);auto I=defs(N,mode);set<long long>S;for(auto d:I)S.insert(d.k);vector<Z>st;for(long long k=0;k<N;k++){int a=F(k+1)-F(k)-(S.count(k)?1:0);Z z{1,a,3,1};while(!st.empty()&&st.back().r==z.r){z=comb(st.back(),z);st.pop_back();}st.push_back(std::move(z));}Z z=st[0];for(size_t i=1;i<st.size();i++)z=comb(z,st[i]);unsigned bits=z.A+1;cpp_int mask=(cpp_int(1)<<bits)-1;cpp_int inv=inv2(z.P&mask,bits);cpp_int rho=(((cpp_int(1)<<z.A)-z.B)*inv)&mask;vector<unsigned char>bb;export_bits(rho,back_inserter(bb),8,false);bb.resize((bits+7)/8,0);ofstream f(fn,ios::binary);f.write((char*)bb.data(),bb.size());cout<<z.A<<" "<<I.size()<<"\n";}
'''


def rho_cpp(N: int, output: Path, mode: str = "first"):
    mode_id = {"first": 1, "second": 2, "alternating": 3}[mode]
    with tempfile.TemporaryDirectory() as td:
        src = Path(td) / "r.cpp"
        exe = Path(td) / "r"
        src.write_text(CPP)
        subprocess.run(["g++", "-O3", "-std=c++17", str(src), "-o", str(exe)], check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        cp = subprocess.run([str(exe), str(N), str(output), str(mode_id)], check=True,
                            text=True, capture_output=True)
    A, nd = map(int, cp.stdout.split())
    raw = output.read_bytes()
    rho = int.from_bytes(raw, "little")
    return rho, A, nd, hashlib.sha256(raw).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--N", type=int, default=10000)
    ap.add_argument("--mode", choices=["first", "second", "alternating"], default="first")
    ap.add_argument("--backend", choices=["python", "cpp"], default="python")
    ap.add_argument("--output", default="")
    args = ap.parse_args()
    if args.backend == "python":
        rho, A, word, S, info = rho_python(args.N, args.mode)
        raw = rho.to_bytes((A + 8) // 8, "little")
        if args.output:
            Path(args.output).write_bytes(raw)
        print({"N": args.N, "A": A, "defects": len(info), "rho_bits": rho.bit_length(),
               "popcount": rho.bit_count(), "low64": rho & ((1 << 64) - 1),
               "sha256_le": hashlib.sha256(raw).hexdigest()})
    else:
        output = Path(args.output or f"rho_{args.mode}_{args.N}.bin")
        rho, A, nd, h = rho_cpp(args.N, output, args.mode)
        print({"N": args.N, "A": A, "defects": nd, "rho_bits": rho.bit_length(),
               "popcount": rho.bit_count(), "low64": rho & ((1 << 64) - 1), "sha256_le": h})

if __name__ == "__main__":
    main()
