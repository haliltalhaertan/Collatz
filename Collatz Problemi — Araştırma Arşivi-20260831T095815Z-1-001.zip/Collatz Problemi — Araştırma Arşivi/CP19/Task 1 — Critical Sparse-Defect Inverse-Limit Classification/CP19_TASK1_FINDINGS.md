# COLLATZ CP19 — TASK 1 FINDINGS
## Critical Sparse-Defect Inverse-Limit Classification

**Final strategic verdict**

\[
\boxed{\textbf{A — [FAIL: CONSTRUCTION A ITSELF DOES NOT EXCLUDE POSITIVE LEVEL 3]}}
\]

No Side-B theorem is proved.  A nontrivial theorem-level classification gain is obtained: Construction A's inverse-limit realizer is nonzero and cannot be a negative ordinary integer.  Positive-ordinary and rational critical-density possibilities remain open.

---

## 1. Source recovery and frozen Construction A

Construction A was recovered from the frozen CP18 Task-9 operational reproducer, not reconstructed from memory.

Let

\[
F_k=\lfloor k\log_2 3\rfloor,
\qquad
b_k=F_{k+1}-F_k-1\in\{0,1\}.
\]

The frozen schedule is:

1. `buffer = 12`;
2. choose the first 12 indices `k` with `b_k=1`;
3. after the buffer, for `m=1,2,...` set
   \[
   r_m=\left\lceil\frac{2^m}{m+1}\right\rceil;
   \]
4. choose
   \[
   p_m=\min\{k\ge \max(r_m,p_{m-1}+1):b_k=1\};
   \]
5. put `d_k=+1` at the selected positions and `d_k=0` elsewhere;
6. define
   \[
   a_k=g_k-d_k,
   \qquad
   g_k=F_{k+1}-F_k.
   \]

The exact first defects are

\[
1,3,5,6,8,10,11,13,15,17,18,20,22,23,25,27,29,30,32,34,52,94,172,316,\ldots
\]

and the exact defects below `10^6` end at

\[
95327,182362,349526,671089.
\]

There are exactly **36** defects below `10^6`.

Status: `[EXACT]`.

---

## 2. Exact finite-prefix realizer

For a finite word `w_R=(a_0,...,a_{R-1})`, define

\[
A_R=\sum_{k<R}a_k,
\qquad
B_R=\sum_{j=0}^{R-1}3^{R-1-j}2^{A_j}.
\]

The affine identity is

\[
2^{A_R}n_R=3^R n_0+B_R.
\]

Exact terminal oddness gives the unique odd start cylinder

\[
\boxed{
 n_0\equiv\rho_R
 =3^{-R}(2^{A_R}-B_R)
 \pmod{2^{A_R+1}}.
}
\]

The canonical representative is chosen with

\[
1\le \rho_R<2^{A_R+1}.
\]

Selected finite prefixes were forward simulated independently and reproduce every prescribed valuation exactly.

Status: `[EXACT]`.

---

## 3. Infinite 2-adic realizer and two independent implementations

The cylinders are nested:

\[
\rho_{R+1}\equiv\rho_R\pmod{2^{A_R+1}}.
\]

Since `A_R>=R`, they determine a unique

\[
\boxed{x_A\in\mathbb Z_2.}
\]

Implementation A computes the affine cylinder directly by divide-and-conquer composition.

Implementation B computes the Task-6 series/truncation

\[
q_R=-\sum_{j<R}\frac{2^{A_j}}{3^{j+1}}
=-\frac{X_R}{3}
\quad\pmod{2^{A_R+1}},
\]

then uses

\[
\rho_R\equiv q_R+2^{A_R}\pmod{2^{A_R+1}}.
\]

At `R=10000`, the two conceptually different implementations agree exactly on the entire canonical truncation.  The common SHA256 is

`d82f488b361460b2b3a5451996822774e0a3ca02c2106fadb5abe716cb6aedab`.

Status: `[EXACT CROSS-CHECK]`.

---

## 4. Certified exact phase generation to one million

No floating-point decision is used for

\[
F_k=\lfloor k\log_2 3\rfloor.
\]

The implementation uses the exact rational bracket

\[
\frac{1686221}{1063887}<\log_2 3<\frac{301994}{190537}.
\]

The endpoint inequalities were verified by integer arithmetic:

\[
2^{1686221}<3^{1063887},
\qquad
2^{301994}>3^{190537}.
\]

For `1<=k<=10^6`, the two rational floors differ only at

\[
190537,381074,571611,762148,952685.
\]

At all five points direct exact integer `bit_length(3^k)-1` gives the lower value used by the implementation.

Status: `[EXACT]`.

---

## 5. Deep Construction-A computation

At

\[
R=10^6
\]

we obtain exactly

\[
F_R=1,584,962,
\qquad
s_R=36,
\qquad
A_R=1,584,926,
\]

\[
L_R=19,
\qquad
E_R=17.
\]

The canonical truncation has:

- modulus depth: **1,584,927 bits**;
- `rho_R` bit length: **1,584,926**;
- popcount: **792,063**;
- low 64 bits: **4,838,348,622,506,491,903**;
- SHA256 of the fixed-length little-endian truncation:
  `533c71db59ed620ef4eda71c1c9d8416b60380cebbff625254492c21026c3e72`.

A fresh packaged-code reproduction of the `R=10^6` result produced the same SHA256.

Status: `[CERTIFIED NUM / EXACT ARITHMETIC]`.

---

## 6. Lift diagnostics

Write

\[
\rho_{R+1}=\rho_R+\lambda_R2^{A_R+1},
\qquad
0\le\lambda_R<2^{a_R}.
\]

The final truncation contains all earlier disjoint lift blocks, so the entire finite lift history can be decoded exactly from `rho_R`.

Through `R=10^6`:

\[
\boxed{646,277}
\]

lifts are nonzero, even though only 36 valuation defects occur.

The longest observed zero-lift run is only

\[
\boxed{12},
\]

and the last observed nonzero lift occurs at

\[
k=999999.
\]

This shows that the binary realizer complexity is generated mostly inside the long critical gaps, not only at defect sites.

However:

\[
\boxed{
646,277\text{ observed nonzero lifts}\not\Rightarrow
\text{infinitely many future nonzero lifts}.
}
\]

Status: `[CERTIFIED NUM]`, not a theorem of non-eventual stabilization.

---

## 7. Theorem: Construction A has divergent carry mass

For Construction A, after the finite buffer,

\[
p_m=\frac{2^m}{m+1}+O(1).
\]

More quantitatively, for `m>=9`, the exact schedule satisfies

\[
\boxed{
p_{m+1}-p_m\ge\frac{2^{m-3}}{m}.
}
\]

Between the `m`-th and `(m+1)`-st scheduled defects,

\[
s_j=12+m
\]

apart from the harmless endpoint convention.  Since

\[
D_j=-s_j-\{j\log_2 3\},
\]

\[
2^{D_j}\ge2^{-m-13}.
\]

Therefore that gap contributes at least

\[
\frac{2^{m-3}}m2^{-m-13}
=
\frac1{2^{16}m}
\]

to

\[
X_R=\sum_{j<R}2^{D_j}.
\]

The harmonic lower bound diverges:

\[
\boxed{X_R\to+\infty.}
\]

Status: `[PROVED]`.

---

## 8. New classification theorem: negative ordinary integers are impossible

Suppose the inverse-limit realizer were a negative ordinary integer

\[
x_A=-C,
\qquad C\ge1.
\]

For an actual ordinary realizer, the exact affine identity gives

\[
\frac{2^{A_R}}{3^R}n_R
=
-C+\frac{X_R}{3}.
\]

A negative odd integer stays negative under every finite odd-only Syracuse step, because `3n+1<0` and division by a positive power of two preserves sign.

Hence every `n_R` would be negative.

But `X_R->infinity`, so the right side is eventually positive, contradiction.

Thus

\[
\boxed{x_A\notin\mathbb Z_{<0}.}
\]

Also `x_A` is odd, so

\[
\boxed{x_A\ne0.}
\]

Therefore the rigorous classification progress is

\[
\boxed{
x_A\in\mathbb Z_2^\times\setminus\mathbb Z_{<0}.
}
\]

Status: `[PROVED]`.

This is new relative to merely restating Task-10 eventual-stabilization or Task-7 nonzero-lift criteria, but it does **not** exclude positive ordinary integers.

---

## 9. Positive ordinary integer test

A nonnegative ordinary 2-adic integer is equivalent to eventual constancy of the canonical truncations:

\[
x_A\in\mathbb Z_{>0}
\iff
\rho_R\text{ is eventually constant}.
\]

That equivalence is frozen Task-10 structure and is not new here.

Construction A shows no stabilization through `R=10^6`, but no exact recurrence was proved that forces a future nonzero lift after every sufficiently deep point.

Therefore

\[
\boxed{x_A\in\mathbb Z_{>0}\text{ remains [OPEN]}.}
\]

This prevents verdict B/C/E.

---

## 10. Rationality and the critical-density barrier

If `x_A` were rational with odd denominator, its binary 2-adic expansion would be eventually periodic.

Finite diagnostics exclude only simple candidates:

- no candidate `p/q` with odd `q<=100000` and centered `|p|<2^64` modulo `2^512`;
- no binary period `<=4096` on the exact bit window `[1,000,000,1,262,143]`.

Status: `[CERTIFIED NUM]` only.

Construction A lies exactly at the known critical parity-density threshold.  Since

\[
A_R=F_R-s_R
\]

with `s_R=O(log R)`, we have

\[
\frac{A_R}{R}\to\log_2 3.
\]

Thus the corresponding standard parity vector has one-density

\[
\boxed{
\frac{R}{A_R}\to\frac1{\log_2 3}=\frac{\ln2}{\ln3}.
}
\]

The valuation word is aperiodic because an eventually periodic valuation word would have rational mean valuation, while `log_2 3` is irrational.

External literature cross-check:

- Josefina López & Peter Stoll, *The 3x+1 Periodicity Conjeture in R* (arXiv:2101.12747, 2021) proves an aperiodic-to-aperiodic result under the **strict** lower-density inequality `> ln(2)/ln(3)` and notes equality as the necessary density for a hypothetical rational 2-adic with non-cyclic trajectory.
- López & Stoll, *The 3x+1 Conjugacy Map over a Sturmian Word* (INTEGERS 9, 2009) explicitly records that it is unknown whether an aperiodic parity vector can have an eventually periodic conjugacy image.

Construction A sits at the equality boundary, so those general results do not classify `x_A`.

Therefore

\[
\boxed{x_A\in\mathbb Q\cap\mathbb Z_2\text{ remains [OPEN]}.}
\]

---

## 11. Same envelope, different exact 2-adic realizers

Two falsification variants preserve the same number of sparse defects and hence the same final `s_R`, `A_R`, and `E_R`, but move each scheduled defect microscopically among admissible `b=1` sites.

At `R=10^6`:

| schedule | defects | `A_R` | `s_R` | `E_R` | low64 | SHA256 |
|---|---:|---:|---:|---:|---:|---|
| frozen FIRST | 36 | 1,584,926 | 36 | 17 | 4,838,348,622,506,491,903 | `533c71db...c3e72` |
| SECOND admissible phase-one | 36 | 1,584,926 | 36 | 17 | 2,793,530,590,232,575 | `c8bf725c...77971` |
| alternating FIRST/SECOND | 36 | 1,584,926 | 36 | 17 | 15,434,686,520,576,966,655 | `ab9aeac6...b72f8` |

Thus

\[
\boxed{
\text{the same critical }E\text{-envelope does not determine the 2-adic realizer value.}
}
\]

Status: `[COUNTEREXAMPLE]` to the coarse-value claim.

It is **not** proved that these realizers belong to different rational/ordinary classes.

---

## 12. Finite stabilization search

A finite search over microscopic admissible defect choices was run as a falsification test for the proposed universal sparse-defect obstruction.

For the packaged three deterministic variants at `R=4096`, the final zero-lift plateau is at most 1 and the maximum zero-lift run is at most 9.

A broader previously generated 256-branch finite search reached a maximum final plateau of 5.

These diagnostics supply no positive-level counterexample and no theorem.

Status: `[CERTIFIED NUM]`.

---

## 13. Long critical-gap LEVEL-3 lead

Construction A has exponentially growing gaps between defects.  The largest gap below `10^6` is approximately `3.2e5` steps.

Exact finite diagnostics show that the canonical current-state residue for these long critical blocks is typically of essentially full block-modulus bit length, while a hypothetical fixed positive Construction-A orbit would have only polynomial/polylogarithmic Archimedean state growth from

\[
n_k=n_0U_k2^{s_k+\{k\alpha\}}.
\]

This is a potentially high-value two-topology bridge.

However no theorem was proved that every sufficiently long critical block forces an exponentially large positive current-state representative.  Proving that appears to intersect the unresolved critical/Sturmian conjugacy problem.

Status: `[LEAD]`, not a theorem.

---

## 14. Hypothesis ledger

| Hypothesis | Verdict | Evidence |
|---|---|---|
| H1. `x_A` is a positive ordinary integer | `[OPEN]` | no eventual-stabilization exclusion theorem |
| H2. `x_A` is a negative integer | `[FAIL][PROVED FALSE]` | `X_R->infinity` + negative-state sign preservation |
| H3. `x_A` is rational in `Q∩Z_2` | `[OPEN]` | simple candidates/periods excluded only finitely |
| H4. Construction-A lifts are nonzero infinitely often | `[OPEN]` | 646,277 nonzero lifts through `10^6` is finite evidence |
| H5. Every sparse `Q=0` Task-5-compatible branch is nonordinary | `[OPEN]` | no positive-ordinary exclusion theorem |
| H6. Defect count/envelope determines the realizer | `[FAIL]` for exact value | first/second/alternating schedules differ exactly |
| H7. Same `E` envelope gives essentially same 2-adic behavior | `[COUNTEREXAMPLE]` | different low bits and full-prefix SHA256 |
| H8. Critical occupation alone forces infinitely many nonzero lifts | `[OPEN]` | Task-7 barrier remains |
| H9. A fixed positive integer can realize Construction A | `[OPEN]` | exact central LEVEL-3 question |
| H10. Sparse-defect mechanism supplies new positive LEVEL-3 obstruction | `[FAIL]` | only zero/negative classification achieved |

---

## 15. Required final table

| Question | Verdict | Evidence |
|---|---|---|
| Was exact Task-9 Construction A recovered correctly? | `[EXACT] YES` | frozen `buffer=12`, target and first-phase-one tie-break reproduced |
| Does every tested finite prefix reproduce the frozen construction? | `[EXACT] YES` | forward valuations + frozen 32/64/128/256 witnesses + 1M schedule regression |
| What is `x_A` in `Z_2`? | unique odd inverse-limit point; partial classification only | `x_A∈Z_2^×\Z_{<0}` |
| Is `x_A` a positive ordinary integer? | `[OPEN]` | no proof of infinitely many future lifts |
| Is `x_A` a negative integer? | `[PROVED] NO` | divergent-carry sign theorem |
| Is `x_A` rational with odd denominator? | `[OPEN]` | critical-density boundary; finite simple-candidate exclusions only |
| Do `rho_R` truncations provably change infinitely often? | `[OPEN]` | 646,277 changes through 1M is finite |
| Can lift behavior be derived from defect times? | `[PARTLY EXACT]` | lift blocks exactly decodable; most lift activity occurs between defects; no infinite recurrence theorem |
| Is the Construction-A exclusion theorem-level? | `[PARTIAL]` | zero and negative ordinary classes excluded; positive class not excluded |
| Does it generalize to sparse `Q=0` branches? | `[PARTIAL]` | general `X_R->∞ => x∉Z_{<0}` theorem only |
| Does the same `E` envelope allow different realizer classes? | `[OPEN at class level]` | different exact realizers proved, classes not classified |
| Is the result new vs Tasks 6/7/10? | `[PARTLY NEW]` | divergent-carry negative-integer exclusion is new; stabilization/lift criteria are redundant |
| Do we have a new LEVEL-3 obstruction? | **NO** | positive ordinary realization remains open |
| Do we have Side B? | **NO** | Task-5-compatible positive LEVEL-3 exclusion not proved |

---

# Ne denedik?

Construction A'nın tek bir sonsuz 2-adic başlangıcını gerçekten sınıflandırmaya çalıştık.  Önce pozitif integer olma fikrini kırmaya çalıştık; bunun için 1 milyon adıma kadar exact cylinder/lift hesabı, iki bağımsız realizer hesabı, rational/period testleri, sparse-defect varyantları ve uzun critical-gap testleri yaptık.

# Ne bulduk?

Construction A çok seyrek defect üretmesine rağmen 2-adic başlangıcının binary liftleri seyrek değil: 1 milyon valuation adımında 646 binden fazla nonzero lift var.  Ayrıca carry toplamının sonsuza gittiğini exact olarak kanıtladık.  Bu, realizer'ın sıfır veya negatif ordinary integer olmasını kesin olarak eliyor.

# Construction A'nın 2-adik başlangıcı ne çıktı?

Kapalı bir rational/negative form bulunmadı.  Rigorous olarak bildiğimiz:

\[
\boxed{x_A\in\mathbb Z_2^\times\setminus\mathbb Z_{<0}.}
\]

Pozitif ordinary integer mı, yoksa rational/irrational nonordinary bir 2-adic mi olduğu açık kaldı.

# Bu tek bir pozitif Collatz yörüngesini neden eliyor / neden henüz elemiyor?

Negatif başlangıç ihtimalini eliyoruz, fakat aradığımız şey zaten **pozitif** tek bir ordinary integer'ın bütün sonsuz prescription'ı taşıyamayacağını göstermekti.  Bir milyon adım boyunca stabilizasyon olmaması sonsuz geleceği kanıtlamıyor.  Dolayısıyla Construction A henüz pozitif LEVEL 3'ü elemiyor.

# CP19 Task 2 için en yüksek bilgi değerli sonraki soru ne?

En yüksek bilgi değerli soru, uzun **critical gaps** için positive current-state cylinder'ının zorunlu Archimedean büyüklüğünü kanıtlamak: Construction A'nın polynomial/polylog state envelope'i ile critical-gap exact residue geometrisi arasında gerçekten exponential bir uyumsuzluk var mı?  Böyle bir theorem, Task-7'nin genel lift-count bariyerini tekrar etmek yerine explicit sparse schedule'ın uzun-gap yapısından yeni bir LEVEL-3 invariant çıkarabilir.

---

# FINAL STRATEGIC VERDICT

\[
\boxed{\textbf{A — [FAIL: CONSTRUCTION A ITSELF DOES NOT EXCLUDE POSITIVE LEVEL 3]}}
\]

Task 1 nevertheless produces a useful exact theorem: Construction A has divergent carry mass and therefore its inverse-limit realizer is neither zero nor a negative ordinary integer.  The positive-ordinary/rational critical-density classification remains open.

No Side-B theorem and no major-theorem audit trigger.
