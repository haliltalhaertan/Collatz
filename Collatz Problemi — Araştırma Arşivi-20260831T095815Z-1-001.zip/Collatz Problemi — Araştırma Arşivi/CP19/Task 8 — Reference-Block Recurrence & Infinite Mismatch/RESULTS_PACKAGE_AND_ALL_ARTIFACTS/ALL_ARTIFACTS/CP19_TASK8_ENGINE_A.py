from __future__ import annotations
from array import array

LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537

def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q; hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1

def L(k):return k.bit_length()-1 if k else 0
def g(k):return F(k+1)-F(k)
def b(k):return g(k)-1

def neutral_pair(k):
    if b(k)==1:return 1,-1
    assert b(k+1)==1
    return -1,1

def gain_pair(k):
    x,y=neutral_pair(k)
    if x<0:x=0
    else:y=0
    return x,y

def base_schedule(N,p=53,q=50):
    d=array("b",[0])*N;s=0
    for j in range(0,N-1,2):
        target=p*L(j+2)//q
        x,y=gain_pair(j) if s<target else neutral_pair(j)
        d[j]=x;d[j+1]=y;s+=x+y
    return d

def apply_event(d,base,m):
    t=3*(1<<(m-1));ell=max(2,m//2);v=t-ell
    A0=F(t)-F(v)-sum(base[v:t])
    R=max(1,2*ell-A0)
    drop=t-1
    d[drop]=base[drop]-R
    rem=R;k=t
    while rem:
        cap=b(k)-base[k]
        if cap>0:
            inc=min(rem,cap);d[k]=base[k]+inc;rem-=inc
        k+=1
    assert sum(d[drop:k])-sum(base[drop:k])==0

def pre_event_schedule(m,w):
    t=3*(1<<(m-1))
    # enough room for q+w crossing
    N=t+4*w+128
    base=base_schedule(N)
    d=array("b",base)
    for j in range(10,m):
        apply_event(d,base,j)
    return d,t

def qevent(m):
    t=3*(1<<(m-1))
    return F(t)-(53*m//50)

def block_A(m,w):
    d,t=pre_event_schedule(m,w)
    q=qevent(m);target=q+w
    A=B=0;P=1
    R=0
    while A<target:
        k=R;a=g(k)-d[k]
        B=3*B+(1<<A);P*=3;A+=a;R+=1
    mod=1<<(A+1)
    rho=(((1<<A)-B)*pow(P,-1,mod))%mod
    return (rho>>q)&((1<<w)-1),R,A

if __name__=="__main__":
    for m in range(10,13):
        x,R,A=block_A(m,16)
        print(m,hex(x),R,A)
    print("CP19 TASK8 ENGINE A: OK")
