# COLLATZ CP19 — TASK 8 FINDINGS
## Reference-Block Recurrence & Infinite Mismatch

## Final verdict

\[
\boxed{\textbf{B — [LEAD: REFERENCE-BLOCK RECURRENCE FOUND]}}
\]

Task 8 does **not** prove an infinite fixed-width mismatch. Therefore the
explicit Task-5 survivor remains open at positive/nonnegative ordinary LEVEL 3.

The main progress is an exact decomposition of the difficult pre-event block
into:

1. one fixed pure-neutral critical 2-adic background;
2. a recursively generated rational correction coming from permanent dyadic
   height gains and earlier finite event surgeries.

This isolates the remaining unknown object much more sharply.

## 1. Pure-neutral reference

Remove both the dyadic height gains and the mean-2 events, leaving only the
canonical neutral high-turnover pair rule.

At every even pair boundary,
\[
\boxed{A^{(0)}_{2r}=F_{2r}.}
\]

Put
\[
\gamma=2\alpha-3,\qquad \delta=2-\alpha.
\]
Writing
\[
\theta_r=\{r\gamma\},
\]
the pure-neutral pair valuation types are exactly

\[
(a_{2r},a_{2r+1})=
\begin{cases}
(2,1),&0\le\theta_r<\delta,\\
(1,2),&\delta\le\theta_r<2\delta,\\
(1,3),&2\delta\le\theta_r<1.
\end{cases}
\]

Thus the background is an exact three-interval coding of the irrational
rotation
\[
\theta_{r+1}=\{\theta_r+\gamma\}.
\]

Its odd-step valuation mean is
\[
\alpha,
\]
so the corresponding full parity density is exactly
\[
\boxed{\frac1\alpha=\frac{\ln2}{\ln3}.}
\]

The word is aperiodic: eventual periodicity would force rational mean
valuation, contradicting irrationality of \(\alpha\).

## 2. Permanent-gain operator

Suppose a valuation sequence is modified at one index \(k\) by lowering
\(a_k\) by exactly one, with every later valuation symbol otherwise unchanged.

Let
\[
P_k=-\sum_{j=0}^{k}\frac{2^{A_j}}{3^{j+1}}
\]
be the pre-gain partial inverse-limit sum and \(x\) the old infinite
realizer.

Then the new cumulative exponents equal the old exponents minus one for
every \(j\ge k+1\), hence the new realizer is exactly

\[
\boxed{x'=\frac{x+P_k}{2}.}
\]

This is the key Task-8 recurrence.

If the first \(H\) permanent gains occur at indices \(k_1,\ldots,k_H\),
with \(P_r\) evaluated in the schedule just before gain \(r\), then

\[
\boxed{
2^H x_{\rm ref}^{[H]}
=
x_{\rm neutral}
+
\Gamma_H,
}
\]
where
\[
\boxed{
\Gamma_H=
\sum_{r=1}^{H}2^{r-1}P_r
\in\mathbb Q\cap\mathbb Z_2[2^{-H}]
}
\]
in the exact scaled identity. Each \(P_r\) itself has odd denominator.

Equivalently the scaled correction obeys the recursion
\[
\boxed{
\Gamma_{H+1}=\Gamma_H+2^H P_{H+1}.
}
\]

## 3. Pre-event reference reduction

At event \(m\),
\[
H_m=\lfloor53m/50\rfloor,
\qquad
q_m=F_{t_m}-H_m.
\]

Before the current event, all previous mean-2 surgeries have recovered their
cumulative valuation offset. Between the last dyadic gain near \(2^m\) and
the current event \(t_m=3\cdot2^{m-1}\), the schedule follows the neutral
rule.

For every fixed protected width \(w\), and all sufficiently large \(m\), no
new gain/event occurs before the first prefix whose cumulative valuation
reaches \(q_m+w\).

Therefore the protected block can be reduced exactly to

\[
\boxed{
B_m(w)
=
\operatorname{HB}_{F_{t_m},w}
\left(
x_{\rm neutral}+\mathcal R_m
\right),
}
\]

where \(\mathcal R_m\) is a finite rational 2-adic correction formed from:

- the first \(H_m\) permanent gain operators;
- all previous finite event corrections.

Here
\[
\operatorname{HB}_{n,w}(y)
=
\left\lfloor
\frac{y\bmod2^{n+w}}{2^n}
\right\rfloor\bmod2^w.
\]

This is an exact reference-block reduction. It is not yet a closed
finite-state automaton because the high block of the fixed
\(x_{\rm neutral}\) remains unresolved.

## 4. Rational high-half Hensel theorem

For
\[
y=P/Q\in\mathbb Z_2,\qquad Q\ \text{odd},
\]
let
\[
r_n=P Q^{-1}\pmod{2^n},
\qquad 0\le r_n<2^n,
\]
and
\[
c_n=\frac{P-Qr_n}{2^n}\in\mathbb Z.
\]

Writing
\[
r_{n+w}=r_n+2^n h,
\]
the exact next high block is

\[
\boxed{
h\equiv c_n Q^{-1}\pmod{2^w}.
}
\]

The carry then updates by
\[
\boxed{
c_{n+w}=\frac{c_n-Qh}{2^w}.
}
\]

Thus every rational gain/event component has an exact finite carry
recurrence.

The obstruction is not rational Hensel lifting. It is the fixed
pure-neutral nonrational/unknown high block.

## 5. Parity

Task 7 already gives
\[
U_m\equiv1\pmod2.
\]

Hence ordinary cancellation at width one requires
\[
\boxed{B_m\equiv1\pmod2}
\]
for every sufficiently large \(m\).

Direct exact values for \(m=10,\ldots,20\) are

\[
(B_m\bmod2)
=
(1,0,0,0,1,0,0,1,0,1,1),
\]

so parity mismatches and parity cancellations both occur.

The final mismatch bits are
\[
(c_m)=(0,1,1,1,0,1,1,0,1,0,0).
\]

This falsifies any theorem claiming an event-by-event parity mismatch.

No infinite parity theorem was obtained.

## 6. Why the obvious finite automaton did not close

For fixed \(w\), the local event units \(U_m\bmod2^w\) are easy and exact.
Task 7 already computes them to \(m=1000\).

The \(B_m\) side is different. Even after the permanent-gain reduction,
one still needs the high block of
\[
x_{\rm neutral}
\]
at the exponentially growing depths
\[
F_{t_m}.
\]

The rational corrections admit finite Hensel carry states, but the
pure-neutral high block does not have a proved finite-state recurrence.

A recurrence depending only on
\[
m\bmod50,\quad h_m,\quad\varepsilon_m
\]
was not found. Finite data already show that these local descriptors alone
do not determine the direct parity values without additional state.

## 7. Critical-density barrier

The pure-neutral full parity word is aperiodic and has density exactly
\[
\ln2/\ln3.
\]

Known 3x+1 conjugacy results prove aperiodicity of the 2-adic image under a
**strictly larger** parity-density hypothesis, while the critical equality
case is precisely the unresolved boundary.

Thus existing general periodicity/rationality theorems do not classify
\(x_{\rm neutral}\).

Task 8 does not claim that the present problem is equivalent to the full
Periodicity Conjecture. It records the narrower fact that the available
general theorems stop exactly at the density occupied by this reference
background.

## 8. Eventual-cancellation consequence

If the explicit survivor were an ordinary nonnegative integer \(n_0\), then
for every fixed \(w\) and all sufficiently large \(m\),

\[
X_{m-1}
\equiv
n_0-\delta_m
\pmod{2^{q_m+w}}.
\]

After multiplying by \(2^{H_m}\),

\[
\boxed{
x_{\rm neutral}+\mathcal R_m
\equiv
2^{H_m}n_0
-
2^{F_{t_m}}U_m
\pmod{2^{F_{t_m}+w}}.
}
\]

So eventual ordinary stabilization imposes an infinite exact high-half
matching law on the single fixed pure-neutral background.

No contradiction with that law was proved.

## 9. Status

What is proved:

- pure-neutral rotation coding and critical density;
- exact permanent-gain operator;
- exact scaled gain recurrence;
- exact reduction of \(B_m\) to pure-neutral high block + rational correction;
- exact rational high-half Hensel recurrence;
- Task-7 parity/cancellation data remain valid.

What is open:

- a closed fixed-width automaton for the pure-neutral high blocks;
- infinitely many \(B_m\neq-U_m\pmod{2^w}\);
- classification of \(x_{\rm neutral}\);
- classification of \(x_{\rm ref}\);
- nonnegative ordinary exclusion for \(x_S\).

Therefore

\[
\boxed{x_S\in\mathbb Z_{\ge0}\ ?\quad[\mathrm{OPEN}].}
\]

The next highest-information target is the pure-neutral critical-density
high-half cocycle sampled at the dyadic depths \(F_{3\cdot2^{m-1}}\).


## 10. Independent engine validation

Fresh Task-8 engines were run independently.

- Engine A: affine/canonical-cylinder construction.
- Engine B: direct infinite inverse-series truncation modulo the requested
  protected depth.

For pre-event protected blocks at width 16 they agree exactly:

\[
\begin{array}{c|c}
m & B_m\bmod2^{16}\\
\hline
10 & \texttt{0x80e1}\\
11 & \texttt{0x35f2}\\
12 & \texttt{0x1e0e}
\end{array}
\]

The corresponding prefix crossings are also identical.

A third independent Hensel engine passed 500 randomized rational
high-half identities.

This validates the exact arithmetic used in the Task-8 reduction.
