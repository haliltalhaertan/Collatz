# CP19 TASK 8 — FIXED-WIDTH AUTOMATON SEARCH

## Exact local input

For fixed \(w\), the event unit
\[
U_m\bmod2^w
\]
is computable in \(O(\mathrm{poly}(m,w))\) from the local event schedule.
Task-7 compressed data reach \(m=1000\).

The dyadic depth input satisfies
\[
q_{m+1}=2q_m+H_m-h_m+\varepsilon_m.
\]

The phase bit
\[
\varepsilon_m
=
F_{2t_m}-2F_{t_m}
=
\lfloor2\{\alpha t_m\}\rfloor
\]
is the binary coding of the doubling orbit of the fixed irrational phase.

## Attempted finite state

A desired automaton would have
\[
Z_{m+1}
=
\Phi_w(Z_m,m\bmod50,h_m,\varepsilon_m),
\]
with
\[
B_m\bmod2^w=\Psi_w(Z_m).
\]

No such closed finite state \(Z_m\) was derived.

The permanent-gain theorem instead gives a state decomposition into:

1. the high-half state of one fixed pure-neutral 2-adic background;
2. finitely many rational Hensel carry states.

The rational states are finite/compressible for fixed denominators, but the
pure-neutral state has no proved finite automaton.

## Falsification

The exact direct \(w=1\) data contain both \(B_m=0\) and \(B_m=1\) under
repeated local descriptor classes. Thus \(B_m\) is not a memoryless function
of only \(h_m,\varepsilon_m\).

This does not rule out a larger hidden-state automaton.

## Status

\[
\boxed{\text{[OPEN: NO FIXED-WIDTH AUTOMATON PROVED]}}
\]

The absence of an automaton is a research outcome, not a theorem that none
exists.
