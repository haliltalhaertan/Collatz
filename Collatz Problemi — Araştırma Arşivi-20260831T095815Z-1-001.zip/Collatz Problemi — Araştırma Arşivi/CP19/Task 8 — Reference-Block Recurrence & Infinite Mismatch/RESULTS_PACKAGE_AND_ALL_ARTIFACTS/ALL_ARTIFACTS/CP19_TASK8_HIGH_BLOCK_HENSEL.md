# CP19 TASK 8 — HIGH-BLOCK HENSEL THEOREM

Let
\[
y=P/Q\in\mathbb Z_2,\qquad Q\ \text{odd}.
\]

For depth \(n\), choose
\[
r_n\in[0,2^n)
\]
with
\[
Qr_n\equiv P\pmod{2^n}.
\]

Define the exact integer carry
\[
c_n=\frac{P-Qr_n}{2^n}.
\]

For a requested next width \(w\), write
\[
r_{n+w}=r_n+2^n h,\qquad 0\le h<2^w.
\]

Then
\[
Q(r_n+2^nh)\equiv P\pmod{2^{n+w}}
\]
is equivalent to
\[
Qh\equiv c_n\pmod{2^w}.
\]

Therefore the next high block is
\[
\boxed{
H_w(n)=h\equiv c_nQ^{-1}\pmod{2^w}.
}
\]

The next carry is
\[
\boxed{
c_{n+w}=\frac{c_n-Qh}{2^w}.
}
\]

This is an exact high-half recurrence; no giant \(n+w\)-bit modular inverse
is required once \((r_n,c_n)\) is known.

Newton lifting
\[
Q^{-1}_{2n}
=
Q^{-1}_n(2-QQ^{-1}_n)
\pmod{2^{2n}}
\]
is an equivalent inverse update.

## Application

Every finite event correction and every finite gain-prefix partial sum is a
rational 2-adic with odd denominator, so its high binary tail is governed by
this finite carry recurrence.

The unresolved term in Task 8 is not these rational tails. It is the fixed
pure-neutral 2-adic background, for which no rational \(P/Q\) representation
is known or claimed.
