# CP19 TASK 8 — REFERENCE CLASSIFICATION

## Pure-neutral background

The pure-neutral odd-only valuation word has:

\[
A^{(0)}_{2r}=F_{2r},
\]
hence mean valuation
\[
\lim_{r\to\infty}\frac{A^{(0)}_{2r}}{2r}
=
\alpha=\log_2 3.
\]

Its corresponding full parity word therefore has one-density
\[
\boxed{
\frac1\alpha
=
\frac{\ln2}{\ln3}.
}
\]

The word is aperiodic because an eventually periodic positive valuation word
has rational mean, whereas \(\alpha\) is irrational.

Its pair word is an irrational-rotation coding, so it has low symbolic
complexity but is not periodic.

## Realizer classification

No proof was obtained that
\[
x_{\rm neutral}
\]
is:

- ordinary;
- nonordinary;
- rational;
- irrational as a 2-adic number.

This is not surprising: known 3x+1 conjugacy results leave the critical
parity-density equality case unresolved. General results that force the
image of an aperiodic parity word to remain aperiodic require a strict
density inequality above \(\ln2/\ln3\).

The classical Sturmian-conjugacy literature also explicitly notes that the
existence of an aperiodic parity word with eventually periodic image is not
known in general.

Task 8 therefore does **not** claim a new classification theorem for
\(x_{\rm neutral}\).

## Reference background

The actual no-event reference is obtained from this neutral object by sparse
permanent gains:
\[
x'=(x+P)/2.
\]

The exact scaled recurrence
\[
2^H x_{\rm ref}^{[H]}
=
x_{\rm neutral}+\Gamma_H
\]
reduces reference classification to the neutral high-half problem plus
rational corrections.

Status:
\[
\boxed{\text{[REFERENCE CLASSIFICATION OPEN]}}.
\]
