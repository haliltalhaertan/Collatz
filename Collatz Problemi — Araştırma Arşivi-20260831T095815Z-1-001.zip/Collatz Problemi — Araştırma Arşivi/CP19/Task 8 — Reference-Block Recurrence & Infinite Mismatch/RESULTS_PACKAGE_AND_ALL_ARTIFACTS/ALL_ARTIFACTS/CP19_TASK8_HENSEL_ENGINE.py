from __future__ import annotations
import random, math

def residue(P,Q,n):
    assert Q&1
    M=1<<n
    return (P*pow(Q,-1,M))%M

def carry(P,Q,n,r):
    z=P-Q*r
    assert z%(1<<n)==0
    return z>>n

def high_block(P,Q,n,w):
    r=residue(P,Q,n)
    c=carry(P,Q,n,r)
    h=(c*pow(Q,-1,1<<w))%(1<<w)
    r2=r+(h<<n)
    assert (Q*r2-P)%(1<<(n+w))==0
    c2=(c-Q*h)>>w
    return h,c2,r,r2

def test():
    rng=random.Random(20260825)
    for _ in range(500):
        Q=rng.randrange(1,1<<20)|1
        P=rng.randrange(-(1<<30),1<<30)
        n=rng.randrange(1,80)
        w=rng.randrange(1,20)
        h,c2,r,r2=high_block(P,Q,n,w)
        direct=(residue(P,Q,n+w)>>n)&((1<<w)-1)
        assert h==direct
        assert c2==carry(P,Q,n+w,r2)
    print("CP19 TASK8 HENSEL ENGINE: OK")

if __name__=="__main__":test()
