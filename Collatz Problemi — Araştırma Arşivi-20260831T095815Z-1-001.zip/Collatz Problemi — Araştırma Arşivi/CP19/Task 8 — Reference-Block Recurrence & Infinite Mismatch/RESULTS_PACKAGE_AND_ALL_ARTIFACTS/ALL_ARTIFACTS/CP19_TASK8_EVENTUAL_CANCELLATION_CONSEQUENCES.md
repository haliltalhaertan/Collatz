# CP19 TASK 8 — EVENTUAL CANCELLATION CONSEQUENCES

Assume for contradiction that the explicit survivor realizer is
\[
x_S=n_0\in\mathbb Z_{\ge0}.
\]

For every fixed width \(w\) and all sufficiently large \(m\),
\[
B_m+U_m\equiv0\pmod{2^w}.
\]

Since current/future event corrections begin at depth \(q_m\),
\[
X_{m-1}
\equiv
n_0-\delta_m
\pmod{2^{q_m+w}}.
\]

Multiply by
\[
2^{H_m},
\qquad
q_m+H_m=F_{t_m}.
\]

Using the reference reduction,
\[
2^{H_m}X_{m-1}
\equiv
x_{\rm neutral}+\mathcal R_m
\pmod{2^{F_{t_m}+w}},
\]
so ordinary stabilization forces

\[
\boxed{
x_{\rm neutral}+\mathcal R_m
\equiv
2^{H_m}n_0
-
2^{F_{t_m}}U_m
\pmod{2^{F_{t_m}+w}}.
}
\]

Therefore:

- the lower \(F_{t_m}\) bits must equal \(2^{H_m}n_0\);
- the next \(w\) bits must equal the unique cancelling block \(-U_m\).

This is an infinite exact approximation law on one fixed
\(x_{\rm neutral}\).

## What this does not imply automatically

The rational correction \(\mathcal R_m\) changes with \(m\), and its
denominators/heights grow exponentially with the event scale.

The resulting 2-adic approximation exponent is not automatically strong
enough for a standard Roth/Baker-type contradiction.

Nor was an implication
"eventual cancellation => eventual periodicity of \(\varepsilon_m\)"
derived.

Thus the contrapositive route remains open.
