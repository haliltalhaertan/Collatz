# CP19 TASK 8 — PARITY THEOREM

Task 7 proved
\[
U_m\equiv1\pmod2.
\]

Hence
\[
\boxed{
(B_m+U_m)\bmod2
=
1-(B_m\bmod2).
}
\]

If the explicit survivor is an ordinary nonnegative integer, then for all
sufficiently large \(m\),
\[
\boxed{B_m\equiv1\pmod2.}
\]

Equivalently, infinitely many even values of \(B_m\) would already exclude
ordinary nonnegative LEVEL 3.

## Exact finite data

For \(m=10,\ldots,20\),
\[
(B_m\bmod2)
=
(1,0,0,0,1,0,0,1,0,1,1).
\]

Thus both values occur in the exact direct range.

The mismatch sequence is
\[
(c_m)
=
(0,1,1,1,0,1,1,0,1,0,0).
\]

So neither event-by-event mismatch nor event-by-event cancellation is true.

## Reduction through the neutral background

For fixed width \(w=1\),
\[
B_m
=
\operatorname{bit}_{F_{t_m}}
(x_{\rm neutral}+\mathcal R_m),
\]
where \(\mathcal R_m\) is rational and exact.

No theorem proving infinitely many zeros of this bit sequence was obtained.

Therefore parity remains the cheapest possible future success route, but it
did not close Task 8.
