# CP19 TASK 6 — DYADIC EVENT CORRECTIONS

Let \(x_{\rm ref}\) be the no-mean-2-excursion reference schedule, keeping
the same high-turnover pair rule and dyadic height tracking.

Each Task-5 excursion is a finite surgery whose cumulative valuation offset
returns to zero before the next event. The event intervals are disjoint.

Therefore
\[
\boxed{
x_S=x_{\rm ref}+\sum_{m\ge10}\delta_m
}
\]
in \(\mathbb Z_2\), with each \(\delta_m\) a finite exact 2-adic correction.

From the finite-surgery lemma,
\[
\boxed{
v_2(\delta_m)=q_m
=
F_{3\cdot2^{m-1}}
-
\left\lfloor\frac{53m}{50}\right\rfloor.
}
\]

For \(m\ge10\), the depths are strongly separated. Since
\[
F_{2t}\ge2F_t
\]
and the height target rises by at most two per dyadic scale,
\[
\boxed{
q_{m+1}\ge2q_m
}
\]
for the packaged event range, and the weaker asymptotic separation is
immediate in general.

Thus all later corrections are zero modulo \(2^{q_{m+1}}\):
\[
\boxed{
x_S\equiv
x_{\rm ref}+\sum_{j\le m}\delta_j
\pmod{2^{q_{m+1}}}.
}
\]

So the correction introduced at scale \(m\) is protected from **later**
surgeries below the next event depth.

## Why this still does not prove ordinary-positive exclusion

A leading odd correction at depth \(q_m\) may cancel the pre-existing
\(q_m\)-block of
\[
x_{\rm ref}+\sum_{j<m}\delta_j.
\]

Later surgeries cannot undo that cancellation, but the earlier/reference
part can already contain precisely the required opposite block.

This is not a technicality. In abstract \(\mathbb Z_2\), for any separated
\(q_m\), set
\[
x_{\rm ref}=1-\sum_m2^{q_m},
\qquad
\delta_m=2^{q_m}.
\]
Then \(x_{\rm ref}\) is nonordinary while
\[
x_{\rm ref}+\sum_m\delta_m=1.
\]

Hence:

\[
\boxed{
\text{infinitely many separated nonzero surgeries}
\not\Rightarrow
\text{nonordinary final realizer}.
}
\]

A schedule-specific theorem must control the reference/pre-event binary
content at the correction depths.
