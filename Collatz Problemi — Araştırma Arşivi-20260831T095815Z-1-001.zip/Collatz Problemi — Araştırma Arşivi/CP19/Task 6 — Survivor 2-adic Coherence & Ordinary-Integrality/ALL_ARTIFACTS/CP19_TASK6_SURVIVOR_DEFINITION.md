# CP19 TASK 6 — SOURCE-ACCURATE SURVIVOR DEFINITION

The canonical Task-5 survivor is taken from `CP19_TASK5_COMPUTE.py`, not
reconstructed from prose.

## Canonical microscopic convention

1. At every even pair `(j,j+1)`, the source chooses the **first** phase-one
   site if both sites are available:
   - if `b_j=1`, neutral pair `(d_j,d_{j+1})=(+1,-1)`;
   - otherwise `(-1,+1)`.

2. Baseline height tracking uses
\[
\text{target}(j+2)=\left\lfloor\frac{53}{50}L_{j+2}\right\rfloor.
\]
If the current pair-boundary height is below target, the negative member of
the neutral pair is changed to zero, giving net `+1`.

3. For each `m>=10`,
\[
t_m=3\cdot2^{m-1},\qquad \ell_m=\lfloor m/2\rfloor.
\]
The special negative defect is placed at the **last step**
`t_m-1` of the window.

4. Its exact size is the minimum positive integer making the special window
have total valuation at least `2 ell_m`; in the canonical source it gives
the prescribed exact mean-2 window at the tested large scales.

5. Recovery is greedy: use the earliest available phase-valid upward
capacity relative to the baseline until the cumulative offset returns to zero.

There is therefore no ambiguity in the frozen canonical Task-5 source.

## Independent reproduction

Two separately written generators were compared at
\[
N=2^{10},2^{12},2^{14},2^{16},2^{18},2^{20}.
\]
They agree byte-for-byte in `d_k`, the baseline defects, and event metadata.

Alternative pair ordering / delayed-recovery rules are tested only as
**family variants**, never substituted for the canonical survivor.
