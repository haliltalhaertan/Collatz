from __future__ import annotations
from array import array
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q;hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def L(k):return k.bit_length()-1 if k else 0
def g(k):return F(k+1)-F(k)
def b(k):return g(k)-1
def v2(x):return (x & -x).bit_length()-1
def neutral_pair(k,mode="first"):
    if mode=="first":
        if b(k)==1:return 1,-1
        assert b(k+1)==1;return -1,1
    if b(k+1)==1:return -1,1
    assert b(k)==1;return 1,-1
def gain_pair(k,mode="first"):
    x,y=neutral_pair(k,mode)
    if x<0:x=0
    else:y=0
    return x,y

def finite_surgery_delta(A,A2,j0,j1,modbits=128):
    mod=1<<modbits
    ans=0
    for j in range(j0,j1):
        if A[j]==A2[j]:continue
        ans=(ans-((pow(2,A2[j],mod)-pow(2,A[j],mod))*pow(pow(3,j+1,mod),-1,mod)))%mod
    return ans
def test():
    # Synthetic exact lemma checks.
    for q in [5,11,23]:
        # cumulative exponents: first difference at index 2, then return.
        A=[0,q-2,q,q+2,q+4,q+6]
        A2=[0,q-2,q+1,q+3,q+4,q+6]
        d=finite_surgery_delta(A,A2,2,4,128)
        assert v2(d)==q
    # Generic cancellation counterexample to "separated corrections preserve nonordinary".
    qs=[10,30,70,150]
    mod=1<<200
    corr=sum(1<<q for q in qs)
    xref=(1-corr)%mod
    assert (xref+corr)%mod==1
    print("CP19 TASK6 SURGERY CHECK: OK")
if __name__=="__main__":test()
