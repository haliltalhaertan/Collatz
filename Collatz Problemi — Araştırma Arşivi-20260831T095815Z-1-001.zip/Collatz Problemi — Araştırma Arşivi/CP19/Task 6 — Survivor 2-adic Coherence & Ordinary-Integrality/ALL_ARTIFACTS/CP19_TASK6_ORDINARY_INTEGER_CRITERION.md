# CP19 TASK 6 — ORDINARY-INTEGER CRITERION

Let \(x\in\mathbb Z_2\) be the unique inverse-limit realizer of an infinite
positive valuation word. Let
\[
1\le \rho_R<2^{A_R+1},
\qquad
\rho_R\equiv x\pmod{2^{A_R+1}}
\]
be the canonical positive cylinder residue.

Because \(A_R\ge R\), the modulus depths tend to infinity.

## Theorem

\[
\boxed{
x\in\mathbb Z_{\ge0}
\iff
\rho_R\ \text{is eventually constant as an ordinary integer}.
}
\]

### Forward direction

If \(x=n\ge0\), choose \(R_0\) with
\[
2^{A_R+1}>n\qquad(R\ge R_0).
\]
The canonical representative of \(n\bmod2^{A_R+1}\) is then exactly \(n\).
Thus \(\rho_R=n\) forever after.

### Reverse direction

If \(\rho_R=C\) for all \(R\ge R_0\), then
\[
x\equiv C\pmod{2^{A_R+1}}
\]
for arbitrarily large depths, hence \(x=C\) in \(\mathbb Z_2\).

The valuation word is odd, so \(C=0\) cannot be the realized start.

## Distinctions

- positive ordinary integer: binary tail eventually zero;
- negative ordinary integer: canonical truncations look like \(2^M-c\), not constant;
- rational noninteger in \(\mathbb Q\cap\mathbb Z_2\): eventually periodic binary tail;
- genuinely nonrational 2-adic: no such classification.

## Exact Engine-B specification repair

For
\[
q_R=-\sum_{j<R}\frac{2^{A_j}}{3^{j+1}}
=-\frac{B_R}{3^R},
\]
the finite cylinder residue is **not**
\(q_R\bmod2^{A_R+1}\).

Instead
\[
\boxed{
\rho_R
\equiv
q_R+2^{A_R}3^{-R}
\pmod{2^{A_R+1}}.
}
\]

Since \(3^{-R}\) is odd,
\[
\boxed{
\rho_R-q_R\equiv2^{A_R}\pmod{2^{A_R+1}}.
}
\]

Only modulo \(2^{A_R}\) does \(\rho_R\equiv q_R\) hold.

This was independently reproduced at every common engine depth. It is a
proof-critical one-bit repair to the Task-6 prompt's raw Engine-B
comparison condition, not a change to the inverse-limit series itself.
