from __future__ import annotations
from array import array
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q;hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def L(k):return k.bit_length()-1 if k else 0
def g(k):return F(k+1)-F(k)
def b(k):return g(k)-1
def v2(x):return (x & -x).bit_length()-1
def neutral_pair(k,mode="first"):
    if mode=="first":
        if b(k)==1:return 1,-1
        assert b(k+1)==1;return -1,1
    if b(k+1)==1:return -1,1
    assert b(k)==1;return 1,-1
def gain_pair(k,mode="first"):
    x,y=neutral_pair(k,mode)
    if x<0:x=0
    else:y=0
    return x,y

def generate(N,p=53,q=50,m0=10):
    base=array("b",[0])*N;height=0
    for j in range(0,N-1,2):
        target=p*L(j+2)//q
        if height<target:
            x,y=gain_pair(j);height+=1
        else:x,y=neutral_pair(j)
        base[j]=x;base[j+1]=y
    d=array("b",base);meta=[]
    for m in range(m0,L(N)+1):
        t=3*(1<<(m-1))
        if t>=N-16:break
        ell=max(2,m//2);v=t-ell
        A0=sum(g(k)-base[k] for k in range(v,t))
        R=max(1,2*ell-A0);drop=t-1
        d[drop]-=R;rem=R;k=t
        while rem:
            cap=b(k)-base[k]
            if cap>0:d[k]+=1;rem-=1
            k+=1
        assert sum(d[drop:k])-sum(base[drop:k])==0
        meta.append((m,v,t,ell,R,drop,k))
    return d,base,meta
if __name__=="__main__":
    d,b0,m=generate(1<<18)
    print("CP19 TASK6 SCHEDULE B: OK",len(m))
