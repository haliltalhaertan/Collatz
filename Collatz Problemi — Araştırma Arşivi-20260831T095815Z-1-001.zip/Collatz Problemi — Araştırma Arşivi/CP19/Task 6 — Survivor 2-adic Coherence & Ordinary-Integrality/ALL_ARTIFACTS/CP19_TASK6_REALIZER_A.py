from __future__ import annotations
from array import array
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q;hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def L(k):return k.bit_length()-1 if k else 0
def g(k):return F(k+1)-F(k)
def b(k):return g(k)-1
def v2(x):return (x & -x).bit_length()-1
def neutral_pair(k,mode="first"):
    if mode=="first":
        if b(k)==1:return 1,-1
        assert b(k+1)==1;return -1,1
    if b(k+1)==1:return -1,1
    assert b(k)==1;return 1,-1
def gain_pair(k,mode="first"):
    x,y=neutral_pair(k,mode)
    if x<0:x=0
    else:y=0
    return x,y

def combine(X,Y):
    r1,A1,P1,B1=X;r2,A2,P2,B2=Y
    return r1+r2,A1+A2,P1*P2,P2*B1+(1<<A1)*B2
def invpow2(a,nb):
    x=1;bits=1
    while bits<nb:
        nb2=min(2*bits,nb);mask=(1<<nb2)-1
        x=(x*(2-a*x))&mask;bits=nb2
    return x
def cylinder(word):
    stack=[None]*32
    for a in word:
        cur=(1,a,3,1);lv=0
        while stack[lv] is not None:
            cur=combine(stack[lv],cur);stack[lv]=None;lv+=1
        stack[lv]=cur
    T=None
    for lv in range(len(stack)-1,-1,-1):
        if stack[lv] is not None:T=stack[lv] if T is None else combine(T,stack[lv])
    r,A,P,B=T;mask=(1<<(A+1))-1
    rho=(((1<<A)-B)*invpow2(P,A+1))&mask
    return rho,A
if __name__=="__main__":
    print("CP19 TASK6 REALIZER A: READY")
