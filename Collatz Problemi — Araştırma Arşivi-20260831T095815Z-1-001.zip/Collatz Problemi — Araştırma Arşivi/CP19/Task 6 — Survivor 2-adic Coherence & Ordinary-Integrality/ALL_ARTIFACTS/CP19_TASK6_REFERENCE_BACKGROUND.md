# CP19 TASK 6 — REFERENCE BACKGROUND

The reference background is defined source-accurately by deleting the
mean-2 dyadic excursion surgeries while keeping:

- the canonical Task-9-style first-phase-one neutral pair convention;
- the same `53/50` dyadic height tracking;
- the same sparse gain-pair adjustments.

Call its unique 2-adic realizer \(x_{\rm ref}\).

Then
\[
s_k^{\rm ref}=\frac{53}{50}\log_2k+O(1),
\]
outside microscopic pair oscillations, and its carry is summable.

## Exact relation to the survivor

\[
\boxed{
x_S=x_{\rm ref}+\sum_{m\ge10}\delta_m,
\qquad
v_2(\delta_m)=q_m\to\infty.
}
\]

Because the first surgery depth is \(q_{10}=2424\),
\[
x_S\equiv x_{\rm ref}\pmod{2^{2424}}.
\]

This explains why all deep survivor/reference prefixes have identical low
64-bit truncations in the packaged computations.

## Classification

No exact rational, negative-integer, positive-integer, or nonrational
classification of \(x_{\rm ref}\) was obtained.

Its canonical residues continue to acquire high binary information through
all tested dyadic depths, but finite nonstabilization is not a theorem.

The reference background is therefore itself an unresolved LEVEL-3
coherence object. This is precisely why finite-surgery separation alone
cannot classify \(x_S\).

Status:
\[
\boxed{[OPEN]}.
\]
