# COLLATZ CP19 — TASK 6 FINDINGS
## Explicit Survivor 2-adic Coherence & Ordinary-Integrality

## Final strategic verdict

\[
\boxed{\textbf{B — [LEAD: NONSTABILIZATION STRUCTURE FOUND]}}
\]

The explicit Task-5 survivor is **not** proved nonordinary-positive.
No Side-B theorem appears.

## 1. Exact schedule reproduction

Two independent schedule generators agree exactly for
\[
N=2^{10},2^{12},2^{14},2^{16},2^{18},2^{20}.
\]

The canonical microscopic convention is therefore reconciled.

## 2. Proof-critical Engine-B repair

The raw Task-6 prompt asked to compare the finite partial sum
\[
q_R=-\sum_{j<R}2^{A_j}/3^{j+1}
\]
directly to \(\rho_R\) modulo \(2^{A_R+1}\).

That statement is off by exactly the terminal top bit.

The correct identity is
\[
\boxed{
\rho_R
\equiv
q_R+2^{A_R}3^{-R}
\pmod{2^{A_R+1}}.
}
\]

Since \(3^{-R}\) is odd,
\[
\rho_R-q_R\equiv2^{A_R}\pmod{2^{A_R+1}}.
\]

After this repair, the two independent realizer engines agree exactly at
all common tested depths through \(R=16384\).

## 3. Ordinary-positive criterion

\[
\boxed{
x_S\in\mathbb Z_{\ge0}
\iff
\rho_R\ \text{eventually stabilizes as an ordinary integer}.
}
\]

This remains the decisive LEVEL-3 criterion.

## 4. New exact finite-surgery lemma

If two valuation schedules differ only through a finite cumulative-valuation
surgery and \(j_0\) is the first changed cumulative prefix, then
\[
\boxed{
v_2(x'-x)=\min(A_{j_0},A'_{j_0}).
}
\]

For the \(m\)-th Task-5 dyadic event,
\[
\boxed{
v_2(\delta_m)
=
q_m
=
F_{t_m}-\left\lfloor\frac{53m}{50}\right\rfloor.
}
\]

Every normalized event correction is an odd 2-adic unit.

The event depths are rapidly separated; later events cannot modify lower
correction bands.

This is genuine new infinite-structure information.

## 5. What deep computation says

Events \(m=10,\ldots,20\) were tracked exactly.

For each event:

- the correction valuation is exactly \(q_m\);
- the 64-bit normalized correction unit is odd;
- the special block contains at least one nonzero canonical lift in every
  tested event;
- after enough post-event steps the final \(x_S\) block beginning at \(q_m\)
  is nonzero in all 11 tested scales.

Global lift scan through
\[
R=2^{18}=262144
\]
finds

- `166224` nonzero lifts;
- last nonzero lift at `262142`;
- longest zero-lift plateau `10`;
- \(\rho_R\) bitlength `415469` with \(A_R=415469\).

These are `[CERTIFIED NUM]`, never an infinite theorem.

## 6. Why separated corrections are not enough

Although
\[
x_S=x_{\rm ref}+\sum_m\delta_m,
\qquad
v_2(\delta_m)=q_m,
\]
an earlier/reference binary block may cancel the odd correction at \(q_m\).

There is an exact generic counterexample:
\[
x_{\rm ref}=1-\sum_m2^{q_m},
\qquad
\delta_m=2^{q_m},
\]
for which the final sum is the ordinary integer 1.

Therefore H8 in unrestricted form is false.

## 7. Reference background

The no-excursion high-turnover reference realizer \(x_{\rm ref}\) was
computed in parallel.

Its deep canonical prefixes remain high-bit nonstabilizing numerically, but
no exact classification was found.

\[
\boxed{x_{\rm ref}\text{ classification }[OPEN].}
\]

Without control of its bits near \(q_m\), the surgery theorem cannot force
final nonzero bits.

## 8. Microscopic variants

Alternative phase-valid pair ordering, one-site delayed recovery, and
nearby rational \(\kappa>\kappa_*\) variants were scanned.

None showed finite stabilization through \(R=8192\); longest zero-lift
plateaus remained small.

This is only adversarial finite evidence. No variant positive LEVEL-3
counterexample was proved.

## 9. Rationality diagnostics

No rational candidate with numerator/denominator bounded by \(2^{64}\)
survived rational reconstruction at the tested deep truncations.

This does not exclude rationality.

## 10. The exact missing lemma

To exclude \(x_S\in\mathbb Z_{>0}\), it would suffice to prove one of:

1. infinitely many event depths \(q_m\) contain a final nonzero protected
   block;
2. the pre-event/reference block cannot equal the unique cancelling block
   for all large \(m\);
3. the event-level canonical residues change infinitely often;
4. the reference background has a classified binary tail incompatible with
   the odd correction units.

None is proved.

The problem has therefore been sharpened to a specific event-level
infinite-coherence statement rather than a global occupation/growth
inequality.
