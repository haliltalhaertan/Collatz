from __future__ import annotations
from array import array
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q;hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def L(k):return k.bit_length()-1 if k else 0
def g(k):return F(k+1)-F(k)
def b(k):return g(k)-1
def v2(x):return (x & -x).bit_length()-1
def neutral_pair(k,mode="first"):
    if mode=="first":
        if b(k)==1:return 1,-1
        assert b(k+1)==1;return -1,1
    if b(k+1)==1:return -1,1
    assert b(k)==1;return 1,-1
def gain_pair(k,mode="first"):
    x,y=neutral_pair(k,mode)
    if x<0:x=0
    else:y=0
    return x,y

# Lightweight event-level theorem-regression engine.
def event_depth(m):
    t=3*(1<<(m-1))
    return F(t)-(53*m//50)
def check():
    last=None
    for m in range(10,21):
        q=event_depth(m)
        if last is not None:
            assert q>=2*last
        last=q
    print("CP19 TASK6 EVENT ENGINE: OK")
if __name__=="__main__":check()
