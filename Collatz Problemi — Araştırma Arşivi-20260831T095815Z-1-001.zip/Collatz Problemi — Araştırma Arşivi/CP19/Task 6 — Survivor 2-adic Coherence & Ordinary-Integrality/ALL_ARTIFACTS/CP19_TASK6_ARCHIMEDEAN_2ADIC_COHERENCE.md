# CP19 TASK 6 — ARCHIMEDEAN–2-ADIC COHERENCE

Task 5 gives
\[
X_\infty<\infty.
\]

If the explicit survivor had a fixed positive ordinary realizer
\[
x_S=n_0>0,
\]
then
\[
U_k=1+\frac{X_k}{3n_0}\to U_\infty\in(1,\infty),
\]
and
\[
n_k=n_0U_k2^{s_k+\{\alpha k\}}.
\]

Outside excursion cores,
\[
s_k=\frac{53}{50}\log_2k+O(1),
\]
so
\[
\boxed{
n_k=k^{53/50+o(1)}
}
\]
along the ordinary baseline.

At the exact mean-2 special window,
\[
2^{2\ell_m}n_{\rm out}
=
3^{\ell_m}n_{\rm in}
+
B_m^{\rm window},
\]
whose multiplicative part is
\[
(3/4)^{\ell_m}.
\]

The recovery then restores the discrepancy baseline.

All of this is Archimedeanly compatible with a hypothetical polynomially
divergent positive orbit. No contradiction follows from superlinear state
growth itself.

The selected dyadic state scaling, bounded \(X\)-tail, and integer-valued
states did not yield an exact incompatible subsequence law.

Thus the Archimedean route remains:
\[
\boxed{[\mathrm{OPEN}]}.
\]

The missing ingredient is not another growth estimate. It is a theorem
linking these dyadic state maps to eventual-zero binary tail of the same
ordinary start.
