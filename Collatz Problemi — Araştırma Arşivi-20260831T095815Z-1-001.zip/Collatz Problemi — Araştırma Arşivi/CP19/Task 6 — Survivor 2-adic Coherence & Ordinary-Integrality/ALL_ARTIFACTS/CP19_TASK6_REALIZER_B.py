from __future__ import annotations
from array import array
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q;hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def L(k):return k.bit_length()-1 if k else 0
def g(k):return F(k+1)-F(k)
def b(k):return g(k)-1
def v2(x):return (x & -x).bit_length()-1
def neutral_pair(k,mode="first"):
    if mode=="first":
        if b(k)==1:return 1,-1
        assert b(k+1)==1;return -1,1
    if b(k+1)==1:return -1,1
    assert b(k)==1;return 1,-1
def gain_pair(k,mode="first"):
    x,y=neutral_pair(k,mode)
    if x<0:x=0
    else:y=0
    return x,y

def invpow2(a,nb):
    x=1;bits=1
    while bits<nb:
        nb2=min(2*bits,nb);mask=(1<<nb2)-1
        x=(x*(2-a*x))&mask;bits=nb2
    return x
def cylinder_from_partial_sum(word):
    As=[];A=0
    for a in word:As.append(A);A+=a
    mask=(1<<(A+1))-1
    inv3=invpow2(3,A+1);ip=inv3;qR=0
    for Aj in As:
        qR=(qR-((ip<<Aj)&mask))&mask
        ip=(ip*inv3)&mask
    # SPEC REPAIR:
    # rho_R = q_R + 2^A * 3^{-R} mod 2^(A+1).
    # 3^{-R} is odd, so the correction is exactly 2^A at this modulus.
    rho=(qR+(1<<A))&mask
    return rho,A,qR
if __name__=="__main__":
    print("CP19 TASK6 REALIZER B: READY")
