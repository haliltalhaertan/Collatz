# CP19 TASK 6 — FINITE SURGERY LEMMA

Let \(a,a'\) be two positive valuation sequences and
\[
A_j=\sum_{i<j}a_i,\qquad A'_j=\sum_{i<j}a'_i.
\]

Assume their cumulative sums agree before the surgery and again after a
finite interval. Let
\[
j_0=\min\{j:A'_j\ne A_j\}.
\]

Their inverse-limit realizers satisfy
\[
x'-x
=
-\sum_j
\frac{2^{A'_j}-2^{A_j}}{3^{j+1}},
\]
and only finitely many summands are nonzero.

## Exact valuation theorem

\[
\boxed{
v_2(x'-x)
=
\min(A_{j_0},A'_{j_0}).
}
\]

### Proof

The first nonzero term is
\[
-\frac{2^{A'_{j_0}}-2^{A_{j_0}}}{3^{j_0+1}}.
\]
Because the exponents differ,
\[
v_2(2^u-2^v)=\min(u,v).
\]
The denominator is a 2-adic unit.

For every later \(j>j_0\), both \(A_j\) and \(A'_j\) are strictly larger
than their corresponding values at \(j_0\), because all valuations are
positive. Therefore every later nonzero summand has strictly larger
2-adic valuation. Cancellation of the leading term is impossible.

QED.

## Task-5 event specialization

The canonical event changes \(a_{t_m-1}\) first, so the first changed
cumulative prefix is \(j_0=t_m\).

Relative to the no-excursion reference background,
\[
A_{\rm event}(t_m)=A_{\rm ref}(t_m)+R_m.
\]
Hence
\[
\boxed{
v_2(\delta_m)
=
A_{\rm ref}(t_m)
=
q_m.
}
\]

For the source schedule and \(m\ge10\),
\[
\boxed{
q_m
=
F_{t_m}-\left\lfloor\frac{53m}{50}\right\rfloor.
}
\]

The normalized correction
\[
u_m=\delta_m/2^{q_m}
\]
is always an odd 2-adic unit.

This lemma is `[PROVED]`. It does **not** by itself imply that the final
survivor has a nonzero bit at every \(q_m\).
