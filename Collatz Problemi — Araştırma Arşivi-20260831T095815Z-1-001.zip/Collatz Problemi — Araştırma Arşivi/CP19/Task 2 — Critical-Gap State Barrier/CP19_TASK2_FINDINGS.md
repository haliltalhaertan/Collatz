# COLLATZ CP19 — TASK 2 FINDINGS
## Critical-Gap State Barrier

\[
\boxed{\textbf{B — [LEAD: CONSTRUCTION-A GAP COST GROWS]}}
\]

No Construction-A positive LEVEL-3 exclusion is proved.

## 1. Ne test edildi?

Construction A'da defectler arasında giderek uzayan exact critical blocks var:
\[
a_k=g_k.
\]
Bir critical block başlangıcındaki positive state'in minimum değeri
\[
M(u,r)
\]
exact cylinder ile hesaplandı.

Hedef:
\[
M(u_j,r_j)
\quad\text{vs}\quad
n_{u_j}\le P(u_j;n_0).
\]

## 2. Local critical cylinder exact

For
\[
G=F_{u+r}-F_u
\]
and
\[
B_{\rm crit}=\sum_{j<r}3^{r-1-j}2^{F_{u+j}-F_u},
\]
\[
2^G n_{u+r}=3^r n_u+B_{\rm crit}.
\]
The unique exact odd cylinder is
\[
n_u\equiv
3^{-r}(2^G-B_{\rm crit})
\pmod{2^{G+1}}.
\]
Its canonical positive representative is the true minimum state
\[
\boxed{M(u,r)}.
\]

Two independent implementations agree exactly on all moderate regression blocks.

## 3. Universal critical-gap falsification search

Because \(g_k-1\) is a Sturmian mechanical word, the number of distinct length-\(r\) factors is exactly \(r+1\).

For each
\[
r=16,32,\ldots,16384
\]
all \(r+1\) distinct factors were collected and their exact minimum positive critical cylinders were computed.

No bounded/polynomial collapse was found.

Selected minima:

| r | all factors | min bits(M) | modulus bits | log2(M)/r |
|---:|---:|---:|---:|---:|
| 64 | 65 | 97 | 102 | 1.50835 |
| 256 | 257 | 399 | 406 | 1.55590 |
| 1024 | 1025 | 1614 | 1624 | 1.57597 |
| 4096 | 4097 | 6482 | 6493 | 1.58230 |
| 16384 | 16385 | 25957 | 25969 | 1.58427 |

This is `[CERTIFIED NUM]`, not a universal theorem.

## 4. Construction-A gaps

For the long gaps already reachable under the exact Task-1 schedule, the minimum state remains essentially full-modulus sized.

Examples:

| u | r | G | bits(M) | log2(M)/r | log2(M)/log2(u) |
|---:|---:|---:|---:|---:|---:|
| 53 | 41 | 64 | 64 | 1.56098 | 11.17 |
| 1095 | 954 | 1512 | 1512 | 1.58491 | 149.75 |
| 7283 | 6516 | 10327 | 10328 | 1.58502 | 804.97 |
| 49934 | 45393 | 71946 | 71947 | 1.58498 | 4609.7 |
| 349527 | 321562 | 509663 | 509663 | 1.58496 | 27676.4 |

Again: finite exact evidence only.

## 5. Gap growth theorem

Construction A has
\[
p_m=\frac{2^m}{m+1}+O(1).
\]
Hence consecutive critical gap length \(R_m\) satisfies
\[
\boxed{\frac{R_m}{u_m}\to1}
\]
and therefore
\[
\boxed{\frac{R_m}{\log u_m}\to\infty}.
\]

This part is theorem-level.

## 6. Fixed-positive state upper bound

Assume
\[
x_A=n_0>0.
\]
Then the exact Construction-A dynamics gives, for \(k\ge53\),
\[
\boxed{
n_k<
8192\,k(2\log_2 k+1)
\left[
n_0+\frac{52}{3}
+\frac{1+\ln(2\log_2 k)}{3072}
\right].
}
\]

Thus
\[
n_k=O_{n_0}(k\log k\log\log k).
\]

This upper half is proved.

## 7. Why the contradiction is still missing

If one could prove only
\[
\frac{\log M(u_j,r_j)}{\log u_j}\to\infty,
\]
then \(M_j\) would eventually beat the explicit fixed-\(n_0\) upper bound and Construction A would be excluded.

The computed ratios explode numerically:
\[
11,\ 149,\ 805,\ 4609,\ 27676,\ldots
\]
but no theorem forces this trend forever.

A future small-residue collapse cannot be excluded from finite data.

Therefore:
\[
\boxed{\text{Construction A positive LEVEL 3 remains OPEN.}}
\]

## 8. Redundancy check

This is not merely CP18 Task 1/2:

- the block is the exact Beatty/Sturmian critical word;
- starts are the deterministic Construction-A gap starts;
- the intended contradiction couples local cylinder cost to one fixed orbit's Archimedean state bound.

However, without the asymptotic \(M_j\) lower theorem the bridge is not complete.

## 9. Required theorem table

| Question | Verdict | Evidence |
|---|---|---|
| Is local critical cylinder formula exact? | `[EXACT] YES` | affine identity + two implementations |
| Is M(u,r) the true minimum positive state? | `[EXACT] YES` | unique odd cylinder |
| Is there a universal exponential lower bound in r? | `[OPEN]` | exhaustive finite support only |
| Are there arbitrarily long small-residue critical phases? | `[OPEN]` | none found through r=16384 |
| How do Construction-A gap lengths grow? | `[PROVED]` | \(r_j/u_j\to1\) |
| Is M_j exponential in r_j? | `[OPEN / CERTIFIED NUM SUPPORT]` | through r=321562 |
| Is M_j superpolynomial in u_j? | `[OPEN / CERTIFIED NUM SUPPORT]` | exact power certificates |
| What is exact Construction-A state upper bound? | `[PROVED]` | explicit formula above |
| Does M_j eventually beat every fixed-n0 upper bound? | `[OPEN]` | missing asymptotic lower theorem |
| Is positive Construction-A LEVEL 3 excluded? | **NO** | missing lower theorem |
| Is this new vs CP18 Tasks 1/2/7/10? | `[NEW LEAD, PARTIAL THEOREMS]` | special gaps + Archimedean collision |
| Does result generalize to sparse-gap families? | `[OPEN]` | conditional framework only |
| Do we have Side B? | **NO** | positive branch not excluded |

# User-facing summary

## Ne denedik?

Uzun critical boşlukların bir sayıyı çok büyük olmaya zorlayıp zorlamadığını test ettik.

## Ne bulduk?

Bugüne kadar hesaplayabildiğimiz Construction-A boşluklarında gereken minimum state neredeyse tam \(2^G\) büyüklüğünde. Küçük-residue çökmesi bulamadık.

## Uzun boşluk gerçekten exponential maliyet yaratıyor mu?

Hesaplarda evet görünüyor. Ama bunun sonsuza kadar böyle olduğunu henüz kanıtlamadık.

## Aynı tek Collatz sayısı bu maliyeti karşılayabiliyor mu?

Eğer Construction A'yı tek bir pozitif sayı gerçekleştiriyorsa, onun state'i için yalnız poly/polylog büyüyen explicit bir üst sınır kanıtladık. Bu yüzden exponential gap maliyeti theorem olursa çelişki çıkar.

## Construction A artık elendi mi?

Hayır. Eksik parça, critical-gap minimum state'in gelecekte küçük bir residue'ye çökemeyeceğini kanıtlamak.

## Bunun genel Collatz problemine etkisi ne?

Henüz Side B değil. Fakat finite-prefix esnekliğini aşabilecek gerçek bir LEVEL-3 köprünün tam olarak hangi lemma'ya ihtiyaç duyduğunu izole ettik.

## Sıradaki en yüksek bilgi değerli soru ne?

Shifted critical-tail realizers \(x_u^{crit}\) için canonical truncation'ların neden sürekli full-modulus ölçekte kaldığını açıklayan bir Sturmian/2-adic lower-bound mekanizması aramak.
