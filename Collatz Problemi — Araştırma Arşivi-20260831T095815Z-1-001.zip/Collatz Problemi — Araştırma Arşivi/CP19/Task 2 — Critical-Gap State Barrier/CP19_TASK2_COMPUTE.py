#!/usr/bin/env python3
from __future__ import annotations
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q; hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def g(k):return F(k+1)-F(k)
def v2(x):return (x & -x).bit_length()-1

from CP19_TASK2_CRITICAL_RESIDUE_A import rho_direct
from CP19_TASK2_CRITICAL_RESIDUE_B import rho_lift
def main():
    tests=[(53,41),(95,77),(173,143),(317,269),(1095,954)]
    for u,r in tests:
        a=rho_direct(u,r); b=rho_lift(u,r)
        assert a==b,(u,r)
    # exact local affine formula sanity
    for u,r in tests:
        rho,G=rho_direct(u,r)
        n=rho
        for k in range(u,u+r):
            x=3*n+1; aa=v2(x)
            assert aa==g(k)
            n=x>>aa
    print("CP19 TASK2 CROSS-CHECKS: OK")
if __name__=="__main__": main()
