# CP19 TASK 2 — ARCHIMEDEAN UPPER BOUND

Assume, only for this section, that the Construction-A inverse-limit realizer is one fixed positive integer
\[
x_A=n_0\in\mathbb Z_{>0}.
\]

Then Construction A is the actual valuation sequence of that positive orbit.

## Exact state identity

The frozen state/carry identity gives
\[
n_k=n_0U_k2^{s_k+\{k\alpha\}},
\qquad
U_k=1+\frac{X_k}{3n_0},
\]
where
\[
X_k=\sum_{j<k}2^{-s_j-\{j\alpha\}}.
\]
Hence
\[
\boxed{
n_k<2\,2^{s_k}\left(n_0+\frac{X_k}{3}\right).
}
\]

## Explicit bound on \(2^{s_k}\)

For the long sparse schedule, after \(m\ge9\),
\[
p_m\in\{r_m,r_m+1\},
\qquad
r_m=\left\lceil\frac{2^m}{m+1}\right\rceil.
\]

For a time \(k\) in the \(m\)-th long interval,
\[
s_k\le12+m.
\]
Since \(k\ge p_m\ge2^m/(m+1)\),
\[
2^m\le k(m+1).
\]
For \(m\ge9\), \(m+1\le2^{m/2}\), so
\[
m\le2\log_2 k.
\]
Therefore
\[
\boxed{
2^{s_k}
\le
4096\,k(2\log_2 k+1).
}
\]

## Direct Construction-A carry bound

For \(m\ge9\),
\[
p_{m+1}-p_m\le \frac{2^{m+1}}m.
\]
On the whole interval \([p_m,p_{m+1})\),
\[
s_j\ge11+m.
\]
Therefore its carry contribution is at most
\[
\frac{2^{m+1}}m\,2^{-(m+11)}
=
\frac1{1024m}.
\]

Before \(p_9=52\) there are at most 52 summands, each at most one. Thus for \(k\ge53\),
\[
\boxed{
X_k
\le
52+\frac{1+\ln(2\log_2 k)}{1024}.
}
\]

## Explicit fixed-orbit upper envelope

Combining the preceding bounds gives, for \(k\ge53\),
\[
\boxed{
n_k<
8192\,k(2\log_2 k+1)
\left[
n_0+\frac{52}{3}
+\frac{1+\ln(2\log_2 k)}{3072}
\right].
}
\]

Thus
\[
\boxed{
n_k=O_{n_0}(k\log k\log\log k).
}
\]

The displayed explicit formula is the bound used in Task 2. No uniformity in unknown \(n_0\) is required: an eventual superpolynomial lower bound for \(M(u_j,r_j)\) would beat the fixed \(n_0\)-dependent constant.

## Status

`[PROVED UNDER POSITIVE LEVEL-3 ASSUMPTION]`.

The upper half of the hoped-for collision is valid. The lower half remains open.
