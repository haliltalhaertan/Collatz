#!/usr/bin/env python3
from __future__ import annotations
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q; hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def g(k):return F(k+1)-F(k)
def v2(x):return (x & -x).bit_length()-1

def rho_direct(u,r):
    A=B=0; P=1
    for k in range(u,u+r):
        a=g(k)
        B=3*B+(1<<A); P*=3; A+=a
    M=1<<(A+1)
    rho=(((1<<A)-B)*pow(P,-1,M))%M
    return rho,A
if __name__=="__main__":
    for u,r in [(53,41),(95,77),(173,143),(1095,954)]:
        rho,A=rho_direct(u,r)
        print(u,r,A,rho.bit_length(),rho & ((1<<64)-1))
