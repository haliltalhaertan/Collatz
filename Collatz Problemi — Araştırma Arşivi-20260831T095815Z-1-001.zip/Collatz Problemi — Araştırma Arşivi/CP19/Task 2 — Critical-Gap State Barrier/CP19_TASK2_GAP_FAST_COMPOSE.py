#!/usr/bin/env python3
from __future__ import annotations
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q; hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def g(k):return F(k+1)-F(k)
def v2(x):return (x & -x).bit_length()-1

def all_factors_minimum(r,max_scan=500000):
    # Sturmian complexity is r+1; scan until all distinct factors are collected.
    A=B=0; code=0
    for j in range(r):
        a=g(j)
        if a==2: code|=1<<j
        B=3*B+(1<<A); A+=a
    P=pow(3,r); seen={}; inv_cache={}; u=0
    while u<max_scan and len(seen)<r+1:
        G=F(u+r)-F(u)
        if code not in seen:
            bits=G+1
            inv=inv_cache.setdefault(bits,pow(P,-1,1<<bits))
            rho=(((1<<G)-B)*inv)&((1<<bits)-1)
            seen[code]=(u,rho,G)
        g0=g(u)
        B=(3*B-P+(1<<G))>>g0
        code=(code>>1)|((g(u+r)-1)<<(r-1))
        u+=1
    assert len(seen)==r+1
    return min(seen.values(),key=lambda x:x[1]),u
if __name__=="__main__":
    for r in [64,256,1024,4096]:
        (u,M,G),scan=all_factors_minimum(r)
        print(r,u,M.bit_length(),G+1,scan)
