# CP19 TASK 2 — CRITICAL GAP THEOREM PACKAGE

## Status

The exact local cylinder, the Construction-A gap asymptotics, and the fixed-positive Archimedean upper bound are proved.

The missing load-bearing statement is an asymptotic lower bound on the Construction-A critical-gap minimum states. Therefore **Construction A is not excluded in Task 2**.

## 1. Exact critical block

Let
\[
g_k=F_{k+1}-F_k,\qquad F_k=\lfloor k\log_2 3\rfloor,
\]
and
\[
w_{\rm crit}(u,r)=(g_u,\ldots,g_{u+r-1}).
\]
Its total valuation is exactly
\[
\boxed{G(u,r)=F_{u+r}-F_u}.
\]

Put
\[
G_j=F_{u+j}-F_u.
\]
Then
\[
\boxed{
2^G n_{u+r}=3^r n_u+B_{\rm crit}(u,r)
}
\]
with
\[
\boxed{
B_{\rm crit}(u,r)=
\sum_{j=0}^{r-1}3^{r-1-j}2^{G_j}.
}
\]

Exact terminal oddness yields one unique odd start cylinder
\[
\boxed{
n_u\equiv
\rho_{\rm crit}(u,r)
=
3^{-r}(2^G-B_{\rm crit})
\pmod{2^{G+1}}.
}
\]

Let \(M(u,r)\) be its canonical representative in
\[
1\le M(u,r)<2^{G+1}.
\]
Every positive integer realizing the exact block is
\[
M(u,r)+q2^{G+1},\qquad q\ge0.
\]
Hence
\[
\boxed{n_u\ge M(u,r)}
\]
and \(M(u,r)\) is the true minimum positive critical-block state.

## 2. Independent computation

Implementation A uses the affine formula above.

Implementation B grows the exact cylinder one valuation at a time. If a length-\(R\) prefix has canonical start \(\rho\), endpoint \(y\), total valuation \(A\), and \(P=3^R\), then after replacing the start by
\[
\rho+\lambda2^{A+1}
\]
the old endpoint becomes
\[
y+2\lambda P.
\]
The unique \(\lambda\in\{0,\ldots,2^a-1\}\) satisfying
\[
v_2(3(y+2\lambda P)+1)=a
\]
gives the next exact cylinder.

The two implementations agree exactly on all packaged regression blocks through length 954.

## 3. Construction-A gap growth

After the finite buffer, Construction A has
\[
p_m=\frac{2^m}{m+1}+O(1).
\]
The critical gap after defect \(p_m\) begins at
\[
u_m=p_m+1
\]
and ends at \(p_{m+1}\), so
\[
R_m=p_{m+1}-p_m-1.
\]

Therefore
\[
\frac{p_{m+1}}{p_m}
\to
2,
\]
and hence
\[
\boxed{\frac{R_m}{u_m}\to1.}
\]
In particular
\[
\boxed{\frac{R_m}{\log u_m}\to\infty.}
\]

Thus any lower bound
\[
\log M(u_m,R_m)\gg R_m^\gamma
\]
for any fixed \(\gamma>0\), or merely
\[
\frac{\log M(u_m,R_m)}{\log u_m}\to\infty,
\]
would dominate every fixed polynomial in \(u_m\).

## 4. What is not proved

Task 2 does **not** prove
\[
M(u_m,R_m)\ge2^{cR_m}
\]
for any \(c>0\), nor even
\[
M(u_m,R_m)=u_m^{\omega(1)}.
\]

Finite exact data strongly support such behavior, but finite growth cannot replace the required infinite lower theorem.

This is the sole missing load-bearing half of the proposed LEVEL-3 collision.
