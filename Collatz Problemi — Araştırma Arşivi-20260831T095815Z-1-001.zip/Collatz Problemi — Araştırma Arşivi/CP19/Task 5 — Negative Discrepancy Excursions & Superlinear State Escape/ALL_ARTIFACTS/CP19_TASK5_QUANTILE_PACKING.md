# CP19 TASK 5 — QUANTILE PACKING

Let \(S\) be any set of starts in a positive injective orbit segment such
that
\[
n_v\le H,\qquad A(v,\ell)\le U
\quad(v\in S).
\]

Then
\[
\boxed{
|S|
\le
\frac H2 Z_\ell(U)+\binom U\ell,
}
\]
where
\[
Z_\ell(U)=
\sum_{A=\ell}^{U}\binom{A-1}{\ell-1}2^{-A}.
\]

Proof: group selected starts by exact valuation word and apply the frozen
\(2^{A+1}\) cylinder spacing to the distinct injective states.

Thus rare huge \(H_N\) spikes alone do not save a sub-\(\mu\) language if
\(1-o(1)\) of starts remain below a usable state threshold.

However current frozen theory provides no upper-tail frequency bound on
\(s_k\) or \(n_k\). Task 5 controls the lower tail of \(E_k\), not the upper
tail.

Status: `[PROVED]` but not load-bearing for exclusion.
