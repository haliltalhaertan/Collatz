# COLLATZ CP19 — TASK 5 FINDINGS
## Negative Discrepancy Excursions + Superlinear State Escape

## Final strategic verdict

\[
\boxed{\textbf{A — [FAIL: SURVIVING ABSTRACT REGIME EXISTS]}}
\]

No Side-B theorem is obtained.

The strongest result is a falsification: the frozen CP17/18/19 global
inequalities still permit an explicit infinite phase-valid schedule with:

- Task-5 occupation pressure;
- bounded carry;
- turnover density tending to one;
- no long exact-critical gaps;
- one exact mean-2 logarithmic bad window in every large dyadic scale;
- hypothetical state exponent \(\kappa>\kappa_*\);
- positive exact LEVEL-2 realizers for every finite prefix.

Its one fixed positive ordinary LEVEL-3 realizer remains `[OPEN]`.

## Exact window relation

For \(\vartheta_v=\{\alpha v\}\),
\[
\boxed{
A(v,\ell)
=
\lfloor\alpha\ell+\vartheta_v\rfloor
-
(s_{v+\ell}-s_v).
}
\]

Hence if \(A(v,\ell)\ge\mu\ell\),
\[
s_{v+\ell}-s_v
\le
\lfloor\alpha\ell+\vartheta_v\rfloor-\lceil\mu\ell\rceil
<
-(\mu-\alpha)\ell+1.
\]

At \(\mu=2\),
\[
\boxed{
\Delta s\le\lfloor\beta\ell+\vartheta_v\rfloor-\ell.
}
\]

## Exact recovery geometry

The number of phase-one sites in \([t,t+L)\) is
\[
\boxed{
F_{t+L}-F_t-L
=
\lfloor\beta L+\{\alpha t\}\rfloor.
}
\]

A depth-\(R\) recovery therefore satisfies
\[
\boxed{
L\ge\left\lfloor\frac{R-1}{\beta}\right\rfloor+1.
}
\]

The area below the old height is at least
\[
\sum_{q\ge0}(R-\lceil\beta q\rceil)_+
=
\frac{R^2}{2\beta}+O(R).
\]

These are theorem-level local facts.

## Why occupation does not close the regime

An \(O(\log N)\)-long excursion near \(N=2^m\) has harmonic weight
\[
O(m/2^m).
\]
Thus even one such event in every dyadic block has total weight
\[
\boxed{\sum_m O(m2^{-m})<\infty.}
\]

So global Task-5 lower-tail occupation cannot forbid it.

## Why carry does not close the regime

Choose outside excursion cores
\[
s_k=\kappa\log_2k+O(1),\qquad \kappa>1.
\]
Then the baseline carry is summable.

For a mean-2 window of length
\[
\ell\sim\tfrac12\log_2k,
\]
the required depth is only
\[
R=\frac{2-\alpha}{2}\log_2k+O(1).
\]

The core contribution remains summable as well. The explicit construction
has \(X_\infty<\infty\) asymptotically.

## Explicit survivor

Take
\[
\kappa=53/50=1.06>\kappa_*.
\]
Use Task-9-style neutral pairs, with only the few net-gain pairs needed to
track dyadic height
\[
B_m=\lfloor 53m/50\rfloor.
\]

In every dyadic block insert one exact mean-2 logarithmic window and then
recover phase-validly.

Finite deterministic diagnostic:
- horizon: 262144;
- turnover density: 0.999855041504;
- maximum zero-defect run: 1;
- carry diagnostic: 13.632383942501;
- exact mean-2 bad windows: 8.

Canonical positive finite witnesses were forward-verified and injective
through depth 16384.

This is LEVEL 1 + finite LEVEL 2 only.

## The \(\mu=2\) boundary is genuinely sharp

For a fixed phase word, **every** positive valuation word \(a_i\ge1\)
is phase-compatible by setting
\[
d_i=g_i-a_i.
\]
Hence phase compatibility does not reduce the finite composition language.

Therefore
\[
\boxed{h_{\rm phase}(\mu)=h_{\rm comp}(\mu)}
\]
and
\[
\boxed{h_{\rm phase}(2)=2.}
\]

Moreover
\[
\boxed{
Z_\ell(2\ell)
=
\frac12+\frac12\frac{\binom{2\ell}{\ell}}{4^\ell}
\to\frac12.
}
\]

There is no hidden exponential entropy saving at \(\mu=2\).

## Threshold optimization

Let
\[
h(\mu)=\mu\log_2\mu-(\mu-1)\log_2(\mu-1),
\qquad
K(\mu)=\mu/h(\mu).
\]

Exactly
\[
\boxed{
K'(\mu)=\frac{\log_2(\mu-1)}{h(\mu)^2}<0
\quad(1<\mu<2).
}
\]

Also
\[
K(\alpha)=\kappa_*=1.052680858607971.
\]

Once \(\kappa\ge\kappa_*\), the Task-4 threshold has moved to
\(\mu\le\alpha\), so exceeding it does not force a negative discrepancy
window. No fixed-point contradiction appears.

## Quantile packing

For any selected injective starts satisfying
\[
n_v\le H,\qquad A(v,\ell)\le U,
\]
\[
\boxed{
|S|
\le
\frac H2 Z_\ell(U)+\binom U\ell.
}
\]

So rare huge spikes alone do not defeat packing if almost all remaining
starts are low-state and sub-\(\mu\).

But the frozen theory has no upper-tail frequency bound on \(s_k\) or
\(n_k\). The explicit survivor instead puts essentially its whole baseline
in the super-near-linear state regime.

## LEVEL-3 status

Finite nonstabilization is not a theorem.

\[
\boxed{
x_{\rm survivor}\in\mathbb Z_{>0}?\quad[\mathrm{OPEN}].
}
\]

The next barrier is an ordinary-integrality/coherence theorem for this
high-state excursion class, not another global occupation inequality.
