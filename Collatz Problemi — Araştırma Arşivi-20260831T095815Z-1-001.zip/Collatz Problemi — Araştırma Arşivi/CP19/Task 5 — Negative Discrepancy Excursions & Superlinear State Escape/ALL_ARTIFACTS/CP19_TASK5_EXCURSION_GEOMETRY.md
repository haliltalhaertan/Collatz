# CP19 TASK 5 — EXCURSION GEOMETRY

For any window \([v,v+\ell)\), with \(\vartheta_v=\{\alpha v\}\),
\[
F_{v+\ell}-F_v=\lfloor\alpha\ell+\vartheta_v\rfloor
\]
and therefore
\[
\boxed{
A(v,\ell)
=
\lfloor\alpha\ell+\vartheta_v\rfloor
-
(s_{v+\ell}-s_v).
}
\]

If \(A(v,\ell)\ge\mu\ell\),
\[
\boxed{
s_{v+\ell}-s_v
\le
\lfloor\alpha\ell+\vartheta_v\rfloor-\lceil\mu\ell\rceil
<
-(\mu-\alpha)\ell+1.
}
\]

Let
\[
P=\#\{d_k=1\},\quad
Q=\sum(-d_k)_+,\quad
V=P+Q.
\]
Exactly,
\[
\Delta s=P-Q,
\qquad
A=G+Q-P,
\]
and
\[
P=(V+\Delta s)/2,\qquad
Q=(V-\Delta s)/2.
\]

A deep negative drop need not have large support turnover: one negative
defect can carry arbitrary magnitude. Weighted negative mass \(Q\), not
support \(T\), is the correct quantity.
