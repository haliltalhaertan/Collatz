# CP19 TASK 5 — PHASE-COMPATIBLE ENTROPY

Fix any phase word \(g_i\in\{1,2\}\).

For every positive valuation word \(a_i\ge1\), set
\[
d_i=g_i-a_i.
\]
Then automatically
\[
d_i\le g_i-1=b_i.
\]

If \(d_i=+1\), necessarily \(g_i=2,a_i=1\), exactly the phase restriction.
Negative defects are unrestricted in magnitude.

Conversely each valid defect word gives \(a_i=g_i-d_i\ge1\).

Thus
\[
\boxed{
\{\text{phase-compatible finite defect words}\}
\leftrightarrow
\{\text{all positive valuation words}\}.
}
\]

So phase compatibility alone does not reduce finite-language entropy.

For exact total \(A\),
\[
\#=\binom{A-1}{\ell-1}.
\]
For total \(A\le U\),
\[
\#=\binom U\ell.
\]

Therefore
\[
\boxed{
h_{\rm phase}(\mu)=h_{\rm comp}(\mu)
}
\]
and in particular
\[
\boxed{h_{\rm phase}(2)=2.}
\]

The proposed phase-entropy extension beyond the Task-4 boundary is
`[FAIL]`. Any improvement must use global LEVEL-3 coherence, not local
phase compatibility.
