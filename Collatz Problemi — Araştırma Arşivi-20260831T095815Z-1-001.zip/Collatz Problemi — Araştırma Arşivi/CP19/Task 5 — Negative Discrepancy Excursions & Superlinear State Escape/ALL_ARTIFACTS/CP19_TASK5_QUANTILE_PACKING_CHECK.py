from __future__ import annotations
import math
from fractions import Fraction
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q; hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def L(k):return k.bit_length()-1 if k else 0
def g(k):return F(k+1)-F(k)
def b(k):return g(k)-1
def v2(x):return (x & -x).bit_length()-1
ALPHA=math.log2(3.0);BETA=ALPHA-1.0

def orbit(n,R):
    vals=[];states=[n]
    for _ in range(R):
        x=3*n+1;a=v2(x);n=x>>a
        if n in states:break
        vals.append(a);states.append(n)
    return vals,states
def check(n0,R=80,ell=5):
    vals,states=orbit(n0,R)
    if len(vals)<ell:return
    starts=states[:len(vals)-ell+1]
    H=sorted(starts)[max(0,3*len(starts)//4-1)]
    U=2*ell-1
    sel=[]
    for j,n in enumerate(starts):
        w=tuple(vals[j:j+ell])
        if n<=H and sum(w)<=U:sel.append((n,w))
    words={w for n,w in sel}
    Z=sum(Fraction(1,1<<sum(w)) for w in words)
    assert Fraction(len(sel),1)<=Fraction(H,2)*Z+len(words)
def main():
    for n in range(1,2000,2):check(n)
    print("CP19 TASK5 QUANTILE PACKING CHECK: OK")
if __name__=="__main__":main()
