# CP19 TASK 5 — RECOVERY THEOREM

Let \(\beta=\log_2(3/2)\). Positive defects occur only at phase-one sites.

The exact number of such sites in \([t,t+L)\) is
\[
\boxed{
B(t,L)=F_{t+L}-F_t-L
=\lfloor\beta L+\{\alpha t\}\rfloor.
}
\]

If an excursion is \(R\ge1\) below a previous level at time \(t\) and later
returns, at least \(R\) positive defects are needed. Hence
\[
R\le B(t,L),
\]
so
\[
\boxed{
L\ge\left\lfloor\frac{R-1}{\beta}\right\rfloor+1.
}
\]

The bound is sharp up to \(O(1)\), by using \(d=+1\) at every available
phase-one site.

At recovery step \(q\), the remaining deficit is at least
\[
(R-\lceil\beta q\rceil)_+.
\]
Therefore
\[
\boxed{
\mathrm{Area}
\ge
\sum_{q\ge0}(R-\lceil\beta q\rceil)_+
=
\frac{R^2}{2\beta}+O(R).
}
\]

If the pre-height is \(H\), the fastest-recovery carry cost has scale
\[
\boxed{
C_{\rm rec}=\Theta_\beta(2^{R-H})
}
\]
up to bounded phase factors. In particular
\[
C_{\rm rec}\ge2^{-H+R-1}.
\]

Thus high pre-height can hide a deep excursion cheaply; recovery geometry
alone does not contradict the carry upper bound.
