# CP19 TASK 5 — BOUNDARY \(\mu=2\)

Define
\[
Z_\ell(U)=
\sum_{A=\ell}^{U}\binom{A-1}{\ell-1}2^{-A}.
\]

This is the CDF of a sum of \(\ell\) independent Geom(1/2) variables.

At \(U=2\ell\),
\[
Z_\ell(2\ell)
=
\Pr(\mathrm{Bin}(2\ell,1/2)\ge\ell).
\]

By exact binomial symmetry,
\[
\boxed{
Z_\ell(2\ell)
=
\frac12+
\frac12\frac{\binom{2\ell}{\ell}}{4^\ell}.
}
\]

Hence
\[
Z_\ell(2\ell)\to1/2
\]
and
\[
Z_\ell(2\ell)
=
\frac12+\frac{1}{2\sqrt{\pi\ell}}+O(\ell^{-3/2}).
\]

At \(2\ell+c\sqrt{\ell}\), the CLT gives a nontrivial constant limit.
For every fixed \(\mu>2\),
\[
Z_\ell(\lfloor\mu\ell\rfloor)\to1.
\]

Therefore the weighted-cylinder exponential saving ends exactly at mean 2.
A polynomial prefactor cannot replace it under an \(N^{1+o(1)}\) state
ceiling.
