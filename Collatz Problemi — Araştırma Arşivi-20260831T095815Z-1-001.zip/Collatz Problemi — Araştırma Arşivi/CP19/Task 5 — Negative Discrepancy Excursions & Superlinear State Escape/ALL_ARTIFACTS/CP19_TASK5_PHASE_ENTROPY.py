from fractions import Fraction
import math
def Z(ell,U):
    return sum(Fraction(math.comb(A-1,ell-1),1<<A) for A in range(ell,U+1))
def Z2(ell):
    return Fraction(1,2)+Fraction(math.comb(2*ell,ell),2*(4**ell))
def main():
    for ell in range(1,20):
        assert Z(ell,2*ell)==Z2(ell)
        assert sum(math.comb(A-1,ell-1) for A in range(ell,2*ell+1))==math.comb(2*ell,ell)
    for g in [(1,2,1,2),(2,1,2,2)]:
        for a in [(1,1,1,1),(1,2,3,4),(4,1,2,1)]:
            d=[gi-ai for gi,ai in zip(g,a)]
            assert all(di<=gi-1 for di,gi in zip(d,g))
    print("CP19 TASK5 PHASE ENTROPY: OK")
if __name__=="__main__":main()
