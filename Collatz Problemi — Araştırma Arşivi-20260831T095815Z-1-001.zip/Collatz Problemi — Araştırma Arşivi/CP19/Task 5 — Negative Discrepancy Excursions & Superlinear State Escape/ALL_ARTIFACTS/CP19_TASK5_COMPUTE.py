from __future__ import annotations
import math
from fractions import Fraction
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q; hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def L(k):return k.bit_length()-1 if k else 0
def g(k):return F(k+1)-F(k)
def b(k):return g(k)-1
def v2(x):return (x & -x).bit_length()-1
ALPHA=math.log2(3.0);BETA=ALPHA-1.0

def neutral_pair(j):
    if b(j)==1:return 1,-1
    assert b(j+1)==1
    return -1,1
def gain_pair(j):
    x,y=neutral_pair(j)
    if x<0:x=0
    else:y=0
    return x,y
def base(N,p=53,q=50):
    d=[0]*N;s=0
    for j in range(0,N-1,2):
        x,y=gain_pair(j) if s<p*L(j+2)//q else neutral_pair(j)
        d[j]=x;d[j+1]=y;s+=x+y
    return d
def excursions(base,m0=10):
    N=len(base);d=base[:];meta=[]
    for m in range(m0,L(N)+1):
        t=3*(1<<(m-1))
        if t>=N-16:break
        ell=max(2,m//2);v=t-ell
        A0=F(t)-F(v)-sum(base[v:t])
        R=max(1,2*ell-A0);drop=t-1
        d[drop]=base[drop]-R
        rem=R;k=t
        while rem:
            cap=b(k)-base[k]
            if cap>0:
                inc=min(rem,cap);d[k]=base[k]+inc;rem-=inc
            k+=1
        assert sum(d[drop:k])-sum(base[drop:k])==0
        meta.append((v,t,ell))
    return d,meta
def word(d):
    w=[]
    for k,dk in enumerate(d):
        assert dk<=b(k)
        a=g(k)-dk;assert a>=1;w.append(a)
    return w
def cylinder(w):
    A=B=0;P=1
    for a in w:B=3*B+(1<<A);P*=3;A+=a
    M=1<<(A+1)
    return (((1<<A)-B)*pow(P,-1,M))%M,A
def verify(n,w):
    seen={n}
    for a in w:
        x=3*n+1;assert v2(x)==a;n=x>>a
        assert n not in seen;seen.add(n)
def main():
    for k in range(10000):
        assert g(k) in (1,2)
        assert b(k)+b(k+1) in (1,2)
    N=1<<16
    d0=base(N);d,meta=excursions(d0);w=word(d)
    for v,t,ell in meta:assert sum(w[v:t])>=2*ell
    for R in [256,512,1024,2048,4096]:
        rho,A=cylinder(w[:R]);verify(rho,w[:R])
    for ell in range(1,12):
        z=sum(Fraction(math.comb(A-1,ell-1),1<<A) for A in range(ell,2*ell+1))
        rhs=Fraction(1,2)+Fraction(math.comb(2*ell,ell),2*(4**ell))
        assert z==rhs
    print("CP19 TASK5 COMPUTE: OK")
if __name__=="__main__":main()
