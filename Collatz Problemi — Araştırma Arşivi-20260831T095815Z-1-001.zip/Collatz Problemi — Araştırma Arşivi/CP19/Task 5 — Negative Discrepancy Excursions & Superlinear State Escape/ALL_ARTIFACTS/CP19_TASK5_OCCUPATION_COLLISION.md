# CP19 TASK 5 — OCCUPATION COLLISION

If a depth
\[
R=\rho\log_2N+O(1)
\]
excursion is required to remain above a low-\(E\) threshold \(B_N\) at every
step, then its pre-height must obey
\[
s_{\rm pre}\ge\log_2N+R+B_N-O(1).
\]

Under a positive LEVEL-3 realization,
\[
n_{\rm pre}\ge n_0\,2^{s_{\rm pre}},
\]
so pointwise hiding forces state exponent at least
\[
\boxed{1+\rho.}
\]

For a mean-2 window of length
\[
\ell=\tfrac12\log_2N+O(1),
\]
\[
\rho=(2-\alpha)/2,
\]
so pointwise hiding requires exponent at least
\[
1+(2-\alpha)/2
=
1.2075187496\ldots.
\]

But Task 5 is a global harmonic statement, not a pointwise one.
An \(O(\log N)\)-long low-\(E\) core near \(N=2^m\) contributes only
\[
O(m/2^m)
\]
harmonic mass. Hence one such core in every dyadic block still gives
finite total low-\(E\) mass.

Therefore recovery time and low-\(E\) occupation do not yield a global
contradiction from current frozen inputs.
