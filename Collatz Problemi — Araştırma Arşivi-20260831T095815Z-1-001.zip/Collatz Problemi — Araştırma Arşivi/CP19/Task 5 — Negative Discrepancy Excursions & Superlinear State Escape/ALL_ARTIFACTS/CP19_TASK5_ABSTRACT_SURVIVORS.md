# CP19 TASK 5 — ABSTRACT SURVIVORS

Fix
\[
\kappa=53/50=1.06>\kappa_*.
\]

For dyadic block \(I_m=[2^m,2^{m+1})\), use target height
\[
B_m=\lfloor53m/50\rfloor.
\]

On ordinary pairs use the frozen Task-9 neutral high-turnover pattern:
one \(+1\) and one \(-1\) defect in phase-valid order, net zero.
At dyadic height changes, replace the negative member of the required
first pairs by 0, giving net \(+1\).

Hence outside bounded adjustment regions
\[
s_k=\kappa\log_2k+O(1),
\qquad
T_N/N\to1,
\]
and every pair contains a nonzero defect.

In each dyadic block choose
\[
t_m=3\cdot2^{m-1},
\qquad
\ell_m=\lfloor m/2\rfloor.
\]
At the last step of \([t_m-\ell_m,t_m)\), add the exact negative defect
needed to force
\[
\boxed{
A(t_m-\ell_m,\ell_m)=2\ell_m.
}
\]
Recover afterward using phase-valid upward capacity and resume the neutral
pattern.

The depth is
\[
R_m=(2-\alpha)\ell_m+O(1)=O(m),
\]
and recovery length is \(O(m)\).

Outside cores,
\[
E_k=(\kappa-1)\log_2k+O(1).
\]
Core harmonic mass is \(O(m/2^m)\), so Task-5 occupation holds.

Carry outside cores is summable like
\[
\sum 2^{-(\kappa-1)m},
\]
and core carry is also summable because
\[
\kappa-(2-\alpha)/2>0.
\]
Thus
\[
\boxed{X_\infty<\infty.}
\]

If a fixed positive LEVEL-3 realizer existed, bounded \(U_k\) would give
\[
\boxed{
H_N=N^{\kappa+o(1)}.
}
\]
So the construction lives precisely in the super-near-linear escape regime.

Finite diagnostic:
- \(N=\)262144;
- turnover density \(=\)0.999855041504;
- max zero-defect run \(=\)1;
- carry diagnostic \(X_N=\)13.632383942501;
- exact mean-2 dyadic windows \(=\)8.

Every finite prefix is positive-realizable. Canonical witnesses were
forward-verified and injective through depth 16384.

The unique infinite 2-adic realizer is not classified:
\[
\boxed{x_S\in\mathbb Z_{>0}?\quad[\mathrm{OPEN}].}
\]
