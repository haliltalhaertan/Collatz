# CP19 TASK 5 — STATE EXPONENT TRADEOFF

Let
\[
h(\mu)=\mu\log_2\mu-(\mu-1)\log_2(\mu-1),
\quad
K(\mu)=\mu/h(\mu).
\]

Then
\[
h'(\mu)=\log_2\frac{\mu}{\mu-1}
\]
and
\[
\boxed{
K'(\mu)=\frac{\log_2(\mu-1)}{h(\mu)^2}<0
\quad(1<\mu<2).
}
\]

The limits are
\[
K(1+)=\infty,\qquad K(2-)=1.
\]

At the critical mean,
\[
\boxed{
K(\alpha)=\kappa_*=1.052680858607971.
}
\]

Thus for \(\kappa\ge\kappa_*\), the Task-4 threshold \(\mu\) satisfying
\(K(\mu)=\kappa\) lies at or below \(\alpha\). A window exceeding such a
threshold need not have negative discrepancy.

For a genuine bad mean \(\mu>\alpha\) over
\[
\ell=c\log_2N+O(1),
\]
the forced drop is
\[
R\ge c(\mu-\alpha)\log_2N-O(1).
\]

If that drop must stay pointwise above low \(E\), the state exponent is at
least
\[
\boxed{1+c(\mu-\alpha).}
\]

Sparse low-\(E\) excursion cores evade the pointwise premise, so the
tradeoff is structural but not an exclusion theorem.
