from __future__ import annotations
import math
from fractions import Fraction
LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537
def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q; hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1
def L(k):return k.bit_length()-1 if k else 0
def g(k):return F(k+1)-F(k)
def b(k):return g(k)-1
def v2(x):return (x & -x).bit_length()-1
ALPHA=math.log2(3.0);BETA=ALPHA-1.0

def phase_ones(t,L):return F(t+L)-F(t)-L
def lower(R):return math.floor((R-1)/BETA)+1
def brute():
    for t in range(40):
        for R in range(1,25):
            LL=0
            while phase_ones(t,LL)<R:LL+=1
            assert LL>=lower(R)
    print("CP19 TASK5 EXCURSION OPT: OK")
if __name__=="__main__":brute()
