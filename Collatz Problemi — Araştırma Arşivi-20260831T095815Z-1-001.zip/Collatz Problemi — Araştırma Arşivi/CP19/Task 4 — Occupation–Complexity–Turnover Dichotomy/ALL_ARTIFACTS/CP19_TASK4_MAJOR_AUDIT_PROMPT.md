# CP19 TASK 4 — ZERO-TRUST ADVERSARIAL AUDIT PROMPT

Audit `CP19_TASK4_BIG_AUDIT_PACKAGE.zip` with the explicit goal of BREAKING
the new theorem. Do not trust CP19 Task 4 labels.

## Main candidate

1. Exact weighted packing:

   m <= (H/2) * sum_W 2^{-A(W)} + |C|.

2. Composition theorem:

   for positive length-ell words with total A<=U,

   P=binom(U,ell),
   Z=sum_{A=ell}^U binom(A-1,ell-1)2^{-A}.

   If U=(mu+o(1))ell, 1<mu<2,

   log2 P = (h(mu)+o(1))ell,
   log2 Z <= -(eta(mu)-o(1))ell,

   h(mu)=mu H_2(1/mu), eta=mu-h(mu)>0.

3. High-turnover Task-9 Construction B:

   A_H(v,ell)<=ceil(alpha ell)+2 for every window,
   and under one fixed positive realization H_N=N^{1+o(1)}.

   With ell=floor((1/2)log2 N), weighted packing gives N<=o(N), hence
   Construction B has no positive ordinary LEVEL-3 realizer.

## Mandatory attack list

1. Re-derive the `2^{A+1}` exact cylinder depth for arbitrary positive
   valuation words.
2. Check that injectivity gives exactly `N-ell+1` distinct window-start
   states and that overlap of cylinders is handled safely.
3. Check the factor `H/2` in the weighted sum and every `+1` term.
4. Prove the hockey-stick identity `sum C(A-1,ell-1)=C(U,ell)`.
5. Re-derive the Geom(1/2) weighted-mass identity and the optimized Chernoff
   exponent; search for a sign or tail-direction reversal.
6. Check uniformity when `U=ceil(alpha ell)+2` and
   `ell=floor((1/2)log2 N)`.
7. Check the exact frozen Construction-B relation `|s_H-s_L|<=1` and infer
   `Delta s_H>=-2` correctly from monotonicity of the low path.
8. Check `A_H(v,ell)<=ceil(alpha ell)+2` for ALL windows, including protected
   pairs and boundary-crossing windows.
9. Re-derive `H_N=N^{1+o(1)}` from the exact state identity and the frozen
   Task-9 `s/X` bounds. Do not assume it from prose.
10. Check that a hypothetical fixed positive realization of Construction B
    is injective; if using nonperiodicity, prove it.
11. Try brute-force finite counterexamples to the general weighted packing
    inequality and the discrepancy-band ceiling.
12. Verify that the theorem does not contradict finite LEVEL-2 cylinder
    realizability: finite canonical starts may simply have enormous H.
13. Determine whether the conclusion is exactly Construction-B exclusion,
    not Side B.

Required verdict:
- PROOF VALID
- PROOF VALID AFTER MINOR REPAIR
- MAJOR GAP
- FALSE / COUNTEREXAMPLE

If valid, state whether the general sub-2 near-linear-state theorem is also
valid or only the Construction-B specialization survives.
