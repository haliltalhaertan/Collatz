# CP19 TASK 4 — ENTROPY ANALYSIS

## 1. Composition entropy

For positive valuation words of length `ell` with mean total valuation
`mu=A/ell`, the asymptotic combinatorial entropy is

\[
\boxed{
h_{\rm comp}(\mu)
=\mu H_2(1/\mu)
=\mu\log_2\mu-(\mu-1)\log_2(\mu-1).
}
\]

At the critical mean

\[
\alpha=\log_2 3=1.5849625007\ldots,
\]

we obtain diagnostically

\[
h_{\rm comp}(\alpha)
=1.5056438879\ldots,
\]

and

\[
\boxed{
\eta_\alpha
=\alpha-h_{\rm comp}(\alpha)
=0.0793186127\ldots>0.
}
\]

The proof-critical sign does not rely on decimals: since
`1<alpha<2`, we have `1/alpha in (1/2,1)` and therefore
`H_2(1/alpha)<1` strictly.

## 2. Maximum-entropy interpretation

Among positive-integer distributions with fixed mean `mu`, the maximum
Shannon entropy is attained by the geometric distribution with parameter
`p=1/mu`. Its entropy is exactly the same function `h_comp(mu)`.

Thus even the **largest possible combinatorial entropy** at critical mean is
strictly below the cylinder depth rate `alpha`.

This falsifies the concern that an arbitrarily complicated near-critical
valuation language necessarily has enough entropy to defeat packing.

## 3. General asymptotic threshold

Assume an injective prefix of horizon `N` has

\[
H_N=N^{\kappa+o(1)}
\]

and for

\[
\ell=c\log_2N+o(\log N)
\]

every length-`ell` window has total valuation at most

\[
U=(\mu+o(1))\ell,
\qquad 1<\mu<2.
\]

Weighted packing gives two error exponents:

\[
P_\ell(U)=N^{c h(\mu)+o(1)},
\]

\[
H_N Z_\ell(U)
=N^{\kappa-c\eta(\mu)+o(1)}.
\]

A contradiction follows whenever one can choose `c` with

\[
ch(\mu)<1,
\qquad
\kappa-c\eta(\mu)<1.
\]

Such `c` exists exactly when

\[
\boxed{
\kappa<\frac{\mu}{h(\mu)}.
}
\]

At `mu=alpha`, the diagnostic threshold is

\[
\frac{\alpha}{h(\alpha)}
=1.0526808586\ldots.
\]

In particular `kappa=1` is safely below threshold.

## 4. Especially simple near-linear case

If

\[
H_N=N^{1+o(1)},
\]

then **every fixed `mu<2` is packable**. We may simply choose

\[
\ell=\left\lfloor\frac12\log_2N\right\rfloor.
\]

Because `h(mu)<mu<2`,

\[
\frac12h(\mu)<1,
\]

while `eta(mu)>0`; hence both terms in the packing upper bound are `o(N)`.

Therefore a near-linear-state injective orbit cannot keep every logarithmic
window below any fixed mean valuation strictly less than 2.

This is the key structural necessity produced by Task 4.
