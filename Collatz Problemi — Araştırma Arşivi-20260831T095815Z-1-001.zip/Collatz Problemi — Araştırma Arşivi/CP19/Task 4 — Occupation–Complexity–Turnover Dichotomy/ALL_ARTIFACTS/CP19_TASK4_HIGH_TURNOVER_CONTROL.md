# CP19 TASK 4 — TASK-9 HIGH-TURNOVER CONTROL

## Frozen Construction B

Start from the Task-9 sparse low-turnover path. On every unprotected pair
`(2j,2j+1)`, insert one `+1` and one `-1` defect in the phase-valid order.
Protected pairs containing a sparse net-gain site are left unchanged.

Frozen consequences:

\[
|s_k^H-s_k^L|\le1,
\qquad
X_N^H\le2X_N^L,
\]

\[
T_N=N-O(\log N),
\qquad
E_k^H=E_k^L+O(1).
\]

Every finite prefix is positive-realizable, but LEVEL 3 was previously open.

## 1. It is not high-complexity

Let `K_N` be the number of protected pairs in the first `N` positions.
As proved in `CP19_TASK4_FACTOR_COMPLEXITY_THEOREM.md`,

\[
P_a(N,\ell)
\le2(\ell+3)+K_N(\ell+1)
=O(\ell\log N).
\]

Thus turnover density tends to one while subword complexity stays very low.
This is an exact counterexample to `high turnover => high complexity`.

## 2. Uniform total-valuation upper bound

Write

\[
s_k^H=s_k^L+e_k,
\qquad |e_k|\le1.
\]

The low path has only `+1` net defects, so it is nondecreasing:

\[
s_{v+\ell}^L-s_v^L\ge0.
\]

Therefore

\[
s_{v+\ell}^H-s_v^H\ge-2.
\]

For every window,

\[
\boxed{
A_H(v,\ell)
=F_{v+\ell}-F_v-[s_{v+\ell}^H-s_v^H]
\le\lceil\alpha\ell\rceil+2.
}
\]

This bound is independent of turnover inside the window.

## 3. Hypothetical positive LEVEL-3 state ceiling

Assume one fixed positive integer `n_0` realizes Construction B forever.
Task 9 gives

\[
s_k^H=s_k^L+O(1),
\quad
s_k^L=\log_2k+\log_2\log_2k+O(1),
\]

and

\[
X_N^H=O(\log\log N).
\]

The exact state identity therefore yields uniformly for `k<=N`

\[
\boxed{
n_k=O_{n_0}(N\log N\log\log N)=N^{1+o(1)}.
}
\]

The prescribed word is not eventually periodic, so a fixed positive
realization cannot repeat a state; it is injective.

## 4. Weighted packing contradiction

Choose

\[
\ell=\left\lfloor\frac12\log_2N\right\rfloor,
\qquad
U=\lceil\alpha\ell\rceil+2.
\]

All occurring length-`ell` words lie among all positive compositions with
sum `<=U`. Exact weighted packing gives

\[
N-\ell+1
\le
\frac{H_N}{2}Z_\ell(U)+\binom{U}{\ell}.
\]

Let

\[
h_\alpha=\alpha H_2(1/\alpha),
\qquad
\eta_\alpha=\alpha-h_\alpha>0.
\]

Then

\[
\binom{U}{\ell}
=N^{h_\alpha/2+o(1)}=o(N)
\]

because `h_alpha<alpha<2`, while

\[
H_N Z_\ell(U)
=N^{1-\eta_\alpha/2+o(1)}=o(N).
\]

The right side is `o(N)` but the left side is `N-o(N)`. Contradiction.

Hence

\[
\boxed{
\text{Task-9 Construction B has no fixed positive ordinary LEVEL-3 realizer.}
}
\]

## Status

`[NEW EXACT HIGH-TURNOVER LEVEL-3 EXCLUSION CANDIDATE]`

Independent adversarial audit is required before freeze.
