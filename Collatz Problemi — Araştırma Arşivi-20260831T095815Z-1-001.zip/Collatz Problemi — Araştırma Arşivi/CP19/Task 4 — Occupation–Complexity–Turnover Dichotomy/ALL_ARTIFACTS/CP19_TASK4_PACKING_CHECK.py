#!/usr/bin/env python3
from __future__ import annotations
from fractions import Fraction
from math import comb
import random

LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537

def F(k:int)->int:
    if k==0:return 0
    lo=k*LOW_P//LOW_Q; hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1

def v2(x:int)->int:return (x&-x).bit_length()-1

def cylinder(word):
    A=B=0; P=1
    for a in word:
        B=3*B+(1<<A); P*=3; A+=a
    M=1<<(A+1)
    rho=(((1<<A)-B)*pow(P,-1,M))%M
    return rho,A

def forward(n,r):
    vals=[]; states=[n]
    for _ in range(r):
        x=3*n+1; a=v2(x); vals.append(a); n=x>>a; states.append(n)
    return vals,states

def weighted_pack_check(vals,states,ell):
    r=len(vals); assert len(states)==r+1
    starts=states[:r-ell+1]
    assert len(set(starts))==len(starts)
    H=max(starts)
    words={tuple(vals[j:j+ell]) for j in range(r-ell+1)}
    Z=Fraction(0,1)
    for w in words:
        A=sum(w); Z+=Fraction(1,1<<A)
        rho,A2=cylinder(w); assert A==A2
        for j in range(r-ell+1):
            if tuple(vals[j:j+ell])==w:
                assert states[j]% (1<<(A+1))==rho
    lhs=Fraction(r-ell+1,1)
    rhs=Fraction(H,2)*Z+len(words)
    assert lhs<=rhs

def discrepancy_ceiling_check(n,u,r):
    vals,states=forward(n,r)
    sigma=[0]; A=0
    for j,a in enumerate(vals,1):
        A+=a; sigma.append((F(u+j)-F(u))-A)
    W=max(sigma)-min(sigma)
    for j,x in enumerate(states):
        # x < 2^W(2n+4j/3), exact integer form
        assert 3*x < (1<<W)*(6*n+4*j)

def hockey_stick():
    for ell in range(1,10):
        for U in range(ell,ell+20):
            assert sum(comb(A-1,ell-1) for A in range(ell,U+1))==comb(U,ell)

def main():
    hockey_stick()
    rng=random.Random(20260824)
    checked=0
    for _ in range(500):
        n=rng.randrange(1,200000)|1
        u=rng.randrange(0,1000)
        r=rng.randrange(8,32)
        vals,states=forward(n,r)
        if len(set(states))<len(states):
            continue
        discrepancy_ceiling_check(n,u,r)
        for ell in [1,2,3,4,min(6,r)]:
            if ell<=r: weighted_pack_check(vals,states,ell)
        checked+=1
    assert checked>300
    print('CP19 TASK4 PACKING CHECK: OK',checked)

if __name__=='__main__':main()
