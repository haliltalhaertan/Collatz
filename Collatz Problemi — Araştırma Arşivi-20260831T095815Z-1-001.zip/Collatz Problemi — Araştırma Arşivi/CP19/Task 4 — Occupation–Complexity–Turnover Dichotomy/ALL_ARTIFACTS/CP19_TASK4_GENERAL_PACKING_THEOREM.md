# CP19 TASK 4 — GENERAL VALUATION-FACTOR PACKING THEOREM

## Status

`[PROVED CANDIDATE — LOAD-BEARING, AUDIT REQUIRED]`

This note is self-contained except for the frozen exact valuation-cylinder fact:
a finite positive valuation word `W=(a_0,...,a_{ell-1})` of total valuation
`A(W)` pins every positive start realizing it to one odd residue class modulo
`2^{A(W)+1}`.

## 1. Exact weighted packing lemma

Let

\[
n_u,n_{u+1},\ldots,n_{u+r}
\]

be a positive **injective** odd-only Syracuse orbit segment. Fix
`1 <= ell <= r`. Let `C` be the set of distinct length-`ell` valuation words
occurring at starts

\[
u,u+1,\ldots,u+r-\ell.
\]

For `W in C`, write

\[
A(W)=\sum_{i<\ell}a_i.
\]

Let

\[
H\ge \max_{0\le j\le r-\ell}n_{u+j}.
\]

Define

\[
P_C=|C|,
\qquad
Z_C=\sum_{W\in C}2^{-A(W)}.
\]

Then

\[
\boxed{
 r-\ell+1
 \le
 \frac H2 Z_C+P_C.
}
\]

### Proof

A fixed word `W` has one exact start residue `rho_W` modulo
`Q_W=2^{A(W)+1}`. Hence the number of positive integers `<=H` in that class is
at most

\[
\left\lfloor\frac{H-\rho_W}{Q_W}\right\rfloor+1
\le \frac{H}{2^{A(W)+1}}+1.
\]

Injectivity makes the `r-ell+1` window-start states distinct. Sum the safe
upper bound over the distinct word types. QED.

## 2. Unweighted corollary

If

\[
A(W)\ge A_{\min}\quad(W\in C),
\qquad P_C\le P,
\]

then

\[
\boxed{
 r-\ell+1
 \le
 P\left(\frac{H}{2^{A_{\min}+1}}+1\right).
}
\]

Equivalently

\[
\boxed{
P\ge
\frac{r-\ell+1}{H/2^{A_{\min}+1}+1}.
}
\]

This is the exact **complexity necessity** form.

## 3. Exact discrepancy-band ceiling

Let

\[
\sigma_j=s_{u+j}-s_u,
\qquad
W=\max_{0\le j\le r}\sigma_j-
  \min_{0\le j\le r}\sigma_j.
\]

Put `N=n_u`. Then for every `0<=j<=r`,

\[
\boxed{
 n_{u+j}<2^W\left(2N+\frac{4j}{3}\right)
 \le
 2^W\left(2N+\frac{4r}{3}\right).
}
\]

### Proof

Let

\[
G_j=F_{u+j}-F_u,
\qquad
A_j=G_j-\sigma_j,
\qquad
c_j=\frac{2^{G_j}}{3^j}.
\]

Since

\[
G_j=\alpha j+\{\alpha u\}-\{\alpha(u+j)\},
\]

we have `1/2<c_j<2`. The exact affine recurrence gives

\[
c_j2^{-\sigma_j}n_{u+j}
=N+\sum_{i<j}\frac{c_i2^{-\sigma_i}}3.
\]

If `M=max sigma` and `m=min sigma`, then `M-m=W` and `0` lies between
`m` and `M`. Thus

\[
n_{u+j}
<2^{M+1}N+\frac43 2^{M-m}j
\le 2^W\left(2N+\frac{4j}{3}\right).
\]

## 4. Local valuation depth from the band

For every length-`ell` subwindow inside the segment,

\[
A(v,\ell)
=F_{v+\ell}-F_v-[s_{v+\ell}-s_v]
\ge \lfloor\alpha\ell\rfloor-W.
\]

Therefore the unweighted packing lemma yields

\[
\boxed{
N\ge
2^{\lfloor\alpha\ell\rfloor-2W}
\left(
\frac{r-\ell+1}{P}-1
\right)
-\frac{2r}{3}.
}
\]

## 5. Exact recovery of frozen Task 3

For an exact critical segment:

- `W=0`;
- `P=ell+1` by Sturmian factor complexity;
- every length-`ell` critical factor has total valuation at least
  `floor(alpha ell)`.

Substitution gives

\[
N\ge
2^{\lfloor\alpha\ell\rfloor}
\frac{r-2\ell}{\ell+1}
-\frac{2r}{3},
\]

which is exactly the independently audited CP19 Task-3 finite theorem.

Hence the generalized lemma is consistent with the frozen theorem, including
all factors of two and the `+1` cylinder depth.
