# COLLATZ CP19 — TASK 4 FINDINGS
## Occupation–Complexity–Turnover Dichotomy

## Final strategic verdict

\[
\boxed{
\textbf{D — [HIGH-TURNOVER CONTROL EXCLUDED]}
}
\]

with status

\[
\boxed{
\textbf{[MAJOR LOAD-BEARING THEOREM CANDIDATE — AUDIT REQUIRED]}
}
\]

The result is **not frozen** and is **not Side B**.

## 1. What was falsified first?

The frozen Task-9 Construction B has turnover density tending to one, but it
does **not** have high factor complexity.

If `K_N` is the number of protected sparse pairs, then exactly

\[
P_a(N,\ell)
\le2(\ell+3)+K_N(\ell+1)
=O(\ell\log N).
\]

Therefore

\[
\boxed{
\text{high turnover}\not\Rightarrow\text{high factor complexity}.
}
\]

This is `[COUNTEREXAMPLE][FAIL]` for H3.

The old implication `high turnover => high carry` remains the frozen Task-9
`[FAIL]` as well.

## 2. New exact packing theorem

For any positive injective segment, let `C` be the distinct occurring
length-`ell` valuation words and `H` a state ceiling. Then

\[
\boxed{
 r-\ell+1
 \le
 \frac H2\sum_{W\in C}2^{-A(W)}+|C|.
}
\]

The unweighted corollary recovers the independently audited Task-3 packing
theorem exactly when `W=0`, `P=ell+1`.

## 3. The surprise: high complexity is not enough to escape

For **all** positive valuation words of length `ell` and total valuation at
most `U`,

\[
P_\ell(U)=\binom{U}{\ell}
\]

and

\[
Z_\ell(U)=\sum_{A=\ell}^{U}\binom{A-1}{\ell-1}2^{-A}.
\]

If `U=(mu+o(1))ell` with `1<mu<2`, then

\[
P_\ell(U)=2^{(h(\mu)+o(1))\ell},
\]

\[
Z_\ell(U)=2^{-(\eta(\mu)-o(1))\ell},
\]

where

\[
h(\mu)=\mu H_2(1/\mu),
\qquad
\eta(\mu)=\mu-h(\mu)>0.
\]

At `mu=alpha=log_2 3`, diagnostics give

\[
h(\alpha)=1.5056438879\ldots,
\]

\[
\eta(\alpha)=0.0793186127\ldots.
\]

The proof-critical strictness is exact because `alpha<2` and
`H_2(1/alpha)<1`.

Thus even the entire near-critical composition language is too small in
**weighted cylinder mass** to defeat packing under a near-linear state
ceiling.

## 4. Construction B exact properties

Frozen Task 9 gives

\[
|s_k^H-s_k^L|\le1,
\qquad
X_N^H\le2X_N^L,
\]

with

\[
s_k^L=\log_2k+\log_2\log_2k+O(1),
\qquad
X_N^L=O(\log\log N).
\]

Hence under a hypothetical fixed positive realization,

\[
\boxed{H_N=N^{1+o(1)}}.
\]

Moreover the low path is nondecreasing in `s`, so for every high-path
length-`ell` window

\[
s_{v+\ell}^H-s_v^H\ge-2,
\]

and therefore

\[
\boxed{
A_H(v,\ell)\le\lceil\alpha\ell\rceil+2.
}
\]

## 5. Construction B collision

Set

\[
\ell=\left\lfloor\frac12\log_2N\right\rfloor.
\]

All length-`ell` factors lie inside the composition language with
`U=ceil(alpha ell)+2`. Weighted packing gives

\[
N-\ell+1
\le
\frac{H_N}{2}Z_\ell(U)+\binom{U}{\ell}.
\]

The two right-hand terms are respectively

\[
N^{1-\eta(\alpha)/2+o(1)}
\]

and

\[
N^{h(\alpha)/2+o(1)},
\]

both `o(N)`. The left side is `N-o(N)`. Contradiction.

Therefore, subject to independent audit,

\[
\boxed{x_B\notin\mathbb Z_{>0}.}
\]

This is the first exact LEVEL-3 exclusion of the canonical Task-9
high-turnover control branch.

## 6. What survives?

The theorem does **not** close every Task-5-compatible path.

For a near-linear-state survivor, logarithmic windows cannot all have mean
total valuation bounded below `2`. Taking

\[
\mu_0=(\alpha+2)/2
\]

shows that a survivor must exhibit windows with

\[
\boxed{
s_{v+\ell}-s_v<-(2-\alpha)\ell/2+1.}
\]

Thus the remaining escape is a genuinely **large negative discrepancy
excursion**, or a state ceiling growing faster than the near-linear entropy
threshold.

Task 5 does not currently exclude either possibility.

## 7. Hypothesis ledger

| Hypothesis | Verdict |
|---|---|
| H1 packing extends beyond exact critical words | `[PROVED CANDIDATE]` |
| H2 low weighted turnover gives count control | `[PROVED CONDITIONAL]` |
| H3 high turnover forces high complexity | `[COUNTEREXAMPLE][FAIL]` |
| H4 bounded discrepancy gives state ceiling | `[PROVED CANDIDATE]` exact `2^W(2N+4r/3)` |
| H5 every fixed-band language entropy < alpha | `[OPEN / not needed]` |
| H6 near-critical composition entropy < alpha | `[PROVED]` for mean `<2`; in particular alpha |
| H7 Task-9 Construction B excluded | `[NEW EXACT EXCLUSION CANDIDATE]` |
| H8 Task5 forces packable intervals | `[OPEN]` |
| H9 survivor needs high complexity | `[FAIL]`; complexity is not the sole escape |
| H10 high complexity itself creates arithmetic cost | `[PARTLY: weighted mass, not raw complexity]` |
| H11 large discrepancy range is alternative escape | `[PROVED NECESSITY under near-linear H]` |
| H12 all Task5 regimes closed | `[OPEN][NO]` |

## 8. Required result table

| Question | Verdict | Evidence |
|---|---|---|
| General valuation-factor packing lemma? | `[PROVED CANDIDATE]` | exact weighted cylinder sum |
| Recover Task 3 exactly? | `[EXACT] YES` | W=0, P=ell+1 substitution |
| Bounded s-range state ceiling? | `[PROVED CANDIDATE]` | `n_j<2^W(2N+4j/3)` |
| Low turnover => controlled complexity? | `[CONDITIONAL]` | exact variation generating function |
| Defect-language entropy rate? | `[CERTIFIED NUM / OPEN generally]` | banded DP |
| Composition entropy at mean alpha? | `[PROVED FORMULA]` | `alpha H_2(1/alpha)` |
| Composition entropy below alpha? | `[PROVED] YES` | binary entropy strictness |
| Weighted cylinder mass decay? | `[PROVED]` for total mean `<2` | exact Geom(1/2) Chernoff |
| Fixed-band high-turnover paths packable? | `[PARTIAL]`; raw band entropy route not needed | DP + weighted theorem |
| Complexity required for survivor? | exact packing necessity exists; high complexity alone not enough | theorem |
| Task-9 Construction B excluded? | `[NEW EXACT EXCLUSION CANDIDATE] YES` | weighted packing collision |
| Do low-range Task5 branches survive? | general case `[OPEN]` | Task5 lacks state upper/local-window control |
| What regime remains? | large negative log-window s excursions and/or faster state growth | structural necessity |
| Side B? | **NO** | surviving regimes remain |

## 9. User-facing summary

### Ne denedik?

Construction A gibi sakin yolları öldürdükten sonra, çok fazla ileri-geri
sapma yapan yolların yeni packing mekanizmasından kaçıp kaçamadığını test
ettik.

### Yeni packing theorem high-turnover'a uzandı mı?

Evet. Hatta ham factor complexity'yi aşan weighted-composition formuna
uzandı.

### Task-9 Construction B hâlâ yaşayabiliyor mu?

Yeni proof candidate doğruysa hayır: bir fixed positive ordinary integer
Construction B'yi sonsuza kadar taşıyamaz.

### Kaçabilmek için orbit ne kadar karmaşık olmak zorunda?

Sadece karmaşık olmak yetmiyor. Near-linear state büyümesinde orbit,
logaritmik ölçeklerde ortalama valuation'ı 2'ye yaklaştıran büyük negative
`s` excursions üretmek zorunda.

### Yeni theorem mi çıktı?

Evet, load-bearing theorem candidate çıktı ve bu yüzden bağımsız audit
zorunlu.

### Side B'ye ne kadar yaklaştık?

İki canonical Task-9 countermodelinin low-turnover tarafı Task 3'te,
high-turnover tarafı Task 4 candidate theorem ile kapanıyor. Fakat tüm
interpolating Task-5 paths kapanmış değil.

### Sıradaki tek en yüksek bilgi değerli soru ne?

Audit geçerse sıradaki hedef, **large negative logarithmic-window discrepancy
excursions** rejiminin Task-5 occupation + fixed ordinary integrality ile
uyumlu olup olmadığını araştırmaktır.
