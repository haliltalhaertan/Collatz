# CP19 TASK 4 — WEIGHTED CYLINDER MASS

## Status

`[PROVED CANDIDATE — LOAD-BEARING, AUDIT REQUIRED]`

The weighted packing object is

\[
Z_{\mathcal C}(\ell)
=\sum_{W\in\mathcal C}2^{-A(W)}.
\]

It is stronger than replacing all cylinders by one minimum depth.

## 1. Positive-composition language

There are exactly

\[
\binom{A-1}{\ell-1}
\]

positive valuation words of length `ell` and total valuation `A`.
Consequently the number with total valuation at most `U` is exactly

\[
\boxed{
P_{\ell}(U)
=\sum_{A=\ell}^{U}\binom{A-1}{\ell-1}
=\binom{U}{\ell}.
}
\]

The corresponding total weighted cylinder mass is

\[
\boxed{
Z_{\ell}(U)
=\sum_{A=\ell}^{U}
\binom{A-1}{\ell-1}2^{-A}.
}
\]

Therefore any injective segment whose length-`ell` windows all have
`A<=U` satisfies the exact finite inequality

\[
\boxed{
 r-\ell+1
 \le
 \frac H2 Z_{\ell}(U)
 +\binom{U}{\ell}.
}
\]

No Sturmian or turnover hypothesis is used here.

## 2. Geometric-probability interpretation

Let `X_1,...,X_ell` be iid positive Geometric(1/2):

\[
\Pr(X_i=a)=2^{-a},\qquad a\ge1.
\]

Then

\[
\boxed{
Z_{\ell}(U)=
\Pr(X_1+\cdots+X_\ell\le U).
}
\]

The unrestricted weighted mass is exactly one:

\[
\sum_{A\ge\ell}\binom{A-1}{\ell-1}2^{-A}=1.
\]

Thus the new mechanism is a **lower-tail restriction** on total valuation,
not an assumption that the valuation language itself is tiny.

## 3. Exact Chernoff rate below mean 2

For `1<mu<2` and `U=(mu+o(1))ell`, define

\[
h(\mu)=\mu H_2(1/\mu),
\qquad
\eta(\mu)=\mu-h(\mu).
\]

Because `1/mu != 1/2`, binary entropy satisfies

\[
H_2(1/\mu)<1,
\]

so

\[
\boxed{\eta(\mu)>0.}
\]

A Chernoff bound with

\[
t=\frac{2(\mu-1)}{\mu}\in(0,1)
\]

gives

\[
\boxed{
Z_\ell(U)
\le
2^{-(\eta(\mu)-o(1))\ell}.
}
\]

Indeed one-step generating function is

\[
\sum_{a\ge1}2^{-a}t^a=\frac{t}{2-t},
\]

and the optimized per-step bound is

\[
\frac{\mu^\mu}{2^\mu(\mu-1)^{\mu-1}}
=2^{h(\mu)-\mu}.
\]

Also the exact hockey-stick count and the standard binomial entropy bound give

\[
\boxed{
P_\ell(U)
\le
2^{(h(\mu)+o(1))\ell}.
}
\]

This entropy-vs-cylinder gap is the load-bearing new mechanism in Task 4.
