# CP19 TASK 4 — NEAR-CRITICAL COMPOSITION PACKING

## Theorem candidate

Let a positive injective odd-only Syracuse orbit have prefixes with

\[
H_N:=\max_{0\le k<N}n_k=N^{\kappa+o(1)}.
\]

Suppose there are constants `1<mu<2` and `c>0` such that, with

\[
\ell_N=c\log_2N+o(\log N),
\]

all length-`ell_N` valuation windows in the first `N` steps obey

\[
A(v,\ell_N)\le(\mu+o(1))\ell_N
\]

uniformly in `v`.

Write

\[
h(\mu)=\mu H_2(1/\mu),
\qquad
\eta(\mu)=\mu-h(\mu)>0.
\]

If

\[
ch(\mu)<1,
\qquad
\kappa-c\eta(\mu)<1,
\]

then such prefixes cannot occur for all sufficiently large `N`.

Equivalently, some admissible `c` exists whenever

\[
\boxed{
\kappa<\mu/h(\mu).
}
\]

### Proof

Apply the exact weighted packing theorem to all `N-ell+1` window starts.
The occurring language is contained in all positive compositions of length
`ell` and total at most `U=(mu+o(1))ell`.

The exact number of such words is `binom(U,ell)`, whose exponent is
`h(mu)ell+o(ell)`. Their total weighted cylinder mass is the lower-tail
probability for a sum of iid positive Geom(1/2) variables and is at most
`2^{-(eta(mu)-o(1))ell}`.

Thus

\[
N-\ell+1
\le
N^{\kappa-c\eta(\mu)+o(1)}
+
N^{ch(\mu)+o(1)}
=o(N),
\]

contradiction.

## Near-linear corollary

If `H_N=N^{1+o(1)}`, choose `c=1/2`. Then for **any** fixed `mu<2`,
no uniform logarithmic-window bound

\[
A(v,\ell)\le(\mu+o(1))\ell
\]

can persist.

This theorem does not assume low turnover, low factor complexity, Sturmian
structure, or a bounded valuation alphabet.
