#!/usr/bin/env python3
from __future__ import annotations
from collections import defaultdict
import argparse

LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537

def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q;hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1

def b(k):return F(k+1)-F(k)-1

def factors(ell):
    out={}
    for u in range(200000):
        w=tuple(b(u+i) for i in range(ell));out.setdefault(w,u)
        if len(out)==ell+1:return out
    raise RuntimeError('factor scan failed')

def dp(word,W):
    D={(0,0,0):(1,1.0)}
    for bb in word:
        N={}
        for (s,mn,mx),(cnt,wt) in D.items():
            lo=mx-W;hi=min(mn+W,s+bb)
            for sp in range(lo,hi+1):
                a=1+bb-(sp-s)
                key=(sp,min(mn,sp),max(mx,sp))
                c,z=N.get(key,(0,0.0));N[key]=(c+cnt,z+wt*2.0**(-a))
        D=N
    return sum(c for c,z in D.values()),sum(z for c,z in D.values())

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--ell',type=int,default=20);ap.add_argument('--W',type=int,default=4);args=ap.parse_args()
    C=0;Z=0.0
    for w in factors(args.ell):
        c,z=dp(w,args.W);C+=c;Z+=z
    print({'ell':args.ell,'W':args.W,'phase_path_count_sum':C,'weighted_sum':Z})

if __name__=='__main__':main()
