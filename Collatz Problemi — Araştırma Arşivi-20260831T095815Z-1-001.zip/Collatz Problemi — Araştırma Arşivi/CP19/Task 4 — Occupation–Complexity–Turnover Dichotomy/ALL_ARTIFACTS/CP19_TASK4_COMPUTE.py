#!/usr/bin/env python3
from __future__ import annotations
import subprocess,sys

def run(name,*args):
    cp=subprocess.run([sys.executable,name,*map(str,args)],capture_output=True,text=True,check=True)
    print(cp.stdout.strip())

def main():
    run('CP19_TASK4_PACKING_CHECK.py')
    run('CP19_TASK4_COMPLEXITY_SCAN.py','--N',65536)
    run('CP19_TASK4_DEFECT_TRANSFER.py','--ell',20,'--W',4)
    run('CP19_TASK4_MAJOR_PROOF_CHECK.py')
    print('CP19 TASK4 COMPUTE: OK')

if __name__=='__main__':main()
