# CP19 TASK 4 — TURNOVER / PACKING DICHOTOMY

## Frozen negative fact

Task 9 already proved

\[
T_N\text{ or }Q_N\text{ large}
\not\Rightarrow
X_N\text{ large}.
\]

Task 4 does not reopen that failed carry mechanism.

## New structural split

The weighted packing theorem shows that, for a positive injective orbit with
near-linear state ceiling

\[
H_N=N^{1+o(1)},
\]

high factor complexity alone is not an escape.

Let

\[
\ell_N=\left\lfloor\frac12\log_2N\right\rfloor.
\]

For any fixed `mu<2`, it is impossible that every length-`ell_N` window obey

\[
A(v,\ell_N)\le(\mu+o(1))\ell_N.
\]

Hence a surviving near-linear-state orbit must exhibit logarithmic windows
with mean valuation arbitrarily close to `2` from below (or above).

## Discrepancy-excursion formulation

Choose the fixed value

\[
\mu_0=\frac{\alpha+2}{2}<2.
\]

A surviving near-linear-state orbit must have infinitely many logarithmic
windows with

\[
A(v,\ell)>\mu_0\ell.
\]

Since

\[
A(v,\ell)
=F_{v+\ell}-F_v-[s_{v+\ell}-s_v]
\le \alpha\ell+1-[s_{v+\ell}-s_v],
\]

such a window forces

\[
\boxed{
s_{v+\ell}-s_v
<-rac{2-\alpha}{2}\ell+1.
}
\]

Thus the real escape variable is not turnover or factor complexity by itself:
it is a **linear downward discrepancy excursion on logarithmic scales**, or
else a state ceiling with exponent sufficiently above one.

## What remains open

General Task-5 compatibility does not supply a near-linear upper state
ceiling, nor does it forbid these negative discrepancy excursions.

Therefore the new theorem is not Side B.

The surviving regimes are:

1. state growth exponent above the entropy-packing threshold;
2. repeated logarithmic windows with large negative `s` drops / total
   valuation approaching or exceeding mean `2`;
3. combinations of the two.

These are the correct targets after Task 4.
