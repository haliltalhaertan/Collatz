#!/usr/bin/env python3
from __future__ import annotations
import math,subprocess,sys
from math import comb
from fractions import Fraction

# Exact finite composition identities and numerical rate sanity.
def composition_checks():
    for ell in range(1,20):
        for U in range(ell,ell+30):
            P=sum(comb(A-1,ell-1) for A in range(ell,U+1))
            assert P==comb(U,ell)
            Z=sum((Fraction(comb(A-1,ell-1),1<<A) for A in range(ell,U+1)),Fraction(0,1))
            assert 0<Z<=1
    alpha=math.log2(3)
    p=1/alpha
    H2=-p*math.log2(p)-(1-p)*math.log2(1-p)
    h=alpha*H2;eta=alpha-h
    assert 1<alpha<2 and h<alpha and eta>0 and h/2<1
    return alpha,h,eta

def run(script,*args):
    cp=subprocess.run([sys.executable,script,*map(str,args)],capture_output=True,text=True,check=True)
    return cp.stdout.strip()

def main():
    a,h,e=composition_checks()
    print(run('/mnt/data/CP19_TASK4_PACKING_CHECK.py'))
    print(run('/mnt/data/CP19_TASK4_COMPLEXITY_SCAN.py','--N',65536))
    print('alpha=',a,'h=',h,'eta=',e)
    print('CP19 TASK4 MAJOR PROOF CHECK: OK')

if __name__=='__main__':main()
