# CP19 TASK 4 — HIGH-TURNOVER CONSTRUCTION-B EXCLUSION

## Candidate theorem

The frozen CP18 Task-9 high-turnover Construction B cannot be realized by
one fixed positive ordinary integer for all time.

\[
\boxed{x_B\notin\mathbb Z_{>0}.}
\]

## Proof dependencies

1. Frozen Task-9 facts:
   `|s^H-s^L|<=1`, `X_N^H<=2X_N^L`,
   `s_k^L=log_2 k+log_2 log_2 k+O(1)` and
   `X_N^L=O(log log N)`.
2. Exact finite valuation-cylinder theorem modulo `2^{A+1}`.
3. New exact weighted packing inequality.
4. Exact composition count `sum_{A=ell}^U C(A-1,ell-1)=C(U,ell)`.
5. Strict composition/cylinder entropy gap for every mean `mu<2`.

## Key two bounds

For every Construction-B length-`ell` window,

\[
A(v,\ell)\le\lceil\alpha\ell\rceil+2.
\]

Under a fixed positive realization,

\[
H_N:=\max_{k<N}n_k=N^{1+o(1)}.
\]

Set `ell=floor((1/2)log_2 N)`. The exact packing upper bound on the number
of distinct window-start states is `o(N)`, while injectivity requires
`N-ell+1=N-o(N)` distinct states. Contradiction.

## Scope

This excludes one canonical high-turnover Task-5-compatible abstract branch
and a wider sub-2 / near-linear-state family. It does **not** exclude every
Task-5-compatible path and is not Side B.

## Status

`[MAJOR LOAD-BEARING THEOREM CANDIDATE — AUDIT REQUIRED]`
