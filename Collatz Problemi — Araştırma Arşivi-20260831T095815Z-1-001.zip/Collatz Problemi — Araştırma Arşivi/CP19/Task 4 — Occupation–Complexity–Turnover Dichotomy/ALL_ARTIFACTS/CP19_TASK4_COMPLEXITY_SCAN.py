#!/usr/bin/env python3
from __future__ import annotations
import math,csv,random,argparse
from pathlib import Path

LOW_P,LOW_Q=1686221,1063887
UP_P,UP_Q=301994,190537

def F(k):
    if k==0:return 0
    lo=k*LOW_P//LOW_Q; hi=k*UP_P//UP_Q
    if lo==hi:return lo
    if (k*UP_P)%UP_Q==0 and hi==lo+1:return lo
    return pow(3,k).bit_length()-1

def g(k):return F(k+1)-F(k)
def b(k):return g(k)-1

def first_phase_one(start):
    k=start
    while b(k)!=1:k+=1
    return k

def construction_a(N,buffer=12):
    S=set(); k=0
    while len(S)<buffer and k<N:
        if b(k)==1:S.add(k)
        k+=1
    prev=max(S) if S else -1
    m=1
    while True:
        r=((1<<m)+m)//(m+1)
        p=first_phase_one(max(r,prev+1))
        if p>=N:break
        S.add(p);prev=p;m+=1
    return S

def low_path(N):
    S=construction_a(N);d=[1 if k in S else 0 for k in range(N)]
    a=[g(k)-d[k] for k in range(N)];return a,d,S

def high_path(N):
    a,d,S=low_path(N)
    for j in range(0,N-1,2):
        if j in S or j+1 in S:continue
        if b(j)==1:d[j],d[j+1]=1,-1
        else:d[j],d[j+1]=-1,1
    a=[g(k)-d[k] for k in range(N)];return a,d,S

def factor_count(x,l):return len({tuple(x[i:i+l]) for i in range(len(x)-l+1)})

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--N',type=int,default=65536);args=ap.parse_args()
    a,d,S=high_path(args.N)
    for c in [0.5,1.0,1.5]:
        ell=max(2,int(c*math.log2(args.N)))
        P=factor_count(a,ell);Pd=factor_count(d,ell)
        K=len({k//2 for k in S})
        bound=2*(ell+3)+K*(ell+1)
        assert P<=bound
        Amax=max(sum(a[v:v+ell]) for v in range(args.N-ell+1))
        assert Amax<=math.ceil(math.log2(3)*ell)+2
        print(args.N,ell,P,Pd,bound,Amax)

if __name__=='__main__':main()
