# CP19 TASK 4 — MAJOR LOAD-BEARING THEOREM CANDIDATE

## Status

\[
\boxed{
\textbf{[MAJOR LOAD-BEARING THEOREM CANDIDATE — INDEPENDENT AUDIT REQUIRED]}
}
\]

Do not freeze or build Task 5 on this result until zero-trust audit passes.

## Theorem A — weighted valuation-cylinder packing

For any positive injective orbit segment, window length `ell`, state ceiling
`H`, and set `C` of distinct occurring valuation words,

\[
\boxed{
\#\text{window starts}
\le
\frac H2\sum_{W\in C}2^{-A(W)}+|C|.
}
\]

## Theorem B — sub-2 logarithmic-window obstruction

Suppose a positive injective infinite orbit has

\[
H_N=N^{1+o(1)}.
\]

Fix any `mu<2` with `mu>1` and set

\[
\ell_N=\left\lfloor\frac12\log_2N\right\rfloor.
\]

It is impossible that every length-`ell_N` valuation window in the first
`N` steps satisfies

\[
A(v,\ell_N)\le(\mu+o(1))\ell_N.
\]

The proof counts **all** positive valuation compositions of total at most
`mu ell`; no low-complexity assumption is needed.

## Theorem C — Task-9 Construction B exclusion

Frozen Construction B satisfies

\[
A(v,\ell)\le\lceil\alpha\ell\rceil+2
\]

for every window and, under a hypothetical fixed positive realization,

\[
H_N=N^{1+o(1)}.
\]

Since `alpha=log_2 3<2`, Theorem B applies and gives a contradiction.
Therefore

\[
\boxed{x_B\notin\mathbb Z_{>0}.}
\]

## Structural survivor necessity

For near-linear-state injective orbits, complexity itself cannot be the
escape. A survivor must produce logarithmic windows with total valuation
arbitrarily close to mean `2` from below or above. Taking

\[
\mu_0=(\alpha+2)/2
\]

forces windows with

\[
\boxed{
s_{v+\ell}-s_v<-(2-\alpha)\ell/2+1.}
\]

Thus the next unresolved regime is **large negative discrepancy excursions
and/or super-near-linear state growth**, not merely high turnover.

## Scope

This is not Side B. Task 5 does not currently rule out the surviving regimes
above.
