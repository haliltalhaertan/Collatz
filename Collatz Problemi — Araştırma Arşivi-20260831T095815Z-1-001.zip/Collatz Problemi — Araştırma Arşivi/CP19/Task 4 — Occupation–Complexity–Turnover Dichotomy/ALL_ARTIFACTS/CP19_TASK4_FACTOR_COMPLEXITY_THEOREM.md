# CP19 TASK 4 — FACTOR COMPLEXITY THEOREM / NECESSITY

## 1. Exact complexity necessity

From the general packing lemma, if every relevant length-`ell` factor has
`A(W)>=A_min` and all selected states are `<=H`, then

\[
\boxed{
P_a(I,\ell)
\ge
\frac{r-\ell+1}{H/2^{A_{\min}+1}+1}.
}
\]

Thus packing can be read either as a state lower bound or a factor-complexity
lower bound.

## 2. Bounded-discrepancy corollary

If the discrepancy range on the interval is `W`, then

\[
A_{\min}\ge\lfloor\alpha\ell\rfloor-W
\]

and

\[
H<2^W(2n_u+4r/3).
\]

These are exact. Substitution gives a quantitative complexity requirement.

## 3. Weighted-turnover conditional count

For a fixed critical binary factor `b` of length `ell`, a defect coordinate
must satisfy `d_i<=b_i`.

The exact generating functions for the weighted variation cost `|d_i|` are

\[
f_0(x)=1+x+x^2+\cdots=\frac1{1-x}
\]

at a `b=0` site, and

\[
f_1(x)=1+2x+x^2+x^3+\cdots
\]

at a `b=1` site.

If the factor has `q` phase-one sites, the number of defect vectors with
weighted turnover at most `V` is exactly the sum of coefficients through
`x^V` of

\[
\boxed{f_1(x)^qf_0(x)^{\ell-q}.}
\]

Multiplying by at most `ell+1` critical phase factors gives a safe factor
complexity upper bound for a class with a local `V` budget.

This does **not** imply that large global turnover means large complexity.

## 4. High turnover does not imply high factor complexity

Frozen Task-9 Construction B is an exact counterexample.
Outside protected sparse pairs, the valuation pair is a fixed local function
of the Sturmian phase word and absolute parity. A length-`ell` window avoiding
protected pairs is therefore determined by parity and an underlying Sturmian
factor of length at most `ell+2`, giving at most

\[
2(\ell+3)
\]

types.

If `K_N` protected pairs occur in the first `N` steps, at most
`K_N(ell+1)` window starts meet one of them. Hence

\[
\boxed{
P_a(N,\ell)
\le
2(\ell+3)+K_N(\ell+1).
}
\]

Because `K_N=O(log N)`,

\[
\boxed{P_a(N,\ell)=O(\ell\log N).}
\]

Yet Construction B has

\[
T_N=N-O(\log N).
\]

Therefore

\[
\boxed{
\text{high turnover}\not\Rightarrow\text{high symbolic complexity}.
}
\]

This kills Task-4 hypothesis H3.
