# CP19 TASK 4 — BANDED DEFECT TRANSFER DIAGNOSTICS

## Exact finite DP

For a fixed critical phase factor `b_0,...,b_{ell-1}` and defect path

\[
\sigma_{j+1}-\sigma_j=d_j,
\qquad d_j\le b_j,
\]

we enumerated paths with `sigma_0=0` and total range

\[
\max\sigma-\min\sigma\le W.
\]

The DP state is exactly

\[
(\sigma_j,\min_{i\le j}\sigma_i,\max_{i\le j}\sigma_i).
\]

A transition to `sigma'` is allowed iff

\[
\sigma'-\sigma\le b_j
\]

and the new range remains at most `W`. The resulting valuation is

\[
a_j=1+b_j-(\sigma'-\sigma)\ge1.
\]

For each path the cylinder weight is multiplied by `2^{-a_j}`.

`CP19_TASK4_BANDED_COUNTS.csv` gives exact integer path counts for all
`ell in {4,8,12,16,20}` and `W=0,...,8`; weighted sums are numerical
DP diagnostics. Exact union-of-valuation-word counts are additionally
recorded where feasible at the smallest lengths.

## Falsification result

The naive conjecture that raw band-limited path entropy is automatically
below `alpha` is not justified by small finite data. For larger `W`, the
phase-path count rate at `ell=20` can exceed `alpha`.

Therefore no theorem of the form

\[
\text{fixed band}\Rightarrow
\text{raw path count rate}<\alpha
\]

is promoted from this DP.

This subroute is `[OPEN / NON-LOAD-BEARING]`.

The successful Task-4 theorem instead uses **weighted composition mass**,
which remains exponentially small whenever total valuation is bounded by
`(mu+o(1))ell` with `mu<2`.
