#include <bits/stdc++.h>
using namespace std;
using u64=uint64_t; using u128=__uint128_t;

static inline u64 ipow(u64 a,int e){u64 r=1; while(e--){r*=a;} return r;}
static u64 modpow(u64 a,u64 e,u64 m){u64 r=1; while(e){if(e&1)r=(u128)r*a%m; a=(u128)a*a%m; e>>=1;}return r;}
static u64 invmod(u64 a,u64 m){ // m odd, phi not easy; extended gcd
    long long t=0,newt=1; long long r=(long long)m,newr=(long long)(a%m);
    while(newr){ long long q=r/newr; long long tt=t-q*newt; t=newt; newt=tt; long long rr=r-q*newr; r=newr; newr=rr; }
    if(t<0)t+=m; return (u64)t;
}

struct Runner{
 int t,L; u64 q,qpowt; unordered_set<u64> seen; long double sum=0; u64 words=0;
 vector<int> a;
 Runner(int tt,int LL):t(tt),L(LL){q=ipow(3,t+1); qpowt=ipow(3,t); a.resize(t); seen.reserve((size_t)1<<20);}
 void handle(int A){
   // B = sum 3^(t-1-j) 2^prefix
   u64 B=0; int pref=0; u64 p3=ipow(3,t-1);
   for(int j=0;j<t;j++){ B += p3 * (1ULL<<pref); pref += a[j]; if(j<t-1) p3/=3; }
   u64 inv2A=invmod(modpow(2,A,q),q);
   u64 base=(u128)(B%q)*inv2A%q;
   u64 add=(u128)qpowt*inv2A%q;
   for(int sig=1;sig<=2;sig++){
      u64 y=(base + (u128)add*sig)%q;
      if(seen.insert(y).second){
        u64 r=(y&1)?y:y+q;
        sum += (long double)qpowt / ((long double)(1ULL<<A)*(long double)r);
      }
   }
   words++;
 }
 void rec(int idx,int rem,int A){
   if(idx==t-1){ a[idx]=rem; handle(A); return; }
   int slots=t-idx-1;
   for(int v=1; v<=rem-slots; ++v){ a[idx]=v; rec(idx+1,rem-v,A); }
 }
 void run(){
   for(int A=t;A<=L;A++) rec(0,A,A);
 }
};
int main(int argc,char**argv){int t=atoi(argv[1]); long double c=strtold(argv[2],nullptr); int L=floor(c*t+1e-15L); Runner R(t,L); auto st=chrono::steady_clock::now(); R.run(); auto en=chrono::steady_clock::now(); cerr<<"words="<<R.words<<" seen="<<R.seen.size()<<" sec="<<chrono::duration<double>(en-st).count()<<"\n"; cout<<setprecision(18)<<"t="<<t<<" L="<<L<<" B="<<(double)R.sum<<" B/t="<<(double)(R.sum/t)<<"\n"; }
