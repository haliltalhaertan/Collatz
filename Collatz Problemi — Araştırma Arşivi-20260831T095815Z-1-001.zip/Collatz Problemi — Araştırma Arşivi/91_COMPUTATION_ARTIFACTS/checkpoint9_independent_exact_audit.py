#!/usr/bin/env python3
"""
Checkpoint 9 independent exact-arithmetic audit.

Tests:
  * exact valuation-word realizability
  * affine terminal formula
  * two terminal classes modulo 3^(t+1)
  * mu_t distributions
  * # {y : mu_t(y)=A} <= 2*C(A-1,t-1)
  * natural weighted residue-packing coefficients

No floating point is used in the arithmetic checks.
"""
from fractions import Fraction
from math import comb
from collections import Counter

def compositions_pos(A, t):
    if t == 1:
        yield (A,)
        return
    def rec(rem, parts):
        if len(parts) == t - 1:
            if rem >= 1:
                yield tuple(parts + [rem])
            return
        slots = t - len(parts) - 1
        for a in range(1, rem - slots + 1):
            yield from rec(rem - a, parts + [a])
    yield from rec(A, [])

def affine_B(word):
    t = len(word)
    pref = 0
    B = 0
    for j, a in enumerate(word):
        B += 3 ** (t - 1 - j) * 2 ** pref
        pref += a
    return B

def exact_start_residue_pow2(word):
    """
    Unique x mod 2^(A+1) for which the prescribed word is exact.
    Derived from 2^A*y = 3^t*x + B with y odd:
       3^t*x+B == 2^A (mod 2^(A+1)).
    """
    A = sum(word)
    t = len(word)
    mod = 2 ** (A + 1)
    return ((2 ** A - affine_B(word)) * pow(3 ** t, -1, mod)) % mod

def crt_with_mod3(r2, mod2, sigma):
    # x == r2 (mod mod2), x == sigma (mod 3), gcd(mod2,3)=1
    j = ((sigma - r2) * pow(mod2, -1, 3)) % 3
    return r2 + j * mod2

def v2(n):
    a = 0
    while n % 2 == 0:
        n //= 2
        a += 1
    return a

def simulate_exact(x, word):
    vals = []
    states = [x]
    for a in word:
        m = 3 * x + 1
        vals.append(v2(m))
        x = m // (2 ** a)
        states.append(x)
    return tuple(vals), states

def terminal_class(word, sigma):
    A = sum(word)
    t = len(word)
    B = affine_B(word)
    q = 3 ** (t + 1)
    return (pow(2, -A, q) * (B + 3 ** t * sigma)) % q

def exhaustive_word_test():
    # Chosen ranges comfortably cover all mu_t saturation levels below.
    Amax = {1: 6, 2: 9, 3: 12, 4: 14, 5: 16, 6: 18}
    count = 0
    for t in range(1, 7):
        q = 3 ** (t + 1)
        for A in range(t, Amax[t] + 1):
            for word in compositions_pos(A, t):
                count += 1
                r2 = exact_start_residue_pow2(word)
                mod2 = 2 ** (A + 1)
                ys = []
                for sigma in (1, 2):
                    x = crt_with_mod3(r2, mod2, sigma)
                    if x == 0:
                        x += 3 * mod2
                    vals, states = simulate_exact(x, word)
                    assert vals == word, ("valuation mismatch", t, word, sigma, x, vals)
                    assert all(s & 1 for s in states), ("non-odd state", t, word, sigma)
                    assert all(s % 3 for s in states), ("non-unit state", t, word, sigma)
                    y = states[-1] % q
                    yf = terminal_class(word, sigma)
                    assert y == yf, ("terminal formula mismatch", t, word, sigma, y, yf)
                    ys.append(y)
                assert ys[0] != ys[1], ("two terminal classes collide", t, word, ys)
    return count

def compute_mu(t, max_A=40):
    q = 3 ** (t + 1)
    target = 2 * 3 ** t  # unit classes mod 3^(t+1)
    mu = {}
    for A in range(t, max_A + 1):
        for word in compositions_pos(A, t):
            for sigma in (1, 2):
                y = terminal_class(word, sigma)
                mu.setdefault(y, A)
        if len(mu) == target:
            return mu, A
    raise RuntimeError(f"mu_t did not saturate for t={t}")

def main():
    word_count = exhaustive_word_test()
    print(f"Exact word tests passed: {word_count} valuation words, each with sigma=1,2.")
    print()
    print("t  classes  max_mu  mu-distribution  natural_weighted_coefficient")
    for t in range(1, 7):
        mu, max_mu = compute_mu(t)
        dist = Counter(mu.values())
        for A, cnt in dist.items():
            rhs = 2 * comb(A - 1, t - 1)
            assert cnt <= rhs, ("count bound failed", t, A, cnt, rhs)
        Q = 2 * 3 ** (t + 1)
        coeff = sum((Fraction(3 ** t, 2 ** m) for m in mu.values()), Fraction()) / Q
        print(t, len(mu), max_mu, sorted(dist.items()), f"{coeff} = {float(coeff):.12f}")

if __name__ == "__main__":
    main()
