#include <bits/stdc++.h>
using namespace std;
using u64=unsigned long long;
static inline u64 T(u64 n){return (n&1)?(3*n+1)/2:n/2;}

unsigned long long Fcount(int J,int m,int q){
  u64 N=1ULL<<m; unsigned long long ans=0;
  for(u64 x=0;x<N;x++){
    u64 y=x; int s=0;
    for(int k=0;k<J;k++){s += y&1; y=T(y);}
    if(s>=q) ans++;
  }
  return ans;
}
void Mstats(int m,int q){
  u64 N=1ULL<<m;
  unordered_map<u64,int> cnt; cnt.reserve(N/4);
  int mx=0;
  for(u64 x=0;x<N;x++){
    u64 y=x; int s=0;
    for(int k=0;k<m;k++){s += y&1; y=T(y);}
    if(s==q) mx=max(mx,++cnt[y]);
  }
  vector<u64> ep; map<int,long long> hist;
  for(auto &kv:cnt){hist[kv.second]++; if(kv.second==mx) ep.push_back(kv.first);}
  sort(ep.begin(),ep.end());
  cout<<"M "<<m<<" "<<q<<" "<<mx<<" "<<(1ULL<<(m-q))<<" endpoints";
  for(size_t i=0;i<min<size_t>(ep.size(),12);i++) cout<<" "<<ep[i];
  cout<<" | tail";
  int shown=0;
  for(auto it=hist.rbegin(); it!=hist.rend() && shown<6; ++it,++shown)
    cout<<" "<<it->first<<":"<<it->second;
  cout<<"\n";
}
int main(){
  vector<array<int,4>> rows={
    {10,16,10,11},{12,20,14,13},{14,23,16,15},
    {16,26,18,17},{18,29,20,19},{19,31,22,20}
  };
  for(auto a:rows){
    auto F=Fcount(a[1],a[2],a[3]);
    double ratio=(double)F/(double)(1ULL<<a[2]);
    double saving=log((double)(1ULL<<a[2])/(double)F)/a[0];
    cout<<setprecision(15)
        <<"F "<<a[0]<<" "<<a[1]<<" "<<a[2]<<" "<<a[3]
        <<" "<<F<<" "<<ratio<<" "<<saving<<"\n";
  }
  vector<pair<int,int>> ms={{10,6},{12,8},{14,9},{16,10},{18,11},{20,13},{22,14}};
  for(auto [m,q]:ms) Mstats(m,q);
}
