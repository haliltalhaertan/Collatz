#!/usr/bin/env python3
"""Independent exact checks for Checkpoint 10 local lemmas.

Tests t=1..4:
- minimum valuation mu_t(y) for every terminal unit class mod 3^(t+1)
- least odd representative r_y mod 2*3^(t+1)
- backward reconstruction through a minimum word
- positivity, oddness, mod-3 unit property, and exact v2 valuations
- affine identity and w_t(y)/r_y < 1/x_y
- pairwise distinct auxiliary starts x_y

All logical tests use Python integers exactly.
"""
from itertools import product


def comps(A, t):
    if t == 1:
        yield (A,)
        return
    def rec(rem, parts):
        if len(parts) == t - 1:
            if rem >= 1:
                yield tuple(parts + [rem])
            return
        slots = t - len(parts) - 1
        for a in range(1, rem - slots + 1):
            yield from rec(rem-a, parts+[a])
    yield from rec(A, [])


def affine_B(word):
    B = 0
    pref = 0
    t = len(word)
    for j, a in enumerate(word):
        B += 3**(t-1-j) * 2**pref
        pref += a
    return B


def terminal_class(word, sigma):
    t = len(word); A = sum(word); q = 3**(t+1)
    return (pow(2, -A, q) * (affine_B(word) + 3**t*sigma)) % q


def v2(n):
    a = 0
    while n % 2 == 0:
        n //= 2; a += 1
    return a


def find_min_words(t, maxA=40):
    target = 2*3**t
    best = {}
    for A in range(t, maxA+1):
        for word in comps(A, t):
            for sigma in (1,2):
                y = terminal_class(word, sigma)
                best.setdefault(y, (A, word, sigma))
        if len(best) == target:
            return best
    raise RuntimeError(f"not saturated t={t}")


def audit_t(t):
    q = 3**(t+1); Q = 2*q
    best = find_min_words(t)
    xs = []
    maxmu = 0
    for y, (A, word, sigma) in best.items():
        maxmu = max(maxmu, A)
        assert y % 3 != 0
        r = y if y % 2 else y + q
        assert 0 < r < Q and r % 2 == 1 and r % q == y
        # backward exact inversion
        cur = r
        revstates = [cur]
        for a in reversed(word):
            num = (2**a)*cur - 1
            assert num % 3 == 0, (t,y,word,"noninteger")
            prev = num // 3
            assert prev > 0 and prev % 2 == 1 and prev % 3 != 0
            assert v2(3*prev+1) == a
            assert (3*prev+1)//(2**a) == cur
            cur = prev
            revstates.append(cur)
        x = cur
        assert x % 3 == sigma
        B = affine_B(word)
        assert 2**A * r == 3**t * x + B
        # Cross-multiplied strict inequality w/r < 1/x:
        # (3^t / 2^A)/r < 1/x  iff 3^t*x < 2^A*r.
        assert 3**t * x < 2**A * r
        xs.append(x)
    assert len(xs) == len(set(xs))
    return len(best), maxmu, len(set(xs))


def main():
    for t in range(1,5):
        classes,maxmu,starts = audit_t(t)
        print(f"t={t}: classes={classes}, max_mu={maxmu}, distinct_aux_starts={starts}, PASS")

if __name__ == '__main__':
    main()
