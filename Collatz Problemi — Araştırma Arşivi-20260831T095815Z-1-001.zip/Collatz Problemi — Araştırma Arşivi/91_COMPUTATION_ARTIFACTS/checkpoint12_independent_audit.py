#!/usr/bin/env python3
# Checkpoint 12 independent adversarial audit: small exact checks + interval certificate.
from itertools import combinations
import math
import mpmath as mp

def T(n):
    return n//2 if n % 2 == 0 else (3*n+1)//2

def parity_encoding(x,J):
    q=0
    y=x
    for k in range(J):
        q |= (y & 1) << k
        y=T(y)
    return q

def q_recursion_check(Jmax=8):
    for J in range(1,Jmax+1):
        mod=1<<J
        vals=[parity_encoding(x,J) for x in range(mod)]
        assert sorted(vals)==list(range(mod))
        if J>=2:
            for u in range(1<<(J-1)):
                assert parity_encoding(2*u,J)==2*parity_encoding(u,J-1)
                rhs=1+2*parity_encoding((3*u+2)%(1<<(J-1)),J-1)
                assert parity_encoding(2*u+1,J)==rhs
    return True

def C_positions(pos,q):
    return sum(3**(q-1-r)*2**d for r,d in enumerate(pos))

def C_injective_check(mmax=10):
    for m in range(1,mmax+1):
        for q in range(m+1):
            seen={}
            for pos in combinations(range(m),q):
                C=C_positions(pos,q)
                if C in seen:
                    return False,(m,q,seen[C],pos,C)
                seen[C]=pos
                if q:
                    d=m-q
                    assert C <= 2**d*(3**q-2**q)
    return True,None

def fixed_endpoint_cap_check(mmax=14):
    rows=[]
    for m in range(1,mmax+1):
        for q in range(m+1):
            counts={}
            for x in range(1<<m):
                y=x; ones=0
                for _ in range(m):
                    ones += y&1
                    y=T(y)
                if ones==q:
                    counts[y]=counts.get(y,0)+1
            mx=max(counts.values(), default=0)
            assert mx <= 2**(m-q)
        # critical-ish q
        q=round(m/math.log(3,2))
        counts={}
        for x in range(1<<m):
            y=x; ones=0
            for _ in range(m):
                ones += y&1
                y=T(y)
            if ones==q:
                counts[y]=counts.get(y,0)+1
        rows.append((m,q,max(counts.values(),default=0),2**(m-q)))
    return rows

def fundamental_rectangle_check(mmax=14):
    for m in range(1,mmax+1):
        for x in range(1<<m):
            y=x; q=0
            for _ in range(m):
                q += y&1
                y=T(y)
            assert y < 3**q
    return True

# Directed interval arithmetic certificate for beta0.
iv=mp.iv
alpha_iv=iv.log(3)/iv.log(2)
beta0_str="1.12338126"
b=iv.mpf([beta0_str,beta0_str])
R=alpha_iv-b
z=alpha_iv-1-b/2
u=1-b/2
# In the relevant full-period / upper-tail branch:
# f(beta)=B(alpha,beta,beta/2)-beta ln 2
f=((b-alpha_iv+(alpha_iv-1)*b/2)*iv.log(2)
   + R*iv.log(R)-z*iv.log(z)-u*iv.log(u))
# f'(beta)=1/2 log(6 z u / R^2); g=R^2-6zu>0 => f'<0.
g=R**2-6*z*u

h=alpha_iv*iv.log(alpha_iv)-(alpha_iv-1)*iv.log(alpha_iv-1)
I=alpha_iv*iv.log(2)-h
K=b*iv.log(2)/(3*I)

print("Q recursion/permutation J<=8:", q_recursion_check())
print("C_w injectivity m<=10:", C_injective_check())
print("fundamental rectangle m<=14:", fundamental_rectangle_check())
print("fixed endpoint critical-ish rows m<=14:")
for row in fixed_endpoint_cap_check():
    print(row)
print()
print("INTERVAL CERTIFICATE")
print("alpha =", alpha_iv)
print("beta0 =", beta0_str)
print("f(beta0) =", f)
print("g(beta0) =", g)
print("K(beta0) =", K)
print("Certified consequences:")
print("  f(beta0)<0 and g(beta0)>0.")
print("  Since g'(beta)=alpha-beta>0 for beta<alpha, f is decreasing on [beta0, 2(alpha-1)].")
print("  Hence the entire beta-band (beta0, 2(alpha-1)) has strict two-block rate saving at c=alpha.")
print("  Joint continuity then preserves a fixed positive-width subband for c>alpha sufficiently close to alpha.")
print("  Therefore K12 <= beta0*ln(2)/(3 I(alpha)) < 4.720966.")
