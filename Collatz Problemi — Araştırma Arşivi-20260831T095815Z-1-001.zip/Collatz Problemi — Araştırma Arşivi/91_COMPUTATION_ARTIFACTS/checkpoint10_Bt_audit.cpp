#include <bits/stdc++.h>
using namespace std;
using u64=uint64_t; using u128=__uint128_t;

struct Runner {
    int t,L;
    u64 q, qbase, three_t;
    vector<u64> pow2, invpow2;
    unordered_set<u64> seen;
    long double Bsum=0;
    vector<size_t> newByA;

    static u64 modmul(u64 a,u64 b,u64 m){return (u128)a*b % m;}
    static u64 modpow(u64 a,u64 e,u64 m){u64 r=1;while(e){if(e&1)r=modmul(r,a,m);a=modmul(a,a,m);e>>=1;}return r;}

    Runner(int tt):t(tt){
        L=(int)floor(1.6L*t + 1e-15L);
        q=1; for(int i=0;i<t+1;i++) q*=3;
        three_t=q/3;
        pow2.resize(L+1); invpow2.resize(L+1);
        pow2[0]=1%q;
        u64 inv2=(q+1)/2;
        invpow2[0]=1%q;
        for(int i=1;i<=L;i++){pow2[i]=modmul(pow2[i-1],2,q);invpow2[i]=modmul(invpow2[i-1],inv2,q);}        
        newByA.assign(L+1,0);
        size_t est=0;
        // rough reserve <= 2*C(L,t)
        long double c=1; for(int i=1;i<=t;i++) c=c*(L-t+i)/i;
        est=(size_t)min<long double>(2*c, 100000000.0L);
        seen.reserve((size_t)(est/0.7)+10);
        seen.max_load_factor(0.72f);
    }

    void emit(u64 Bmod,int A){
        u64 inv=invpow2[A];
        for(int sig=1;sig<=2;sig++){
            u64 tmp=(Bmod + (u128)three_t*sig)%q;
            u64 y=modmul(inv,tmp,q);
            if(y%3==0){cerr<<"bad y\n"; abort();}
            auto [it,ins]=seen.insert(y);
            if(ins){
                newByA[A]++;
                u64 r=(y&1)?y:y+q;
                long double w=pow((long double)3.0,t)/ldexpl(1.0L,A);
                Bsum += w/(long double)r;
            }
        }
    }

    void rec(int pos,int rem,int prefix,u64 Bmod,int A){
        if(pos==t){ if(rem==0) emit(Bmod,A); return; }
        int slots=t-pos;
        // each remaining a >=1
        for(int a=1;a<=rem-(slots-1);a++){
            u64 Bnew=(modmul(3,Bmod,q)+pow2[prefix])%q;
            rec(pos+1,rem-a,prefix+a,Bnew,A);
        }
    }

    void run(){
        for(int A=t;A<=L;A++) rec(0,A,0,0,A);
        cout<<setprecision(15);
        cout<<"t="<<t<<" L="<<L<<" distinct="<<seen.size()<<" B="<<(double)Bsum<<" B/t="<<(double)(Bsum/t)<<"\n";
        cout<<"newByA:"; for(int A=t;A<=L;A++) if(newByA[A]) cout<<" "<<A<<":"<<newByA[A]; cout<<"\n";
    }
};
int main(int argc,char**argv){for(int i=1;i<argc;i++){int t=stoi(argv[i]);Runner r(t);r.run();}}
