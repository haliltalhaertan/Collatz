from math import comb, floor
from collections import defaultdict
import mpmath as mp


def comps(A,t,p=()):
    if t==1:
        yield p+(A,); return
    for a in range(1,A-t+2):
        yield from comps(A-a,t-1,p+(a,))

def B_word(w):
    t=len(w); pref=0; B=0
    for j,a in enumerate(w):
        B += 3**(t-1-j)*2**pref
        pref += a
    return B

def term_class(w,sig):
    t=len(w); A=sum(w); q=3**(t+1)
    return (pow(2,-A,q)*(B_word(w)+3**t*sig))%q

def least_odd(y,t):
    q=3**(t+1)
    return y if y&1 else y+q

def aux(w,y):
    t=len(w); A=sum(w); r=least_odd(y,t)
    return (2**A*r-B_word(w))//3**t

def v2(n):
    a=0
    while n%2==0: a+=1; n//=2
    return a

def syr_vals(x,t):
    out=[]
    for _ in range(t):
        m=3*x+1; a=v2(m); out.append(a); x=m//2**a
    return tuple(out),x

def canonical(t,L):
    d={}
    for A in range(t,L+1):
        for w in comps(A,t):
            for sig in (1,2):
                y=term_class(w,sig); x=aux(w,y)
                if y not in d or A<d[y][0] or (A==d[y][0] and x<d[y][1]):
                    d[y]=(A,x,w)
    return d

# Tie audit
print('Tie y=65 mod 81')
for w in [(1,3,3),(2,4,1)]:
    for sig in (1,2):
        if term_class(w,sig)==65:
            x=aux(w,65); vals,end=syr_vals(x,3)
            print(w, 'sigma',sig,'x',x,'vals',vals,'terminal',end)
for A in range(3,7):
    assert all(term_class(w,s)!=65 for w in comps(A,3) for s in (1,2))
print('mu_3(65)=7 verified')

# Exhaustive parity-prefix inequality for t<=6, all t<=L<2t and J<=L+1
fails=[]; equal=[]
for t in range(1,7):
    for L in range(t,2*t):
        d=canonical(t,L); D=L-t
        for J in range(1,L+2):
            actual=sum(x<=2**J-1 for mu,x,w in d.values())
            bound=sum(comb(J-1,z) for z in range(0,min(D,J-1)+1))
            if actual>bound: fails.append((t,L,J,actual,bound))
            if actual==bound and bound: equal.append((t,L,J,actual))
print('parity-prefix failures:',fails)
print('equality examples:',equal[:10])

# x=31 persistence
x=31; A=0
print('x=31 exit window')
for t in range(1,39):
    m=3*x+1; a=v2(m); x=m//2**a; A+=a
    if t>=31: print(t,A,A/t)

# constants
mp.mp.dps=60
alpha=mp.log(3)/mp.log(2)
h=lambda c:c*mp.log(c)-(c-1)*mp.log(c-1)
I=lambda c:c*mp.log(2)-h(c)
K=2*(alpha-1)*mp.log(2)/(3*I(alpha))
p=K/3
b=2*(alpha-1)*mp.log(2)/3
req=3*I(alpha)
print('alpha=',alpha)
print('K11=',K)
print('p11=',p)
print('b11(alpha)=',b)
print('3I(alpha)=',req)
print('required saving=',1-req/b)
