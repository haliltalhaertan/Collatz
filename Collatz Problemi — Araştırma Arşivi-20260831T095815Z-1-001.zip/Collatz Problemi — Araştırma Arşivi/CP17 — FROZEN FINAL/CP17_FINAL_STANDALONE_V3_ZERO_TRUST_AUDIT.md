# CP17 FINAL STANDALONE V3 — ZERO-TRUST ADVERSARIAL AUDIT

Date: 2026-08-23   Package: `CP17_FINAL_PACKAGE_V3.zip` (18 files, 18/18 SHA256 OK)
Primary object: `CP17_FINAL_STANDALONE_PROOF_V3.md` (2865 lines)
Prior pass: `CP17_FINAL_V2_AUDIT_2026-08-23.md` (verdict: VALID AFTER MINOR REPAIRS, 2 items + 1 note)

## 0. Basis of verification, stated up front

* `SHA256SUMS.txt` verifies 18/18.
* `CP17_FINAL_RATE_CERTIFICATE_V3.py` differs from the audited V2 certificate by
  **one character in the docstring** (`V2` → `V3`). It reruns **byte-identical** to the
  shipped `..._OUTPUT.txt`, which is itself byte-identical to the V2 output.
  Arithmetic re-inspected: `fractions.Fraction` for chi, artanh series with an explicit
  rational remainder `2 z^(2N+3)/((2N+3)(1-z^2))` for logs, interval multiplication by
  min/max over the four corner products, and every final `assert` a rational comparison.
  No decimal is used for any proof-critical sign decision.
* Diff of the standalone proof V2 → V3: **8 lines removed, 142 added, at exactly three loci** —
  line 422 (§5.3), lines 729–830 (§10 alignment), lines 1023–1033 (§10 compactness).
  Everything else, including §§1–4, §§6–9, §11, §12 and Appendices A/B/C, is
  **byte-identical to V2**, which was byte-identical to V1 outside §10.
* Consequently the parts of this audit that are carried forward — Appendix A's Lemma 4.1
  and the `O(log^2 t)` composition error, §6's Stieltjes ledger, Appendix C's energy proof
  internals — rest on from-scratch verification done in the earlier passes on *the same bytes*,
  not on any label in the package. Everything V3 changed, plus every numerical claim, was
  re-derived fresh in this pass with newly written code.

## 1. The three V3 patches, checked line by line

### (i) §5.3, support bound (5.S) — `xi_t(y) < 6·2^L`
Now derived inline from objects displayed in the same file:
`2^mu r_y = 3^t xi_t(y) + B_y` (Appendix B (7.1)), `B_y > 0`, `r_y <= Q_t = 2·3^{t+1}` (§3),
`mu <= L` (the summation range). Then `3^t xi < 2^mu r_y <= 2^L Q_t`, so
`xi < 2^L · 2 · 3^{t+1} / 3^t = 6·2^L`. **Correct, and every input is in-file.**

### (ii) §10, reverse-gap alignment (10.RG)/(10.RG2)
This is exactly the repair named in the V2 report, written out in full. Verified:

* `S_j := m - i_{s+1-j}`, `S_0 := 0`.
* `S_1 = m - i_s >= 1` because `i_s <= m-1`.
* `S_{j+1} = m - i_{s-j} > m - i_{s+1-j} = S_j` because `i_{s-j} < i_{s+1-j}`.
* `S_s = m - i_1 <= m`.
* Substitution `j = s+1-k` gives `i_k - m = -S_j` and `s-k = j-1`, hence
  `2^{-m} C = Σ_k 3^{s-k} 2^{i_k-m} = Σ_j 3^{j-1} 2^{-S_j}`  — **(10.RG)**.
* `A_j := S_j - S_{j-1} ∈ Z_{>0}`, partial sums are the `S_j`, tuple weight
  `Π 2^{-A_j} = 2^{-S_s} >= 2^{-m}`.
* Summing over the distinct reverse-gap tuples of the `M(y)` words gives
  `M(y) 2^{-m} <= p_s^Syr(y)`  — **(10.RG2)**.

The file now also states explicitly that the alignment is `y ≡ 2^{-m} C (mod 3^s)` and
**not** `C (mod 3^s)`. That distinction matters: the unaligned version is genuinely false.

Independent verification (fresh code):

| Check | Result |
|---|---|
| (10.RG) as an **exact rational identity** (not merely a congruence), m<=15, s<=7 | 39186 words, **0 failures** |
| `S_1>=1`, strictly increasing, `S_s = m-i_1 <= m`, `A_j>0`, `Σ A_j = S_s` | **0 violations** |
| (10.RG2) `M(y) <= 2^m p_s^Syr(y)` against an independently computed exact Syracuse law, s<=4, m<=14 | 640 (s,m,y) pairs, **0 violations**, worst ratio 0.75 (never tight) |
| endpoint residue equals aligned `2^{-m}C` **and** endpoint lies in `[0,3^s)`, m<=12 | 8178 words, **0 failures** |

### (iii) §10, explicit global-x compactness
The one-sentence version is replaced by the two-region construction:
`B_beta(x_0) < beta·log2` at `x_0 = beta/2` plus continuity gives `U` and `delta_1`;
`A_beta` has its **unique** maximum `beta·log2` at `beta/2`, so on the compact complement
`K \ U` continuity gives `delta_2`; on `U` the envelope is `<= B_beta`, on `K \ U` every slice
is bounded by `A_beta` (empty-success slices are zero); hence
`R_17 <= beta·log2 - min(delta_1, delta_2)` uniformly. **Correct.**
The closing sentence is also sharpened to "the argument does not locate the maximizer at all."

This is the right *form* of the argument, and it is the form that is needed: `min{A,B}` is
**not** continuous across the branch boundary (it jumps down where the success set becomes
nonempty), so a bare "min of continuous functions on a compact set" claim would have been
wrong. The two-region split sidesteps that entirely — it never needs the min to be continuous.

Numerical confirmation that the construction is sound (c = alpha):

```
beta          gap at x0     largest valid radius h for U
0.652685652   1.55e-12      3.81e-06
0.653684652   1.55e-06      3.91e-03
0.660000000   8.22e-05      3.12e-02
0.700000000   3.25e-03      1.25e-01
1.169925001   1.44e-01      1.25e-01
```

and separately `B_beta(x) <= beta·log2` **everywhere** (max excursion 1.1e-16 = float noise),
so `U` can never be spoiled by `B` rising above the target — only by saturated equality.

Note the radius shrinks as `beta ↓ beta_0`. That is not a defect: `beta_0` is exactly sharp,
and the proof only ever works on `[beta_0+eps, beta_*-eps]` with `eps` fixed, where the radius
is bounded below. The proof asserts *existence* of `U`, never a fixed radius. Correct as written.

## 2. Everything else re-checked in this pass

| Check | Result |
|---|---|
| Lemma 10.1 `T^m(x) <= 3^s-1`, exhaustive, m<=18 | 524286 starts, **0 violations**, 1651 tight |
| Full invariant `z_i <= 3^{q_i}2^{m-i}-1` at every i, m<=14 | **0 violations** |
| Lemma 5.1 parity-prefix bijection, J<=14 | **0 failures** |
| Prefix-cylinder (8.1)/(8.2) on `I=[0,3^s)`, endpoints `j=0`, `j=R` included | 728 cases, **0 violations** |
| `A_t(x) <= L ⟺ >= t+1 ones in first L+1 bits` | 264000 triples, **0 mismatches** |
| `F(L+1,m,t+1) = Σ_s W_s` exact partition | 280 configs, **0 failures** |
| Appendix A (2.1)(2.2)(2.4)(2.5)(2.7), exact rationals, 7 real orbits × N × t | 105 configs, **0 failures** |
| `gcd(n_k,6)=1` for k>=1 from `3|n_0` starts | **0 violations** |
| **Appendix B objects on observed orbits (new this pass):** `xi_t(y)` a unit mod 6; `xi` **distinct across terminal classes** (this is what the 1/3 packing needs); domination `3^t xi < 2^mu r` | t=3,5,7,9; up to 21222 classes; **0 non-units, 0 duplicates, 0 domination violations** |
| chi_1, chi_2 by independent brute force with rigorous tails | contain 5/3 and 15/7 |
| K17, K11, I(alpha), beta0 (mpmath, independent formulas) | 2.742881438765941863306095 / 4.91656355094999688084663 — all displayed digits match |
| Saving threshold bisection | 0.6526854548 vs `beta_0` = 0.6526846522 (grid-limited); gap at `beta_0` is 5.7e-42 = exactly zero ⇒ `beta_0` sharp, band open there |
| Persistence for fixed `c > alpha`, eps=0.02 | OK at `alpha+0.005`, `+0.01`; **FAILS at `+0.02`**, exactly as `c-alpha < eps(alpha+2)/4 = 0.0179` predicts |

Adversarial sweep clean: no circularity, no converse swap, no quantifier swap (§11 still
explicitly refuses any `limsup_{c↓alpha} b(c)` and asserts no continuity of `b(c)`), no
pointwise-to-uniform error, correct domain/modulus (`Q_t = 2·3^{t+1}`, units mod 6), no
off-by-one, ceiling/floor losses `O(log t)`, uniform two-sided binomial bound (no endpoint
Stirling blow-up), slice count `m+1 = O(t)` with `(t+1)^d` union bound, Hoeffding threshold
correct, no hidden exponential in `chi_s`, Cauchy–Schwarz square root present, normalization
consistent, conclusion is additive-slack only. **No counterexample exists to the
endpoint-rectangle invariant** (exhaustive to m=18); CP12 itself flags the real-`lambda`
version as false and V3 uses only `lambda = 1`.

## 3. Provenance cross-check (Phase 4)

Unchanged from the V2 pass and re-confirmed: CP11 §6 count, CP13 prefix geometry, CP12 §3
rectangle, `CP17_RATE_TO_K_LT_3_REPAIRED.md` §0 chain, Appendix C == provenance verbatim.
No mathematical difference; only citation rewiring. §8 remains strictly stronger than CP12 (4)
(`ceil(3^s/2^j)` vs `floor(3^s/2^R)+1`, plus the binomial-tail factor CP13's extract omitted).

## 4. Verdict table

| Node | Verdict | First failure / reason |
|---|---|---|
| carry/harmonic identity + lower coefficient 3 | `[VALID]` | — |
| reachable-terminal lemma | `[VALID]` | Appendix B; unit property, cross-class distinctness and domination all re-confirmed on observed orbits this pass |
| growing-depth master inequality | `[VALID]` | Appendix A; (2.7) exact rational identity on real orbits; n0 and N+t repairs present and effective |
| parity-prefix theorem and theta_max tail | `[VALID]` | bijection verified; Hoeffding threshold correct; support bound now derived inline as (5.S) |
| arithmetic 1/3 + Stieltjes ledger | `[VALID]` | — |
| Syracuse polynomial collision energy | `[VALID]` | Appendix C verbatim; chi_1, chi_2 independently reproduced |
| prefix-cylinder theorem | `[VALID]` | brute-forced incl. `j=0`, `j=R` |
| endpoint rectangle + value/residue bridge | `[VALID]` | exhaustive to m=18; bridge exact |
| canonical-start → two-block slice chain | `[VALID]` | `F = Σ_s W_s` exact partition |
| uniform o(t) bookkeeping | `[VALID]` | Lemma 9.1 |
| **reverse-gap alignment** | `[VALID]` | **new in V3**; (10.RG) verified as an exact rational identity, (10.RG2) verified against an independent exact Syracuse law |
| global-x strictness | `[VALID]` | **repaired in V3**; explicit `delta_1`/`delta_2` two-region construction, which is the form actually required |
| strict saving band | `[VALID]` | `(beta_0, beta_*]`; `beta_0` sharp |
| c→alpha quantifier order | `[VALID]` | §11; `rho_eps` genuinely eps-dependent, confirmed numerically |
| K11 regression | `[VALID]` | 4.916563550949996880846… |
| K17 certificate | `[VALID]` | 2.742881438765941863306…; `K17 < 2.742882 < 3` by rational comparison only |
| final additive-slack theorem | `[VALID]` | — |
| standalone completeness | `[VALID]` | no load-bearing step is left to an external checkpoint |

## OVERALL VERDICT: `PROOF VALID`

No `[GAP]`, no `[BUG]`, no `[FALSE]`, no `[COUNTEREXAMPLE]`, no `[UNVERIFIED]`.

## Final question

**Is there any load-bearing mathematical step that is not proved inside
`CP17_FINAL_STANDALONE_PROOF_V3.md` or one of its reproduced appendices?**

**No.** The single item named in the V2 report — the reverse-gap alignment behind
`M(y) <= 2^m p_s^Syr(y)` — is now displayed in full as (10.RG)/(10.RG2), and the two
sub-threshold notes (the compactness split, and `xi_t(y) < 6·2^L`) are both written out
as well. Every load-bearing lemma is now proved in the main text or in Appendix A/B/C.

### Two observations that are *not* repairs

1. **Package/prompt mismatch:** `CP17_FINAL_AUDIT_PROMPT_V3.md` Phase 3 tells the auditor to
   run `CP17_FINAL_RATE_CERTIFICATE_V2.py`, but the ZIP ships `CP17_FINAL_RATE_CERTIFICATE_V3.py`.
   The two files are identical except for the version string in the docstring, and the outputs
   are byte-identical, so nothing mathematical turns on it — but the prompt should name the
   shipped filename.
2. **`beta = beta_*` edge in the `U` argument:** at the top endpoint `beta = beta_*` one has
   `d(beta/2) = 0` exactly, so `x_0` sits on the boundary of the nonempty-success branch and
   `U` may contain empty-success points. Those slices have count zero and are already
   discarded by the global sentence earlier in §10, and the load-bearing chain only ever uses
   `[beta_0+eps, beta_*-eps]`, so this is genuinely inert. Mentioned only for completeness.

### Scope, restated

The theorem is `limsup H_N/loglog N <= K_17 < 3` on the stated positive injective odd-only
Syracuse-orbit domain, hence `limsup_k (s_k - log_2 k) = +infinity`. It does **not** claim
`limsup s_k / log_2 k > 1`, does not exclude general divergence or nontrivial cycles, and is
not a proof of the Collatz conjecture. Every document in the package states this correctly.